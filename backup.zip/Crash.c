#include "ldefns.h"
#if	defined(__HAVE_USHORT__)
#	define ushort Ushort
#	define ulong Ulong
#	include <sys/types.h>
#	undef ushort
#endif
#include <signal.h>

void Crash(const char *fmt, ...)
{
	int	no_force = fmt[0]=='!';
	VA_START(fmt);
	_lm_werr( fmt+no_force, IVA_LIST(fmt) );
	lm_fflushall();
	if(!no_force) *((char *)NULL) = 1;
	exit(1);
}
