#if defined(__SYSNT__)
#include <io.h>
#endif
#include<fcntl.h>

/*I did this because LINUX couldn't get open,read etc. from c++ */
/*11-11-2010 I now realise all I need to do is use unistd.h on LINUX */

#if defined(__SYSNT__)
int my_read(int i,void* backstuff,unsigned int j)
{
	return read(i,backstuff,j);
}
int my_write(int i,void* backstuff,unsigned int j)
{
	return write(i,backstuff,j);
}

int my_creat(const char* filename,int mode)
{
	return creat(filename,mode);
}

int my_open(const char* filename,int mode)
{
	return open(filename,mode);
}

int my_close(int fileno)
{
	return close(fileno);
}
#endif

#ifdef _WINDOWS
int my_setmode(int fileno,int mode)
{
	return setmode(fileno,mode);
}
#endif

