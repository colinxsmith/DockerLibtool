$found = 0;

while(<STDIN>)
{
	if( /SWIGPERL5/ )
	{
		$found = 1;
	}
	elsif($found  && /math.h/)
	{
		print "\t\t/* ________________________________________________*/\n";
		print "\t\t/* We need to do this sort of thing only on Windows*/\n";
		print "#include <iostream>\n";
		print "#include <sstream>\n";
		print "#include <fstream>\n";
		print "#include <valarray>\n";
		print "\t\t/* ________________________________________________*/\n";
	}
	print;
}
