#!/usr/bin/env python
#Robust long/short optimisations
from Opt import *
def var(x,Q):
    n=len(x)
    y=[]
    Sym_mult(n,Q,x,y)
    return dot(x,y)
def risk(x,Q):
    return pow(var(x,Q),.5)

n=3
m=1
w=[0]*n
A=[1,1,1]
Q=[1,.02,3,.04,.05,6]
alpha=[.02,.01,.03]
dalpha=[1e-4,3e-4,2e-4]
full=0
rmin=.8
rmax=1.1
L=[-1,-1,-1,0]
U=[1,1,1,0]
val=0
TopRisk=2.6
MaxDalpha=0.00032
nabs=0
Aabs=[]
Uabs=[]
SOCPlstest(n,m,w,A,Q,alpha,full,rmin,rmax,L,U,val,TopRisk,dalpha,MaxDalpha,nabs,Aabs,Uabs)
error=pow(sum([w[i]*w[i]*dalpha[i]*dalpha[i] for i in range(n)]),.5)
print w,sum(w),dot(alpha,w),risk(w,Q),error
(l,s,g)=longshortgross(w)
print l,s,-s/l,g
for i in range(n):
    if w[i]>0:L[i]=0
    else:U[i]=0

print L
print U
SOCPlstest(n,m,w,A,Q,alpha,full,rmin,rmax,L,U,val,TopRisk,dalpha,MaxDalpha,nabs,Aabs,Uabs)
error=pow(sum([w[i]*w[i]*dalpha[i]*dalpha[i] for i in range(n)]),.5)
print w,sum(w),dot(alpha,w),risk(w,Q),error
(l,s,g)=longshortgross(w)
print l,s,-s/l,g


#inverse check
RQ=[0]*(n*n)
RQm1=[0]*(n*n)
RootQ(n,Q,RQ,RQm1)

for i in range(n):
    out=''
    for j in range(n):
        out+=str(dot(RQ[i*n:(i+1)*n],RQm1[j*n:(j+1)*n]))+' '
    print out
    