/*
	dxminmax returns the values xmax and xmin given by
	xmax = max( abs( x( i ) ) ),   xmin = min( abs( x( i ) ) ).
		i				i

	where i=0, incx,  ..., (n-1)*incx

	If n is less than unity then xmax and xmin are returned as zero.

	R. G. Becker for DAS 1990
*/
#include "ldefns.h"

void dxminmax(dimen n, vector x, stride incx, real *xmax, real *xmin)
{
	if(n<1) *xmin = *xmax = 0;
	else	{
		real	ax = fabs(*x);
		real	xm=ax, xn=ax;
		while(--n){
			x += incx;
			ax = *x;
			if(ax<0) ax = -ax;
			if(ax>xm) xm = ax;
			if(ax<xn) xn = ax;
			}
		*xmin = xn;
		*xmax = xm;
		}
}
