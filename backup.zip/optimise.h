#ifndef _OPTCLSS_H
#define _OPTCLSS_H

#include "baseoptimise.h"
#include<vector>
#include<fstream>
#include<cfloat>
#include<cerrno>
#ifndef NOCLASS
class KeepBest
{
public:
	KeepBest(size_t n,short back=-1,size_t nround=0,double util=lm_max,size_t stage=0);
	~KeepBest();
	void Message();
	void Setw(vector w,short back,size_t nround,double utility,size_t stage);
	vector w;
	vector oldw;
	vector first;
	double utility;
	short back;
	size_t nround;
	size_t n;
	size_t stage;
	size_t stuck;
	std::stringstream *printstream;
};

template<typename T> class objectorder
{
public:
	T val;
	size_t pos;
	unsigned char dropbad;
};
typedef bool (*FF)(const objectorder<double> & x, const objectorder<double> & y);

class piececostpasser
{
public:
	size_t npiece;
	size_t nstocks;
	vector hpiece;
	vector pgrad;
	vector initial;
	double ShortCostScale;
};
class linearcostpasser
{
public:
	size_t nstocks;
	vector buy;
	vector sell;
	vector qbuy;
	vector qsell;
	vector initial;
	double ShortCostScale;
	linearcostpasser();
};

class optinfopasser
{
public:
	short back;
	long nfac;
	double kappa;
	void* opter;
	vector alpha;
	vector shortalphacost;
	vector benchmark;
	size_t dropnt;
	size_t dropnb;
	double desiredrisk;
	bool optactive_but_set_total;
	double zetaS;
	double zetaF;
	int roundlots;
	long basket;
	long trades;
	int revise;
	vector initial;
	vector min_lot;
	vector size_lot;
	int* shake;
	bool tradethresh;
	std::valarray<double> *minholdlot;
	std::valarray<double> *mintradelot;
	double keepgamma;
	vector keepw;
};
class entropyinfopasser
{
public:
	short back;
	double lambda;
	void* opter;
	vector alpha;
	vector shortalphacost;
	vector benchmark;
	size_t dropnt;
	size_t dropnb;
	double desiredU;
	double zetaS;
	double zetaF;
	int roundlots;
	long basket;
	long trades;
	int revise;
	vector initial;
	vector min_lot;
	vector size_lot;
	int* shake;
	bool tradethresh;
	std::valarray<double> *minholdlot;
	std::valarray<double> *mintradelot;
	double keep_entropy_gamma;
	vector keepw;
};
class downinfopasser
{
public:
	int leaveoutreturn;
	double kappa;
	double ret_coef;
	double mult;
	int activedown;
	long nfac;
	void* opter;
	vector alpha;
	vector benchmark;
	size_t dropnt;
	size_t dropnb;
	double desireddown;
	int roundlots;
	long basket;
	long trades;
	int revise;
	vector initial;
	vector min_lot;
	vector size_lot;
	int* shake;
	bool tradethresh;
	std::valarray<double> *minholdlot;
	std::valarray<double> *mintradelot;
};


extern void split(std::string &temp,std::vector<double> &data,std::string splitter=(char*)",");
extern void split(std::string &temp,std::vector<int> &data,std::string splitter=(char*)",");
extern void split(std::string &temp,std::vector<long> &data,std::string splitter=(char*)",");
extern void split(std::string &temp,std::vector<std::string> &data,std::string splitter=(char*)",");
extern void split(std::string &temp,std::vector<char*> &data,std::string splitter=(char*)",");
extern void deletechar(std::vector<char*> &data);
extern void printx(size_t n,vector a);

template <typename T> extern bool stocksort(const objectorder<T> & x, const objectorder<T> & y);
template <typename T> extern void Reorder_gen(size_t n, size_t* order,T* array,size_t m);
template <typename T> extern void getorder_gen(size_t n,const T* a,size_t* bb1,FF ff,unsigned char *dropbad,const T init,const short sign);
template <typename T> extern void getorder_eig(size_t n,const T* a,size_t* bb1,FF ff,unsigned char *dropbad,const short sign);
template <typename T> extern void Reorder_sym(size_t n, size_t* order,T* array);
template <typename T> extern void Printvalarray (const std::valarray<T>& va, size_t num);
#endif
#ifdef	__cplusplus
extern	"C"{
#endif
void	HMUL(size_t n,size_t n1,size_t n2,size_t n3,vector H,vector x,vector y,void* info);
void	buysell_grad(dimen n,vector w,vector g,void *info);
double	buysell_cost(dimen n,vector w,void*info);
void	piece_grad(dimen n,vector w,vector gg,void* info);
double	piece_cost(dimen n,vector w,void*info);
double	opt_func(double gamma,void*info);
double	entropy_func(double gamma,void*info);
double	down_func(double gamma,void*info);
DLLEXPORT size_t multistage(size_t n,size_t y,vector w,vector before,vector rebalanced,vector risks,vector Growth,vector Yield,vector Liability,
				vector lbound,vector ubound,char** names,vector Q,vector first,
				double delta,double maxrisk,dimen* NumberYears=0,size_t meth=1,size_t print=0);
DLLEXPORT size_t get_nstocks(char*name=(char*)"modelgen.txt");
DLLEXPORT void get_stocknames(char** sname,char*name=(char*)"modelgen.txt");
DLLEXPORT void get_factornames(char** fname,char*name=(char*)"modelgen.txt");
DLLEXPORT size_t get_nfac(char* name=(char*)"modelgen.txt");
DLLEXPORT void getdata(size_t nstocks,size_t nfac,char** namelist,double* FFL,double* SSV,double* FFC,char* name=(char*)"modelgen.txt");
DLLEXPORT void dmx_transpose(dimen n, dimen m, matrix a, matrix b);
DLLEXPORT void getorder(size_t n,const double* a,size_t* bb1,unsigned char* dropbad,double init=0.0);
DLLEXPORT void getorderrev(size_t n,const double* a,size_t* bb1,unsigned char* dropbad,double init=0.0);
DLLEXPORT void getordereig(size_t n,const double* a,size_t* bb1,unsigned char* dropbad);
DLLEXPORT void getorderneg(size_t n,const double* a,size_t* bb1,unsigned char* dropbad);
DLLEXPORT void Reorder_st(size_t n, size_t* order,size_t * array);
DLLEXPORT void Reorder_u(size_t n, size_t* order,unsigned char* array);
DLLEXPORT void ReorderS(size_t n, size_t* order,double* array);
DLLEXPORT void Reorder(size_t n, size_t* order,double* array);
DLLEXPORT void Reorder_mult(size_t n, size_t* order,double* array,size_t m);
DLLEXPORT void ReorderSquare(size_t n,size_t* order,vector SquareArray);
DLLEXPORT void	bound_reorganise(int f,dimen n,dimen nn,dimen m,double* b);
DLLEXPORT char* BasicQpOpt(dimen n,dimen m,vector A,vector lower,vector upper,vector x,vector c,
				   vector H,unsigned char lp,pHmul Hmul,long fixn,dimen ncomp,
				   vector Composites,long nfac,vector SV,
				   vector FL,dimen LS,dimen Full,dimen npiece,vector costdata,
				   pUtility Util,
				   pModC ModDeriv,pModQ ModHessian,void *Hinfo,void *Uinfo,void *Minfo,	
				   void* ModQObjectInfo);
DLLEXPORT short conj_solve(dimen n,vector M,vector y,vector w_opt,dimen ndiag=0,pHmul Qmul=0,
						  void* info=0,int usediag=1,int log=1);
DLLEXPORT void	symm_inverse_x(size_t n,vector Q,vector x,vector w_opt);
DLLEXPORT void	factor_model_process(dimen n,dimen nfac,vector FL,vector FC,
									 vector SV,vector Q);
DLLEXPORT void	apt_model_process(dimen n,dimen nf,vector eigvec,vector eigval,vector SV,vector Q);
DLLEXPORT short Optimise_internalCVP(dimen n,long nfac,char** names,vector w_opt,dimen m,
                                    vector A,vector L,vector U,vector alpha,
                                    vector benchmark,vector Q,double gamma,vector initial,
                                    double delta,vector buy,vector sell,double kappa,long basket,
                                    long trades,int revise,int costs,double min_holding,double min_trade,
                                    int m_LS,int Fully_Invested,double Rmin,double Rmax,
                                    int m_Round,vector min_lot,vector size_lot,int* shake,dimen ncomp,vector Composites,
									double LSValue,dimen npiece,vector hpiece,vector pgrad);


DLLEXPORT short  Optimise_internalCVPAextcosts(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,real kappa,long basket,
									long trades,int revise,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,
									vector Abs_U,vector FC,vector FL,vector SV,
									pUtility Util=0,pModC ModDeriv=0,
									pModQ ModHessian=0,
									double minRisk=-1,double maxRisk=-1,double* ogamma=0,
									void *Uinfo=0,void *Minfo=0,void *Qinfo=0,
									short take_out_costs=0,vector mask=0,int log=0,char* logfile=0,
									short DoExtraIterations=1,int downrisk=0,double downfactor=3.0,
									long longbasket=-1,long shortbasket=-1,
									long tradebuy=-1,long tradesell=-1,
									double zetaS=1,double zetaF=1,double ShortCostScale=1);
DLLEXPORT short  Optimise_internalCVPAextcostsl(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,real kappa,long basket,
									long trades,int revise,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,
									vector Abs_U,vector FC,vector FL,vector SV,
									pUtility Util=0,pModC ModDeriv=0,
									pModQ ModHessian=0,
									double minRisk=-1,double maxRisk=-1,double* ogamma=0,
									void *Uinfo=0,void *Minfo=0,void *Qinfo=0,
									short take_out_costs=0,vector mask=0,int log=0,char* logfile=0,
									short DoExtraIterations=1,int downrisk=0,double downfactor=3.0,
									long longbasket=-1,long shortbasket=-1,
									long tradebuy=-1,long tradesell=-1,
									double zetaS=1,double zetaF=1,double ShortCostScale=1,
									double LSValuel=0,vector Abs_L=0);
DLLEXPORT short  Optimise_internalCVPAextcostslSa(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,real kappa,long basket,
									long trades,int revise,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,
									vector Abs_U,vector FC,vector FL,vector SV,
									pUtility Util=0,pModC ModDeriv=0,
									pModQ ModHessian=0,
									double minRisk=-1,double maxRisk=-1,double* ogamma=0,
									void *Uinfo=0,void *Minfo=0,void *Qinfo=0,
									short take_out_costs=0,vector mask=0,int log=0,char* logfile=0,
									short DoExtraIterations=1,int downrisk=0,double downfactor=3.0,
									long longbasket=-1,long shortbasket=-1,
									long tradebuy=-1,long tradesell=-1,
									double zetaS=1,double zetaF=1,double ShortCostScale=1,
									double LSValuel=0,vector Abs_L=0,vector shortalphacost=0);
DLLEXPORT short  Optimise_internalCVPAextcostslSaM(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,real kappa,long basket,
									long trades,int revise,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,
									vector Abs_U,vector FC,vector FL,vector SV,
									pUtility Util=0,pModC ModDeriv=0,
									pModQ ModHessian=0,
									double minRisk=-1,double maxRisk=-1,double* ogamma=0,
									void *Uinfo=0,void *Minfo=0,void *Qinfo=0,
									short take_out_costs=0,vector mask=0,int log=0,char* logfile=0,
									short DoExtraIterations=1,int downrisk=0,double downfactor=3.0,
									long longbasket=-1,long shortbasket=-1,
									long tradebuy=-1,long tradesell=-1,
									double zetaS=1,double zetaF=1,double ShortCostScale=1,
									double LSValuel=0,vector Abs_L=0,vector shortalphacost=0,
									int never_slow=0,size_t*mem_kbytes=0);
DLLEXPORT short  Optimise_internalCVPAextcostslSaMS(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,real kappa,long basket,
									long trades,int revise,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,
									vector Abs_U,vector FC,vector FL,vector SV,
									pUtility Util=0,pModC ModDeriv=0,
									pModQ ModHessian=0,
									double minRisk=-1,double maxRisk=-1,double* ogamma=0,
									void *Uinfo=0,void *Minfo=0,void *Qinfo=0,
									short take_out_costs=0,vector mask=0,int log=0,char* logfile=0,
									short DoExtraIterations=1,int downrisk=0,double downfactor=3.0,
									long longbasket=-1,long shortbasket=-1,
									long tradebuy=-1,long tradesell=-1,
									double zetaS=1,double zetaF=1,double ShortCostScale=1,
									double LSValuel=0,vector Abs_L=0,vector shortalphacost=0,
									int never_slow=0,size_t*mem_kbytes=0,dimen msoft=0,double errorBound=.25);
DLLEXPORT short  Optimise_internalCVPAextcostslSaMSoft(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,real kappa,long basket,
									long trades,int revise,vector min_holding,//min_holding and min_trade are now both vectors, i.e. we can have different thresh for each asset
									vector min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,
									vector Abs_U,vector FC,vector FL,vector SV,
									pUtility Util=0,pModC ModDeriv=0,
									pModQ ModHessian=0,
									double minRisk=-1,double maxRisk=-1,double* ogamma=0,
									void *Uinfo=0,void *Minfo=0,void *Qinfo=0,
									short take_out_costs=0,vector mask=0,int log=0,char* logfile=0,
									short DoExtraIterations=1,int downrisk=0,double downfactor=3.0,
									long longbasket=-1,long shortbasket=-1,
									long tradebuy=-1,long tradesell=-1,
									double zetaS=1,double zetaF=1,double ShortCostScale=1,
									double LSValuel=0,vector Abs_L=0,vector shortalphacost=0,
									int never_slow=0,size_t*mem_kbytes=0,dimen soft_m=0,vector soft_l=0,vector soft_b=0,
									vector soft_L=0,vector soft_U=0,vector soft_A=0,double five=-1,double ten=-1,double forty=-1,int*issues=0);
DLLEXPORT short  Optimise_internalCVPA(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,int revise,int costs,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector mask=0,int log=0,char* logfile=0);
DLLEXPORT short  Optimise_internalCVPAF(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,int revise,int costs,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,double minRisk=-1,
									double maxRisk=-1,double* ogamma=0,vector mask=0,
									int log=0,char* logfile=0,
									int downrisk=0,double downfactor=3.0);
DLLEXPORT short  Optimise_internalCVPAFb(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,int revise,int costs,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,double minRisk=-1,
									double maxRisk=-1,double* ogamma=0,vector mask=0,
									int log=0,char* logfile=0,
									int downrisk=0,double downfactor=3.0,
									long longbasket=-1,long shortbasket=-1,
									long tradebuy=-1,long tradesell=-1,
									double zetaS=1,double zetaF=1,double ShortCostScale=1);
DLLEXPORT short  Optimise_internalCVPAFblQ(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,int revise,int costs,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,double minRisk=-1,
									double maxRisk=-1,double* ogamma=0,vector mask=0,
									int log=0,char* logfile=0,
									int downrisk=0,double downfactor=3.0,
									long longbasket=-1,long shortbasket=-1,
									long tradebuy=-1,long tradesell=-1,
									double zetaS=1,double zetaF=1,double ShortCostScale=1,
									double LSValuel=0,vector Abs_L=0,vector qbuy=0,vector qsell=0);
DLLEXPORT short  Optimise_internalCVPAFbl(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,int revise,int costs,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,double minRisk=-1,
									double maxRisk=-1,double* ogamma=0,vector mask=0,
									int log=0,char* logfile=0,
									int downrisk=0,double downfactor=3.0,
									long longbasket=-1,long shortbasket=-1,
									long tradebuy=-1,long tradesell=-1,
									double zetaS=1,double zetaF=1,double ShortCostScale=1,
									double LSValuel=0,vector Abs_L=0);
DLLEXPORT short  Optimise_internalCVPAFblSa(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,int revise,int costs,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,double minRisk=-1,
									double maxRisk=-1,double* ogamma=0,vector mask=0,
									int log=0,char* logfile=0,
									int downrisk=0,double downfactor=3.0,
									long longbasket=-1,long shortbasket=-1,
									long tradebuy=-1,long tradesell=-1,
									double zetaS=1,double zetaF=1,double ShortCostScale=1,
									double LSValuel=0,vector Abs_L=0,vector shortalphacost=0);
DLLEXPORT short  Optimise_internalCVPAFblSaM(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,int revise,int costs,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,double minRisk=-1,
									double maxRisk=-1,double* ogamma=0,vector mask=0,
									int log=0,char* logfile=0,
									int downrisk=0,double downfactor=3.0,
									long longbasket=-1,long shortbasket=-1,
									long tradebuy=-1,long tradesell=-1,
									double zetaS=1,double zetaF=1,double ShortCostScale=1,
									double LSValuel=0,vector Abs_L=0,vector shortalphacost=0,
									int never_slow=0,size_t*mem_kbytes=0);
DLLEXPORT short  Optimise_internalCVPAFblSaMS(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,int revise,int costs,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,double minRisk=-1,
									double maxRisk=-1,double* ogamma=0,vector mask=0,
									int log=0,char* logfile=0,
									int downrisk=0,double downfactor=3.0,
									long longbasket=-1,long shortbasket=-1,
									long tradebuy=-1,long tradesell=-1,
									double zetaS=1,double zetaF=1,double ShortCostScale=1,
									double LSValuel=0,vector Abs_L=0,vector shortalphacost=0,
									int never_slow=0,size_t*mem_kbytes=0,dimen msoft=0,double errorBound=.25);
DLLEXPORT short  Optimise_internalCVPAFblSaMSoft(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,int revise,int costs,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,double minRisk=-1,
									double maxRisk=-1,double* ogamma=0,vector mask=0,
									int log=0,char* logfile=0,
									int downrisk=0,double downfactor=3.0,
									long longbasket=-1,long shortbasket=-1,
									long tradebuy=-1,long tradesell=-1,
									double zetaS=1,double zetaF=1,double ShortCostScale=1,
									double LSValuel=0,vector Abs_L=0,vector shortalphacost=0,
									int never_slow=0,size_t*mem_kbytes=0,dimen soft_m=0,vector soft_l=0,vector soft_b=0,
									vector soft_L=0,vector soft_U=0,vector soft_A=0);
DLLEXPORT short  Optimise_internalCVPAFblSaMSoftQ(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,int revise,int costs,real min_holding,
									real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,double minRisk=-1,
									double maxRisk=-1,double* ogamma=0,vector mask=0,
									int log=0,char* logfile=0,
									int downrisk=0,double downfactor=3.0,
									long longbasket=-1,long shortbasket=-1,
									long tradebuy=-1,long tradesell=-1,
									double zetaS=1,double zetaF=1,double ShortCostScale=1,
									double LSValuel=0,vector Abs_L=0,vector shortalphacost=0,
									int never_slow=0,size_t*mem_kbytes=0,dimen soft_m=0,vector soft_l=0,vector soft_b=0,
									vector soft_L=0,vector soft_U=0,vector soft_A=0,vector qbuy=0,vector qsell=0,double five=-1,double ten=-1,double forty=-1,int*issues=0);
DLLEXPORT short  Optimise_internalCVPAFblSaMSoftQV(dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,real gamma,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,int revise,int costs,vector min_holding,
									vector min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Composite,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,double minRisk=-1,
									double maxRisk=-1,double* ogamma=0,vector mask=0,
									int log=0,char* logfile=0,
									int downrisk=0,double downfactor=3.0,
									long longbasket=-1,long shortbasket=-1,
									long tradebuy=-1,long tradesell=-1,
									double zetaS=1,double zetaF=1,double ShortCostScale=1,
									double LSValuel=0,vector Abs_L=0,vector shortalphacost=0,
									int never_slow=0,size_t*mem_kbytes=0,dimen soft_m=0,vector soft_l=0,vector soft_b=0,
									vector soft_L=0,vector soft_U=0,vector soft_A=0,vector qbuy=0,vector qsell=0,double five=-1,double ten=-1,double forty=-1,int*issues=0);
DLLEXPORT void PropertiesC(dimen n,long nfac,char** names,vector w,vector alpha,
                                    vector benchmark,
                                    vector Q,double* risk,double* arisk,double* Rrisk,
									double* rreturn,
                                    double* areturn,double* Rreturn,
                                    vector MCAR,vector MCTR,vector MCRR,vector FMCRR,
                                    vector FMCTR,vector   beta,vector FX,vector RFX,
                                    vector  FL,vector FC,vector SV,dimen ncomp,
									vector Composites);

DLLEXPORT void 	PropertiesCA(dimen n,long nfac,char** names,vector w,
									  vector benchmark,
									  vector alpha,real *rreturn,real *areturn,real *Rreturn,
									  real *breturn,
									  vector Q,real *risk,real *arisk,real *Rrisk,real *brisk,
									  real *srisk,
									  real *pbeta,
									  vector MCAR,vector MCTR,vector MCRR,vector MCBR,
									  vector FMCRR,
									  vector FMCTR,vector FMCAR,vector FMCBR,vector FMCSR,
									  vector	beta,
									  vector FX,vector RFX,vector AFX,vector BFX,vector SFX,
									  vector  FL,vector FC,vector SV,dimen ncomp,
									  vector Composite);
DLLEXPORT short FrontierCVPA(dimen npoints,vector risk,
									vector arisk,vector rreturn,vector areturn,
									dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,dimen revise,int costs,real min_holding,real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Comp,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector mask=0);
DLLEXPORT short FrontierCVPAF(dimen npoints,vector risk,
									vector arisk,vector rreturn,vector areturn,
									dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,dimen revise,int costs,real min_holding,real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Comp,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,vector mask=0,int DoByRisks=0);
DLLEXPORT short FrontierCVPAFb(dimen npoints,vector risk,
									vector arisk,vector rreturn,vector areturn,
									dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,dimen revise,int costs,real min_holding,real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Comp,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,vector mask=0,int DoByRisks=0,
									long longbasket=-1,long shortbasket=-1,
									long tradebuy=-1,long tradesell=-1,double ShortCostScale=1);
DLLEXPORT short FrontierCVPAFbl(dimen npoints,vector risk,
									vector arisk,vector rreturn,vector areturn,
									dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,dimen revise,int costs,real min_holding,real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Comp,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,vector mask=0,int DoByRisks=0,
									long longbasket=-1,long shortbasket=-1,
									long tradebuy=-1,long tradesell=-1,double ShortCostScale=1,
									double LSValuel=0,vector Abs_L=0);
DLLEXPORT short FrontierCVPAFblQ(dimen npoints,vector risk,
									vector arisk,vector rreturn,vector areturn,
									dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,dimen revise,int costs,real min_holding,real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Comp,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,vector mask=0,int DoByRisks=0,
									long longbasket=-1,long shortbasket=-1,
									long tradebuy=-1,long tradesell=-1,double ShortCostScale=1,
									double LSValuel=0,vector Abs_L=0,vector qbuy=0,vector qsell=0);
DLLEXPORT short FrontierCVPF(dimen npoints,vector risk,
									vector arisk,vector rreturn,vector areturn,
									dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,vector initial,
									real delta,vector buy,vector sell,real kappa,long basket,
									long trades,dimen revise,int costs,real min_holding,real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Comp,real LSValue,
									dimen npiece,vector hpiece,vector pgrad,
									vector FC,vector FL,vector SV,vector mask=0,int DoByRisks=0);
DLLEXPORT short FrontierCVPAextcosts(dimen npoints,vector risk,
									vector arisk,vector rreturn,vector areturn,
									dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,vector initial,
									real delta,real kappa,long basket,
									long trades,dimen revise,real min_holding,real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Comp,real LSValue,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,
									pUtility Util=0,pModC ModDeriv=0,pModQ ModHessian=0,
									void *Uinfo=0,void *Minfo=0,void *Qinfo=0,
									short take_out_costs=0,vector mask=0,short DoExtraIterations=1,
									int DoByRisks=0,
									long longbasket=-1,long shortbasket=-1,
									long tradebuy=-1,long tradesell=-1,double ShortCostScale=1);
DLLEXPORT short FrontierCVPAextcostsl(dimen npoints,vector risk,
									vector arisk,vector rreturn,vector areturn,
									dimen n,long nfac,char** names,vector w,dimen m,
									vector A,vector L,vector U,vector alpha,
									vector benchmark,vector Q,vector initial,
									real delta,real kappa,long basket,
									long trades,dimen revise,real min_holding,real min_trade,
									int m_LS,int Fully_Invested,real Rmin,real Rmax,
									int m_Round,vector min_lot,vector size_lot,int* shake,
									dimen ncomp,vector Comp,real LSValue,
									dimen nabs,vector Abs_A,dimen mabs,dimen* I_A,vector Abs_U,
									vector FC,vector FL,vector SV,
									pUtility Util=0,pModC ModDeriv=0,pModQ ModHessian=0,
									void *Uinfo=0,void *Minfo=0,void *Qinfo=0,
									short take_out_costs=0,vector mask=0,short DoExtraIterations=1,
									int DoByRisks=0,
									long longbasket=-1,long shortbasket=-1,
									long tradebuy=-1,long tradesell=-1,double ShortCostScale=1,
									double LSValuel=0,vector Abs_L=0);

DLLEXPORT void	GetBeta(dimen n,long nfac,vector benchmark,vector Q,vector beta,
						dimen ncomp,vector Composite);
DLLEXPORT void Get_RisksC(dimen n,long nfac,vector Q,vector w,vector benchmark,double* arisk,
									 double* risk,double* Rrisk,double* brisk,
									 double *pbeta,dimen ncomp,vector Composite);
DLLEXPORT void 	MarginalUtility(dimen n,long nfac,char** names,vector w,
									  vector benchmark,vector initial,
									  vector Q,real gamma,real kappa,
									  dimen npiece,vector hpiece,vector pgrad,
									  vector buy,vector sell,
									  vector alpha,real *tcost,real *utility,
									  vector gradutility,
									  vector utility_per_stock,
									  vector cost_per_stock,
									  dimen ncomp,
									  vector Composite);
DLLEXPORT void 	MarginalUtilityb(dimen n,long nfac,char** names,vector w,
									  vector benchmark,vector initial,
									  vector Q,real gamma,real kappa,
									  dimen npiece,vector hpiece,vector pgrad,
									  vector buy,vector sell,
									  vector alpha,real *tcost,real *utility,
									  vector gradutility,
									  vector utility_per_stock,
									  vector cost_per_stock,
									  dimen ncomp,
									  vector Composite,double ShortCostScale=1);
DLLEXPORT void 	MarginalUtilitybSa(dimen n,long nfac,char** names,vector w,
									  vector benchmark,vector initial,
									  vector Q,real gamma,real kappa,
									  dimen npiece,vector hpiece,vector pgrad,
									  vector buy,vector sell,
									  vector alpha,real *tcost,real *utility,
									  vector gradutility,
									  vector utility_per_stock,
									  vector cost_per_stock,
									  dimen ncomp,
									  vector Composite,double ShortCostScale=1,vector shortalphacost=0);
DLLEXPORT void 	MarginalUtilitybSaQ(dimen n,long nfac,char** names,vector w,
									  vector benchmark,vector initial,
									  vector Q,real gamma,real kappa,
									  dimen npiece,vector hpiece,vector pgrad,
									  vector buy,vector sell,
									  vector alpha,real *tcost,real *utility,
									  vector gradutility,
									  vector utility_per_stock,
									  vector cost_per_stock,
									  dimen ncomp,
									  vector Composite,double ShortCostScale=1,vector shortalphacost=0,vector qbuy=0,vector qsell=0);
DLLEXPORT void 	MarginalUtility_ext(dimen n,long nfac,char** names,vector w,
									  vector benchmark,vector initial,
									  vector Q,real gamma,real kappa,
									  vector alpha,real *tcost,real *utility,
									  vector gradutility,
									  dimen ncomp,
									  vector Composite,double ShortCostScale=1,
									  pUtility Util=0,pModC ModDeriv=0,
									  void *Uinfo=0,void *Minfo=0,vector shortalphacost=0);
DLLEXPORT int	fix_covariancem(dimen n,vector Q);
DLLEXPORT short InvQ_d(dimen n,vector Q,vector d,vector Qm1d);
DLLEXPORT short ConstrRegress(dimen n,dimen m,vector Q,vector c,vector w,vector L,vector U,vector A);
DLLEXPORT int	pickout(dimen nstocks,char **stocklist,dimen M_nstocks,char** M_stocklist,vector Q,size_t*Order);
DLLEXPORT int	pickoutstrings(dimen nstocks,char **stocklist,dimen M_nstocks,char** M_stocklist,char** Q,size_t*Order);
DLLEXPORT char*	Return_Message(int ifail);
DLLEXPORT char*	MultiStageMessage(int ifail);
DLLEXPORT short eigendecomp(dimen n, matrix S, vector d, dimen itmax);
DLLEXPORT char* expire_date(char*a);
DLLEXPORT char* version(char*a);
DLLEXPORT char* cversion(char*a);
DLLEXPORT char* component_key(char*a);
DLLEXPORT int	days_left(char **a);
DLLEXPORT void Extract_Factor_Information(dimen nstocks,dimen numfac,dimen Mnstocks,
								vector FL,vector SV,char** stocklist,
								vector MFL,vector MSV,char** Mstocklist);
DLLEXPORT short OptAdvanced(dimen NN, dimen MM, vector XX, vector AA, vector LL,
	vector UU, vector CC, vector LAMBDA, pHmul hhh, void*info, vector QQ);
#ifdef	__cplusplus
}
#endif

typedef	double	(*UFUNC)(void*info);
typedef	short	(*OFUNC)(void*info);
typedef	void	(*GFUNC)(void*info);

//using namespace std;

//Extend Base_Optimise to use for historic covariances
#ifndef NOCLASS
class DLLEXPORT Optimise:public Base_Optimise
{
public:
#ifdef PAS
	static bool bitago;
#endif
	char* OptSetup(dimen nvab,dimen nvabt);
	char* OptSetup(dimen nvab);
	char* AccumOpt(dimen nvab,dimen nvabt);
	char* AccumOpt(dimen nvab);
	bool ImportantCheck();
	short GOpt(dimen nvab,dimen m,vector x,vector A,vector lower,vector upper,vector c);
	short	Drop(dimen Nvab,dimen nvab);
	short	Drop2(dimen nvab,dimen basket,dimen trades,bool onlyfast=0);
	short	Drop(dimen Nvab,dimen nvab,dimen nvabt,dimen NZB,dimen NZT,dimen& nvabmin,bool switcher=0);
	size_t	DropCheck();
	size_t	DropCheckB();
	size_t	DropCheckT();
	size_t	ThreshCheck(double thresh);
	size_t	ThreshCheck(vector thresh);
	size_t	ThreshCheckB(double thresh);
	size_t	ThreshCheckB(vector thresh);
	size_t	ThreshCheckT(double thresh);
	size_t	ThreshCheckT(vector thresh);
	vector	threshvector;
	vector	threshvectort;
	double	threshscalar;
	double	threshscalart;
	bool leave_out_trivial;
	vector lsinitial;

	UFUNC KagUtil;
	GFUNC KagGrad;
	OFUNC KagOpt;

	Optimise();
	void Thresh(size_t basket,size_t trades,vector initial,vector threshvec,vector roundw);
	void Thresh(size_t basket,size_t trades,vector initial,
		vector weightthresh,vector tradethresh,vector roundw,
		vector weightthresh1=0,vector tradethresh1=0);
	void Rounding(size_t basket,size_t trades,vector initial,vector minlot,vector sizelot,vector roundw,vector minholdlot=0,vector mintradelot=0);
	short roundopt(class KeepBest &KB,size_t basket,size_t trades,vector lower,vector upper,vector L1,vector U1,
		vector initial,vector minlot1,vector sizelot,size_t stage=0,vector naive=0,
		size_t nround=0,vector minlot2=0,double oldutil=1e55,bool nopt=0,
		vector minlot3=0,vector minlot4=0);
#ifndef MYNOVIRT
	virtual 
#endif
	~Optimise();
	virtual void 	qphess_base(dimen nvab,dimen nrowh,dimen ncolh,dimen jcol,double *H,vector x,vector y);
	void 	qphess(dimen nvab,dimen nrowh,dimen ncolh,dimen jcol,double *H,vector x,vector y);
	virtual real shortcost(dimen n,vector x);
	virtual void update_with_higher(size_t n,vector Higher,vector Q,short plus=0);
	virtual	void	TransformH(size_t nvab=0,unsigned char reverse=0);
	real utility(dimen nvab,vector x,vector c,vector Q);
	void ModifyC(dimen nvab,vector Q,vector x,vector newc,unsigned char all);
	virtual void ResetInitial(unsigned char forward=1);
	virtual void beta(vector bench,vector beta);
	virtual real risk(vector w,vector bench);
	virtual void MC(vector w,vector bench,vector MARG);
	virtual void CompSetup();
	virtual size_t H_size();
	double turnover();
	size_t ncomp;
	long longbasket;
	long shortbasket;
	long tradebuy;
	long tradesell;
	vector lowerusednow;
	vector upperusednow;
	double ShortCostScale;
	vector Composites;
	vector initial;
	vector absoluteA;
	vector lowerA;
	vector upperA;
	vector mask;//Turnover is defined as sum (x[i]-initial[i])*mask[i]*0.5
	vector shortalphacost;
	size_t mabs;
	short	gross;
	double SLRATmax;
	double SLRATmin;
	double five,ten,forty;
	int* issues;
	real delta;
	size_t*	neworder;	//New order for dropping etc.
	size_t*	inverse;	//Inverse of new order
	vector drop_to_this;
	vector drop_to_this_both;
	short hess_choice;
	short Full;
	real LSValue;
	real LSValue_Low;
	real dropfac;
	real threshfac;
	real equalbounds;
	real nowTime;
	size_t badcountlimit;
	unsigned char UseDiagPenalty;
	short back;
	short take_out_costs;
	double NaturalTurnover;
	std::valarray<unsigned char>	*dropbad;
	std::valarray<double>			*buysell;
private:
	bool cannot_drop_any_more;
	double leigen(size_t nn);
	void lspenaltyvec(size_t nn,vector pen);
	bool	have_ls,have_rev;
	std::valarray<double> *SSS1;
	std::valarray<double> *SSS2;
	std::valarray<size_t> *SSS3;
	std::valarray<double> *SSS4;
	void releaseSSS();
protected:
	real large_eigen;
	vector lspenalty,newA,newC,newL,newU,newX,work;
	size_t* lab;
	size_t* labrev; 
	size_t lsi,revi,lsrevi,zeroinit;
	size_t							non_zero,fixed_zero,fixed_zerot,fixed_bounds,nbefore,non_threshed;
	unsigned char					fileset;
	std::valarray<double> *vx,*fixed_implied,*yc,*CompQ;
	std::valarray<size_t>			*vneworder,*vinverse;
	std::valarray<size_t>			*vdroporder,*vdinverse;
	std::valarray<size_t>			*vcomporder,*vcinverse;
	std::valarray<size_t>			*effectiveorder;
};

class DLLEXPORT FOptimise:public Optimise
{
public:
	size_t nfac;
	vector FL,SV,FC;
	void	facmul(dimen nvab,double *H,vector x,vector y);
	void	factor_model_process();
	void	CompSetup();
	void	FMC(vector w,vector bench,vector MARG,vector FX);
	size_t H_size();
	FOptimise();
	~FOptimise();
	void 	qphess_base(dimen nvab,dimen nrowh,dimen ncolh,dimen jcol,double *H,vector x,vector y);
	void	TransformH(size_t nvab=0,unsigned char reverse=0);
protected:
	std::valarray<double>			*vQ;
private:
#ifdef USE_STOREX
	std::valarray<double>	*storex;
#endif
};

//#include"SparseClass.h"
#endif
//Extras for doing rounding with SOCP etc.
short roundopt(void*info,class KeepBest &KB,vector lower,vector upper,vector L1,vector U1,
		vector initial,vector minlot1,vector sizelot,size_t stage=0,vector naive=0,
		size_t nround=0,vector minlot2=0,double oldutil=1e55,bool nopt=0,
		vector minlot3=0,vector minlot4=0);

void Thresh(void*info,vector initial,vector minlot,vector roundw,vector minlot1=0);
extern "C" DLLEXPORT short Accumulation5_10_40(void*info,dimen basket,dimen trades,int way);


#ifndef NOCLASS
class DLLEXPORT OptPassAccum
{
public:
	dimen n,m,m1;
	short back;
	vector L,U,A,L1,U1,A1,w;
	char* Optname;
	char* Utilname;
	char* GUtilname;
	OFUNC Opt;
	GFUNC GUtil;
	UFUNC Util;
	int*issues;
	double five,ten,forty;
	void*caller;
	short infease_error;
	double constraint_eps;
	OptPassAccum();
	~OptPassAccum();
};
class OptParamAccum
{
public:
	UFUNC UtilityFunc;
	OFUNC OptFunc;//This must set back member
	GFUNC GradFunc;
	void* MoreInfo;
	size_t n;
	size_t m;
	vector x;
	vector grad;
	vector lower;
	vector upper;
	vector A;
	dimen basket,trades;
	short KagOpt();
	OptParamAccum(void*info);
	~OptParamAccum();
	void SetExtras(int way);
	void UpdateSolution(vector X,size_t&UUstable);
	double five,ten,forty,totalg5,bestU;
	bool dokagcheck,tencheck;

	dimen* bn,*bm;
	vector* bL,*bU,*bA,*bx;
	short*bback;
	size_t nish;
	vector issues;
	int*issues_def;
	std::valarray<double> *pissues;
	short infease_error;
	double constraint_eps;
};
class OptParamRound
{
public://This should be all we need to vary to get a rounded solution
	size_t n;
	size_t m;
	vector x;
	vector grad;
	void SetLog();
	void PrintLog();
//	void AddLog(const char* mm);
	void AddLog(const char *mm,...); 
	UFUNC UtilityFunc;
	OFUNC OptFunc;//This must set back member
	GFUNC GradFunc;
	void* MoreInfo;
	vector lower;
	vector upper;
	vector c;
	short back;
	dimen mabs;
	int lp;
	dimen basket;
	dimen trades;
	long longbasket;
	long shortbasket;
	long tradebuy;
	long tradesell;
	vector initial;
	double equalbounds;
	double dropfac;
	vector minholdlot;
	vector mintradelot;
	void* TimeOptData;
	OptParamRound();
	~OptParamRound();
	char*dump;
	std::stringstream* Getlogprint();
	std::stringstream* logprint;
private:
	std::stringstream* logprint_check;
};
class ExtraR
{
public:
	dimen n,m;									//Introduced for 4-10-40
	vector x,lower,upper,minlot,sizelot;		//Introduced for 4-10-40
	char*inputData;								//Introduced for 4-10-40
	double five,ten,forty;						//Introduced for 4-10-40
	int*issues;									//Introduced for 4-10-40

	UFUNC KagUtil;								//Introduced for 4-10-40
	GFUNC KagGrad;								//Introduced for 4-10-40
	OFUNC KagOpt;								//Introduced for 4-10-40
	short back;									//Introduced for 4-10-40

	vector A;
	vector alpha;
	vector benchmark;
	vector initial;
	vector buy;
	vector sell;
	int costs;
	double delta;
	double psum;
	double psumL;
	double nsum;
	double nsumU;
	double rmax;
	double rmin;
	size_t mabs;
	vector A_abs;
	vector L_abs;
	vector U_abs;
	vector FC;
	long nfac;
	vector FL;
	vector SV;
	double maxrisk;
	double maxarisk;
	int meanstd;
	double meanstdl;
	double*lambda1;
	double*lambda2;
	double*lambda3;
	double*optvalue;
	int log;
	char*logfile;
	long basket;
	long trades;
	long longbasket;
	long shortbasket;
	long tradebuy;
	long tradesell;
	double equalbounds;
	vector min_trade;
	vector min_hold;
};
class SymmetricSolver
{
public:
	vector M;
	vector D;
	vector E;
	size_t* order;
	size_t n;
	bool*sparse;
	bool Factor(size_t n,vector M);
	void Solve(vector x);
	void SparseGen(size_t n,vector M);
	SymmetricSolver();
	~SymmetricSolver();
};
#endif
#endif
