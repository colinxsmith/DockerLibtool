/* ========================================================================== */
/* === ldl.h:  include file for the LDL package ============================= */
/* ========================================================================== */

/* LDL Version 1.1 (Apr. 22, 2005), Copyright (c) 2005 by Timothy A Davis,
 * University of Florida.  All Rights Reserved.  See README for the License.
 */
//#include "ldefns.h"
#if !defined(DLLEXPORT)
#if	defined(__SYSNT__)
#define	DLLEXPORT	__declspec( dllexport )
#else
#define	DLLEXPORT	
#endif
#endif
#ifndef	__cplusplus
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#else
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#endif
DLLEXPORT void ldl_symbolic (size_t n, size_t* Ap, size_t* Ai, size_t* Lp,
    size_t* Parent , size_t* Lnz, size_t* Flag , size_t* P , size_t* Pinv ) ;

DLLEXPORT size_t ldl_numeric (size_t n, size_t* Ap , size_t* Ai , double* Ax ,
    size_t* Lp , size_t* Parent , size_t* Lnz , size_t* Li , double* Lx ,
    double* D , double* Y , size_t* Pattern , size_t* Flag ,
    size_t* P , size_t* Pinv ) ;

DLLEXPORT void ldl_lsolve (size_t n, double* X , size_t* Lp , size_t* Li ,
    double* Lx ) ;

DLLEXPORT void ldl_dsolve (size_t n, double* X , double* D ) ;

DLLEXPORT void ldl_ltsolve (size_t n, double* X , size_t* Lp , size_t* Li ,
    double* Lx ) ;

DLLEXPORT void ldl_perm  (size_t n, double* X , double* B , size_t* P ) ;
DLLEXPORT void ldl_permt (size_t n, double* X , double* B , size_t* P ) ;

DLLEXPORT size_t ldl_valid_perm (size_t n, size_t* P , size_t* Flag ) ;
DLLEXPORT size_t ldl_valid_matrix ( size_t n, size_t* Ap , size_t* Ai ) ;
