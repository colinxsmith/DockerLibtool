/*
	x = y + constant for vectors x and y
*/
#include "ldefns.h"
void daddcvec(dimen n, vector y, real c, vector x )
{
	while(n--)
		*x++ = *y++ + c;
}
