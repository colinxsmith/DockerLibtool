#ifdef __SYSNT__
#ifndef MINGW32 
#include <crtdbg.h>
#else
#define _ASSERT
#endif
#pragma warning(disable:4786)
#endif
#include "optimise.h"
//#define NO_NORM_SCAL
/*//Choleski test
//SUBROUTINE DPPTRF( UPLO, N, AP, INFO )
extern "C" int dpptrf_BITA(char*uplo,Integer*n,double*ap,Integer*info);
//SUBROUTINE DPPTRS( UPLO, N, NRHS, AP, B, LDB, INFO )
extern "C" int dpptrs_BITA(char*uplo,Integer*n,Integer*nrhs,double*ap,double*b,Integer*LDB,Integer*info);
*/

//#define USE_SINGLE		//May be quicker to use this, but 32 and 64 systems give slightly different results if we do!
#define Conic_featol lm_rooteps32  //This is 32*lm_rooteps i.e a whole number times lm_eps

extern "C" void	facmulold(size_t n,size_t nf,double *H,vector x,vector y);
extern "C" short Droptwo(void*info,dimen basket,dimen trades,bool SOCP=false,bool onlyfast=false,bool revway=false);
extern "C" DLLEXPORT short Conic_General(size_t ncone,int*cone,int*typecone,size_t m,vector x,vector s,vector y,vector A,vector b,
										 vector c,vector tau,vector kappa,double comptoll=1e-8,double gaptoll=1e-8,double stepmax=2e-2,int straight=0,
										 int fastbreak=1,int log=0,char*outfile=0,int method=0);

extern "C" DLLEXPORT short Conic_VeryGeneral(size_t ncone,int*cone,int*typecone,size_t m,vector x,vector s,vector y,vector A,vector b,
										 vector c,vector tau,vector kappa,double comptoll,double gaptoll,double stepmax,int straight,int fastbreak,
										 int log,char*outfile,int method,int homog,long nf,vector SV,vector FL,vector FC,size_t fcone);
extern "C" void facmul_and_inv(dimen n,dimen nfac,vector Q,vector x,vector y,int inv=0);
extern "C" void factor_model_process_inverse(dimen n,dimen nfac,vector Q,vector Qm1);
extern "C" void	lowrank_facmul_and_inv(dimen n,dimen nfac,vector LL,vector A,vector x,vector y,int inv=0,short_scl*Apiv=0);
extern "C" void process_lowrank_plus_symm_inverse(dimen n,dimen nfac,vector LL,vector A,vector LLm1,short_scl*Apiv);
#ifdef _OPENMP
#include<omp.h>
#endif
enum ParityUtype {VarianceType,ConcentrationType,EntropyType};


template<typename T> size_t zerocount(size_t n,T* a,size_t skip=1)
{
	size_t back=0;
	while(n--)
	{
		if(*a==0)back++;
		a+=skip;
	}
	return back;
}
extern "C" DLLEXPORT void multT(dimen n,vector e,vector x)
{
	//Multiply by the triangle from gramS
	size_t i;
	for(i=0;i<n;++i)
	{
		//for(j=0;j<n-i-1;++j)
		//	x[n-i-1]+=e[(n-i-1)*n+j]*x[j];
		x[n-i-1]+=ddotvec(n-i-1,e+n*(n-i-1),x);
	}
}
extern "C" DLLEXPORT void multTS(dimen n,vector e,vector x,bool*sparse)
{
	//Multiply by the triangle from gramS
	size_t i,j;
	bool* spa;
	vector ee;
	for(i=0;i<n;++i)
	{
		for(j=0,spa=sparse+(n-i-1)*n,ee=e+(n-i-1)*n;j<n-i-1;++j,spa++,ee++)
		{
			//if(!sparse[(n-i-1)*n+j])
			if(!*spa)
				x[n-i-1]+=*ee /*e[(n-i-1)*n+j]*/ *x[j];
		}
	}
}
extern "C" DLLEXPORT void multTt(dimen n,vector e,vector x)
{
	//Multiply by the transpose of triangle from gramS
	size_t i;
	for(i=0;i<n;++i)
	{
		//for(j=i+1;j<n;++j)
		//	x[i]+=e[i+j*n]*x[j];
		x[i]+=BITA_ddot(n-i-1,e+i+(i+1)*n,n,x+i+1,1);
	}
}
extern "C" DLLEXPORT void multTtS(dimen n,vector e,vector x,bool*sparse)
{
	//Multiply by the transpose of triangle from gramS
	size_t i,j;
	bool* spa;
	vector ee;
	for(i=0;i<n;++i)
	{
		for(j=i+1,spa=sparse+j*n+i,ee=e+j*n+i;j<n;++j,spa+=n,ee+=n)
		{
			//if(!sparse[j*n+i])
			if(!*spa)
				x[i]+=*ee /*e[i+j*n]*/ *x[j];
		}
	}
}
extern "C" DLLEXPORT void solveTt(dimen n,vector e,vector x)
{
	//Solve with the transpose of triangle from gramS
	size_t i;
	for(i=1;i<n;++i)
	{
		//for(j=0;j<i;++j)
		//	x[n-i-1]-=x[n-j-1]*e[n-i-1+(n-j-1)*n];
		x[n-i-1]-=BITA_ddot(i,x+n-1,1,e+n-i-1+(n-1)*n,n);
	}
}
extern "C" DLLEXPORT void solveT(dimen n,vector e,vector x)
{
	//Solve with the triangle from gramS
	size_t i;
	for(i=1;i<n;++i)
	{
		//for(j=0;j<i;++j)
		//	x[i]-=x[j]*e[j+i*n];
		x[i]-=ddotvec(i,x,e+i*n);
	}
}
extern "C" DLLEXPORT void inverseT(dimen n,vector e,vector em1=0)
{
	//Inverse of the triangular matrix from gramS
	size_t n2=n*n,i,j;
	if(em1)//If em1 is null then put the inverse in the unused triangle of e
	{
		dzerovec(n2,em1);
		for(i=0;i<n;++i)
		{
			em1[i+i*n]=1;
		}
	}
	if(em1)
	{
		for(i=1;i<n;++i)
		{
			for(j=0;j<i;++j)
			{
				em1[j+i*n]-=e[j+i*n];
				/*for(k=j+1;k<i;++k)
				{
					em1[j+n*i]-=em1[j+n*k]*e[k+i*n];
				}*/
				if(j<i-1)em1[j+n*i]-=BITA_ddot(i-j-1,em1+j+(j+1)*n,n,e+j+1+i*n,1);
			}
		}
	}
	else
	{
		for(i=1;i<n;++i)
		{
			for(j=0;j<i;++j)
			{
				e[i+j*n]-=e[j+n*i];
				/*for(k=j+1;k<i;++k)
				{
					e[i+j*n]-=e[k+n*j]*e[k+i*n];
				}*/
				if(j<i-1)e[i+j*n]-=ddotvec(i-j-1,e+j*n+j+1,e+j+1+i*n);
			}
		}
	}
}
extern "C" DLLEXPORT short gramS(dimen n,vector Q,vector e,vector d,bool* sparse=0)
{
/*#ifdef __SYSNT__
	_ASSERT(0);
#endif*/
	//Decomposition  diag(d) = e'.Q.e   ' means transpose
	size_t n2=n*n,n1=(n*(n+1))>>1,i,j,k;
	std::valarray<double>away(n2),b(n);//,ae(n);
	vector awa,bb;
	bool nob=false;
	short back=n;
	vector em=e,ei;
	b=0;away=0;
	dzerovec(n2,e);
	for(i=0,awa=&away[0];i<n;++i,awa+=(n+1))
	{
		*awa=1;
	}
	*em=1;
	//dsmxmulv(n,Q,em,&b[0]);
	for(i=0,awa=Q,bb=&b[0];i<n;++i,awa+=i,bb++)
		*bb=*awa;
	*d=ddotvec(n,&b[0],&b[0]);
	if(*d<=lm_eps)
	{
		*d=0;
		dzerovec(n,&b[0]);
		nob=true;
	}
	else
	{
		*d=b[0];//*em*b[0];//ddotvec(n,em,&b[0]);
		if(fabs(*d)<=lm_eps)
		{
			nob=false;
			back=1;
		}
		else
		{
			b[0]=1;
			dscalvec(n-1,1./ *d,&b[1]);
			nob=false;
		}
	}

	for(i=1,d++,ei=e+n;i<n;++i,ei+=n,em+=n,d++)
	{
		if(!nob)
		{
			long nblk=256,nproc=8;
#ifdef _OPENMP
			nproc=omp_get_max_threads();
			if(nblk<nproc)
#endif
			if(n-i<1000) nblk=1;
			long iblk,iproc;
			if(nblk==1)
			{
				for(j=0,awa=&away[i*n];j<i;j++,awa++)
				{
					/*if(em[j])
					{
					for(k=0;k<n;++k)
					{
					away[j+k*n]-=b[k]*em[j];
					}
					}*/
					BITA_daxpy(n-i,-em[j],&b[i],1,awa,n);
				}
			}
			else
			{
				if(i>=nblk)
				{
					for(j=0,awa=&away[i*n];j<i;j+=nblk,awa+=nblk)
					{
						/*if(em[j])
						{
						for(k=0;k<n;++k)
						{
						away[j+k*n]-=b[k]*em[j];
						}
						}*/
#pragma omp parallel shared(nproc,nblk,n,i,j,em,b,awa) 
						{
#pragma omp for schedule(dynamic) private(iproc,iblk) nowait
							for(iproc=0;iproc < nproc;iproc++)
							{
								for(iblk=iproc;iblk<nblk;iblk+=nproc)
								{
									if(j+iblk<i)
										BITA_daxpy(n-i,-em[j+iblk],&b[i],1,awa+iblk,n);
								}
							}
						}
					}
				}
				else
				{
					for(j=0,awa=&away[i*n];j<i;j++,awa++)
					{
						/*if(em[j])
						{
						for(k=0;k<n;++k)
						{
						away[j+k*n]-=b[k]*em[j];
						}
						}*/
						BITA_daxpy(n-i,-em[j],&b[i],1,awa,n);
					}
				}
			}
		}
		//ae=0;
		ei[i]=0;//ei[i]=1 is taken care of in daddvec line
		/*if(sparse)
		{
			bool* spa;
			vector eij;
			for(j=0,eij=ei,awa=&away[i*n],spa=sparse+n*i;j<=i;++j,awa++,spa++,eij++)
			{
				if(!*spa)
				{
					//k=i;
					//for(k=0;k<n;++k)
					{
						*eij+=*awa;//away[j+k*n];// *ei[k];
					}
				}
			}
		}
		else*/
		{
			//for(k=0;k<n;++k)
			{
				/*if(ei[k])
				{
				for(j=0;j<n;++j)
				{
				ae[j]+=away[j+k*n]*ei[k];
				}
				}*/
				//daxpyvec(n,ei[k],&away[k*n],&ae[0]);
				daddvec(i+1,&away[i*n],ei,ei);
			}
		}
		//dcopyvec(i+1,&ae[0],ei);
		//dsmxmulv(n,Q,ei,&b[0]);
		for(k=0,awa=Q,bb=&b[0];k<n;++k,awa+=k,bb++)
		{
			*bb=ddotvec(i+1,ei,awa);
		}
		*d=ddotvec(n,&b[0],&b[0]);
		if(*d<=lm_eps)
		{
			*d=0;
			dzerovec(n,&b[0]);
			nob=true;
		}
		else
		{
			*d=b[i];//ei[i]*b[i];//ddotvec(n,ei,&b[0]);
			if(fabs(*d)<=lm_eps)
			{
				nob=false;dzerovec(n,&b[0]);
				if(back>i)
					back=i;
			}
			else
			{
				b[i]=1;
				dscalvec(n-i-1,1./ *d,&b[i+1]);
				nob=false;
			}
		}
	}
	if(back==n)back=0;
	/*size_t zz=0;
	for(i=0;i<n;++i)
	{
		for(j=i+1;j<n;++j)
			if(e[i+j*n]==0)zz++;
	}
	printf((char*)"Number of zeros in factorisation %d\n",zz);*/
	return back;
}

extern "C" DLLEXPORT bool FixGram(dimen n,vector Q)
{
	bool fix=false;//Make Q positive definite using Gram Schmidt conjugate basis Colin 16-4-2014
	size_t n2=n*n,n1=(n*(n+1))>>1,i,j;
	size_t*order=0;
	vector e=new double[n2];
	vector d=new double[n];
	if(true)
	{
		vector w=new double[n];
		vector q;
		for(i=0,q=Q;i<n;++i,q+=i)w[i]=q[i];
		order=new size_t[2*n];
		getorder(n,w,order,0);//Reorder to get the largest diagonal first (make sure Q[0] is non-zero)
		for(i=0;i<n;++i)order[n+order[i]]=i;
		ReorderS(n,order,Q);
		delete [] w;
	}
	short back=gramS(n,Q,e,d); //e.Q.e' = d
	for(i=0;i<n;++i)
	{
		if(d[i]<=lm_eps)
		{
			d[i]=lm_rooteps;fix=true;
		}
	}
	if(fix)
	{
		vector QQ,ee;
		inverseT(n,e);//Now e contains e and inverse(e)
		for(i=0,QQ=Q;i<n;++i,QQ+=i)
		{
			dzerovec(i+1,QQ);
			dzerovec(i,e+i*n);//This part of e contains e, the rest contains inverse(e). We have to zero e part to get the next step correct.
			for(j=0,ee=e;j<=i;++j,ee+=n)
			{
				if(ee[i])daxpyvec(i+1,d[j]*ee[i],ee,QQ);
			}
		}
	}
	if(order)
	{
		ReorderS(n,order+n,Q);
		delete[]order;
	}
	delete[] e;
	delete[] d;
	return fix;
}

void SymmetricSolver::SparseGen(size_t n,vector M)
{
	if(!sparse)
	{
		sparse=new bool[n*n];
	}
	memset(sparse,false,n*n*sizeof(*sparse));
	size_t i,j,k;
	vector MM;
	bool *spal,*spau,*spa;
	size_t remove;
	for(i=0,MM=M;i<n;++i)
	{
		for(j=0,spal=sparse+i,spau=sparse+i*n;j<=i;++j,spal+=n,spau++)
		{
			*spau=!*MM;
			*spal=!*MM++;
		}
	}
	for(i=0;i<n-1;++i)
	{
		remove=0;
		if(sparse[i+(i+1)*n])
		{
			for(j=i+2,spa=sparse+i+j*n;j<n;++j,spa+=n)
			{
				if(!*spa)
				{
					remove=j;break;
				}
			}
			if(remove)
			{
				for(k=remove+1,spa=sparse+i+k*n;k<n;++k,spa+=n)
					*spa=false;
			}
		}
	}
	/*size_t zz=0;
	for(i=0;i<n;++i)
	{
		for(j=i+1;j<n;++j)
			if(sparse[i+j*n])zz++;
	}
	printf((char*)"Number of expected zeros in factorisation %d\n",zz);*/
}
bool SymmetricSolver::Factor(size_t nn,vector MM)
{
	bool first_time=false,notsparse=true,nochange=true;
	n=nn;
	size_t n2=n*n;
	M=MM;
	size_t i,j;
	std::valarray<size_t>w(n);
	bool useorder=true;
	w=(size_t)0;

	for(i=0;i<n;++i) 
	{
		//By counting the zeros and reordering the matrix in this way, we make sure a larger number of zeros are present in the 
		//factorisation. 
		for(j=0;j<=i;++j)
		{
			if(*MM++ == 0)
			{
				notsparse=false;
				if(i!=j)
				{
					w[j]++;
					w[i]++;
				}
			}
		}
	}

	if(useorder)
	{
		long i;
		double Mii;
		if(!order)order=new size_t[2*n];
		size_t*ooi,*ooj,*ook;
		for(i=0,ooi=order;i<n;++i) *ooi++=i;
		for(i=0,ooi=order;i<n;++i,ooi++)
		{
			Mii=M[*ooi*(*ooi+3)/2];
			for(j=i+1,ooj=order+j;j<n;++j,ooj++)
			{
				if(Mii<M[*ooj*(*ooj+3)/2])//Put largest diag at the top of M
				{
					std::swap(*ooi,*ooj);
					Mii=M[*ooi*(*ooi+3)/2];
					nochange=false;
				}
			}
		}


		size_t ij,k,ik,lastn=n;
		size_t lastoffdiag=0;
		bool swapped;
		if(!notsparse)
		{
			for(i=0,ooi=order;i<lastn;++i,ooi++)
			{
				for(j=i+1,ooj=order+j;j<lastn;++j,ooj++)
				{			
					swapped=false;
					if(w[*ooi]<w[*ooj])
					{
						std::swap(*ooi,*ooj);
						nochange=false;
						swapped=true;
					}

					if(*ooi>*ooj)ij=(*ooi*(*ooi+1)>>1) + *ooj;
					else ij=(*ooj *(*ooj+1)>>1) + *ooi;
					lastoffdiag=j;
					if( *ooi!=*ooj && M[ij])
					{
						for(k=j+1,ook=order+k;k<lastn;++k,ook++)
						{
							if(*ooi>*ook)ik=(*ooi*(*ooi+1)>>1) + *ook;
							else ik=(*ook*(*ook+1)>>1) + *ooi;
							if( *ooi!=*ook && M[ik]==0)
							{
								std::swap(*ooj,*ook);nochange=false;//non sparse at k now
								lastoffdiag=k;
								break;
							}
						}
					}

					if(w[*ooi]<w[*ooj])
					{
						std::swap(*ooi,*ooj);
						nochange=false;
						swapped=true;
					}
					/*if(swapped)
					{
						j=i;
						ooj=order+j;
					}*/ // doesn't do anything actually


				}
				//if(M[ij])lastn=lastoffdiag;//makes no difference to number of zeros but orders without paying attention to size of diagonals
				lastn=min(w[*ooi]+1,lastn);
			}
		}
		/*else
			printf((char*)"NOT SPARSE NOT SPARSE NOT SPARSE NOT SPARSE NOT SPARSE NOT SPARSE NOT SPARSE NOT SPARSE NOT SPARSE NOT SPARSE\n");*/
//		for(i=0;i<n;++i)
//			printf((char*)"%d Result i     %d w %d\n",i,order[i],w[order[i]]);

#ifdef REVERSEGROUPS
		//Reverse members of each group of equal w[i] to try to get more sparsity (makes no difference)
		//______________________________________________________________________________________________________________________
		std::map<size_t,size_t> obot;//,otop;
		std::map<size_t,size_t>::iterator find;
		for(i=0;i<n;++i)
		{
			j=n-1-i;
			obot[w[order[i]]]=i;
			//otop[w[order[j]]]=j;
		}

		size_t ngroup=obot.size();

		if(ngroup)
		{
			std::valarray<size_t> group(ngroup);

			for(i=0,find=obot.begin();find!=obot.end();find++,i++)
			{
				group[i]=find->second;
			}

			long next,now,all;
			for(i=0;i<ngroup;++i)
			{
				now=group[i];
				if(i!=(ngroup-1))next=group[i+1];
				else next=-1;
				all=(now-next)/2;
				for(j=0,ooi=order+now,ooj=order+next+1;j<all;++j,ooi--,ooj++)
				{
					std::swap(*ooi,*ooj);
				}
			}
		}
		//______________________________________________________________________________________________________________________
#endif
		if(M[order[0]*(order[0]+3)/2]==0)//Really bad luck if this is true but we have to avoid it
		{
			for(i=0;i<n-1;++i)
			{
				j=n-i-1;
				if(M[order[j]*(order[j]+3)/2]!=0)
				{
					std::swap(order[0],order[j]);break;
				}
			}
		}
		for(i=0;i<n;++i)
			order[n+order[i]]=i;
		ReorderS(n,order,M);
	}
	if(!E){E=new double[n2];first_time=true;}
	if(!D)D=new double[n];
	//if(!sparse&&!notsparse)
	//	SparseGen(n,M);//Exploiting the sparsity explicitly seems to make little difference. The extra zeros are automatically taken care of.
	bool back=gramS(n,M,E,D);//,sparse);
#ifdef USESPARSEVECTOR
	if(!sparse)
		sparse=new bool[n2];
	memset(sparse,false,n2*sizeof(*sparse));
	for(i=0;i<n;++i)
	{
		for(j=1+i;j<n;++j)
			sparse[i+j*n]=E[i+j*n]==0;
	}
#endif
	if(false&&/*first_time &&*/ sparse)
	{
		delete[] sparse;
		sparse=0;
	}
	return back;
}
void SymmetricSolver::Solve(vector x)
{
	size_t i;
	if(order)Reorder(n,order,x);
	if(sparse)
		multTS(n,E,x,sparse);
	else
		multT(n,E,x);
	for(i=0;i<n;++i)
	{
		if(fabs(D[i])>lm_eps)
			x[i]/=D[i];
		else
			x[i]=0;
	}
	if(sparse)
		multTtS(n,E,x,sparse);
	else
		multTt(n,E,x);
	if(order)Reorder(n,order+n,x);
}
SymmetricSolver::SymmetricSolver()
{
	order=0;
	E=0;
	D=0;
	sparse=0;
}
SymmetricSolver::~SymmetricSolver()
{
	if(order){delete [] order;order=0;}
	if(E) {delete [] E;E=0;}
	if(D) {delete [] D;D=0;}
	if(sparse) {delete[] sparse;sparse=0;}
}
extern "C" DLLEXPORT double EndRound(double a)
{
	long long p=a/lm_eps512;//Must use long long if we divide by such a small number when a is not small
	if(p)
	{
		return lm_eps512 * p;
	}
	else 
	{
		return a;
	}
}
extern "C" void UpdateHfromConstraints(dimen n,dimen m,vector x,vector y,vector H,void*info)
{
	size_t nn=n*(n+1)>>1;
	if(m>1)
	{
		size_t i;
		for(i=0;i<n;++i)
			H[i*(i+3)/2]+=2;
	}
}
extern "C" DLLEXPORT int CanCastAsInteger(double *d, double xmin, double xmax) 
{//From SWIG's generated interface file; it might be useful one day
	double x = *d;
	if ((xmin <= x && x <= xmax)) 
	{
		double fx = std::floor(x);
		double rd =  ((x - fx) < 0.5) ? fx : (double)std::ceil(x); /* simple rounded integer */
		if((errno == EDOM) || (errno == ERANGE)) 
		{
			errno = 0;
		}
		else
		{
			double summ, reps, diff;
			if(rd < x) 
			{
				diff = x - rd;
			}
			else if(rd > x) 
			{
				diff = rd - x;
			}
			else
			{
				return 1;//*d looks like an integer
			}
			summ = rd + x;
			reps = diff/summ;
			if(reps < lm_eps8)//SWIG chose the same as I did for rounding checks.
			{
				*d = rd;
				return 1;//*d was very close to being an integer
			}
		}
	}
	return 0;
}
extern "C" double small_round(double eps)
{
	//Return the next lowest multiple of double base
	double reps=lm_eps*std::floor(eps/lm_eps);
	return (fabs(eps-reps)>lm_eps8?eps:reps);//In case eps is too big
}
void newmult(size_t n,vector M,vector x,vector y)
{
	dzerovec(n,y);
/*
	for(j=0;j<n;++j)
	{
		daxpyvec(n,x[j],M+j*n,y);
	}
*/
	BITA_dgemv((char*)"T",n,n,1,M,n,x,1,0,y,1);
//	Integer m=(Integer)n,one=1;
//	double oned=1,zz=0;
//	dgemm_BITA((char*)"T", "N", &m, &one, &m, &oned, M, &m, x, &m, &zz, y, &m);
}
extern "C" size_t num_zeros(size_t n,vector S)
{
	size_t back=0;
	while(n--)
	{
		if(*S==0)back++;
		S++;
	}
	return back;
}
extern "C" void spivsolve(size_t n,vector M,vector b);
extern "C" int trifact(size_t n,double*M,double*A,double*D,double*E);
extern "C" int trisolve(size_t n,double*A,double*D,double*E,double*b);
extern "C" double trace(size_t n,vector Q);
extern "C" void Lsmooth(size_t n,size_t  m,vector w,vector a,
								  vector A,vector b,double gamma=.95,double eps=1e-8,int*sign=0,
								  vector L=0,
								  vector Q=0,size_t nfac=0,vector FL=0,
								  vector FC=0,vector SV=0);
void printnx(size_t n,vector a,const std::string& name);

extern "C" DLLEXPORT short OptimiseGeneral(dimen n,vector w,dimen m,vector A,vector L,vector U,vector c,vector H,pUtility Util,pModC ModDeriv,pModQ ModHessian,
	void *Uinfo,void *Minfo,void *Qinfo)
{
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	/*
	This sets up an optimisation which adds the functions in Util, ModDeriv and ModHessian to a second order function given in c and H.
	In general we probably need to set c and H to zero, since having them non-zero is a bit contrived, but it may be useful so I keep it in.

	If 1st or 2nd (or both) derivatives are not given for Util then finite difference approximations for first derivatives are used and
	BFGS Hessian update is used (starting from unit matrix).

	A starting Hessian could be given by setting hnow below, I could put this later on if necessary.
	*/
#ifdef PAS
//	UnlockBita((char*)"colincolin");
	if(!Optimise::bitago)
	{
		fprintf(stderr,(char*)"Bad PAS key\n");
		return -1;
	}
	return -1;
#endif
	double gamma=0.5,ogamma;
	std::valarray<double>initial(n);initial=0;
	std::valarray<int>shake(n);shake=-1;
	ForUpdates Passer;
	Passer.Util=Util;
	Passer.Uinfo=Uinfo;
	Passer.BFGS=ModHessian?false:true;
	Passer.ModDeriv=ModDeriv?ModDeriv:0;
	if(Passer.ModDeriv)
		Passer.gradinfo=Minfo;
	std::valarray<double>xnow,xpast,gnow,gpast,hnow;
	if(Passer.BFGS)
	{
		hnow.resize(n*(n+1)>>1);Passer.hnow=&hnow[0];
		xnow.resize(n);Passer.xnow=&xnow[0];
		xpast.resize(n);Passer.xpast=&xpast[0];
		gnow.resize(n);Passer.gnow=&gnow[0];
		gpast.resize(n);Passer.gpast=&gpast[0];
		Passer.count=0;
	}
	std::valarray<double>cc,hh;
	if(!c)//This is really -c since it is in the same place as alpha below!!!!!
	{
		cc.resize(n);cc=0;
		c=&cc[0];
	}
	if(!H)
	{
		hh.resize(n*(n+1)>>1);hh=0;
		H=&hh[0];
	}
	short back= Optimise_internalCVPAextcostslSaMSoft(n,-1,0,w,m,A,L,U,c,0,H,gamma,&initial[0],-1,.5,-1,-1,0,0,0,0,1,-1,-1,0,0,0,&shake[0],0,0,1,0,0,0,0,0,0,0,0,
		Util,FiniteDiffGrad,ModHessian?ModHessian:BFGSHess,-1,-1,&ogamma,Uinfo,&Passer,ModHessian?Qinfo:&Passer,0,0,0,0);
		
	if(false&&Passer.BFGS)//Print out the updated Hessian and its eigenvalues for debug
	{
		size_t nn=n*(n+1)>>1;
		printnx(nn,Passer.hnow,(char*)"Final BFGS Hessian ...");
		std::valarray<double>st(n*n),eig(n);
		dcopyvec(nn,Passer.hnow,&st[0]);
		packed2symm(n,&st[0]);
		short ee=eigendecomp(n,&st[0],&eig[0],100);
		if(!ee)
		{
			printnx(n,&eig[0],(char*)"... and its eigenvalues.");
		}
	}
	return back;
}

#if !(_WINDOWS || __cplusplus >= 201402L)
//template <typename T> inline const T max(T a,T b){return (a<b)?b:a;}
//template <typename T> inline const T min(T a,T b){return (a>b)?b:a;}
template <typename T> inline const T square(T a){return a*a;}
#else
auto square=[](auto a){return a*a;};
auto min=[](auto a,auto b){return(a>b)?b:a;};
auto max=[](auto a,auto b){return(a<b)?b:a;};
#endif
extern "C" DLLEXPORT void clean_w(size_t n,vector w)
{
	while(n--)
	{
		if(fabs(*w)<=lm_rooteps) *w=0;
		w++;
	}
}
class directioninfo
{
public:
	size_t n;
	vector xstart;
	vector step;
	pUtility util;
	void* info;
	double* flow;
	vector xlowest;
	bool failed;
	size_t funcount;
	double A;
	double B;
};

template<typename T> void vecminmax(size_t n,T* a,T& mx,T& mn)
{
	mx=mn=*a;
	while(n--)
	{
		mx=max(*a,mx);
		mn=min(*a,mn);
		a++;
	}
}
inline void screenmax(size_t n,vector x,double&xmax)
{
	xmax=-lm_max;
	while(n--)
	{
		if(*x<1e10)
		{
			xmax=dmax(xmax,*x);
		}
		x++;
	}
}
inline void screen(size_t n,vector deriv)
{
	//	double xmax;
	//	screenmax(n,deriv,xmax);
	while(n--)
	{
		if(*deriv>1e10){*deriv=0;}
		deriv++;
	}
}
inline void resetH(size_t n,vector H)
{
	size_t i,j;
	dzerovec(n*(n+1)/2,H);
	for(i=0,j=0;i<n;++i,j+=(i+1)){H[j]=1;}
}
inline void update(size_t n,vector H,vector a,double bot)
{
	size_t i,j;
	vector a1,a2;
	for(i=0,a1=a;i<n;++i,a1++)
	{
		for(j=0,a2=a;j<=i;++j,a2++)
		{
			*H++ +=(*a1* *a2)/bot;
		}
	}
}
inline void update1(size_t n,vector H,vector delta,vector gamma,vector space)
{
	dsmxmulv(n,H,gamma,space);
	dsubvec(n,delta,space,space);
	double bot=ddotvec(n,space,gamma);
	update(n,H,space,bot);
}
inline void update2(size_t n,vector H,vector delta,vector gamma,vector space)
{
	double bot=ddotvec(n,delta,gamma);
	if(bot<0)return;
	dsmxmulv(n,H,gamma,space);
	update(n,H,delta,bot);
	bot=ddotvec(n,space,gamma);
	update(n,H,space,-bot);
}
void printsym(size_t n,vector a)
{
	size_t i,j;
	printf((char*)"\e[1;1;31m");
	for (i=0;i<n;++i)
	{
		for(j=0;j<=i;++j)
		{
			printf((char*)"%20.12e ",*a++);
		}
		printf((char*)"\n");
	}
}
void printx(size_t n,vector a)
{
    size_t i=0;
	printf((char*)"\e[1;1;31m");
    while(n--)
	{
		printf((char*)"%10.5e ",*a++);
		if(i++%5==4)printf((char*)"\n");
    }
	printf((char*)"\e[0;m\n");
}
void printx(size_t n,vector a,size_t skip)
{
    size_t i=0;
	printf((char*)"\e[1;1;31m");
    while(n--)
	{
		printf((char*)"%21.13e ",*a);
		a+=skip;
		if(i++%5==4)printf((char*)"\n");
    }
	printf((char*)"\e[0;m\n");
}
void printnx(size_t n,vector a,const std::string& name)
{
    size_t i=0;
	printf((char*)"\e[1;1;31m");
	printf((char*)"%s\n",name.c_str());
    while(n--)
	{
		printf((char*)"%21.13e ",*a++);
		if(i++%5==4)printf((char*)"\n");
    }
	printf((char*)"\e[0;m\n");
}
void printx(size_t n,vector a,void* info)
{
    size_t i=0;
	printf((char*)"\e[1;1;31m");
	class Base_Optimise*Info=(class Base_Optimise*)info;
    while(n--)
	{
		Info->AddLog((char*)"%21.13e ",*a++);
		if(i++%5==4)printf((char*)"\n");
    }
	printf((char*)"\e[0;m\n");
}
inline void keepx(size_t n,double& flow,double f,vector xlow,vector x)
{
	if(f<flow-lm_eps8)
	{
		flow=f;
		dcopyvec(n,x,xlow);
	}
}
inline double searchfunc(double delta,void *info)
{
	directioninfo* Info=(class directioninfo*)info;
	std::valarray<double> x(Info->n);
	
	dcopyvec(Info->n,Info->xstart,&x[0]);
	daxpyvec(Info->n,delta,Info->step,&x[0]);
	double fhere=Info->util(Info->n,&x[0],Info->info);
	Info->funcount+=1;
	keepx(Info->n,*(Info->flow),fhere,Info->xlowest,&x[0]);
	return fhere;
}

inline void deriv(size_t n,vector x,vector grad,pUtility func,void*info,int twoside=0)
{
	directioninfo* Info=(class directioninfo*)info;
	std::valarray<double> xp(n);
	size_t i;
	double eps = lm_rooteps,f0=0,f1,f2,teps=2*eps;
	if(!twoside)
	{
		f0=func(n,x,Info->info);
		keepx(n,*(Info->flow),f0,Info->xlowest,x);
		Info->funcount+=1;
	}
	
	dcopyvec(n,x,&xp[0]);
	for(i=0;i<n;++i)
	{
		xp[i]+=eps;
		f1=func(n,&xp[0],Info->info);
		keepx(n,*(Info->flow),f1,Info->xlowest,&xp[0]);
		if(!twoside)
		{
			grad[i]=(f1-f0)/eps;
			xp[i]-=eps;
		}
		else
		{
			xp[i]-=2*eps;
			f2=func(n,&xp[0],Info->info);
			keepx(n,*(Info->flow),f2,Info->xlowest,&xp[0]);
			grad[i]=(f1-f2)/teps;
			xp[i]+=eps;
		}
	}
	Info->funcount+=n;
}

inline double ParabMinPoint(double d1,double d2,double d3,p1DFunc f,void* info)
{
	directioninfo* Info=(class directioninfo*)info;
	double F1=f(d1,info),F2=f(d2,info),F3=f(d3,info),pmin;
	
    Info->A = (F1*(d2-d3)+F3*(d1-d2)+F2*(d3-d1))/(d1-d3)/(d2-d3)/(d1-d2);
    Info->B = (F1-F3)/(d1-d3)-Info->A*(d1+d3);
	
	if(Info->A<lm_eps)
	{
		pmin=-1;
		if(f(pmin,info)>F1)
			Info->failed=1;
		else
			Info->failed=0;
		return pmin;
	}
	else 
	{
		pmin=-0.5*Info->B/Info->A;
		if(f(pmin,info)>F1)
			Info->failed=1;
		else
			Info->failed=0;
		return pmin;
	}
}
inline bool lookmore(size_t n,vector x,pUtility func,void*info,int print=0)
{
	//If func has holes in it, it will be possible for the first derivatives to be very small
	//but for a lower value to be found at the edge of a hole where the first derivatives may not be
	//zero. Here we try to do something to find a lower function value. Sometimes it works well,
	//sometimes......
	return 1;
	directioninfo* Info=(class directioninfo*)info;
	bool done=0;
	size_t cant;
	double pmin,flow=*(Info->flow);
	std::valarray<double> xp(n);
	long i;
	Info->xstart=x;
	for(i=n-1,cant=0;i>=0;--i)
	{
		if(fabs(Info->xlowest[i])<lm_rooteps){cant++;continue;}
		dsetvec(n,fabs(Info->xlowest[i]),&xp[0]);
		xp[i]=0;
		Info->step=&xp[0];
		pmin=PathMin(searchfunc,0,-1,1e-1,Info);
		if(print)
		{
			printf((char*)"lookmore %4ld %20.12f %20.12e\n",i+1,pmin,*(Info->flow));
		}
		if(flow>(*Info->flow)+lm_eps)
		{
			done=1;break;
		}
	}
	if(cant==n)
		return 0;
	else
	{
		if(!done)
			return 0;
		if(print)printf((char*)"Search lowest %20.12e\n",*Info->flow);
		dsubvec(n,Info->xlowest,x,&xp[0]);
		dcopyvec(n,Info->xlowest,x);
		Info->step=&xp[0];
		double pmin=PathMin(searchfunc,10,-10,1e-4,Info);
		if(print)printf((char*)"(look more) min. point on new path %20.12e; lowest %20.12e\n",pmin,*Info->flow);
		return flow<=(*Info->flow);
	}
}
inline short snyman(size_t n,vector x,double dt,vector dvdt,vector v,pUtility func,void* info,
					size_t maxiter,int print=0)
{
	//dvdt is really minus acceleration, hence the minus in the equation for velocity below.
	double kineticenergy=0,change;
	
	//Initialise the dynamics
	if(ddotvec(n,dvdt,dvdt)<=lm_eps8)
		deriv(n,x,dvdt,func,info);
	//	screen(n,dvdt);
	dzerovec(n,v);
	//Solve equations of motion
	daxpyvec(n,-dt,dvdt,v);
	daxpyvec(n,dt,v,x);
	//Find the kinetic energy
	change=ddotvec(n,v,v)-kineticenergy;
	//If the kinetic energy increases, then by conservation of energy, the potential energy (the function
	//we wish to minimise) must decrease. If we are not at the minimum at the start then this must happen
	//at the first stage since we initialise the path with zero velocity (kinetic energy).
	//Note that all the the theory assumes exact derivatives and solution of equations of motion. The
	//conservation of energy is not guaranteed for approximate solutions and seems not to work at all
	//for approximate derivatives, but even with these failings it can lead to a lower objective function
	//when used with other methods.
	while(maxiter--)
	{
		kineticenergy+=change;
		if(print)printf((char*)"Kinetic Energy %20.12e\n",kineticenergy);
		//		if(print)printx(n,x);
		//		if(print)printx(n,v);
		//		if(print)printx(n,dvdt);
		//Get new force vector (= acceleration on unit mass)
		deriv(n,x,dvdt,func,info);
		//		screen(n,dvdt);
		if(ddotvec(n,dvdt,dvdt)<=lm_eps8)
		{
			if(print)printf((char*)"Converged\n");
			return 0;
		}
		//Solve equations of motion
		daxpyvec(n,-dt,dvdt,v);
		daxpyvec(n,dt,v,x);
		//Find the kinetic energy
		change=ddotvec(n,v,v)-kineticenergy;
		//Restart the system with zero kinetic energy if it has gone down, then it must increase next time unless
		//the potential energy minimum has been found.
		if(change<0)
		{
			dzerovec(n,v);
			kineticenergy=0;
			change=0;
		}
	}
	return 1;
}


short QuasiNewton(size_t n,vector x,int print,size_t maxiter,
				  double *f,pUtility func,void*info,double conv,
				  int method,int twosided,double stoplimit)
{
	//Quasi Newton Method 22-6-2004 Colin
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	conv=small_round(conv);
	size_t iter=0;
	double flowest=1e66,fprev=1e67,pmin,ap=.1,switchtest=0,derivnorm=0,mmax,mmin;
	bool newtonOK=0,toolarge=0;
	directioninfo sInfo;
	sInfo.info=info;
	sInfo.n=n;
	sInfo.util=func;
	sInfo.funcount=0;
	
	std::valarray<double>work(n*(n+1)/2+4*n);
	vector H=&work[0],xlowest=&work[n*(n+1)/2],grad=&work[n*(n+1)/2+n],gamma=&work[n*(n+1)/2+2*n],delta=&work[n*(n+1)/2+3*n];
	
	sInfo.flow=&flowest;
	sInfo.xlowest=xlowest;
	
	
	
	resetH(n,H);	
	double newtongrad=1;
	while(fprev>flowest && iter < maxiter && (switchtest=fabs((flowest-fprev)/dmax((fabs(flowest)),1.0)))>n*conv)
	{
		if(iter)
		{
			dxminmax(n,xlowest,1,&mmax,&mmin);
			if(mmax>stoplimit) {toolarge=1;break;}
		}
		if(print)
			printf((char*)"============== conv %20.12e ===================\n",switchtest);
		fprev=flowest;
		deriv(n,x,grad,func,&sInfo,twosided);
		derivnorm=ddotvec(n,grad,grad)/n;
		if(print)
			printf((char*)"average derivative norm2 %20.12e\n",derivnorm);
		if(iter&&derivnorm<=lm_eps8)
		{
			if(lookmore(n,x,func,&sInfo,print))
				break;
		}
		
		if(!newtonOK&&derivnorm<1e-6&&iter)
		{
			if(print)printf((char*)"====================\n=Allow Newton steps=\n====================\n");
			newtonOK=1;newtongrad=dmin(newtongrad,derivnorm);
		}
		else if(newtonOK&&derivnorm>1e-4)
		{
			newtonOK=0;
			resetH(n,H);
			if(print)printf((char*)"====================\n=Stop  Newton steps=\n====================\n");
		}
		/*		else if(newtonOK && derivnorm>newtongrad && derivnorm>1e-9)
		{
		newtonOK=0;
		if(print)printf((char*)"====================\n=Stop  Newton steps=\n====================\n");
		}
		if(newtonOK)
		newtongrad=min(newtongrad,derivnorm);*/
		if(newtonOK)
			dsmxmulv(n,H,grad,delta);
		else
			dcopyvec(n,grad,delta);
		
		
		sInfo.xstart=x;
		sInfo.step=delta;
		pmin=ParabMinPoint(0,ap,2*ap,searchfunc,&sInfo);
		if(!sInfo.failed && pmin<-lm_rooteps && newtonOK)
		{
			if(print)
				printf((char*)"parabola step %20.10e\n",pmin);
			dscalvec(n,pmin,delta);
			daddvec(n,x,delta,x);
			deriv(n,x,gamma,func,&sInfo,twosided);
			dsubvec(n,gamma,grad,gamma);
			switch(method)
			{
			case 1:
				update1(n,H,delta,gamma,grad);
				break;
			case 2:
				update2(n,H,delta,gamma,grad);
				break;
			default:
				update1(n,H,delta,gamma,grad);
			}
		}
		else
		{
			if(switchtest<lm_rooteps&&derivnorm>1e-2 || !newtonOK)
				pmin=1;
			else
			{
				printf((char*)"Pathmin start\n");
				pmin=PathMin(searchfunc,0,-10,1e-4,&sInfo);
				printf((char*)"Pathmin end\n");
			}
			if(pmin<-lm_rooteps)
			{
				if(print)
					printf((char*)"path min step %20.10e\n",pmin);
				dscalvec(n,pmin,delta);
				daddvec(n,x,delta,x);
				deriv(n,x,gamma,func,&sInfo,twosided);
				dsubvec(n,gamma,grad,gamma);
				switch(method)
				{
				case 1:
					update1(n,H,delta,gamma,grad);
					break;
				case 2:
					update2(n,H,delta,gamma,grad);
					break;
				default:
					update1(n,H,delta,gamma,grad);
				}
			}
			else
			{
				sInfo.xstart=x;
				sInfo.step=grad;
				double flow=flowest;
				if(derivnorm<1e15)
				{
					pmin=PathMin(searchfunc,10,-10,1e-4,&sInfo);
					if(print)
						printf((char*)"steepest descent step %20.10e\n",pmin);
				}
				if(fabs((flow-flowest)/dmax((fabs(flowest)),1.0))<lm_rooteps && derivnorm > 1)
				{
					screen(n,grad);
					pmin=PathMin(searchfunc,10,-10,1e-4,&sInfo);
					if(print)
						printf((char*)"screened steepest descent step %20.10e\n",pmin);
				}
				if(fprev==flowest||fabs(pmin)<lm_rooteps)
				{
					if(lookmore(n,x,func,&sInfo,print) && (fprev-flowest<=lm_eps8))
						break;
					//_______________________________________________________________________________________
					/*					dcopyvec(n,xlowest,x);dzerovec(n,grad);
					if(!snyman(n,x,.1,grad,delta,func,&sInfo,100,print))
					{
					if(print)
					printf((char*)"Dynamic step converged\n");
					double fnow=func(n,x,info);
					if(print)
					printf((char*)"dynamic value %20.12e\n",fnow);
					keepx(n,flowest,fnow,xlowest,x);
				}*/
					//_______________________________________________________________________________________
				}
			}
		}
		if(!newtonOK)
		{
			dsubvec(n,xlowest,x,delta);
			dcopyvec(n,xlowest,x);
			sInfo.step=delta;
			pmin=PathMin(searchfunc,10,-10,1e-4,&sInfo);
			if(print)printf((char*)"min. point on new path %20.12e; lowest %20.12e\n",pmin,flowest);
		}
		
		dcopyvec(n,xlowest,x);	
		iter++;
		if(print)
		{
			printf((char*)"iteration %d, %d function evaluations, lowest %20.10e\n",iter,sInfo.funcount,flowest);
			printx(n,xlowest);
		}
		if(!(fprev>flowest && (switchtest=fabs((flowest-fprev)/dmax((fabs(flowest)),1.0)))>n*conv))
			lookmore(n,x,func,&sInfo,print);
		else if(!(iter%10))
			lookmore(n,x,func,&sInfo,print);
	}
	
	if(print)
		printf((char*)"============== conv %20.12e ===================\n",switchtest);
	*f=flowest;
	dcopyvec(n,xlowest,x);	
	if(toolarge) return 2;
	if(iter<maxiter&&(switchtest<n*conv||derivnorm<=lm_eps8))
		return 0;
	else
		return 1;
}
inline double norm(dimen n,vector x)
{
	double s=0;
	dimen n1=n;
    while(n--)
	{
        s+=fabs(*x++);
	}
    return s/n1;
}
void diag_mult(dimen n,vector D1,vector D2,vector r)
{
	while(n--)
		*r++ = *D1++ * *D2++;
}
void diag_div(dimen n,vector D1,vector D2,vector r)
{
	while(n--)
		*r++ = *D1++ / *D2++;
}
inline void dscladdvec(dimen n,double a,vector x,vector y,vector z)
{
	while(n--)
	{
		*z++ = a**x++ + *y++;
	}
}
void SSmult(dimen n,dimen n1,dimen n2,dimen n3,vector Q,vector x,vector y,void* ii)
{
	dsmxmulv(n,Q,x,y);
}
short conj_solve(dimen n,vector M,vector y,vector x,dimen ndiag,pHmul Qmul,void* info,
				int usediag,int log)
{
#ifdef __SYSNT__
	//	_ASSERT(0);
#endif
	/*
	Solve Matrix equations using the preconditioned conjugate gradient method
	*/
	if(n == 1)//Not necessary but quicker
	{
		dimen nn = n + ndiag;
		while(nn--)
			*x++ = *y++ / *M++;
		return 0;
	}
	
    double ny = norm(n,y),nr,rq,a,b;
    double eps = lm_rooteps*n*ny,div;
	
	std::valarray<double>vr(n);
    vector r = &vr[0];
	
	std::valarray<double>vAp(n);
    vector Ap = &vAp[0];
	
	std::valarray<double>vp(n);
    vector p = &vp[0];
	
	std::valarray<double>vq(n);
    vector q = &vq[0];
	
	std::valarray<double>vdiag(n);
    vector diag = &vdiag[0];	//The preconditioning matrix is chosen as inverse(diag(|M|))
    dzerovec(n,diag);
    
	dimen i,j;
	
	if(usediag!=0)
	{
		for(i = 0,j=0;i < n;++i,j+=(i+1))
		{
			div = ((usediag==2)?M[i]:M[j]);
			if(fabs(div*(1-lm_rooteps)) > lm_rooteps)
				diag[i] = 1.0 / div;
			else if(div>=0)
				diag[i] = 1.0/lm_rooteps;
			else if(div<0)
				diag[i] = -1.0/lm_rooteps;
		}
	}
	else
		dsetvec(n,1,diag);
	
    dimen k = 0,repeat=1;
    
	double nx=norm(n,x);
    if(nx < 1e-10)
        x[0]=1;  //We must not have the zero vect as the initial guess
	else if(nx > 1e10)
	{
		dzerovec(n+ndiag,x);
		x[0]=1;
	}
	
	do
	{
		if(k!=0) repeat=0;
		k=0;
		Qmul(n,1,1,1,M,x,r,info);
		dsubvec(n,y,r,r);
		nr = norm(n,r);
		diag_mult(n,diag,r,q);
		dcopyvec(n,q,p);
		
		rq=ddotvec(n,r,q);
		
		while((nr) > eps && k < n)  //It must converge in at least n iterations!
		{
			Qmul(n,1,1,1,M,p,Ap,info);
			a = ddotvec(n,r,q) / ddotvec(n,p,Ap);
			dscladdvec(n,a,p,x,x);
			dscladdvec(n,-a,Ap,r,r);
			nr = norm(n,r);
			diag_mult(n,diag,r,q);
			b = 1.0 / rq;
			rq = ddotvec(n,r,q);
			b *= rq;
			dscladdvec(n,b,p,q,p);
			k++;
		}
		
		if(log&&(k < n))
			printf((char*)"+++++++++++++ Needed only %4ld conjugate iterations out of %4ld\n",k,n);
		
		if(log&&(nr > eps))
			printf((char*)"+++++++++++++ Conjugate gradient method failed, residual is %-.8e per %-.8e\n",nr,ny);
	}
	while(nr>eps && repeat && (nx=norm(n,x))>1e-10);
	
	if(ndiag > 0)
	{
		vector rr=x+n,vv=y+n,LL=M+n*(n+1)/2;
		for(k = 0;k < ndiag;++k)
			*rr++ = *vv++ / *LL++;
	}
	if(nr > eps) return 1;
	else return 0;
}
extern "C" DLLEXPORT void	symm_inverse_x(size_t n,vector Q,vector x,vector Qm1x)
{
/*
This does not need Q to be postive definite
	*/
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	dimen nn = (n * (n + 1)) >> 1;
	std::valarray<double>Qcopy(nn);
	std::valarray<short_scl>P(n);
	dcopyvec(nn,Q,&Qcopy[0]);
	dsmxfac(n,&Qcopy[0],&P[0]);
	if(x!=Qm1x)dcopyvec(n,x,Qm1x);
	dsmxainv(n,&Qcopy[0],&P[0],Qm1x);
}

template <typename T> void minmax(size_t n,const T* a,T& amin,T& amax)
{
	amin = 1e16;
	amax = - amin;
	while(n--)
	{
		if(*a > amax)
			amax = *a;
		if(*a < amin)
			amin = *a;
		a++;
	}
}
inline void update_KKTQ(size_t n,vector Q,vector XS,bool plus=0)
{
	size_t i=0;
	while(n--)
	{
		*Q+=(plus?*XS++:-*XS++);
		i++;
		Q+=i+1;
	}
}
//We use chort instead of bool because the definition of bool in perl on NT messes things up
//and leads to link errors
void Base_Optimise::update_with_higher(size_t nn,vector Higher,vector Q,short plus)
{
	size_t i=0;
	while(nn--)
	{
		*Q+=(plus?*Higher:-*Higher);
		Q++;
		i++;
		Higher+=i+1;
	}
}
void Optimise::update_with_higher(size_t nn,vector Higher,vector Q,short plus)
{
	if(hess_choice==1)
		Base_Optimise::update_with_higher(nn,Higher,Q,plus);
	else if(hess_choice==2 || hess_choice==4||hess_choice==3)
	{
		size_t i,j;
		for(i = 0,j=0;i < nbefore;++i,Higher+=i+1)
		{
			Q[i] += (plus?*Higher:-*Higher);
			if(lab[j] == i)
			{
				Q[nbefore+j++]+= (plus?*Higher:-*Higher);
			}
		}
	}
	else if(hess_choice == 5)
	{
		size_t i,jm=0,jr=0,zeroinit_here=0;
		for(i = 0;i < nbefore;++i,Higher+=i+1)
		{
			//long buy
			if(lab && lab[jm]==i && jm < lsi && labrev && labrev[jr]==i && jr < revi)
			{
				if(initial[i]<0)
					Q[nbefore+jm-zeroinit_here]+= (plus?*Higher:-*Higher);//short buy
				else if(initial[i]>0)
					Q[nbefore+jm-zeroinit_here]+= (plus?*Higher:-*Higher);//long sell
				else
					zeroinit_here++;
				jm++;
				Q[nbefore+lsi-zeroinit+jr++]+= (plus?*Higher:-*Higher);//short sell
			}
			else if(lab && lab[jm]==i && jm < lsi)
			{
				Q[nbefore+jm++-zeroinit_here]+= (plus?*Higher:-*Higher);
			}
			else if(labrev && labrev[jr]==i && jr < revi)
			{
				Q[nbefore+lsi-zeroinit+jr++]+= (plus?*Higher:-*Higher);
			}
		}
	}
}
inline double scalecheck(dimen n,vector x,vector dx,vector bound=0,short* xsign=0)
{
    double scale = 1e20,xx,dxx;
	bool usebound=bound!=0;
	bool usesign=xsign!=0;
    while(n--)
	{
		xx=*x-(usebound?*bound:0);
		if(usesign)
			xx *= *xsign;
		dxx=(usesign?*xsign++ * *dx:*dx);
		/*		if(fabs(dxx) < lm_eps)
		*dx=0;
        else*/ if((xx+scale*dxx) < 0)
		scale = dmin(-xx / dxx,scale);
		x++;
		dx++;
		if(usebound)bound++;
	}
    return scale;
}
inline double midpoint(double a,double b){return (a+b)*.5;}
class KKTinfo
{
public:
	class Base_Optimise* opt;
	size_t n;
	size_t m;
	size_t slack;
	size_t* slackind;
	vector A;
	vector diagSL;
	vector diagSU;
};
void KKT_Q_mult(dimen n,dimen n1,dimen n2,dimen n3,vector H,vector x,vector y,void*info)
{
	class KKTinfo* Oinfo=(class KKTinfo*)info;
	class Base_Optimise*Opt=Oinfo->opt;
	size_t i;
	vector py,pA,px;
	
	if(!Opt->lp_really)
		Opt->qphess(Oinfo->n,n1,n2,n3,Opt->H,x,y);
	else
		dzerovec(Oinfo->n,y);
	
	for(i=0,pA=Oinfo->diagSL,py=y,px=x;i<Oinfo->n;i++)
		*py++ += *px++ * *pA++;
	for(i=0,pA=Oinfo->diagSU,py=y,px=x;i<Oinfo->n;i++)
		*py++ += *px++ * *pA++;
	
	for(i=0,pA=Oinfo->A,py=y+Oinfo->n+Oinfo->slack;i<Oinfo->m;++i,py++,pA++)
	{
		*py = -BITA_ddot(Oinfo->n,pA,Oinfo->m,x,1);
	}
	
	for(i=0,py=y,pA=Oinfo->A;i<Oinfo->n;++i,py++,pA+=Oinfo->m)
	{
		*py+= -ddotvec(Oinfo->m,pA,x+Oinfo->n+Oinfo->slack);
	}
	if(Oinfo->slack)
	{
		size_t ic;
		for(i=0,py=y+Oinfo->n,px=x+Oinfo->n,pA=Oinfo->diagSL+Oinfo->n;i<Oinfo->slack;++i)
			*py++ = *px++ * *pA++;
		for(i=0,py=y+Oinfo->n,px=x+Oinfo->n,pA=Oinfo->diagSU+Oinfo->n;i<Oinfo->slack;++i)
			*py++ += *px++ * *pA++;
		
		for(i=0;i<Oinfo->slack;++i)
		{
			ic=Oinfo->slackind[i];//ic is constraint index, i is slack index
			//Extra for Ax
			y[ic+Oinfo->n+Oinfo->slack]+=x[i+Oinfo->n];//because the slack coef is -1
			//Extra for ATl
			y[i+Oinfo->n]+=x[ic+Oinfo->n+Oinfo->slack];
		}
	}
}
inline void smallfiddle(size_t n,vector x,vector l=0,int limit=1)
{
	bool usel=l!=0;
	double ll=0,testlim=lm_eps8*limit;
	while(n--)
	{
		if(usel)ll=*l;
		if(fabs(*x-ll)<=testlim)
		{
			if(*x-ll > 0)
				*x=ll+testlim;
			else
				*x=ll-testlim;
		}
		x++;
		if(usel)l++;
	}
}

inline double prodmax(size_t n,vector a,vector b)
{
	double back=0;
	while(n--)
	{
		back=dmax(fabs(*a * *b),back);
		a++;b++;
	}
	return back;
}

inline void guess_setS(size_t NN,size_t slack,double firstmu,
					   vector X,vector S,vector SU,vector LL,vector UU,vector slackU,double compensate=100)
{
	double test;
	compensate*=lm_eps;
	while(NN--)
	{
		if((test=*X-*LL)<=lm_eps)
			*X=*LL+compensate;
		if((test=*X-*UU)>=-lm_eps)
			*X=*UU-compensate;
		*S++=firstmu/(*X-*LL++);
		*SU++=firstmu/(*X++-*UU++);
	}
	while(slack--)
	{
		if((test=*X)<=lm_eps)
			*X=compensate;
		if((test=*X-*slackU)>=-lm_eps)
			*X=*slackU-compensate;
		*S++= firstmu / *X;
		*SU++=firstmu/(*X++-*slackU++);
	}
}

short Base_Optimise::OptInterior(dimen NN,dimen MM,vector XX,vector AA,vector LL,vector UU,
								 vector CC)
{
	short messlevel=0;
	short round_result=this->round_result;
//	SparseLDL SparseStuff;
	
	//If the optimal number of non-zero weights is less than NN and
	//if we round the result to make variables which are close to bounds equal to bounds
	//a result with poorer utility will be obtained, but it will look nicer.
	//If a basket constraint is then applied to get the number of variables with weight
	//greater than e.g. 1e-6 correct then the result is likely to have a utility closer to the
	//proper, feasible result that the interior point method can only get arbitrarilly close to.
	//For this we would set round_result to 1.
	
#if defined(MSDOSS) || defined(_DEBUG) || defined(__linux__)
	messlevel=1;
#endif
	short loglevel=(this->logprint!=0);
	if(loglevel)loglevel+=messlevel;
	short CONJ=this->CONJ;//Only sensible to use conjugate gradients
	if(this->lp_really)CONJ=1;//Only conjugate gradient for lp case
/*
Set up a quadratic optimisation of gx + .5x*Q*x with constraints Ax=b and x>0
L = gx + 0.5*x*Q*x - lamb(Ax-b) - s(x-L) s>0
The dual constraint is g + Qx -lambA -s = 0
and we need to solve the system
							  
-Q   AT   I     x        =  g
A    0    0     lamb        b
S    0    X-L   s           mu
							   
where S is diag(s) and X is diag(x) and lamb(Ax-b) = sx = 0 mu > 0 -> 0
								
-Q-(X-L)'S   AT   x   =   g-(X-L)'mu
A            0    lamb    b
								 
and
								  
s = (X-L)'(mu - Sx)
								   
Update a Quasi-Newton step using
-Q   AT   I     dx        =  g+Qx-ATlamb-s
A    0    0     dlamb        b-Ax
S    0    X-L   ds           mu-S(X-L)
									
									 
-Q-(X-L)'S   AT   dx   =   g+Qx-ATlamb-s - (X-L)'(mu-S(X-L))
A            0    dlamb    b-Ax
									  
and
									   
ds = (X-L)'((mu-S(X-L)) - Sdx)
*/
#if defined( __SYSNT__ ) && ! defined(MINGW32)
	_ASSERT(0);
#else
#define _RPT0(x1,x2)
#define _RPT1(x1,x2,x3)
#define _RPT2(x1,x2,x3,x4)
#define _RPT3(x1,x2,x3,x4,x5)
#define _RPT4(x1,x2,x3,x4,x5,x6)
#endif
	size_t i,slack=0;
	std::vector<size_t>slackind;
	std::vector<double>slackU;
	std::map<size_t,size_t>slackindback;
	for(i=0;i<MM;++i)
	{
		if(LL[NN+i]!=UU[NN+i])
		{
			slackind.push_back(i);//Store constraint number
			slackU.push_back(UU[NN+i]-LL[NN+i]);
		}
	}
	slack=slackind.size();
	for(i=0;i<slack;++i)
	{
		slackindback[slackind[i]]=i+1;//Get the slack number +1
	}
	
	_RPT1(_CRT_WARN,(char*)"Number of slack variables %d\n",slack);
	size_t nqq=(((NN+MM+slack)*(NN+MM+slack+1))>>1),j,k;
	std::valarray<double> Q,base((NN+MM+slack)*2);
	
	if(!CONJ)
	{
		try
		{
			Q.resize(nqq);
		}
		catch(...)
		{
			AddLog((char*)"n=%lu. Could not allocate %u bytes\n",NN,nqq*sizeof(double));
			throw MemProb((char*)"Memory problem for Q in BaseOptimise::OptInternal()",nqq*sizeof(double),NN);
		}
	}
	else
	{
		try
		{
			Q.resize(NN+MM+slack);
		}
		catch(...)
		{
			AddLog((char*)"n=%lu. Could not allocate %u bytes\n",NN,(NN+MM+slack)*sizeof(double));
			throw MemProb((char*)"Memory problem for Q in BaseOptimise::OptInternal()",(NN+MM+slack)*sizeof(double),NN);
		}
	}
	
	Q=0;
	vector pQ,pA;
	
	class KKTinfo Info;
	Info.A=AA;
	Info.n=NN;
	Info.m=MM;
	Info.slack=slack;
	Info.slackind=0;
	if(slackind.size())
		Info.slackind=&(slackind.front());
	Info.opt=this;
	base=0;
	
	
	std::valarray<double> extrag,CCuse(NN);
	
	if(this->ModHessian)
	{
		try
		{
			this->extraH->resize(n*(n+1)/2);
		}
		catch(...)
		{
			AddLog((char*)"n=%lu. Could not allocate %u bytes\n",NN,(n*(n+1)/2)*sizeof(double));
			throw MemProb((char*)"Memory problem for extraH in BaseOptimise::OptInternal()",(n*(n+1)/2)*sizeof(double),NN);
		}
		this->H_from_higher_terms=&(*extraH)[0];
	}
	if(!this->lp_really)
	{
		for(i=0,pQ=&Q[0];i<NN;++i)
		{
			base[i]=1;
			qphess(NN,1,1,1,H,&base[0],&base[NN]);
			base[i]=0;
			if(CONJ)
				*pQ++ = -base[NN+i];
			else
				for(j=0;j<=i;++j){*pQ++=-base[j+NN];}
		}
	}
	if(!CONJ)
	{
		for(i=0,pA=AA,pQ=&Q[0]+(((NN+slack)*(NN+slack+1))>>1);i<MM;pA++,pQ+=NN+i+1+slack,++i)
		{
			dcopy(NN,pA,MM,pQ,1);
			if((j=slackindback[i]))
			{
				pQ[NN+--j]=-1;
			}
		}
	}
	
	
	std::valarray<double>	X(NN+slack),S(2*NN+2*slack),vs(2*NN+2*slack),XdS(2*NN+2*slack),mu(2*NN+2*slack);
	std::valarray<double>	Qx,Ax(MM),Al(NN+slack),resid(NN+MM+slack),Sx(2*NN+2*slack),ds(2*NN+2*slack);
	if(!this->lp_really) Qx.resize(NN);
	std::valarray<short>	ssignU(NN+slack);
	vector r_d=&resid[0],r_p=&resid[NN+slack];
	double sdx,SDX=0;
	
	dcopyvec(NN,CC,&CCuse[0]);
	
	if(this->ModDeriv)
	{
		extrag.resize(NN);
		this->DoExtraIterations=1;
	}
	if(this->ModHessian)
	{
		this->ExtraQx->resize(NN);
	}
	
	vector x=&base[0],s=&vs[0],lambda=&base[NN+slack],dx=&base[NN+MM+slack],dlambda=&base[2*NN+MM+2*slack];
	vector sU=s+NN+slack,dsU=&ds[NN+slack],SU=&S[NN+slack],XdSU=&XdS[NN+slack],SxU=&Sx[NN+slack];
	double firstmu=0.5/(NN+slack);
	ssignU=-1;
	
	double modr0=0,mu0=0,modri,scaler=0,scaleprod;
	//	Set up the initial guess for the variables (must be a feasible guess)	
	
	for(i=0;i<NN;++i)
	{
		X[i]=midpoint(LL[i],UU[i]);//(XX[i]<=LL[i] || XX[i]>=UU[i])?midpoint(LL[i],UU[i]):XX[i];//Use given values if possible
	}
	for(i=0;i<slack;++i)
	{
		X[i+NN]=slackU[i]*.5;
	}
	guess_setS(NN,slack,firstmu,&X[0],&S[0],SU,LL,UU,&slackU[0]);
	
	base=0;
	dcopyvec(NN+slack,&X[0],x);
	dcopyvec(NN+slack,&S[0],s);
	dcopyvec(NN+slack,SU,sU);
	Info.diagSL=&XdS[0];
	Info.diagSU=XdSU;
	
	double gamma=0.5,nb=0,ng=0,comp=0,prim=0,dual=0,grad,pdconv=lm_rooteps,scalemu,scale,scalex,scales,scalexU,scalesU;
	short conv=0;
	double neps=(NN+slack)*lm_eps,nconv=(NN+slack)*pdconv;
	
	double nbold=1e12,ngold=1e12,mu_ratio,murbot=.1,murtop=.7;
	bool resetpath=1;
	short mustreset=0;
	size_t maxiter=200,l,resetj=0,smallstepcount=0;
	std::valarray<double>Qcopy;
	std::valarray<short_scl>P;
	if(!CONJ)
	{
		try
		{
			Qcopy.resize(nqq);
		}
		catch(...)
		{
			AddLog((char*)"n=%lu. Could not allocate %u bytes\n",NN,nqq*sizeof(double));
			throw MemProb((char*)"Memory problem for Qcopy in BaseOptimise::OptInternal()",nqq*sizeof(double),NN);
		}
		try
		{
			P.resize(NN+MM+slack);
			P=0;
		}
		catch(...)
		{
			AddLog((char*)"n=%lu. Could not allocate %u bytes\n",NN,(NN+MM+slack)*sizeof(double));
			throw MemProb((char*)"Memory problem for P in BaseOptimise::OptInternal()",(NN+MM+slack)*sizeof(double),NN);
		}
	}
    for(j = 0;j < maxiter;++j)
	{
        if(loglevel>1)AddLog((char*)"++++++++++++++++++++++ j = %3ld ++++++++++++++++++++++++++++\n",j);
        for(i = 0;i < 2;++i)
		{
			switch(i)
			{
			case 1:
                if(loglevel>1)AddLog((char*)"CORRECTOR step %d; gamma is %-.8e\n",j,gamma);
                sdx = ddotvec(NN,s,x)-ddotvec(NN,s,LL)+ddotvec(NN,sU,x)-ddotvec(NN,sU,UU);
				sdx += ddotvec(slack,x+NN,s+NN)+ddotvec(slack,x+NN,sU+NN);
				sdx-=ddotvec(slack,&slackU[0],sU+NN);
				mu_ratio=dmax(murbot,dmin(sdx/SDX,murtop));
				if(loglevel>1)AddLog((char*)"mu_ratio = %-.8e\n",mu_ratio);
				mu = mu_ratio*SDX/(NN+slack)*.5*(1-gamma);
				
                dcopyvec(NN+slack,&X[0],x);
                dcopyvec(NN+slack,&S[0],s);
                dcopyvec(NN+slack,SU,sU);
				break;
			case 0:
                if(loglevel>1)AddLog((char*)"PREDICTOR step %d\n",j);
				mu = 0.0;
				if(this->ModHessian)
				{
					use_higher_H=1;
					higher_reset=1;
				}
				if(!this->lp_really)qphess(NN,1,1,1,H,x,&Qx[0]);
				if(this->ModHessian)
				{
					use_higher_H=1;//Conjugate gradient solver needs the curvatures at this x
					higher_reset=0;
				}
				if(this->ModDeriv)
				{
					extrag=0;
					ModifyC(NN,H,x,&extrag[0],0);
					daddvec(NN,CC,&extrag[0],&CCuse[0]);
					if(this->ModHessian)
					{
						dsubvec(NN,&CCuse[0],&(*ExtraQx)[0],&CCuse[0]);//Here we need the "excess" first derivatives
					}
				}
				break;
			}
			
            SDX=sdx = ddotvec(NN,s,x)-ddotvec(NN,s,LL)+ddotvec(NN,sU,x)-ddotvec(NN,sU,UU)+
				ddotvec(slack,x+NN,s+NN)+ddotvec(slack,x+NN,sU+NN)-
				ddotvec(slack,&slackU[0],sU+NN);
			
			if(i == 0)
			{
				dcopyvec(NN+slack,x,&X[0]);
				dcopyvec(NN+slack,s,&S[0]);
				dcopyvec(NN+slack,sU,SU);
				
				for(k=0,pA=AA;k<NN;++k,pA+=MM)
				{
					Al[k]=ddotvec(MM,pA,lambda);
				}
				for(l=0;l<slack;++l)
				{
					k=slackind[l];
					Al[NN+l]= -lambda[k];
				}
				
				
				
				for(k=0,pA=AA;k<MM;++k,pA++)
				{
					Ax[k]=BITA_ddot(NN,pA,MM,x,1);
					if((l=slackindback[k]))
					{
						Ax[k]+=-x[NN+--l];
					}
				}
				
				if(MM)
				{
					dsubvec(MM,LL+NN,&Ax[0],r_p);
					nb = norm(MM,r_p);
				}
				else nb=0;
				comp=sdx;
				
				dsubvec(NN,&X[0],LL,&X[0]);
				diag_div(NN,&S[0],&X[0],&XdS[0]);
				daddvec(NN,&X[0],LL,&X[0]);
				if(slack)
				{
					diag_div(slack,&S[NN],&X[NN],&XdS[NN]);
					dsubvec(slack,&X[NN],&slackU[0],&X[NN]);
					diag_div(slack,SU+NN,&X[NN],XdSU+NN);
					daddvec(slack,&X[NN],&slackU[0],&X[NN]);
				}
				dsubvec(NN,&X[0],UU,&X[0]);
				diag_div(NN,SU,&X[0],XdSU);
				daddvec(NN,&X[0],UU,&X[0]);
			}
			dsubvec(NN,&CCuse[0],&Al[0],r_d);
			if(!this->lp_really)daddvec(NN,r_d,&Qx[0],r_d);
			if(slack)
			{
				dzerovec(slack,r_d+NN);
				dsubvec(slack,r_d+NN,&Al[NN],r_d+NN);
			}
			dsubvec(NN+slack,r_d,s,r_d);
			dsubvec(NN+slack,r_d,sU,r_d);
			ng = norm(NN+slack,r_d);
			
			dsubvec(NN,&X[0],LL,&X[0]);
			diag_mult(NN+slack,&S[0],&X[0],&Sx[0]);
			dsubvec(NN+slack,&mu[0],&Sx[0],&Sx[0]);
			diag_div(NN+slack,&Sx[0],&X[0],&Sx[0]);
			daddvec(NN,&X[0],LL,&X[0]);
			
			dsubvec(NN,&X[0],UU,&X[0]);
			dsubvec(slack,&X[NN],&slackU[0],&X[NN]);
			diag_mult(NN+slack,SU,&X[0],SxU);
			dsubvec(NN+slack,&mu[NN+slack],SxU,SxU);
			diag_div(NN+slack,SxU,&X[0],SxU);
			daddvec(slack,&X[NN],&slackU[0],&X[NN]);
			daddvec(NN,&X[0],UU,&X[0]);
			
			grad=((this->lp_really)?0:ddotvec(NN,&Qx[0],x)*0.5);
			prim=ddotvec(NN,&CCuse[0],x)+grad;
			dual=-grad+ddotvec(MM,LL+NN,lambda)+ddotvec(NN,LL,s)+ddotvec(NN,UU,sU)+
				ddotvec(slack,&slackU[0],sU+NN);
			
			if(i==0&&loglevel>1)
			{
				AddLog((char*)"Complementarity          %-.8e\n",comp);
				AddLog((char*)"Primal Residual          %-.8e\n",nb);
				AddLog((char*)"Dual   Residual          %-.8e\n",ng);
				AddLog((char*)"Primal\t\t\t\t%-.8e\n",prim);
				AddLog((char*)"Dual\t\t\t\t%-.8e\n",dual);
			}
			
			if(i == 1)
			{
				if(j==0||resetpath)
				{
					modr0=sqrt(ddotvec(NN+slack+MM,&resid[0],&resid[0]));
					mu0=SDX;
					resetpath=0;resetj=j;
					if(loglevel>1)AddLog((char*)"mu0 is %-.8e modr0 is %-.8e\n",mu0,modr0);
				}
				modri=sqrt(ddotvec(NN+MM+slack,&resid[0],&resid[0]));
				scaler=modri/modr0/SDX*mu0;
				if(loglevel>1)AddLog((char*)"residual : mu ratio is %-.8e\n",scaler);
			}
			if(!resetpath)
			{
				double tol=dmax(1e-7,dmax(nb,ng));
				bool doit=(comp>tol)&&(scaler<1);
				if(doit&&nb>nbold && ng>ngold)
				{
					if(loglevel>1)AddLog((char*)"both residuals increase from r_p=%-.8e and r_d=%-.8e\n",nbold,ngold);
					dzerovec(MM,r_p);dzerovec(NN+slack,r_d);
				}
				else if(doit&&nb>nbold)
				{
					if(loglevel>1)AddLog((char*)"primal residual increases from r_p=%-.8e\n",nbold);
					dzerovec(MM,r_p);ngold=ng;
				}
				else if(doit&&ng>ngold)
				{
					if(loglevel>1)AddLog((char*)"dual residual increases from r_d=%-.8e\n",ngold);
					dzerovec(NN+slack,r_d);nbold=nb;
				}
				else if(doit)
				{
					ngold=ng;nbold=nb;
				}
				else
				{
					if(ng<ngold)ngold=ng;
					if(nb<nbold)nbold=nb;
				}
			}
			switch(mustreset)
			{
			case 1:
				if(loglevel>1)AddLog((char*)"recentre for primal\n");
				dzerovec(MM,r_p);
				break;
			case 2:
				if(loglevel>1)AddLog((char*)"recentre for dual\n");
				dzerovec(NN+slack,r_d);
				break;
			case 3:
				if(loglevel>1)AddLog((char*)"recentre for primal and dual\n");
				dzerovec(MM,r_p);
				dzerovec(NN+slack,r_d);
				break;
			}
			
			if(ng <= pdconv && ((fabs((prim-dual)/prim) <= nconv) 
				|| (fabs(prim)<=neps&&fabs(dual)<=neps) //it won't converge if true min is 0
				)
				&& (MM==0||nb <= pdconv))
			{
                conv=1;
				AddLog((char*)"\t\t\t\t++++++++++++++++++++++++++++++++++++++++\n");
				AddLog((char*)"\t\t\t\t+Interior Point Method Method Converged+\n");
				AddLog((char*)"\t\t\t\t++++++++++++++++++++++++++++++++++++++++\n");
                break;
			}
			else if(j>150 && comp<=1e-9 && (MM==0||nb<1e-14) && ng <=1e-6)
			{
				conv=1;//This result will be good enough for restarting the undoubled case
				AddLog((char*)"\t\t\t\t+++++++++++++++++++++++++++++++++++++++++++++++\n");
				AddLog((char*)"\t\t\t\t+Interior Point Method Method Almost Converged+\n");
				AddLog((char*)"\t\t\t\t+++++++++++++++++++++++++++++++++++++++++++++++\n");
                break;
			}
			if(i < 2)
			{
				dsubvec(NN+slack,r_d,&Sx[0],r_d);
				dsubvec(NN+slack,r_d,SxU,r_d);
				if(i==1)
				{
					for(size_t ipp=0;ipp<NN+slack;++ipp)
					{
						r_d[ipp]-=dx[ipp]*(ds[ipp]+dsU[ipp]);
					}
				}
			}
			if(!CONJ)
			{
				if(i == 0)
				{	
					dcopyvec(nqq,&Q[0],&Qcopy[0]);
					//Add in extraH terms
					if(this->ModHessian)
						dsubvec(NN*(NN+1)/2,&Qcopy[0],&(*extraH)[0],&Qcopy[0]);
					update_KKTQ(NN+slack,&Qcopy[0],&XdS[0]);
					update_KKTQ(NN+slack,&Qcopy[0],XdSU);
					//dsmxfac(NN+MM+slack,&Qcopy[0],&P[0]);
/*					SparseStuff.n=NN+MM+slack;
					SparseStuff.CreateSparseIndices(&Qcopy[0]);
					SparseStuff.Factor();*/
				}
				dcopyvec(NN+slack,r_d,dx);
				dcopyvec(MM,r_p,dlambda);
				//dsmxainv(NN+MM+slack,&Qcopy[0],&P[0],dx);
//				SparseStuff.Solve(dx);
			}
			else
			{
				if(!this->lp_really)
				{
					//					update_KKTQ(NN+slack,&Q[0],&XdS[0]);
					//					update_KKTQ(NN+slack,&Q[0],XdSU);
					dsubvec(NN+slack,&Q[0],&XdS[0],&Q[0]);
					dsubvec(NN+slack,&Q[0],XdSU,&Q[0]);
				}
				else
				{
					dcopyvec(NN+slack,&XdS[0],&Q[0]);
					daddvec(NN+slack,XdSU,&Q[0],&Q[0]);
				}
				if(this->ModHessian)
				{
					update_with_higher(NN,H_from_higher_terms,&Q[0]);
				}
				dnegvec(NN+MM+slack,dx);
				conj_solve(NN+MM+slack,&Q[0],&resid[0],dx,0,KKT_Q_mult,&Info,2,(messlevel&&loglevel));
				if(!this->lp_really)
				{
					//					update_KKTQ(NN+slack,&Q[0],&XdS[0],1);
					//					update_KKTQ(NN+slack,&Q[0],XdSU,1);
					daddvec(NN+slack,&Q[0],&XdS[0],&Q[0]);
					daddvec(NN+slack,&Q[0],XdSU,&Q[0]);
				}
				if(this->ModHessian)
				{
					update_with_higher(NN,H_from_higher_terms,&Q[0],1);
				}
				dnegvec(NN+MM+slack,dx);
			}
			
			diag_mult(NN+slack,&S[0],dx,&ds[0]);
			dsubvec(NN,&X[0],LL,&X[0]);
			diag_div(NN+slack,&ds[0],&X[0],&ds[0]);
			daddvec(NN,&X[0],LL,&X[0]);
			dsubvec(NN+slack,&Sx[0],&ds[0],&ds[0]);
			
			diag_mult(NN+slack,SU,dx,dsU);
			dsubvec(NN,&X[0],UU,&X[0]);
			dsubvec(slack,&X[NN],&slackU[0],&X[NN]);
			diag_div(NN+slack,dsU,&X[0],dsU);
			daddvec(NN,&X[0],UU,&X[0]);
			daddvec(slack,&X[NN],&slackU[0],&X[NN]);
			dsubvec(NN+slack,SxU,dsU,dsU);
			
			scalemu = (ddotvec(NN+slack,x,&ds[0])-ddotvec(NN,LL,&ds[0])+ddotvec(NN+slack,s,dx)+
				ddotvec(NN+slack,x,dsU)-ddotvec(NN,UU,dsU)-ddotvec(slack,&slackU[0],dsU+NN)+
				ddotvec(NN+slack,sU,dx)) / 
				(ddotvec(NN+slack,&ds[0],dx)+ddotvec(NN+slack,dsU,dx))/2;//Lu requires step which gives lowest predicted mu if possible
			
			scalex = scalecheck(NN,x,dx,LL);
			scalex = dmin(scalex,scalecheck(slack,x+NN,dx+NN));
			scalexU = scalecheck(NN,x,dx,UU,&ssignU[0]);
			scalexU = dmin(scalexU,scalecheck(slack,x+NN,dx+NN,&slackU[0],&ssignU[NN]));
			scales = scalecheck(NN,s,&ds[0]);
			scales = dmin(scales,scalecheck(slack,s+NN,&ds[NN]));
			scalesU = scalecheck(NN,sU,dsU,0,&ssignU[0]);
			scalesU = dmin(scalesU,scalecheck(slack,sU+NN,dsU+NN,0,&ssignU[NN]));
			scale=dmin(scalex,scalexU);
			scales=dmin(scales,scalesU);
			//No longer have same step length for x and s, and only put the "extra restrictions" on x step
			scale= .9*scale;//If this is too close to the boundary x or s will become too small
			scale=dmin(scale,.99);//Must be lees than 1 to guarantee lower r_p, r_d and sdx for linear approximation
			scales= .9*scales;//If this is too close to the boundary x or s will become too small
			scales=dmin(scales,.99);//Must be lees than 1 to guarantee lower r_p, r_d and sdx for linear approximation
			if(fabs(scalemu)<1)
			{
				if(loglevel>1)AddLog((char*)"Predicted optimal mu step %-.8e, max X step %-.8e, max S step %-.8e\n",scalemu,scale,scales);
				scale=dmin(scale,fabs(scalemu));
			}
			if(i==1)
			{
				double bot=dmax(prodmax(NN+slack,dx,&ds[0]),prodmax(NN+slack,dx,dsU));
				if(bot>lm_eps/*&&scale>lm_eps*/)
				{
					scaleprod=mu[0]*0.5/bot;
				}
				else
				{
					scaleprod=0;
					AddLog((char*)"\t\t\t\t++++++++++++++++++++++++++++++++++++++\n");
					AddLog((char*)"\t\t\t\t+Interior Point Method cannot proceed+\n");
					AddLog((char*)"\t\t\t\t++++++++++++++++++++++++++++++++++++++\n");
					/*
					if(scale<=lm_eps)
					{
					conv=1;
					break;
					}
					*/
					if(comp<1e-5 && (MM==0||nb < 1e-5) && ng < 1e-5)
					{
						conv=1;//Accept it
						break;
					}
					else if(mustreset==3 && comp<1e-8 && (MM==0||nb < 1e-8))
					{
						conv=1;//Accept it
						break;
					}
					else
					{
						mustreset=3;
						continue;
					}
				}
				if(loglevel>1)AddLog((char*)"smallest step to ensure that mu decreases by at least 1-step is %-.8e\n",scaleprod);
				mustreset=0;
			}
			if(loglevel>1)
			{
				AddLog((char*)"\t\t\t\tX Step length %-.8e\n",scale);
				AddLog((char*)"\t\t\t\tS Step length %-.8e\n",scales);
			}
			/*			if((j-resetj>=10)&&(i==1)&&(scale<scaleprod||(ng<1e-6&&scaleprod>1) ))
			{
			double newmu=max(1e-5,max(4*mu[0],max(ng,nb)/(NN+slack)/2));
			if(loglevel>1)AddLog((char*)"j=%d, resetj=%d\t\tReset the central path with mu = %-.8e\n",j,resetj,newmu);
			resetpath=1;
			guess_setS(NN,slack,newmu,x,s,sU,LL,UU,&slackU[0]);
			}
			else */if((i==1)&&(scale<5e-2)&&smallstepcount>5)//Don't allow more than 5 small steps in a row without a restart
			{
				double newmu=dmax(4*mu[0],dmax(ng,nb)/(NN+slack)/2);
				if(loglevel>1)AddLog((char*)"j=%d, resetj=%d\t\tReset the central path with mu = %-.8e\n",j,resetj,newmu);
				resetpath=1;
				guess_setS(NN,slack,newmu,x,s,sU,LL,UU,&slackU[0]);
				smallstepcount=0;
			}
			else if(scale<=lm_eps)
			{
				if(comp<lm_rooteps)
				{
					conv=1;
					AddLog((char*)"\t\t\t\t++++++++++++++++++++++++++++++++++++++\n");
					AddLog((char*)"\t\t\t\t+Interior Point Method cannot proceed+\n");
					AddLog((char*)"\t\t\t\t+     step has zero length           +\n");
					AddLog((char*)"\t\t\t\t++++++++++++++++++++++++++++++++++++++\n");
					break;
				}
				else
				{
					size_t ii;
					double close=1e-5,newmu=dmax(4*mu[0],dmax(ng,nb)/(NN+slack)/2);
					if(loglevel>1)AddLog((char*)"j=%d, resetj=%d\t\tReset the central path with mu = %-.8e\n",j,resetj,newmu);
					resetpath=1;
					for(ii=0;ii<NN;++ii)
					{
						if((x[ii]-LL[ii]) < close)
							x[ii]=LL[ii]+close;
						else if((UU[ii]-x[ii]) < close)
							x[ii]=UU[ii]-close;
					}
					for(ii=0;ii<slack;++ii)
					{
						if(x[ii+NN] < close)
							x[ii+NN]=close;
						else if((slackU[ii]-x[ii+NN]) < close)
							x[ii+NN]=slackU[ii]-close;
					}
					guess_setS(NN,slack,newmu,x,s,sU,LL,UU,&slackU[0]);
					smallstepcount=0;
				}
			}
			else
			{
				daxpyvec(NN+slack,scale,dx,x);
				daxpyvec(NN+slack,scales,&ds[0],s);
				daxpyvec(NN+slack,scales,dsU,sU);
			}
			if(i==1)
			{
				if(scale<5e-2)
					smallstepcount++;
				else
					smallstepcount=0;
			}
			smallfiddle(NN,x,LL);
			smallfiddle(slack,x+NN);
			smallfiddle(NN,x,UU);
			smallfiddle(slack,x+NN,&slackU[0]);
			smallfiddle(NN,s);
			smallfiddle(slack,s+NN);
			smallfiddle(NN,sU);
			smallfiddle(slack,sU+NN);
			/*			if(norm(NN,s)<=lm_eps)
			dzerovec(NN,s);
			if(norm(NN,sU)<=lm_eps)
			dzerovec(NN,sU);
			if(slack)
			{
			if(norm(slack,s+NN)<=lm_eps)
			dzerovec(slack,s+NN);
			if(norm(slack,sU+NN)<=lm_eps)
			dzerovec(slack,sU+NN);
			if(norm(slack,x+NN)<=lm_eps)
			dzerovec(slack,x+NN);
			}*/
			if(i==1&&!resetpath)
				daxpyvec(MM,.99,dlambda,lambda);
		}
		if(conv||fabs(comp)>1e+6)break;
	}
	
	if(loglevel>2)
	{
		AddLog((char*)"Variables\n");
		AddLog((char*)"%4s %16s %16s %16s %16s %16s\n",(char*)" ",(char*)"x",(char*)"x-l",(char*)"sl",(char*)"x-u",(char*)"su");
		for(i=0;i<NN;i++)
		{
			AddLog((char*)"%4ld %16.8e %16.8e %16.8e %16.8e %16.8e\n",i+1,x[i],x[i]-LL[i],s[i],x[i]-UU[i],sU[i]);
		}
		if(MM)
		{
			AddLog((char*)"Linear Constraints\n");
			AddLog((char*)"%4s %16s %16s %16s %16s\n",(char*)" ",(char*)"l",(char*)"Ax",(char*)"u",(char*)"lambda");
			for(i=0,pA=AA;i<MM;i++,pA++)
			{
				AddLog((char*)"%4ld %16.8e %16.8e %16.8e %16.8e\n",i+1,LL[NN+i],BITA_ddot(NN,pA,MM,x,1),UU[NN+i],lambda[i]);
			}
		}
		if(slack)
		{
			AddLog((char*)"Slack variables\n");
			AddLog((char*)"%4s %16s %16s %16s %16s %16s\n",(char*)" ",(char*)"slack x",(char*)"slack x-l",(char*)"slack sl",(char*)"slack x-u",(char*)"slack su");
			for(i=0;i<slack;++i)
			{
				AddLog((char*)"%4ld %16.8e %16.8e %16.8e %16.8e %16.8e\n",i+1,x[NN+i],x[NN+i],s[NN+i],x[NN+i]-slackU[i],sU[NN+i]);
			}
		}
	}
	dcopyvec(NN,x,XX);
	AddLog((char*)"No of iterations %d, primal %-.8e, dual %-.8e, complementarity %-.8e\n",j,prim,dual,comp);
	if(MM>0)AddLog((char*)"primal residual %-.8e\n",nb);
	AddLog((char*)"dual residual %-.8e\n",ng);
	this->objective=prim;
	for(i=0;i<NN;++i)
	{
		if(round_result)
		{
			if(XX[i]-LL[i] < featol)XX[i]=LL[i];
			if(UU[i]-XX[i] < featol)XX[i]=UU[i];
		}
		if(XX[i]<LL[i] || XX[i]>UU[i])
		{
			AddLog((char*)"Bound error in IP i=%d\tl=%-.8e u=%-.8e; x=%-.8e\n",i+1,LL[i],UU[i],XX[i]);
			conv=0;
		}
	}
	if(conv==1){return 0;}
	else 
	{
		AddLog((char*)"\t\t\t\t+++++++++++++++++++++++++++++++\n");
		AddLog((char*)"\t\t\t\t+Interior Point Method failed +\n");
		AddLog((char*)"\t\t\t\t+++++++++++++++++++++++++++++++\n");
		return 16;
	}
}

extern "C" DLLEXPORT double DOT(size_t n,vector A,vector B)
{
	//Frobeneous norm of 2 symmetric matrices
	size_t i,j;
	double back=0,*a,*b,bb;
	for(i=0,a=A,b=B;i<n;i++)
	{
		for(j=0;j<=i;j++)
		{
			bb=*a * *b;
			back+=bb;
			if(i!=j)
			{
				back+=bb;
			}
			a++;
			b++;
		}
	}
	return back;
}

extern "C" DLLEXPORT void combineS(size_t n,vector q,vector g,vector U)
{
	//Combine quadratic and m (usually m is 1) linear terms into a symmetric matrix
	size_t npm=n+1,i;
	size_t size=npm*(npm+1)/2;
	size_t sizen=n*(n+1)/2;
	vector pg,pU;
	if(U!=q)
	{
		dzerovec(size,U);
		dcopyvec(sizen,q,U);
	}
	for(i=0,pg=g,pU=U+sizen;i<1;++i)
	{
		dcopyvec(n,pg,pU);
		pg+=n;
		pU+=n+i+1;
	}
}

extern "C" DLLEXPORT void vec2symm(size_t n,vector vec,vector symm)
{
	vector v1,v2,s;
	size_t i,j;
	for(i=0,s=symm,v1=vec;i<n;++i)
	{
		for(j=0,v2=vec;j<=i;++j)
		{
			*s++=*v1 * *v2++;
		}
		v1++;
	}
	combineS(n,symm,vec,symm);
}

extern "C" DLLEXPORT void symmsymm(size_t n,vector S1,vector S2,vector S1S2)
{
	size_t i,j,k;
	vector pSSij;
	for(i=0;i<n;++i)
	{
		for(j=0,pSSij=S1S2+i;j<n;++j,pSSij+=n)
		{
			*pSSij=0;
			for(k=0;k<n;++k)
			{
				if(k<=i && k<=j)
				{
					*pSSij+=S1[i*(i+1)/2+k]*S2[j*(j+1)/2+k];
				}
				else if(k<=i)
				{
					*pSSij+=S1[i*(i+1)/2+k]*S2[k*(k+1)/2+j];
				}
				else if(k<=j)
				{
					*pSSij+=S1[k*(k+1)/2+i]*S2[j*(j+1)/2+k];
				}
				else
				{
					*pSSij+=S1[k*(k+1)/2+i]*S2[k*(k+1)/2+j];
				}
			}
		}
	}
}

extern "C" DLLEXPORT void Sinv_X(size_t n,vector S,vector X,vector SiX)
{
	size_t nn = (n * (n + 1)) >> 1,i,j;
	vector pSS;
	std::valarray<double>Scopy(nn);
	std::valarray<short_scl>P(n);
	dcopyvec(nn,S,&Scopy[0]);
	dsmxfac(n,&Scopy[0],&P[0]);
	for(i=0,pSS=SiX;i<n;++i,pSS+=n)
	{
		for(j=0;j<n;++j)
		{
			if(i<=j)
			{
				pSS[j]=X[j*(j+1)/2+i];
			}
			else
			{
				pSS[j]=X[i*(i+1)/2+j];
			}
		}
		dsmxainv(n,&Scopy[0],&P[0],pSS);
	}
}

extern "C" DLLEXPORT double A1MA2(size_t n,vector A1,vector A2,vector M)
{
	double s=0;
	vector pM;
	size_t i,j,k;
	for(i=0;i<n;++i)//AijMjkAik
	{
		for(j=0,pM=M;j<n;++j)
		{
			for(k=0;k<n;++k,pM++)
			{
				if(i<=j && i<=k)
					s+=A1[j*(j+1)/2+i]* *pM *A2[k*(k+1)/2+i];
				else if(i<=j)
					s+=A1[j*(j+1)/2+i]* *pM *A2[i*(i+1)/2+k];
				else if(i<=k)
					s+=A1[i*(i+1)/2+j]* *pM *A2[k*(k+1)/2+i];
				else
					s+=A1[i*(i+1)/2+j]* *pM *A2[i*(i+1)/2+k];
			}
		}
	}
	return s;
}
extern "C" DLLEXPORT void square2symm(size_t n,vector S)
{
	size_t nn = (n * (n + 1)) >> 1,i,j;
	std::valarray<double> Ss(nn);
	vector pS;
	for(i=0,pS=&Ss[0];i<n;i++)
	{
		for(j=0;j<=i;j++)
		{
			*pS++=.5*(S[i+j*n]+S[j+i*n]);
		}
	}
	dcopyvec(nn,&Ss[0],S);
}
extern "C" DLLEXPORT void square2sqsymm(size_t n,vector S)
{
	size_t i,j;
	for(i=0;i<n;i++)
	{
		for(j=0;j<=i;j++)
		{
			S[i+j*n]=S[j+i*n]=.5*(S[i+j*n]+S[j+i*n]);
		}
	}
}
extern "C" DLLEXPORT void gensymm(size_t n,vector M,vector S,vector MS)
{
	size_t i,j,k;
	for(i=0;i<n;++i)
	{
		for(j=0;j<n;++j)
		{
			*MS=0;
			for(k=0;k<n;++k)
			{
				if(j<=k)
					*MS+=M[i+n*k]*S[k*(k+1)/2+j];
				else
					*MS+=M[i+n*k]*S[j*(j+1)/2+k];
			}
			MS++;
		}
	}
}
extern "C" DLLEXPORT void Sinv_M(size_t n,vector S,vector M)
{
	size_t nn = (n * (n + 1)) >> 1,i;
	vector pSS;
	std::valarray<double>Scopy(nn);
	std::valarray<short_scl>P(n);
	dcopyvec(nn,S,&Scopy[0]);
	dsmxfac(n,&Scopy[0],&P[0]);
	for(i=0,pSS=M;i<n;++i,pSS+=n)
	{
		dsmxainv(n,&Scopy[0],&P[0],pSS);
	}
}

extern "C" DLLEXPORT double AdotSiAX(size_t n,vector Ai,vector S,vector Aj,vector X)
{
	std::valarray<double> AX(n*n);
	symmsymm(n,Aj,X,&AX[0]);
	Sinv_M(n,S,&AX[0]);
	square2symm(n,&AX[0]);
	return DOT(n,Ai,&AX[0]);
}
extern "C" DLLEXPORT double AdotSi(size_t n,vector A,vector S)
{
	std::valarray<double>AS(n*n);
	Sinv_X(n,S,A,&AS[0]);
	double s;
	size_t i;
	for(i=0,s=0;i<n;++i)
		s+=AS[i+i*n];
	return s;
}
extern "C" DLLEXPORT void SiAX(size_t n,vector S,vector A,vector X,vector SAX)
{
	symmsymm(n,A,X,SAX);
	Sinv_M(n,S,SAX);
	square2symm(n,SAX);
}
extern "C" DLLEXPORT void Sisymm(size_t n,vector S,vector Si)
{
	//Inverse of a symmetric matrix
	size_t nn = (n * (n + 1)) >> 1,i;
	std::valarray<double>Scopy(nn);
	std::valarray<short_scl>P(n);
	std::valarray<double> unit(n);
	dcopyvec(nn,S,&Scopy[0]);
	dsmxfac(n,&Scopy[0],&P[0]);
	for(i=0;i<n;++i)
	{
		unit=0;
		unit[i]=1;
		dsmxainv(n,&Scopy[0],&P[0],&unit[0]);
		dcopyvec(i+1,&unit[0],Si);
		Si+=i+1;
	}
}
extern "C" DLLEXPORT void vecvec2symmat(size_t n,vector b,vector a,vector A)
{
/*
Symmetrised outer product of two vectors
	*/
	size_t i,j;
	vector ai,aj,bi,bj;
	for(i=0,bi=b,ai=a;i<n;++i,bi++,ai++)
	{
		for(j=0,bj=b,aj=a;j<=i;++j,bj++,aj++)
		{
			*A++ =0.5*(*bi * *aj + *bj * *ai);
		}
	}
}
extern "C" DLLEXPORT void Amake(size_t n,vector base,vector a,double b,vector A,double B=10.0)
{
/*
"""Set up a quadratic constraint which is met when a*x+b=0
The constraint matrix is:

  basei*aj+basej*ai   (B*aj+b*basej)/2
  (B*ai+b*basei)/2     B*b
  
    Here the last element of basis must be chosen large enough
    to ensure that a false solution is avoided (i.e must not get
    base*x=-B)
	
	  We choose a large number for B  (large is defined by the problem)  
	  """
	*/
	vecvec2symmat(n,base,a,A);
	A+=((n * (n + 1)) >> 1);
	while(n--)
		*A++ = 0.5*(B* *a++ + b* *base++);
	*A=B*b;
}
class SemiDef
{
public:
	SemiDef(size_t n,size_t m,vector X,vector S,vector A);
	~SemiDef();
	size_t n;
	size_t m;
	vector X;
	vector S;
	vector A;
	vector AA;
	vector BB;
	vector Sfac;
	vector Xfac;
	short_scl*PS;
	short_scl*PX;
	short_scl*PAA;
	double stepx(vector dX);
	double steps(vector dS);
	void factorS();
	void factorX();
	void factorA();
	void makeAA();
	void makeBB(vector r_d,vector r_p,double mu,vector dSp=0,vector dXp=0);
	void solveDL(vector dL);
	void solveDS(vector dS,vector dL,vector r_d);
	void solveDX(vector dX,vector dS,double mu);
private:
	size_t nn;
	size_t mm;
	std::valarray<double>*vAA;
	std::valarray<double>*vBB;
	std::valarray<double>*vSfac;
	std::valarray<short_scl>*vPS;
	std::valarray<double>*vXfac;
	std::valarray<short_scl>*vPX;
	std::valarray<short_scl>*vPAA;
	std::valarray<double>*vdSX;
};

SemiDef::SemiDef(size_t n,size_t m,vector X,vector S,vector A)
{
	this->n=n;
	this->m=m;
	this->X=X;
	this->S=S;
	this->A=A;
	nn=(n * (n + 1)) >> 1;
	mm=(m * (m + 1)) >> 1;
	vAA = new std::valarray<double>;
	vBB = new std::valarray<double>;
	vSfac = new std::valarray<double>;
	vPS = new std::valarray<short_scl>;
	vXfac = new std::valarray<double>;
	vPX = new std::valarray<short_scl>;
	vPAA = new std::valarray<short_scl>;
	vdSX = new std::valarray<double>;
	vAA->resize(mm*2);
	AA=&(*vAA)[0];
	vPAA->resize(m);
	PAA=&(*vPAA)[0];
	vBB->resize(m);
	BB=&(*vBB)[0];
	vSfac->resize(nn);
	Sfac=&(*vSfac)[0];
	vPS->resize(n);
	PS=&(*vPS)[0];
	vXfac->resize(nn);
	Xfac=&(*vXfac)[0];
	vPX->resize(n);
	PX=&(*vPX)[0];
}

SemiDef::~SemiDef()
{
	delete vAA;
	delete vBB;
	delete vSfac;
	delete vPS;
	delete vPAA;
	delete vdSX;
}
void SemiDef::factorS()
{
	dcopyvec(nn,S,Sfac);
	int info=dsptrf((char*)"U",n,Sfac,PS);
}
void SemiDef::factorX()
{
	dcopyvec(nn,X,Xfac);
	int info=dsptrf((char*)"U",n,Xfac,PX);
}
void SemiDef::factorA()
{
	dcopyvec(mm,AA,AA+mm);
	int info=dsptrf((char*)"U",m,AA+mm,PAA);
}
void SemiDef::makeAA()
{
	std::valarray<double> AX(n*n);
	size_t i,j;
	vector pAi,pAj,pAX,pAA;
	for(i=0,pAi=A,pAA=AA;i<m;++i,pAi+=nn)
	{
		symmsymm(n,pAi,X,&AX[0]);//must get the order correct i.e. AiX
		for(j=0,pAX=&AX[0];j<n;++j,pAX+=n)
		{
			dsptrs((char*)"U",n,1,Sfac,PS,pAX,n);
		}
		square2symm(n,&AX[0]);
		for(j=0,pAj=A;j<=i;++j,pAj+=nn)
		{
			*pAA++=DOT(n,&AX[0],pAj);
		}
	}
	//	printnx(mm,AA,(char*)"AA");
}
void SemiDef::makeBB(vector r_d,vector r_p,double mu,vector dSp,vector dXp)
{
	std::valarray<double> rX(n*n);
	if(mu!=0)
		vdSX->resize(n*n);
	size_t i;
	vector pAi,prX,pBB,pdSX=0;
	symmsymm(n,r_d,X,&rX[0]);//must get the order correct i.e. r_dX
	if(mu!=0)
	{
		symmsymm(n,dSp,dXp,&(*vdSX)[0]);
		pdSX=&(*vdSX)[0];
	}
	for(i=0,prX=&rX[0];i<n;i++,prX+=n)
	{
		prX[i]-=mu;
		if(mu!=0)
		{
			dsubvec(n,prX,pdSX,prX);pdSX+=n;//Some people include this second order correction
		}
		dsptrs((char*)"U",n,1,Sfac,PS,prX,n);
	}
	square2symm(n,&rX[0]);
	for(i=0,pAi=A,pBB=BB;i<m;++i,pAi+=nn)
	{
		*pBB++=r_p[i]+DOT(n,&rX[0],pAi)+DOT(n,pAi,X);
	}
	//	printnx(m,BB,(char*)"BB");
}
void SemiDef::solveDL(vector dL)
{
	dcopyvec(m,BB,dL);
	dsptrs((char*)"U",m,1,AA+mm,PAA,dL,m);
	//	printnx(m,dL,(char*)"dL");
}
void SemiDef::solveDS(vector dS,vector dL,vector r_d)
{
	size_t i;
	vector pA;
	dcopyvec(nn,r_d,dS);
	for(i=0,pA=A;i<m;++i,pA+=nn)
		daxpyvec(nn,-dL[i],pA,dS);
	//	printnx(nn,dS,(char*)"dS");
}
void SemiDef::solveDX(vector dX,vector dS,double mu)
{
	std::valarray<double> dSX(n*n);
	size_t i;
	vector pdSX,pdSXp=&(*vdSX)[0];
	symmsymm(n,dS,X,&dSX[0]);//must get order correct i.e. dSX
	for(i=0,pdSX=&dSX[0];i<n;i++,pdSX+=n)
	{
		pdSX[i]-=mu;
		if(mu!=0)
		{
			dsubvec(n,pdSX,pdSXp,pdSX);pdSXp+=n;//Some people include this second order correction
		}
		dsptrs((char*)"U",n,1,Sfac,PS,pdSX,n);
	}
	square2symm(n,&dSX[0]);
	dnegvec(nn,&dSX[0]);
	dcopyvec(nn,&dSX[0],dX);
	dsubvec(nn,dX,X,dX);
	//	printnx(nn,dX,(char*)"dX");
}
double SemiDef::stepx(vector dX)
{
	size_t i,j,n2=n*n;
	std::valarray<double>st(n2);
	std::valarray<double>eig(n);
	vector p;
	short r;
	for(i=0,p=&st[0];i<n;i++,p+=n)
	{
		for(j=0;j<n;++j)
		{
			if(j<=i)
				p[j]=dX[i*(i+1)/2+j];
			else
				p[j]=dX[j*(j+1)/2+i];
		}
		dsptrs((char*)"U",n,1,Xfac,PX,p,n);
	}
	square2sqsymm(n,&st[0]);
	r=eigendecomp(n,&st[0],&eig[0],100);
	if(eig[n-1]>=0)return 1;
	return -1.0/eig[n-1];
}
double SemiDef::steps(vector dS)
{
	size_t i,j,n2=n*n;
	std::valarray<double>st(n2);
	std::valarray<double>eig(n);
	vector p;
	short r;
	for(i=0,p=&st[0];i<n;i++,p+=n)
	{
		for(j=0;j<n;++j)
		{
			if(j<=i)
				p[j]=dS[i*(i+1)/2+j];
			else
				p[j]=dS[j*(j+1)/2+i];
		}
		dsptrs((char*)"U",n,1,Sfac,PS,p,n);
	}
	square2sqsymm(n,&st[0]);
	r=eigendecomp(n,&st[0],&eig[0],100);
	if(eig[n-1]>=0)return 1;
	return -1.0/eig[n-1];
}

inline double Mnorm(size_t n,vector M)
{
	double back=0;
	size_t i=0;
	while(n--)
	{
		back = dmax(fabs(*M),back);
		M+=(i + 2);
		i++;
	}
	return back;
}
extern "C" DLLEXPORT short OptSemiGen(size_t N,size_t M,vector X,vector C,vector AA,vector BB,size_t top=100)
{
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	size_t NN=(N * (N + 1)) >> 1;
	size_t i;
	char num[6];
	bool missout1;
	
	printnx(NN,C,(char*)"C");
	for(i=0;i<M;i++)
	{
		sprintf(num,(char*)"%d",i+1);
		printnx(NN,AA+i*NN,std::string((char*)"Constraint ")+num);
	}
	std::valarray<double>S(NN),L(M),r_p(M),r_d(NN),dX(NN),dS(NN),dL(M),dXp(NN),dSp(NN);
	double mu,conv=lm_rooteps,prim,dual,SdX,normp,normd,stepx,steps,murat=1;
	size_t bigiter=0,meth;
	short back=16;
	
	dzerovec(NN,X);
	S=0;
	L=0;
	vector pS,pX;
	for(i=0,pS=&S[0],pX=X;i<N;i++)
	{
		*pS=1;
		*pX=1;
		pS+=i+2;
		pX+=i+2;
	}
	
	/*	double testX=1,testS=Mnorm(N,C);
	
	  for(i=0;i<M;++i)
	  {
	  double dd=Mnorm(N,AA+i*NN);
	  testX=max(testX,(1+fabs(BB[i]))/(1+dd));
	  testS=max(testS,dd);
	  }
	  testX*=N;
	  testS+=1;
	  testS/=sqrt((double)N);
	  
		printf((char*)"X initially diag(%-.8e)\n",testX);
		printf((char*)"S initially diag(%-.8e)\n",testS);
		for(i=0,pS=&S[0],pX=X;i<N;i++)
		{
		*pS=testS;
		*pX=testX;
		pS+=i+2;
		pX+=i+2;
}*/
	
	SemiDef DoOpt(N,M,X,&S[0],AA);
	
	while(1)
	{
		printf((char*)"+++++++++++++++ Iteration %d +++++++++++++++\n",bigiter);
		mu=0;
		SdX=DOT(N,X,&S[0]);
		prim=DOT(N,C,X);
		dual=ddotvec(M,&L[0],BB);
		printf((char*)"SdX %-.8e\n",SdX);
		printf((char*)"prim %-.8e\n",prim);
		printf((char*)"dual %-.8e\n",dual);
		//		printnx(NN,X,(char*)"X");
		//		printnx(NN,&S[0],(char*)"S");
		//		printnx(M,&L[0],(char*)"L");
		for(i=0;i<M;++i)
			r_p[i]=BB[i]-DOT(N,&AA[i*NN],X);
		dsubvec(NN,C,&S[0],&r_d[0]);
		for(i=0;i<M;++i)
			daxpyvec(NN,-L[i],AA+i*NN,&r_d[0]);
		normp=norm(M,&r_p[0]);
		printf((char*)"normp %-.8e\n",normp);
		//		printnx(M,&r_p[0],(char*)"r_p");
		normd=norm(NN,&r_d[0]);
		printf((char*)"normd %-.8e\n",normd);
		//		printnx(NN,&r_d[0],(char*)"r_d");
		if(bigiter>top){break;}
		if((normd<conv)&&(normp<conv)&&(SdX<conv*(2*N+2))){back=0;break;}
		DoOpt.factorS();
		DoOpt.factorX();
		DoOpt.makeAA();
		DoOpt.factorA();
		for(meth=0;meth<2;meth++)
		{
			if(mu==0)
				DoOpt.makeBB(&r_d[0],&r_p[0],mu);
			else
				DoOpt.makeBB(&r_d[0],&r_p[0],mu,&dSp[0],&dXp[0]);
			DoOpt.solveDL(&dL[0]);
			DoOpt.solveDS(&dS[0],&dL[0],&r_d[0]);
			DoOpt.solveDX(&dX[0],&dS[0],mu);
			stepx=DoOpt.stepx(&dX[0]);
			printf((char*)"stepx %-.8e\n",stepx);
			steps=DoOpt.steps(&dS[0]);
			printf((char*)"steps %-.8e\n",steps);
			missout1=(steps>1&&stepx>1)?1:0;
			stepx=dmin(1.0,stepx*.95);
			steps=dmin(1.0,steps*.95);
			daxpyvec(M,1,&dL[0],&L[0]);
			daxpyvec(NN,stepx,&dX[0],X);
			daxpyvec(NN,steps,&dS[0],&S[0]);
			if(meth==0 && !missout1)
			{
				murat=DOT(N,X,&S[0])/SdX;
				printf((char*)"murat %-.8e\n",murat);
				mu=SdX*dmin(.8,murat)/N;
				daxpyvec(M,-1,&dL[0],&L[0]);
				daxpyvec(NN,-stepx,&dX[0],X);
				daxpyvec(NN,-steps,&dS[0],&S[0]);				
				if(murat<0)break;
				dSp=dS*steps;
				dXp=dX*stepx;
			}
			else if(meth==0)
			{
				murat=1;
				printf((char*)"Leave out corrector step\n");
				break;
			}
		}
		if(murat<0)break;
		bigiter++;
	}
	printf((char*)"+++++++++++++++ Iteration %d +++++++++++++++\n",bigiter);
	printf((char*)"SdX %-.8e\n",SdX);
	printf((char*)"prim %-.8e\n",prim);
	printf((char*)"dual %-.8e\n",dual);
	printnx(NN,X,(char*)"X");
	printnx(NN,&S[0],(char*)"S");
	printnx(M,&L[0],(char*)"L");
	printf((char*)"normp %-.8e\n",normp);
	printnx(M,&r_p[0],(char*)"r_p");
	printf((char*)"normd %-.8e\n",normd);
	printnx(NN,&r_d[0],(char*)"r_d");
	for(i=0;i<M;i++)
	{
		printf((char*)"Constraint %4d @ X %20.8e\n",i+1,DOT(N,X,AA+i*NN));
	}
	
	return back;
}

extern "C" DLLEXPORT short OptSemi(size_t n,size_t m,vector w,vector g,vector Q,vector A,vector B)
{
/*
Simple-minded recasting of a QP optimisation to a Semidefinite relaxation.
We have just one matrix constraint for each of the m linear constraints in QP
and the homogenising constraint last X = 1.
	*/
	size_t N=n+1;
	size_t M=m+1;
	size_t NN=(N * (N + 1)) >> 1;
	size_t i;
	short back;
	std::valarray<double>C(NN),AA(NN*M),BB(M),X(NN);
	vector pAA,pA;
	C=0;
	AA=0;
	BB=0;
	combineS(n,Q,g,&C[0]);
	dmx_transpose(m,n,A,A);
	for(i=0,pAA=&AA[0],pA=A;i<m;i++,pAA+=NN,pA+=n)
	{
		Amake(n,pA,pA,-B[i],pAA,-B[i]*10);
	}
	dmx_transpose(n,m,A,A);
	AA[NN*M-1]=1;
	dzerovec(m,&BB[0]);
	BB[M-1]=1;
	back=OptSemiGen(N,M,&X[0],&C[0],&AA[0],&BB[0]);
	dcopyvec(n,&X[n*(n+1)/2],w);
	return back;
	
}
extern "C" DLLEXPORT void Factor2Cov(size_t n,size_t nfac,vector FC,vector FL,vector SV,vector Q)
{
	FOptimise Data;
	Data.SetLog();
	Data.n=n;
	Data.nfac=nfac;
	if(FC&&FL&&SV)
	{
		Data.FC=FC;
		Data.FL=FL;
		Data.SV=SV;
		Data.factor_model_process();
	}
	else
		Data.H=FC;
	if(Data.ImportantCheck())
		return;
	
	std::valarray<double>basis(n);
	basis=0;
	size_t i;
	for(i=0;i<n;++i,Q+=i)
	{
		basis[i]=1;
		Data.qphess_base(n,1,1,1,Data.H,&basis[0],Q);
		basis[i]=0;
	}
}
extern "C" DLLEXPORT void Factor2Var(size_t n,size_t nfac,vector FC,vector FL,vector SV,vector Variance)
{
	FOptimise Data;
	Data.SetLog();
	Data.n=n;
	Data.nfac=nfac;
	if(FC&&FL&&SV)
	{
		Data.FC=FC;
		Data.FL=FL;
		Data.SV=SV;
		Data.factor_model_process();
	}
	else
		Data.H=FC;
	if(Data.ImportantCheck())
		return;
	
	std::valarray<double>basis(2*n);
	basis=0;
	size_t i;
	for(i=0;i<n;++i,Variance++)
	{
		basis[i]=1;
		Data.qphess_base(n,1,1,1,Data.H,&basis[0],&basis[n]);
		*Variance = basis[n+i];
		basis[i]=0;
	}
}
class FixData
{
public:
	size_t n;
	vector Q;
	vector eigvec;
	vector mask;
	size_t* zero_eig;
};
double fixfunc(dimen ne,vector e,void* info)
{
	FixData* optInfo=(FixData*)info;
	size_t n=optInfo->n;
	size_t nn=n*(n+1)/2,i,j,k;
	std::valarray<double>Q(nn);
	vector pQ,pQo,pm;
	dzerovec(nn,&Q[0]);
	size_t iz;
	for(i=0,iz=0;i<n;++i)
	{
		if(optInfo->zero_eig&&optInfo->zero_eig[iz]==i)
		{
			iz++;
			continue;
		}
		for(j=0,pQ=&Q[0];j<n;++j)
		{
			for(k=0;k<=j;++k)
			{
				*pQ+=fabs(*e)*optInfo->eigvec[i*n+j]*optInfo->eigvec[i*n+k];
				pQ++;
			}
		}
		e++;
	}
	double back=0,vv;
	pm=optInfo->mask;
	pQo=optInfo->Q;
	pQ=&Q[0];
	while(n--)
	{
		vv=*pQo++ - *pQ++;
		back+=vv*vv* *pm++;
	}
	return back;
}
//Use general optimisation for fixing (quadratic (quad_fix) works much better)
extern "C" DLLEXPORT int opt_fix(dimen n,vector Q,vector mask,int print,double tol)
{
	std::valarray<double> vmask;
	if(tol<=0) tol=1e-4;
	size_t n2=n*n,nn=n*(n+1)/2,itmax=1000,i,j,k;
	if(!mask)//Use unit matrix for mask if mask hasn't been set.
	{
		vmask.resize(nn);
		vmask=0;
		mask=&vmask[0];
		for(i=0,j=0;i<n;++i,j+=(i+1))
			mask[j]=1;
	}
	std::valarray<double> S(n2),v(n);
	vector pQ;
	for(i=0,pQ=Q;i<n;++i)
	{
		for(j=0;j<=i;++j)
		{
			S[i+n*j]=*pQ;
			if(i!=j)
				S[i*n+j]=*pQ;
			pQ++;
		}
	}
	eigendecomp(n,&S[0],&v[0],itmax);
	std::vector<size_t> zero_eig;
	std::vector<double>use_eig;
	for(i=0;i<n;++i)
	{
		if(fabs(v[i])<=lm_eps8)
		{
			zero_eig.push_back(i);
		}
		else
		{
			use_eig.push_back(v[i]);//Initial guess
		}
	}
	FixData optInfo;
	optInfo.n=n;
	optInfo.Q=Q;
	optInfo.eigvec=&S[0];
	optInfo.mask=mask;
	optInfo.zero_eig=&zero_eig[0];
	size_t ne=use_eig.size();
	double f=fixfunc(ne,&use_eig[0],&optInfo);
	if(print)printf((char*)"tolerance %-.8e, initial f %-.8e\n",tol,f);
	short back=QuasiNewton(ne,&use_eig[0],print>1,ne*20,&f,fixfunc,&optInfo,tol,2,1);
	if(print)printf((char*)"Final f %-.8e\n",f);
	dzerovec(nn,Q);
	size_t iz,ie;
	for(i=0,iz=0,ie=0;i<n;++i)
	{
		if(ne<n&&zero_eig[iz]==i)
		{
			iz++;
			continue;
		}
		for(j=0,pQ=Q;j<n;++j)
		{
			for(k=0;k<=j;++k)
			{
				*pQ+=fabs(use_eig[ie])*S[i*n+j]*S[i*n+k];
				pQ++;
			}
		}
		ie++;
	}
	return back;
}
//Fix by changing negative eigenvalues to zero
extern "C" DLLEXPORT int eig_fix(dimen n,vector Q)
{
	size_t n2=n*n,itmax=1000,i,j,k;
	std::valarray<double> S(n2),v(n);
	vector pQ;
	for(i=0,pQ=Q;i<n;++i)
	{
		for(j=0;j<=i;++j)
		{
			S[i+n*j]=*pQ;
			if(i!=j)
				S[i*n+j]=*pQ;
			pQ++;
		}
	}
	int ret=eigendecomp(n,&S[0],&v[0],itmax);
	for(i=0;i<n;++i)
	{
		if(v[i]>lm_eps8)continue;
		for(j=0,pQ=Q;j<n;++j)
		{
			for(k=0;k<=j;++k)
			{
				*pQ+=(lm_eps8-v[i])*S[i*n+j]*S[i*n+k];
				pQ++;
			}
		}
	}
	return ret;
}
//Use Quadratic optimisation for fixing
extern "C" DLLEXPORT int quad_fix(dimen n,vector Q,vector mask)
{
#ifdef __SYSNT__
	_ASSERT(0);
#endif
/*	
Colin, April 2005
1) Find eigenvalues/eigenvectors.
2) Exit if no negative eigenvalues.
3) Vary all of the eigenvalues ei which have size bigger than ztol so that their sign
is positive and that the symmetric matrix that they define Q' is close to Q, keeping
the eigenvectors vi constant, i.e.
min sum (Qjk-Q'jk)**2 * m[jk] 
for some mask m and ei>=0 where Q'jk=sum ei*vi[j]*vi[k]
Q*vi = ei*vi
	*/
	std::valarray<double> vmask;
	size_t n2=n*n,nn=n*(n+1)/2,itmax=1000,i,j,k,l;
	if(!mask)//Use unit matrix for mask if mask hasn't been set.
	{
		vmask.resize(nn);
		vmask=0;
		mask=&vmask[0];
		for(i=0,j=0;i<n;++i,j+=(i+1))//j generates i*(i+3)/2 i.e. diagonal elements
			mask[j]=1;
	}
	std::valarray<double> S(n2),v(n);
	vector pQ,pM;
	for(i=0,pQ=Q;i<n;++i)
	{
		for(j=0;j<=i;++j)
		{
			S[i+n*j]=*pQ;
			if(i!=j)
				S[i*n+j]=*pQ;
			pQ++;
		}
	}
	eigendecomp(n,&S[0],&v[0],itmax);
	double mmax,mmin,ztol;
	dxminmax(n,&v[0],1,&mmax,&mmin);
	ztol=dmin(10,mmax)*lm_eps;
	std::vector<size_t> zero_eig;
	size_t nneg=0;
	for(i=0;i<n;++i)
	{
		if(fabs(v[i])<ztol)
		{
			zero_eig.push_back(i);
		}
		if(v[i]<=-ztol)nneg++;
	}
	size_t nopt=n-zero_eig.size(),iz1,iz2;
	if(!nneg)return 0;
	size_t non=nopt*(nopt+1)/2;
	std::valarray<double>c(nopt),H(non);
	c=0;
	H=0;
	vector pH,pC;
	double outer;
	for(i=0,pQ=Q,pM=mask;i<n;++i)
	{
		for(j=0;j<=i;++j)
		{
			for(k=0,iz1=0,pC=&c[0],pH=&H[0];k<n;++k)
			{
				if(zero_eig.size()&&zero_eig[iz1]==k)
				{
					iz1++;
					continue;
				}
				outer=S[k*n+i]*S[k*n+j]* *pM;
				*pC++ +=outer* *pQ;
				for(l=0,iz2=0;l<=k;++l)
				{
					if(zero_eig.size()&&zero_eig[iz2]==l)
					{
						iz2++;
						continue;
					}
					*pH++ +=outer*S[l*n+i]*S[l*n+j];
				}
			}
			pQ++;
			pM++;
		}
	}
	std::valarray<double>w(nopt),L(nopt),U(nopt);
	L=0;
	U=1e6;
	int ret=ConstrRegress(nopt,0,&H[0],&c[0],&w[0],&L[0],&U[0],0);
	size_t iz,ie;
	dzerovec(nn,Q);
	for(i=0,iz=0,ie=0;i<n;++i)
	{
		if(nopt<n&&zero_eig[iz]==i)
		{
			iz++;
			continue;
		}
		for(j=0,pQ=Q;j<n;++j)
		{
			if(S[i*n+j]!=0)
			{
				outer=w[ie]*S[i*n+j];
				for(k=0;k<=j;++k)
				{
					*pQ+=outer*S[i*n+k];
					pQ++;
				}
			}
			else
				pQ+=(j+1);
		}
		ie++;
	}
	return ret;
}

//Second Order Cone Optimisation
class SOCP
{
public:
	size_t n;
	size_t m;
	size_t* md;
	size_t nb;
	size_t nblockH;
	vector c;
	vector A;
	vector b;
	vector w;
	vector z;
	SOCP(size_t n,size_t m,size_t *md,vector c,vector A,vector b,vector w,size_t nb,vector z,
		double delt=1e-2,double nu=100);
	~SOCP();
	double coneb(size_t n,vector u);
	void gconeb(size_t n,vector u,vector back);
	void hconeb(size_t n,vector u,vector back);
	void hconebinv(size_t n,vector u,vector back);
	void makeu(vector w);
	void makerhs(vector w,vector z);
	void conj2(vector x,vector H,vector y);
	void BIGSOLVE();
	void SetLog();
//	void AddLog(const char* mess);
	void AddLog(const char *mess, ...);
	void PrintLog();
	short SOCPsolve();
	double gap(vector w,vector z);
	double pot(vector w,vector z);
	double potu(vector u,vector z);
	void newpoint(double step,vector x0,vector dx,vector x1);
	bool linemin(vector pq1,vector dpq,vector pqn);
	void pqget(double&p,double&q);
	double plane(double p,double q);
	double nu;
	double delt;
	size_t printfreq;
	size_t maxiter;
	double gapconv;
private:
	std::stringstream *logprint;
	std::valarray<double> *pspace;
	std::valarray<double> *pu;
	std::valarray<double> *pdu;
	std::valarray<double> *rhs;
	std::valarray<double> *blockHm1;
	std::valarray<double> *DZX;
	std::valarray<double> *newvec;
	double coneconv;
	double GAP;
	double POT;
	double p;
	double q;
	bool badgap;
	bool badconeu;
	bool badconez;
	double cdx;
	double bdz;
	double zu;
	double rho;
	double zdu;
	double udz;
	double gap0;
	double rhocon;
	double mlogcon;
	bool nolog;
	size_t main_iter;
	double planepot;
};
SOCP::SOCP(size_t n,size_t m,size_t *md,vector c,vector A,vector b,vector w,size_t nb,vector z,
		   double delt,double nu)
{
	this->n=n;
	this->m=m;
	this->md=md;
	this->nb=nb;
	this->c=c;
	this->A=A;
	this->b=b;
	this->w=w;
	this->z=z;
	this->nu=nu;
	this->delt=delt;
	this->logprint=0;
	this->nolog=false;
	this->printfreq=100;
	this->maxiter=1000;
	this->gapconv=lm_rooteps;
	nblockH=0;
	size_t i;
	for(i=0;i<m;++i)
	{
		nblockH+=md[i]*(md[i]+1)/2;
	}
	pspace = new std::valarray<double>;
	newvec = new std::valarray<double>;
	newvec->resize(nb*2);
	pu = new std::valarray<double>;
	pdu = new std::valarray<double>;
	rhs = new std::valarray<double>;
	blockHm1 = new std::valarray<double>;
	DZX = new std::valarray<double>;
}
SOCP::~SOCP()
{
	if(logprint)delete logprint;
	delete pspace;
	delete newvec;
	delete pu;
	delete pdu;
	delete rhs;
	delete blockHm1;
	delete DZX;
}
void SOCP::SetLog()
{
	logprint=new std::stringstream;
}
void SOCP::PrintLog()
{
	if(logprint)std::cout<<(*logprint).str();
}
/*void SOCP::AddLog(const char* mess)
{
	if(nolog)return;
#if defined( MSDOSS ) || defined( _DEBUG ) || defined( __linux__ )
	std::cout<<mess;std::cout.flush();
#endif
	if(logprint)*logprint<<mess;
}*/
void SOCP::AddLog(const char *mess, ...)
{
	char mm[200];
	va_list ttt;
	va_start(ttt,mess);
	int i = vsprintf(mm, mess, ttt);
	if(i>0)
	{
		if(logprint)*logprint<<mm;
#if defined( MSDOSS ) || defined( _DEBUG ) || defined( __linux__ )
		std::cout<<mm;std::cout.flush();
#endif
	}
	va_end(ttt);
}
void SOCP::conj2(vector x,vector H,vector y)
{
	//For 2 by 2 symmetric matrix H, find direction y which is conjugate to x
	y[0]=-x[1];y[1]=x[0];
	double Hy[2],Hx[2],xx;
	dsmxmulv(2,H,y,Hy);
	dsmxmulv(2,H,x,Hx);
	double p = ddotvec(2,x,Hy)/(xx=ddotvec(2,x,Hx));
	y[0]-=x[0]*p;
	y[1]-=x[1]*p;
}
void SOCP::makeu(vector w)
{
	//u=A.w+b
	pu->resize(nb);
	size_t i;
	for(i=0;i<nb;++i)(*pu)[i]=ddotvec(n,A+i*n,w)+b[i];
}
double SOCP::gap(vector w,vector z)
{
	return ddotvec(n,c,w)+ddotvec(nb,b,z);
}
double SOCP::pot(vector w,vector z)
{
	double g=gap(w,z);
	vector uu,zz;
	makeu(w);
	double back= rhocon*log(g)-mlogcon;
	size_t i;
	for(i=0,uu=&(*pu)[0],zz=z;i<m;uu+=md[i],zz+=md[i],++i)
		back+=coneb(md[i],uu)+coneb(md[i],zz);
	return back;
}
double SOCP::potu(vector u,vector z)
{
	double g=ddotvec(nb,u,z);
	badgap=0;
	if(g<-lm_eps8)
	{
		badgap=1;return 1e99;
	}
	badconez=0;
	badconeu=0;
	vector uu,zz;
	makeu(w);
	double back= rhocon*log(g)-mlogcon;
	size_t i;
	for(i=0,uu=u,zz=z;i<m;uu+=md[i],zz+=md[i],++i)
	{
		if(uu[md[i]-1] < lm_eps)
		{
			badconeu=1;return 1e99;
		}
		else if(uu[md[i]-1]*uu[md[i]-1]<lm_eps*lm_eps+ddotvec(md[i]-1,uu,uu))
		{
			badconeu=1;return 1e99;
		}
		if(zz[md[i]-1] < lm_eps)
		{
			badconez=1;return 1e99;
		}
		else if(zz[md[i]-1]*zz[md[i]-1]<lm_eps*lm_eps+ddotvec(md[i]-1,zz,zz))
		{
			badconez=1;return 1e99;
		}
		back+=coneb(md[i],uu)+coneb(md[i],zz);
	}
	return back;
}
void SOCP::makerhs(vector w,vector z)
{
	makeu(w);
	vector u=&(*pu)[0];
	GAP=ddotvec(nb,u,z);
	POT=potu(u,z);
	if(!(main_iter%printfreq))AddLog((char*)"gap %20.12e\n",gap(w,z));
	if(!(main_iter%printfreq))AddLog((char*)"potential %20.12e\n",pot(w,z));
	double rho=rhocon/GAP;
	rhs->resize(nb+n);
	blockHm1->resize(nblockH);
	dzerovec(n,&(*rhs)[nb]);
	size_t i;
	vector zz=z,rr=&(*rhs)[0],uu=&(*pu)[0],HH=&(*blockHm1)[0];
	for(i=0,zz=z;i<m;zz+=md[i],HH+=md[i]*(md[i]+1)/2,rr+=md[i],uu+=md[i],++i)
	{
		pspace->resize(md[i]);
		gconeb(md[i],uu,&(*pspace)[0]);
		daxpyvec(md[i],rho,zz,&(*pspace)[0]);
		hconebinv(md[i],uu,HH);
		dsmxmulv(md[i],HH,&(*pspace)[0],rr);
		dnegvec(md[i],rr);
	}
}
short SOCP::SOCPsolve()
{
	this->rhocon=(2*m+nu*sqrt(2.0*m));
	this->mlogcon=2*m*log((double)m);
	size_t i=0;
	main_iter=0;
	do
	{
		if(!(main_iter%printfreq))AddLog((char*)"================ Iteration %4d ================\n",main_iter+1);
		BIGSOLVE();
		main_iter++;
	}
	while(GAP>gapconv && coneconv > lm_eps && main_iter<maxiter && !(fabs(p)<lm_rooteps && fabs(q)<lm_rooteps));
	AddLog((char*)"Number of iterations; %d\n",main_iter+1);
	AddLog((char*)"%7s %20s\n",(char*)"",(char*)"w");
	for(i=0;i<n;++i)
		AddLog((char*)"%7d %20.12e\n",i+1,w[i]);
	AddLog((char*)"%7s %20s %20s\n",(char*)"",(char*)"z",(char*)"u");
	for(i=0;i<nb;++i)
		AddLog((char*)"%7d %20.12e %20.12e\n",i+1,z[i],(*pu)[i]);
	AddLog((char*)"%7s %7s %20s %20s\n",(char*)"cone",(char*)"",(char*)"z",(char*)"u");
	size_t tot;
	coneconv=0;
	double zcone,ucone;
	for(i=0,tot=0;i<m;tot+=md[i],++i)
	{
		ucone=(*pu)[tot+md[i]-1]*(*pu)[tot+md[i]-1]-ddotvec(md[i]-1,&(*pu)[tot],&(*pu)[tot]);
		zcone=z[tot+md[i]-1]*z[tot+md[i]-1]-ddotvec(md[i]-1,z+tot,z+tot);
		AddLog((char*)"%7d %7s %20.12e %20.12e\n",i+1,(char*)"tt-uu",zcone,ucone);
		coneconv+=zcone*ucone;
	}
	AddLog((char*)"Gap %20.12e; Potential %20.12e\n",(GAP=ddotvec(nb,z,&(*pu)[0])),(POT=potu(&(*pu)[0],z)));
	AddLog((char*)"Cone convergence %20.12e\n",coneconv);
	if(GAP<=gapconv||coneconv<=lm_eps)return 0;
	else return 1;
}

void SOCP::BIGSOLVE()
{
	pdu->resize(nb);
	makerhs(w,z);
	size_t i,tot,j,I,J;
/*	if(!(main_iter%printfreq))AddLog((char*)"%7s %20s\n",(char*)"",(char*)"old w");
	for(i=0;i<n;++i)
	{
		if(!(main_iter%printfreq))
			AddLog((char*)"%7d %20.12e\n",i+1,w[i]);
	}
	if(!(main_iter%printfreq))AddLog((char*)"%7s %20s %20s\n",(char*)"",(char*)"old z",(char*)"old u");
	for(i=0;i<nb;++i)
	{
		if(!(main_iter%printfreq))
			AddLog((char*)"%7d %20.12e %20.12e\n",i+1,z[i],(*pu)[i]);
	}*/
	std::valarray<double>HH((nb+n)*(nb+n+1)/2);
	HH=0;
	vector pHH=&HH[0],sHH=&(*blockHm1)[0];
	for(i=0,tot=0;i<m;tot+=md[i],i++)
	{
		for(I=tot;I<tot+md[i];++I)
		{
			for(J=tot;J<=I;++J)
			{
				HH[I*(I+1)/2+J]=*sHH++;
			}
		}
	}
	for(i=nb;i<nb+n;++i)
	{
		for(j=0;j<nb;++j)
		{
			HH[i*(i+1)/2+j]=A[i-nb+j*n];
		}
	}
//	printsym(nb+n,pHH);
	DZX->resize(n+nb);
	{
		dcopyvec(n+nb,&(*rhs)[0],&(*DZX)[0]);
		dimen nn = ((n+nb) * (n+nb + 1)) >> 1;
		std::valarray<double>Qcopy(nn);
		std::valarray<short_scl>P(n+nb);
		dcopyvec(nn,pHH,&Qcopy[0]);
		dsmxfac(n+nb,&Qcopy[0],&P[0]);
		dsmxainv(n+nb,&Qcopy[0],&P[0],&(*DZX)[0]);
	}
//	conj_solve(n+nb,pHH,&(*rhs)[0],&(*DZX)[0],0,SSmult,0,1);//Not good enough
//	symm_inverse_x(n+nb,pHH,&(*rhs)[0],&(*DZX)[0]);
/*	if(!(main_iter%printfreq))AddLog((char*)"%7s %20s %20s\n",(char*)"",(char*)"right hand side",(char*)"new changes");
	for(i=0;i<(n+nb);++i)
	{
		if(!(main_iter%printfreq))
			AddLog((char*)"%7d %20.12e %20.12e\n",i+1,(*rhs)[i],(*DZX)[i]);
	}*/
	vector dw=&(*DZX)[nb];
	pqget(p,q);
	daxpyvec(n,p,dw,w);
	daxpyvec(nb,q,&(*DZX)[0],z);
	if(!(main_iter%printfreq))AddLog((char*)"p %20.12e q %20.12e\n",p,q);
	makeu(w);
/*	if(!(main_iter%printfreq))AddLog((char*)"%7s %20s\n",(char*)"",(char*)"new w");
	for(i=0;i<n;++i)
	{
		if(!(main_iter%printfreq))
			AddLog((char*)"%7d %20.12e\n",i+1,w[i]);
	}
	if(!(main_iter%printfreq))AddLog((char*)"%7s %20s %20s\n",(char*)"",(char*)"new z",(char*)"new u");
	for(i=0;i<nb;++i)
	{
		if(!(main_iter%printfreq))
			AddLog((char*)"%7d %20.12e %20.12e\n",i+1,z[i],(*pu)[i]);
	}
	if(!(main_iter%printfreq))AddLog((char*)"%7s %7s %20s %20s\n",(char*)"cone",(char*)"",(char*)"new z",(char*)"new u");*/
	coneconv=0;
	double zcone,ucone;
	for(i=0,tot=0;i<m;tot+=md[i],++i)
	{
		ucone=(*pu)[tot+md[i]-1]*(*pu)[tot+md[i]-1]-ddotvec(md[i]-1,&(*pu)[tot],&(*pu)[tot]);
		zcone=z[tot+md[i]-1]*z[tot+md[i]-1]-ddotvec(md[i]-1,z+tot,z+tot);
		/*if(!(main_iter%printfreq))
			AddLog((char*)"%7d %7s %20.12e %20.12e\n",i+1,(char*)"tt-uu",zcone,ucone);*/
		coneconv+=zcone*ucone;
	}
	if(!(main_iter%printfreq))
		AddLog((char*)"Cone convergence %20.12e\n",coneconv);
	GAP=ddotvec(nb,z,&(*pu)[0]);
	POT=potu(&(*pu)[0],z);
	if(!(main_iter%printfreq))
		AddLog((char*)"New gap %20.12e; potential %20.12e\n",GAP,POT);
}
void SOCP::newpoint(double q1,vector z,vector dz,vector newz)
{
	dcopyvec(nb,z,newz);
	if(q1!=0)daxpyvec(nb,q1,dz,newz);
}
double SOCP::plane(double x,double y)
{
	vector u=&(*pu)[0];
	vector du=&(*pdu)[0];
	vector dz=&(*DZX)[0];
	vector newu=&(*newvec)[0];
	vector newz=newu+nb;
	newpoint(x,u,du,newu);
	newpoint(y,z,dz,newz);
	return potu(newu,newz);
}
bool SOCP::linemin(vector pq1,vector dpq,vector pqn)
{
	//First find the maximum step which allows a non-negative gap
	double gap1=gap0,pqtest[2];
	if(pq1)gap1+=pq1[0]*zdu+pq1[1]*udz;
	double BB=dpq[0]*zdu+dpq[1]*udz;
	double maxstep=-gap1/BB;
	//Rescale the direction so that 1 means gap=0
	dscalvec(2,maxstep,dpq);
	size_t nstep,i;
	if(pq1)dcopyvec(2,pq1,pqtest);
	else dzerovec(2,pqtest);
	double pot0=plane(pqtest[0],pqtest[1]),potn;
	double potm=pot0;
	double delthere=delt,deltmin=lm_rooteps;
	bool smaller=false;
	//Then minimise along the path using increments of length delthere
	while(potm==pot0)
	{
		nstep=(size_t)(1.0/delt);
		if(pq1)dcopyvec(2,pq1,pqtest);
		else dzerovec(2,pqtest);
		while(delthere>deltmin)
		{
			smaller=false;
			badgap=0;badconez=0;badconeu=0;
			for(i=0;i<nstep&&(!badgap&&!badconeu&&!badconez);++i)
			{
				daxpyvec(2,delthere,dpq,pqtest);
				if((potn=plane(pqtest[0],pqtest[1]))<potm)
				{
					potm=potn;
					dcopyvec(2,pqtest,pqn);smaller=true;
				}
				else if(!badgap&&!badconeu&&!badconez)break;
				else if(badconez)
				{
					if((potn=plane(pqtest[0],0))<potm)
					{
						potm=potn;
						pqn[0]=pqtest[0];pqn[1]=0;smaller=true;
					}
					else break;
				}
				else if(badconeu)
				{
					if((potn=plane(0,pqtest[1]))<potm)
					{
						potm=potn;
						pqn[1]=pqtest[1];pqn[0]=0;smaller=true;
					}
					else break;
				}
			}
			if(smaller&&potm<potn&&potm!=pot0)
			{
				daxpyvec(2,-delthere,dpq,pqtest);
				delthere*=.1;
			}
			else break;
		}
		if(pq1)dcopyvec(2,pq1,pqtest);
		else dzerovec(2,pqtest);
		if(potm==pot0)
		{
			while(delthere>deltmin)
			{
				smaller=false;
				badgap=0;badconez=0;badconeu=0;
				for(i=0;i<nstep&&(!badgap&&!badconeu&&!badconez);++i)
				{
					daxpyvec(2,-delthere,dpq,pqtest);
					if((potn=plane(pqtest[0],pqtest[1]))<potm)
					{
						potm=potn;
						dcopyvec(2,pqtest,pqn);smaller=true;
					}
					else if(!badgap&&!badconeu&&!badconez)break;
					else if(badconez)
					{
						if((potn=plane(pqtest[0],0))<potm)
						{
							potm=potn;
							pqn[0]=pqtest[0];pqn[1]=0;smaller=true;
						}
						else break;
					}
					else if(badconeu)
					{
						if((potn=plane(0,pqtest[1]))<potm)
						{
							potm=potn;
							pqn[1]=pqtest[1];pqn[0]=0;smaller=true;
						}
						else break;
					}
				}
				if(smaller&&potm<potn&&potm!=pot0)
				{
					daxpyvec(2,delthere,dpq,pqtest);
					delthere*=.1;
				}
				else break;
			}
		}
		if(delthere<deltmin) 
			return false;
		if(potm==pot0)
		{
			badgap=0;badconez=0;badconeu=0;
			delthere*=.1;
		/*	if(!(main_iter%printfreq))
				AddLog((char*)" ++++++++++++++ Reducing step size to %20.12e ++++++++++++++\n",delthere);*/
		}
	}
	planepot=potm;
	return true;
}
void SOCP::pqget(double&p,double&q)
{
	size_t i;
	vector dz=&(*DZX)[0];
	vector dx=&(*DZX)[nb];
	vector u=&(*pu)[0];
	vector du=&(*pdu)[0];
	cdx=ddotvec(n,c,dx);
	bdz=ddotvec(nb,b,dz);
	zu=ddotvec(nb,u,z);
	rho=rhocon/zu;
	std::valarray<double> gg(2),perp(2),hh(3);
	for(i=0;i<nb;++i)du[i]=ddotvec(n,A+i*n,dx);
	zdu=ddotvec(nb,z,du),udz=ddotvec(nb,u,dz);
	gap0=ddotvec(nb,z,u);
	gg[0]=cdx*rho;
	gg[1]=bdz*rho;
	hh[0]=-cdx*cdx/rho/zu;
	hh[1]=-cdx*bdz/rho/zu;
	hh[2]=-bdz*bdz/rho/zu;
	size_t tot=0,nn;
	for(i=0,tot=0;i<m;tot+=md[i],++i)
	{
		nn=md[i]*(md[i]+1)/2;
		pspace->resize(2*nn);
		gconeb(md[i],u+tot,&(*pspace)[0]);
		gg[0]+=ddotvec(md[i],du+tot,&(*pspace)[0]);
		gconeb(md[i],z+tot,&(*pspace)[0]);
		gg[1]+=ddotvec(md[i],dz+tot,&(*pspace)[0]);
		hconeb(md[i],u+tot,&(*pspace)[0]);
		dsmxmulv(md[i],&(*pspace)[0],du+tot,&(*pspace)[nn]);
		hh[0]+=ddotvec(md[i],du+tot,&(*pspace)[nn]);
		hconeb(md[i],z+tot,&(*pspace)[0]);
		dsmxmulv(md[i],&(*pspace)[0],dz+tot,&(*pspace)[nn]);
		hh[2]+=ddotvec(md[i],dz+tot,&(*pspace)[nn]);
	}
	double newpq[2],nextpq[2],testpot,oldpot=1e10;
//	double inner=sqrt((hh[0]-hh[2])*(hh[0]-hh[2])+4*hh[1]*hh[1]);
//	double lambda1=0.5*((hh[0]+hh[2])+inner),lambda2=0.5*((hh[0]+hh[2])-inner);
	double newt[2],det=hh[0]*hh[2]-hh[1]*hh[1];
	if(1)///*lambda1>0&&lambda2>0*/det>0 && (hh[0]+hh[2])>0)//Avoid the sqrt
	{
		newt[0]=-(gg[0]*hh[2]-gg[1]*hh[1])/det;
		newt[1]=-(-gg[0]*hh[1]+gg[1]*hh[0])/det;
		perp[0]=newt[1];perp[1]=-newt[0];
		newpq[0]=newpq[1]=0;
		if(linemin(0,newt,newpq))
		{
			p=newpq[0];q=newpq[1];
		}
		nextpq[0]=newpq[0];nextpq[1]=newpq[1];
		if(linemin(newpq,&perp[0],nextpq))
		{
			p=nextpq[0];q=nextpq[1];
		}
		else
		{
			p=newpq[0];q=newpq[1];
			planepot=POT;
		}
	}
	else
	{
		p=q=0;
		nextpq[0]=0;
		nextpq[1]=0;
		planepot=POT;
	}
	if(fabs(det)<1e+10)
	{
		conj2(&gg[0],&hh[0],&perp[0]);
	}
	else if(
		(p==0&&q==0)
		||
		((fabs(p/q)<1e5)&&(fabs(q/p)<1e5))
		)
	{
		perp[0]=gg[1];
		perp[1]=-gg[0];
	}
	else
	{
		gg[0]=1;gg[1]=0;
		perp[0]=0;perp[1]=1;
	}
	i=0;
	while(i++<100&&(testpot=fabs((oldpot-planepot)/oldpot))>1e-6)
	{
		oldpot=planepot;
		newpq[0]=nextpq[0];
		newpq[1]=nextpq[1];
		if(linemin(nextpq,&gg[0],newpq))
		{
			p=newpq[0];q=newpq[1];
		}
		nextpq[0]=newpq[0];
		nextpq[1]=newpq[1];
		if(linemin(newpq,&perp[0],nextpq))
		{
			p=nextpq[0];q=nextpq[1];
		}
	}
	if(!(main_iter%printfreq))AddLog((char*)"Number of plane iterations; %5d, potential %20.12e\n",i,planepot);
}
double SOCP::coneb(size_t n,vector u)
{
	--n;
	double t=u[n];
	return -log(t*t-ddotvec(n,u,u));
}

void SOCP::gconeb(size_t n,vector u,vector back)
{
	--n;
	double t=u[n];
	double front=2.0/(t*t-ddotvec(n,u,u));
	dcopyvec(n,u,back);
	back[n]=-t;
	++n;
	dscalvec(n,front,back);
}
void SOCP::hconeb(size_t n,vector u,vector back)
{
	size_t n1=n,i,j;
	--n;
	double t=u[n];
	double normu=ddotvec(n,u,u),tt=t*t,front=2.0/(tt-normu)/(tt-normu);
	vector ui,uj;
	for(i=0,ui=u;i<n1;++i,ui++)
	{
		for(j=0,uj=u;j<=i;++j,uj++)
		{
			if(i==j && i < n)
			{
				*back=tt-normu+*ui* *ui*2;
			}
			else if(i==j)
			{
				*back=tt+normu;
			}
			else if(i<n)
			{
				*back=2* *ui* *uj;
			}
			else
			{
				*back=-2* *uj*t;
			}
			*back++ *=front;
		}
	}
}
void SOCP::hconebinv(size_t n,vector u,vector back)
{
	size_t n1=n,i,j;
	--n;
	double t=u[n];
	double normu=ddotvec(n,u,u),tt=t*t,front=0.5;
	vector ui,uj;
	for(i=0,ui=u;i<n1;++i,ui++)
	{
		for(j=0,uj=u;j<=i;++j,uj++)
		{
			if(i==j && i < n)
			{
				*back=tt-normu+*ui* *ui*2;
			}
			else if(i==j)
			{
				*back=tt+normu;
			}
			else if(i<n)
			{
				*back=2* *ui* *uj;
			}
			else
			{
				*back=2* *uj*t;
			}
			*back++ *=front;
		}
	}
}

typedef void		(*ConstMul)_PROTO((vector x,vector Ax,void* info));
#ifdef SPARSELIBTEST
extern "C" void DeleteSparseA(void*info);
extern "C" void CreateSparseA(void**info,size_t n);
extern "C" void SetSparseA(void* info,size_t i,size_t j,double val);
extern "C" void SparseFactor(void*info,size_t n,double tol);
extern "C" void SparseSolve(void*info,size_t n,double*b);
#endif
//#define HARWELL
#ifdef HARWELL
extern "C"
{
int ma27id_(int* ICNTL,double* CNTL);
int ma27ad_(int* N,int* NZ,int* IRN,int* ICN,int* IW,int* LIW,int* IKEEP,
					   int* IW1,int* NSTEPS,int* IFLAG,int* ICNTL,double* CNTL,
					   int* INFO,double* OPS);
int ma27bd_(int* N,int* NZ,int* IRN,int* ICN,double* A,int* LA,int* IW,int* LIW,
					   int* IKEEP,int* NSTEPS,int* MAXFRT,int* IW1,int* ICNTL,
					   double* CNTL,int* INFO);
int ma27cd_(int* NN,double* A,int* NLA,int* NIW,int* NLIW,double* W,int* NMAXFRT,
					   double* RHS,int* NIW1,int* NNSTEPS,int* NICNTL,int* NINFO);
int ma37ad_(int* N,int* NE,int* IRN,int* JCN,int* IW,int* LIW,int* IKEEP,
					   int* IW1,int*NSTEPS,int* IFLAG);
int ma37bd_(int* N,int* NE,int* IRN,int* JCN,double* A,int* LA,int* IW,int* LIW,
					   int* IKEEP,int* NSTEPS,int* MAXPRT,int*IFLAG);
int ma37cd_(int* NN,double* A,int* LA,int* IW,int* LIW,double* W,int*maxprt,
					   double* RHS,int* IW1,int* NSTEPS,double*w2,int*mtype);
int ma47id_(double* CNTL,int* ICNTL);
int ma47ad_(int* N,int* NE,int* IRN,int* JCN,int* IW,int* LIW,int* IKEEP,
					   int* ICNTL,double*RINFO,int* INFO);
int ma47bd_(int* N,int* NE,int* JCN,double* A,int* LA,int* IW,int* LIW,
					   int* IKEEP,double* CNTL,int* ICNTL,int* IW1,double*RINFO,
					   int* INFO);
int ma47cd_(int* NN,double* A,int* NLA,int* NIW,int* NLIW,double* W,
					   double* RHS,int* NIW1,int* NICNTL);
extern int ma37ed_[];
}

#define MA47

class Solve
{
public:
	int n;
	int nz;
	int lw;
	int nsteps;
	int icntl[30];
	int info[24];
	int maxprt;
	double cntl[5];
	double ops;
	double*M;
	void Factor();
	void Solve1(double*b);
	Solve(size_t n,double *M);
	Solve();
	~Solve();
private:
	std::valarray<int>*iwork;
	std::vector<double>*SM;
	std::vector<int>*ii;
	std::vector<int>*jj;
	std::vector<int>*pivot;
};
Solve::Solve(size_t n,double *M)
{
	this->n=n;
	this->M=M;
	iwork=new std::valarray<int>;
	ii=new std::vector<int>;
	jj=new std::vector<int>;
	pivot=new std::vector<int>;
	SM=new std::vector<double>;
}
Solve::Solve()
{
	this->n=0;
	this->M=0;
	iwork=new std::valarray<int>;
	ii=new std::vector<int>;
	jj=new std::vector<int>;
	pivot=new std::vector<int>;
	SM=new std::vector<double>;
}
Solve::~Solve()
{
	n=0;
	M=0;
	delete iwork;
	delete ii;
	delete jj;
	delete pivot;
	delete SM;
}
void Solve::Factor()
{
	if(this->M&&n)
	{
		if(!ii->empty())ii->erase(ii->begin(),ii->end());
		if(!jj->empty())jj->erase(jj->begin(),jj->end());
		if(!SM->empty())SM->erase(SM->begin(),SM->end());
#ifdef MA27
		ma27id_(icntl,cntl);
#endif
#ifdef MA47
		ma47id_(cntl,icntl);
#endif
		double* M=this->M;
		for(int i=0;i<n;++i)
		{
			for(int j=0;j<=i;++j)
			{
				if(*M!=0)
				{
					ii->push_back(i+1);
					jj->push_back(j+1);
					SM->push_back(*M);
#ifdef MA37
					if(i!=j)
					{
						ii->push_back(j+1);
						jj->push_back(i+1);
						SM->push_back(*M);
					}
#endif
				}
				M++;
			}
		}
		nz=ii->size();
		std::valarray<double>SM1(nz);
		memmove(&SM1[0],&(SM->front()),nz*sizeof(double));
#ifdef MA27
		lw=(2*nz+3*n+1)*1.25;
		iwork->resize(lw);
		pivot->resize(5*n);
		int setz=0;
		ma27ad_(&n,&nz,&(ii->front()),&(jj->front()),&(*iwork)[0],&lw,&(*pivot)[0],
			&(*pivot)[3*n],&nsteps,&setz,icntl,cntl,info,&ops);
		int la=this->info[4]*1.5;
		do
		{
			SM->resize(la);
			ma27bd_(&n,&nz,&(ii->front()),&(jj->front()),&(SM->front()),&la,&(*iwork)[0],&lw,
				&(*pivot)[0],&nsteps,&maxprt,&(*pivot)[3*n],icntl,cntl,info);
			if(info[0]==-4)
			{
				la=info[1]*1.5;;
				printf((char*)"Increasing la to %d\n",la);
				memmove(&(SM->front()),&SM1[0],nz*sizeof(double));
			}
		}
		while(info[0]==-4);
#endif
#ifdef MA47
		lw=(2*nz+5*n+4)*1.25;
		iwork->resize(lw);
		pivot->resize(nz+5*n+2+2*n+2);
		double rinfo[4];
		ma47ad_(&n,&nz,&(ii->front()),&(jj->front()),&(*iwork)[0],&lw,&(*pivot)[0],icntl,
			rinfo,info);
		int la=info[5]*1.5;
		while(lw<info[6])
		{
			printf((char*)"Re-doing symbolic factoring\n");
			SM->resize(la);
			lw=info[6]*1.5;
			iwork->resize(lw);
			ma47ad_(&n,&nz,&(ii->front()),&(jj->front()),&(*iwork)[0],&lw,&(*pivot)[0],icntl,
				rinfo,info);
		}
		do
		{
			SM->resize(la);
			ma47bd_(&n,&nz,&(jj->front()),&(SM->front()),&la,&(*iwork)[0],&lw,&(*pivot)[0],
				cntl,icntl,&(*pivot)[nz+5*n+2],rinfo,info);
			if(info[0]==-4)
			{
				la=info[5]*1.5;
				printf((char*)"Increasing la to %d\n",la);
				memmove(&(SM->front()),&SM1[0],nz*sizeof(double));
			}
		}
		while(info[0]==-4);
#endif
#ifdef MA37
		lw=(2*nz+3*n+1)*1.25;
		iwork->resize(lw);
		pivot->resize(5*n);
		nsteps;
		int iflag=0;
		ma37ad_(&n,&nz,&(ii->front()),&(jj->front()),&(*iwork)[0],&lw,&(*pivot)[0],
			&(*pivot)[3*n],&nsteps,&iflag);
		int la=ma37ed_[7]*1.5;
		lw=ma37ed_[8]*1.5;
		do
		{
			SM->resize(la);
			iwork->resize(lw);
			iflag=0;
			ma37bd_(&n,&nz,&(ii->front()),&(jj->front()),&(SM->front()),&la,&(*iwork)[0],
				&lw,&(*pivot)[0],&nsteps,&maxprt,&iflag);
			if(iflag==-4)
			{
				la=ma37ed_[7]*1.5;
				memmove(&(SM->front()),&SM1[0],nz*sizeof(double));
			}
		}
		while(iflag==-4);
#endif
	}
}
void Solve::Solve1(double*b)
{
	int la=SM->size();
#ifdef MA27
	std::valarray<double>w(maxprt);
	ma27cd_(&n,&(SM->front()),&la,&(*iwork)[0],&lw,&w[0],&maxprt,b,&(*pivot)[3*n],&nsteps,
		icntl,info);
#endif
#ifdef MA47
	std::valarray<double>w(n);
	ma47cd_(&n,&(SM->front()),&la,&(*iwork)[0],&lw,&w[0],b,&(*pivot)[nz+5*n+2],icntl);
#endif
#ifdef MA37
	std::valarray<double>w(2*n);
	std::valarray<int>iw(nsteps);
	int mtype=1;
	ma37cd_(&n,&(SM->front()),&la,&(*iwork)[0],&lw,&w[0],&maxprt,b,&iw[0],&nsteps,&w[n],
		&mtype);
#endif
}
#endif
//#define MYSPARSE
#ifdef MYSPARSE
class Solve
{
public:
	size_t n;
	double*M;
	short_scl*PIVOT;
	short Factor();
	short Solve1(double*b);
	Solve();
	Solve(size_t n,double*M);
	~Solve();
private:
	std::valarray<short_scl>*pivot;
	std::valarray<size_t>*ap;
	std::vector<size_t>*ai;
	std::vector<double>*ms;
};
#endif
class SOCPhomog
{
public:
	void mat(size_t n,vector m,vector M);
	void inv(size_t n,vector m,vector M);
	void diag(size_t n,vector m,vector M);
	void q(size_t n,vector m);
	void Q(size_t n,vector M);
	void T(size_t n,vector M);
	double gettheta(size_t n,vector s,vector x,vector Q);
	double gettheta(size_t n,vector s,vector x);
	void getw(size_t n,vector s,vector x,double theta,vector Q,vector w);
	void getw(size_t n,vector s,vector x,double theta,vector w);
	void W(size_t n,vector w,vector W);
	void Wm1(size_t n,vector q,vector W,vector Wm1);
	void W2(size_t n,vector w,vector Q,vector W2);
	void thetaWm2(size_t n,vector q,vector W2,double theta,vector W);
	void Wtrans(vector A,vector WA);
	void W2trans(vector A,vector W2A);
	void thetaScale(vector A,bool recip=false,bool square=false);
	void Qmulvec(vector A);
	void makeResid(double gamma,double alpha=0);
	void getDirection(bool updateAA=true);
	void getDirectionL(bool updateAA=true);
	double getStepsize(double gamma,double beta);
	void applyXm1(vector x,vector A,vector Xm1A);
	void applyX(vector x,vector A,vector XA);
	void getw_and_theta();
	void AAsolve(vector qn,vector qm);
	void unit(vector u);
	void* SparseInfo;
	double clocker(int start);
	bool conecheck(vector x,const char* name=(char*)" ",double tol=lm_eps);
//	SparseLDL LDLObj;
	bool useSparse;
//	void AddLog(const char* mess);
	void AddLog(const char *mess, ...);
	void PrintLog(void);
	void SetLog(std::stringstream* logprint=0);
	double convscale(void);
#if defined (MYSPARSE) || defined (HARWELL)
	Solve* put;
#endif
	ConstMul Amx;
	ConstMul ATmy;
	SOCPhomog(size_t n,size_t m,int* ncone,vector c,vector A,vector b,vector x,vector y,vector s,
		double tau,double kappa);
	SOCPhomog();
	bool badtheta;
//	bool log;
	size_t n;
	size_t nx;
	size_t m;
	int* ncone;
	vector c;
	vector A;
	vector b;
	vector x;
	vector y;
	vector s;
	vector xkeep;
	vector ykeep;
	vector skeep;
	double taukeep;
	double kappakeep;
	vector r1;
	vector r2;
	vector r3;
	vector r4;
	vector r5;
	vector h1;
	vector h2;
	vector dx;
	vector dtau;
	vector dy;
	vector ds;
	vector dkappa;
	vector g1;
	vector g2;
	vector w;
	vector theta;
	vector xbar;
	vector sbar;
	double tau;
	double kappa;
	double mu;
	bool homog;
	bool use_conj;
	bool steep;
	~SOCPhomog();
	short conj_res;
	bool use_sparse;
	bool ldlfailed;
	int regmethod;
	bool golong;
	double changeratio;
	size_t badindex;
	bool usedouble;
	bool changetodouble;
private:
	std::valarray<size_t>*AorderR;
	std::valarray<size_t>*AorderC;
	std::valarray<size_t>*AorderC1;
	std::valarray<size_t>*SolveOrder;
	std::valarray<double>*space;
	std::valarray<double>*resid;
	std::valarray<double>*diffs;
	std::valarray<double>*AA;
#ifdef USE_SINGLE
	std::valarray<float>*AAsingle;
#endif
	std::valarray<short_scl>*AA_P;
	std::valarray<double> *xsbar;
	std::vector<double> *sparseDA;
	std::valarray<double> *sparseD;
	std::valarray<size_t> *sparseI;
	std::vector<size_t> *sparseIA;
//	std::valarray<double>*QDE;
	double timeaquired;
#ifndef _OPENMP
	clock_t timebase;
#else
	double timebase;
#endif
	short useordering;
	std::stringstream* logprint;
	vector Aproc;
};
void Amulx(vector x,vector Ax,void* info)
{
	SOCPhomog* here=(SOCPhomog*)info;
	vector A=here->A;
	size_t i;
	for(i=0;i<here->m;++i,A+=here->nx)
		Ax[i]=ddotvec(here->nx,A,x);
}
void ATmuly(vector x,vector Ax,void* info)
{
	SOCPhomog* here=(SOCPhomog*)info;
	vector A=here->A;
	size_t i;
	for(i=0;i<here->nx;++i)
		Ax[i]=BITA_ddot(here->m,A+i,here->nx,x,1);
}
SOCPhomog::SOCPhomog()
{
	space=new std::valarray<double>;
	AorderR=0;
	AorderC=0;
	AorderC1=0;
	SolveOrder=0;
	sparseD=0;
	sparseDA=0;
	sparseI=0;
	sparseIA=0;
	resid=0;
	diffs=0;
	AA=0;
#ifdef USE_SINGLE
	AAsingle=0;
#endif
	AA_P=0;
//	QDE=0;
	xsbar=0;
}
SOCPhomog::SOCPhomog(size_t n,size_t m,int* ncone,vector c,vector A,
						 vector b,vector x,vector y,vector s,double tau,double kappa)
{
#if defined (MYSPARSE) || defined (HARWELL)
	put=new Solve;
#endif
	changeratio=4;
	AorderR=0;
	AorderC=0;
	AorderC1=0;
	SolveOrder=0;
	space=0;
	homog=true;
//	log=true;
	use_conj=false;
	steep=false;
	use_sparse=true;
	sparseD=new std::valarray<double>;
	sparseDA=new std::vector<double>;
	sparseI=new std::valarray<size_t>;
	sparseIA=new std::vector<size_t>;
	resid=new std::valarray<double>;
	diffs=new std::valarray<double>;
	AA=new std::valarray<double>;
#ifdef USE_SINGLE
	AAsingle=new std::valarray<float>;
#endif
	AA_P=new std::valarray<short_scl>;
//	QDE=new std::valarray<double>;
	xsbar=new std::valarray<double>;
	this->n=n;
	this->m=m;
	this->ncone=ncone;
	this->A=A;
	this->b=b;
	this->c=c;
	this->x=x;
	this->y=y;
	this->s=s;
	this->tau=tau;
	this->kappa=kappa;
	this->Amx=(ConstMul)Amulx;
	this->ATmy=(ConstMul)ATmuly;
	regmethod=1;
	conj_res=0;
	nx=0;
	for(size_t i=0;i<n;i++){nx+=ncone[i];}
	resid->resize(2*m+3*nx+2);
	size_t mm=(m*(m+1))>>1;
	usedouble=false;
	changetodouble=false;
#ifdef USE_SINGLE
	AAsingle->resize(0);
	AAsingle->resize(mm);
	AA->resize(m*m);
#else
	AA->resize(0);
	AA->resize(mm);
#endif
	AA_P->resize(m);
//	QDE->resize(m*m+m+m-1);
	r1=&(*resid)[0];
	r2=r1+m;
	r3=r2+nx;
	r4=r3+1;
	r5=r4+nx;
	h1=r5+1;
	h2=h1+nx;
	diffs->resize(2*m+4*nx+2+n);
	dx=&(*diffs)[0];
	dtau=dx+nx;
	dy=dtau+1;
	ds=dy+m;
	dkappa=ds+nx;
	g1=dkappa+1;
	g2=g1+nx;
	w=g2+m;
	theta=w+nx;
	xsbar->resize(2*nx+2*nx+m);
	xbar=&(*xsbar)[0];
	sbar=xbar+nx;
	xkeep=sbar+nx;
	ykeep=xkeep+nx;
	skeep=ykeep+m;
	golong=false;
	ldlfailed=false;
	badindex=0;
	useordering=0;
	logprint=0;
	Aproc=0;
}
SOCPhomog::~SOCPhomog()
{
#if defined (MYSPARSE) || defined (HARWELL)
	if(put) delete put;
#endif
	if(AorderR)delete AorderR ;
	if(AorderC)delete AorderC ;
	if(AorderC1)delete AorderC1 ;
	if(SolveOrder) delete SolveOrder;
	if(sparseD) delete sparseD;
	if(sparseDA) delete sparseDA;
	if(sparseI) delete sparseI;
	if(sparseIA) delete sparseIA;
	if(space) delete space;
	if(resid) delete resid;
	if(diffs) delete diffs;
	if(AA) {AA->resize(0);delete AA;}
	if(AA_P) delete AA_P;
#ifdef USE_SINGLE
	if(AAsingle) {AAsingle->resize(0);delete AAsingle;}
#endif
//	if(QDE) delete QDE;
	if(xsbar) delete xsbar;
}
double SOCPhomog::convscale()
{
	return 1;//dmin(1,dmax(tau,kappa));
}
double SOCPhomog::clocker(int start)
{
#ifndef _OPENMP
	clock_t	t = clock();
#else
	double	t = omp_get_wtime();
#endif
	if(!start)
#ifndef _OPENMP
		timeaquired += (double)(t-timebase)/CLOCKS_PER_SEC;
#else
		timeaquired += (t-timebase);
#endif
	else
		timeaquired = 0;
	timebase=t;
	return timeaquired;
}
void SOCPhomog::mat(size_t n,vector m,vector M)
{
	size_t i,nn=n*(n+1)/2;
	vector MM,mm=m+(n-1);
	dzerovec(nn,M);
	for(i=0,MM=M;i<n-1;++i){MM+=i;*MM++=*mm;}
	dcopyvec(n,m,MM);
}
void SOCPhomog::inv(size_t n,vector m,vector M)
{
	double vv=ddotvec(n-1,m,m);
	size_t i,j,nn=n*(n+1)/2;
	vector MM,mm=m+(n-1),vi,vj;
	double vextra=*mm-vv/ *mm;
	double outer=vextra* *mm;;
	dzerovec(nn,M);
	for(i=0,vi=m,MM=M;i<n-1;++i,++vi)
	{
		for(j=0,vj=m;j<=i;++j,++vj)
		{
			*MM=*vi* *vj/ *mm;
			if(i==j){*MM+=vextra;}
			*MM++ /= outer;
		}
	}
	daxpyvec(n-1,-1./outer,m,MM);
	MM+=n-1;
	*MM=1/outer;
}
void SOCPhomog::diag(size_t n,vector m,vector M)
{
	size_t i,nn=n*(n+1)/2;
	dzerovec(nn,M);
	for(i=0;i<n;++i){M+=i;*M++=*m++;}
}
void SOCPhomog::q(size_t n,vector m)
{
	dsetvec(n-1,-1,m);
	m[n-1]=1;
}
void SOCPhomog::Q(size_t n,vector M)
{
	space->resize(n);
	this->q(n,&(*space)[0]);
	this->diag(n,&(*space)[0],M);
}
void SOCPhomog::T(size_t n,vector M)
{
	space->resize(n);
	(*space)=1;
	this->diag(n,&(*space)[0],M);
}
double SOCPhomog::gettheta(size_t n,vector s,vector x,vector Q)
{
	space->resize(n);
	dsmxmulv(n,Q,s,&(*space)[0]);
	double top=ddotvec(n,s,&(*space)[0]);
	dsmxmulv(n,Q,x,&(*space)[0]);
	double bot=ddotvec(n,x,&(*space)[0]);
	return sqrt(sqrt(top/bot));
}
void SOCPhomog::unit(vector x)
{
	size_t i;
	int* nncone;
	vector u;
	for(i=0,nncone=ncone,u=x;i<n;i++,nncone++)
	{
		if(*nncone==1)
			*u++=1;
		else
		{
			dzerovec(*nncone-1,u);
			u+=(*nncone-1);
			*u++ =1;
		}
	}
}
void SOCPhomog::applyXm1(vector x,vector A,vector Xm1A)
{
	vector rr4,hh1,xx,xm,rm;
	int* nncone;
	double outer,inner;
	size_t i,j;
	for(i=0,nncone=ncone,rr4=A,hh1=Xm1A,xx=x;i<n;++i,nncone++)
	{
		if(*nncone==1)
		{
			*hh1++ = *rr4++/ *xx++;
		}
		else
		{
			outer=xx[*nncone-1]*xx[*nncone-1]-ddotvec(*nncone-1,xx,xx);
			inner=ddotvec(*nncone-1,rr4,xx);
			for(j=0,rm=rr4+*nncone-1,xm=xx+*nncone-1;j<*nncone;++j,xx++,rr4++,hh1++)
			{
				if(j!=(*nncone-1)){*hh1=*xx*inner/ *xm/outer+*rr4/ *xm-*rm* *xx/outer;}
				else{*hh1=(-inner+*rm* *xm)/outer;}
			}
		}
	}
}
void SOCPhomog::applyX(vector x,vector A,vector XA)
{
	vector rr4,hh1,xx,xm,rm;
	int* nncone;
	double inner;
	size_t i,j;
	for(i=0,nncone=ncone,rr4=A,hh1=XA,xx=x;i<n;++i,nncone++)
	{
		if(*nncone==1)
		{
			*hh1++ = *rr4++* *xx++;
		}
		else
		{
			inner=ddotvec(*nncone-1,rr4,xx);
			for(j=0,rm=rr4+*nncone-1,xm=xx+*nncone-1;j<*nncone;++j,xx++,rr4++,hh1++)
			{
				if(j!=(*nncone-1)){*hh1=*xm* *rr4 + *rm* *xx;}
				else{*hh1=inner+*rm* *xm;}
			}
		}
	}
}
double SOCPhomog::gettheta(size_t n,vector s,vector x)
{
	badtheta=0;
	if(n==1)
	{
		if(*s<=0 || *x<=0){badtheta=1;return 0;}
		return sqrt(*s/ *x);
	}
	vector sm=s+n-1,xm=x+n-1;
	double xQx=*xm* *xm - ddotvec(n-1,x,x);
	double sQs=*sm* *sm - ddotvec(n-1,s,s);
	if(xQx < lm_eps)
		AddLog((char*)"Bad x in gettheta %20.12e\n",xQx);
	if(sQs < lm_eps)
		AddLog((char*)"Bad s in gettheta %20.12e\n",sQs);
	if(xQx<=0 || sQs<=0){badtheta=1;return 0;}
	return sqrt(sqrt(sQs/xQx));
}
void SOCPhomog::getw(size_t n,vector s,vector x,double theta,vector Q,vector w)
{
	double xs=ddotvec(n,s,x);
	space->resize(n);
	dsmxmulv(n,Q,s,&(*space)[0]);
	double sQs=ddotvec(n,s,&(*space)[0]);
	dsmxmulv(n,Q,x,&(*space)[0]);
	double xQx=ddotvec(n,x,&(*space)[0]);
	double bot=sqrt((xs+sqrt(xQx*sQs))*2);
	dzerovec(n,w);
	daxpyvec(n,theta/bot,&(*space)[0],w);
	daxpyvec(n,1.0/theta/bot,s,w);
}
void SOCPhomog::getw(size_t n,vector s,vector x,double theta,vector w)
{
	if(n==1)
	{
		*w=sqrt(*s/ *x)/theta;return;
	}
	vector sm=s+n-1,xm=x+n-1;
	double xs=ddotvec(n,s,x);
	double xQx=*xm* *xm - ddotvec(n-1,x,x);
	double sQs=*sm* *sm - ddotvec(n-1,s,s);
	double bot=sqrt((xs+sqrt(xQx*sQs))*2);
	double s1=theta/bot,s2=theta*bot;
	while(n-- > 1)
	{
		*w++ = -s1* *x++ + *s++/s2;
	}
	*w++ = s1* *x++ + *s++/s2;
}
void SOCPhomog::W(size_t n,vector w,vector M)
{
	size_t i,j;
	vector WW,wi,wj,wm=w+n-1;
	double bot=1+*wm;
	for(i=0,wi=w,WW=M;i<n-1;++i,++wi)
	{
		for(j=0,wj=w;j<=i;++j,++wj)
		{
			*WW=*wi* *wj/bot;
			if(i==j)*WW+=1;
			WW++;
		}
	}
	dcopyvec(n,w,WW);
}
void SOCPhomog::Wm1(size_t n,vector w,vector W,vector M)
{
	size_t i,j;
	vector WW,wi,wj;
	for(i=0,wi=w,WW=M;i<n;++i,++wi)
	{
		for(j=0,wj=w;j<=i;++j,++wj)
		{
			*WW=*wi* *wj* *W;
			WW++;W++;
		}
	}
}
void SOCPhomog::W2(size_t n,vector w,vector Q,vector M)
{
	size_t i,j;
	vector WW,wi,wj;
	for(i=0,wi=w,WW=M;i<n;++i,++wi)
	{
		for(j=0,wj=w;j<=i;++j,++wj)
		{
			*WW=2* *wi* *wj;
			if(i==j)*WW-=*Q;
			WW++;Q++;
		}
	}
}
void SOCPhomog::thetaWm2(size_t n,vector q,vector W2,double theta,vector M)
{
	size_t i,j;
	theta*=theta;
	vector WW,qi,qj;
	for(i=0,qi=q,WW=M;i<n;++i,++qi)
	{
		for(j=0,qj=q;j<=i;++j,++qj)
		{
			*WW=*qi* *qj* *W2/theta;
			WW++;W2++;
		}
	}
}
void SOCPhomog::AAsolve(vector qn,vector qm)
{
/*
Solve
	-(theta W)**2       AT  pn    qn
                               =
	A                   0   pm    qm
(overwriting qn and qm with pn and pm.)

We find;
pm = (A(theta W)**-2AT)**-1 (qm + A(theta W)**-2 qn)    ...(1)

pn = -(theta W)**-2 * (qn - ATpm)                       ...(2)
*/
	std::valarray<double> cc1(nx);
	Qmulvec(qn);
	W2trans(qn,&cc1[0]);
	Qmulvec(qn);
	Qmulvec(&cc1[0]);
	thetaScale(&cc1[0],true,true);
	size_t i;
	vector pq,pc,pA;
	for(i=0,pq=qm,pc=&cc1[0],pA=A;i<m;++i,pq++,pA+=nx)
	{
		*pq+=ddotvec(nx,pA,pc);//                       ...(1)
	}
	if(!use_conj)
//		dsmxainv(m,&(*AA)[0],&(*AA_P)[0],qm);
//#ifndef LAPACK
		if(useSparse)
/*			LDLObj.Solve(qm)*/;
		else
		{
#ifdef USE_SINGLE
			if(!usedouble)
			{
				std::valarray<float>sqm(m);
				std::valarray<double>qmkeep(m);
				std::valarray<double>qmest(m);
				double resid;
				float* AAAA=&(*AAsingle)[0];
				for(i=0;i<m;++i)
				{
					sqm[i]=static_cast<float>(qm[i]);
					qmkeep[i]=qm[i];//b
				}
				ssptrs((char*)"U",m,1,AAAA,&(*AA_P)[0],&sqm[0],m);
				for(i=0;i<m;++i)
				{
					qm[i]=static_cast<double>(sqm[i]);//estimate of x
				}
				newmult(m,&(*AA)[0],&qm[0],&qmest[0]);//Ax
				dsubvec(m,&qmkeep[0],&qmest[0],&qmest[0]);//b-Ax
				resid=ddotvec(m,&qmest[0],&qmest[0])/(double)m;
//				printf((char*)"Error in b-Ax %e\n",resid);
				double oldresid=resid;
				size_t single_count=0;
				while (resid>lm_eps8&&single_count<10)
				{
					std::valarray<double>dsqm(m);
					for(i=0;i<m;++i)
						sqm[i]=static_cast<float>(qmest[i]);
					ssptrs((char*)"U",m,1,AAAA,&(*AA_P)[0],&sqm[0],m);//A-1 (b-Ax)
					for(i=0;i<m;++i)
					{
						dsqm[i]=static_cast<double>(sqm[i]);
						qm[i]+=dsqm[i];//x+A-1(b-Ax) update x estimate
					}
					newmult(m,&(*AA)[0],&qm[0],&qmest[0]);
					dsubvec(m,&qmkeep[0],&qmest[0],&qmest[0]);
					resid=ddotvec(m,&qmest[0],&qmest[0])/(double)m;
//					printf((char*)"Error in b-Ax %e\n",resid);
					if(oldresid < resid)
					{
						for(i=0;i<m;++i)
						{
							qm[i]-=dsqm[i];//change it back
						}
						break;
					}
					oldresid=resid;
					single_count++;
				}
				if(resid > lm_rooteps || single_count>4)
				{
					changetodouble=true;
				}
			}
			else
				dsptrs((char*)"U",m,1,&(*AA)[0],&(*AA_P)[0],&qm[0],m);
#else
			{
/*				std::valarray<double> xx(m),bb(m);
				dcopyvec(m,&qm[0],&bb[0]);*/
				dsptrs((char*)"U",m,1,&(*AA)[0],&(*AA_P)[0],&qm[0],m);
/*				dcopyvec(m,&qm[0],&xx[0]);
				applyA((char*)"U",m,1,&(*AA)[0],&(*AA_P)[0],&xx[0],m);//should now be b
				dsubvec(m,&xx[0],&bb[0],&xx[0]);
				double resid=ddotvec(m,&xx[0],&xx[0]);
				printf((char*)"resid %e\n",resid);*/
			}
#endif
		}
		//#else
		//		bunchs(m,&(*AA)[0],&(*AA_P)[0],qm);
//#endif
//	trisolve(m,&(*QDE)[0],&(*QDE)[m*m],&(*QDE)[m*m+m],qm);
//		LDLObj.Solve(qm);
	else
	{
		dcopyvec(m,qm,&cc1[0]);
		conj_solve(m,&(*AA)[0],&cc1[0],qm,0,(pHmul)HMUL,0,0,1);
	}
	for(i=0,pq=qn,pc=&cc1[0],pA=A;i<nx;++i,pq++,pc++,pA++)
	{
		*pc=-*pq+BITA_ddot(m,pA,nx,qm,1);//                  ...(2)
	}
	Qmulvec(&cc1[0]);
	W2trans(&cc1[0],qn);
	Qmulvec(qn);
	thetaScale(qn,true,true);
}
void SOCPhomog::Qmulvec(vector A)
{
	vector pc;
	int* nncone;
	size_t i,j;
	for(i=0,pc=A,nncone=ncone;i<n;++i,nncone++)
	{
		if(*nncone>1)
		{
			for(j=0;j<*nncone-1;++j)
			{
				*pc = -*pc;pc++;
			}
		}
		pc++;
	}
}
void SOCPhomog::Wtrans(vector A,vector WA)
{
	vector pc,pcc,ww,wm,Am;
	int* nncone;
	size_t i,j;
	double wc,bot;
	for(i=0,pcc=WA,pc=A,ww=w,nncone=ncone;i<n;++i,nncone++)
	{
		if(*nncone==1)
		{
			*pcc++=*ww++* *pc++;continue;
		}
		wc=ddotvec(*nncone-1,ww,pc);
		wm=ww+*nncone-1;
		Am=pc+*nncone-1;
		bot=1+*wm;
		for(j=0;j<*nncone-1;++j,pcc++,ww++,pc++)
		{
			*pcc = *ww*wc/bot + *pc + *ww * *Am;
		}
		*pcc++=wc+*wm* *Am;ww++;pc++;
	}
}
void SOCPhomog::W2trans(vector A,vector W2A)
{
	vector pc,pcc,ww;
	int* nncone;
	size_t i,j;
	double wc;
	for(i=0,pcc=W2A,pc=A,ww=w,nncone=ncone;i<n;++i,nncone++)
	{
		if(*nncone==1)
		{
			if(*ww!=0)*pcc=*ww* *ww* *pc;
			else *pcc=0;
			pcc++;ww++;pc++;
			continue;
		}
		wc=ddotvec(*nncone,ww,pc);
		if(wc!=0.0)
		{
			for(j=0;j<*nncone-1;++j)
			{
				*pcc=2* *ww *wc +*pc;
				pcc++;ww++;pc++;
			}
			*pcc=2* *ww *wc- *pc;
			pcc++;ww++;pc++;
		}
		else
		{
			dcopyvec(*nncone-1,pc,pcc);
			pcc+=*nncone-1;ww+=*nncone;pc+=*nncone-1;
			*pcc=-*pc;
			pcc++;pc++;
		}
	}
}
void SOCPhomog::thetaScale(vector A,bool recip,bool square)
{
	vector pc,ttheta;
	int* nncone;
	size_t i,j;
	double thet2;
	for(i=0,pc=A,nncone=ncone,ttheta=theta;i<n;++i,ttheta++,nncone++)
	{
		thet2=*ttheta;
		if(square)
			thet2 *= *ttheta;
		if(recip)
		{
			for(j=0;j<*nncone;++j)
			{
				*pc++ /= thet2;
			}
		}
		else
		{
			for(j=0;j<*nncone;++j)
			{
				*pc++ *= thet2;
			}
		}
	}
}
void SOCPhomog::makeResid(double gamma,double alpha)
{
	size_t i;
	double gamma1=gamma-1;
	bool selfreg=false;
	if(selfreg)//Self-Regular function method
	{
		double scl=1.0/sqrt(mu);
		std::valarray<double>v(nx);
		std::valarray<double>inv(nx),e(nx);
		dcopyvec(nx,xbar,&v[0]);
		dscalvec(nx,scl,&v[0]);//v
		switch(regmethod)//Generally psi'(t)=t**p - t**(-q-1) where q>=1-p
		{
		case 1:
			//psi'(t)=t-t**-1
			unit(&e[0]);
			applyXm1(xbar,&e[0],&inv[0]);
			dscalvec(nx,1./scl,&inv[0]);//v**-1
			//gamma=1;
			dscalvec(nx,gamma,&inv[0]);
			dsubvec(nx,&v[0],&inv[0],&inv[0]);
			break;
		case 2:
			//psi'(t)=1-t**-2
			unit(&inv[0]);
			applyXm1(xbar,&inv[0],&e[0]);
			applyXm1(xbar,&e[0],&inv[0]);
			dscalvec(nx,mu,&inv[0]);
			unit(&e[0]);
			dsubvec(nx,&e[0],&inv[0],&inv[0]);
			break;
		}
		applyX(&v[0],&inv[0],r4);
		dscalvec(nx,-mu,r4);//keep
//		printf((char*)"r4\n");printx(nx,r4);
		if(homog)*r5=-tau*kappa + gamma*mu;//keep
//		printf((char*)"r5 %20.8e\n",*r5);
	}
	else
	{
		applyX(xbar,sbar,r4);//printf((char*)"XbarSbar\n");printx(nx,r4);
		dnegvec(nx,r4);
		vector rr4;
		if(gamma!=0)
		{
			for(i=0,rr4=r4;i<n;rr4+=ncone[i],i++)
			{
				rr4[ncone[i]-1]+= gamma*mu;//keep
			}
		}
//		printf((char*)"r4\n");printx(nx,r4);
		if(homog)*r5=-tau*kappa + gamma*mu;//keep
//		printf((char*)"r5 %20.8e\n",*r5);
	}
	if(alpha!=0)//The correction dsbardxbar
	{
		std::valarray<double> cor(3*nx);
		/*	Qmulvec(ds);
		Wtrans(ds,&cor[0]);
		Qmulvec(ds);
		Qmulvec(&cor[0]);
		thetaScale(&cor[0],true);*/
		dcopyvec(nx,ds,&cor[nx+nx]);//(theta.w)**-1 ds = w**-1 theta**-1 ds
		thetaScale(&cor[nx+nx],true);
		Qmulvec(&cor[nx+nx]);
		Wtrans(&cor[nx+nx],&cor[0]);
		Qmulvec(&cor[0]);
		
		Wtrans(dx,&cor[nx]);//theta.w.dx
		thetaScale(&cor[nx]);
		applyX(&cor[nx],&cor[0],&cor[nx+nx]);
		
		
		dsubvec(nx,r4,&cor[nx+nx],r4);
		if(homog)*r5-=*dtau* *dkappa;
	}
	for(i=0;i<m;++i)
	{
		r1[i]=gamma1*(ddotvec(nx,A+i*nx,x)-b[i]*(homog?tau:1));//keep
	}
	for(i=0;i<nx;++i)
	{
		r2[i]=gamma1*(BITA_ddot(m,A+i,nx,y,1)+s[i]-c[i]*(homog?tau:1));//keep
	}
	if(homog)*r3=gamma1*(-ddotvec(nx,c,x)+ddotvec(m,b,y)-kappa);//keep
}
bool SOCPhomog::conecheck(vector x,const char* name,double tol)
{
	bool back=false;
	vector xc;
	size_t i,j,nn;
	double check;
	int* nncone=ncone;
	for(i=0,xc=x;i<n;++i)
	{
		nn=*nncone++ -1;
		check=0;
		for(j=0;j<nn;++j)
			check-=*xc* *xc++;
		check+=*xc* *xc;
		if(check<=tol)
		{
			back= true;
			*xc+=lm_eps;
		}
		xc++;
	}
	return back;
}
void SOCPhomog::getw_and_theta()
{
	size_t i;
	vector ww,ttheta,xx,ss;
	int* nncone;
	for(i=0,nncone=ncone,ttheta=theta,ss=s,xx=x,ww=w;i<n;++i,ww+=*nncone,
		ss+=*nncone,xx+=*nncone,ttheta++,nncone++)
	{
		*ttheta=gettheta(*nncone,ss,xx);
		if(!badtheta)getw(*nncone,ss,xx,*ttheta,ww);
		else return;
	}
/*	printf((char*)"w\n");printx(nx,w);
	printf((char*)"theta\n");printx(n,theta);
	printf((char*)"x\n");printx(nx,x);
	printf((char*)"s\n");printx(nx,s);
	W2trans(x,xbar);
	thetaScale(xbar,false,true);printf((char*)"should be s\n");printx(nx,xbar);
	Wtrans(x,sbar);
	Wtrans(sbar,xbar);
	thetaScale(xbar);thetaScale(xbar);printf((char*)"should be s\n");printx(nx,xbar);*/
	Wtrans(x,xbar);
	thetaScale(xbar);//printf((char*)"xbar\n");printx(nx,xbar);
	dcopyvec(nx,xbar,sbar);
/*	Qmulvec(s);
	Wtrans(s,sbar);
	Qmulvec(s);
	Qmulvec(sbar);
	thetaScale(sbar,1);//printf((char*)"sbar\n");printx(nx,sbar);*/
}
void	AmakeMul(dimen n, dimen nrh, dimen nc, dimen jc, vector H, vector x, vector hx,
					 void* info)
{
	SOCPhomog* here=(SOCPhomog*)info;
	std::valarray<double>cc(here->nx);
	//vector A=here->A;
	here->W2trans(x,hx);
	here->thetaScale(hx,false,true);
	dnegvec(here->nx,hx);
	here->ATmy(x+here->nx,&cc[0],info);
	daddvec(here->nx,&cc[0],hx,hx);
	here->Amx(x,hx+here->nx,info);
/*	for(i=0;i<here->nx;++i)
	{
		*hx++ += BITA_ddot(here->m,A+i,here->nx,x+here->nx,1);
	}
	for(i=0;i<here->m;++i,A+=here->nx)
	{
		*hx++ = ddotvec(here->nx,A,x);
	}*/
}
inline void PreProcessA(size_t m,size_t nx,vector A,size_t* order,int rev=-1)
{
	//Find the order that reorders the constraint matrix columns so that the dual column with most zeros comes first
	size_t i;
	vector pA;
	std::valarray<double> dropw(m);
	for(i=0,pA=A;i<m;++i,pA+=nx)
	{
		dropw[i]=rev*zerocount(nx,pA);
	}
	getordereig(m,&dropw[0],order,0);
	for(i=0;i<m;++i)
		order[m+order[i]]=i;
}
inline void PreProcessAT(size_t m,size_t nx,vector A,size_t* order,int rev=-1,size_t first=0)
{
	//Find the order that reorders the constraint matrix rows so that the primal row with most zeros comes first
	size_t i;
	vector pA;
	if(first==0)first=nx;
	std::valarray<double> dropw(first);
	for(i=0,pA=A;i<first;++i,pA++)
	{
		dropw[i]=rev*zerocount(m,pA,nx);
		printf((char*)"%d %f\n",i+1,dropw[i]);
	}
	getordereig(first,&dropw[0],order,0);
	for(i=0;i<first;++i)
		order[nx+order[i]]=i;
}
void SOCPhomog::getDirectionL(bool updateAA)
{
	if(updateAA)
	{
		AddLog((char*)"nx = %d; m = %d nx/m %f\n",nx,m,((double)nx)/m);
		if(!golong)
		{
			if(nx>changeratio*m)//&&ddotvec(nx+nx+m+2,r1,r1)>1e-12)
			{
				golong=false;
			}
			else if(nx>m*1000)
			{
				golong=false;
			}
			else
			{
				golong=true;
			}
		}
	}
//	if(!golong){getDirection(updateAA);return;}
//	if(true){getDirection(updateAA);return;}
	if(true){getDirection(updateAA);return;}
	AddLog((char*)"Large system\n");
	size_t nmnm=(nx+m)*(nx+m+1)/2,i,j;
	std::valarray<double>cc1(2*nx+m);
	vector pAA;
	size_t* AP;
	std::valarray<size_t> vAP(nx+m+1);
/*	LDLObj.n=(nx+m);
	LDLObj.SetOrder(nx+m,0);*/
	if(updateAA && !steep && !use_conj && !use_sparse)
	{
		AA->resize(nmnm);
		AA_P->resize(nx+m);
//		QDE->resize((nx+m)*(nx+m)+nx+m+nx+m-1);
		dzerovec(nmnm,&(*AA)[0]);
		for(i=0,pAA=&(*AA)[0];i<nx;i++)
		{
			dzerovec(nx,&cc1[0]);cc1[i]=1;
			W2trans(&cc1[0],&cc1[nx]);
			thetaScale(&cc1[nx],false,true);
			dcopyvec(i+1,&cc1[nx],pAA);
			pAA+=(i+1);
		}
		dnegvec(nx*(nx+1)/2,&(*AA)[0]);
		for(i=nx;i<nx+m;++i)
		{
			dcopyvec(nx,A+(i-nx)*nx,pAA);
			pAA+=(i+1);
		}
		if(m<10&&logprint)
		{
			for(i=0,pAA=&(*AA)[0];i<nx+m;++i)
			{
				AddLog((char*)"%3ld ",i+1);
				for(j=0;j<=i;++j)
				{
					AddLog((char*)"%10.2e ",*pAA++);
				}
				AddLog((char*)"\n");
			}
		}
//		dsmxfac(nx+m,&(*AA)[0],&(*AA_P)[0]);
		int info;
		info=dsptrf((char*)"U",nx+m,&(*AA)[0],&(*AA_P)[0]);
	//	info=trifact(nx+m,&(*AA)[0],&(*QDE)[0],&(*QDE)[(nx+m)*(nx+m)],&(*QDE)[(nx+m)*(nx+m)+nx+m]);
		if(m<10&&logprint)
		{
			for(i=0,pAA=&(*AA)[0];i<nx+m;++i)
			{
				AddLog((char*)"%3ld ",i+1);
				for(j=0;j<=i;++j)
				{
					AddLog((char*)"%10.2e ",*pAA++);
				}
				AddLog((char*)"\n");
			}
		}
	}
#if !defined( SPARSELIBTEST) && !defined(MYSPARSE) && !defined(HARWELL)
	else if(updateAA && use_sparse)
	{
		size_t tot=0;
		size_t ii,jj;
		vector pA;
		if(useordering&&!SolveOrder)
		{
			SolveOrder=new std::valarray<size_t>;
			SolveOrder->resize(2*(nx+m));
			size_t* SO;
			size_t* SI;
			std::valarray<double>Asum(m);
			for(i=0;i<m;++i)Asum[i]=nx-zerocount(nx,A+i*nx);//Reorder the dual variables
			getorder(m,&Asum[0],&(*SolveOrder)[nx],0,0);
			for(i=0,SO=&(*SolveOrder)[0],jj=0;i<n;++i)//Reorder the primal variables
			{//putting the "top" variables together
				for(j=0;j<ncone[i]-1;++j)
				{
					*SO++=jj++ +m;
				}
				jj++;
			}
			for(i=0,jj=0;i<n;++i)
			{
				jj+=ncone[i]-1;
				{
					*SO++=jj++ +m;
				}
			}
			if(useordering==2)
			{
				for(i=0,SO=&(*SolveOrder)[0],SI=&(*SolveOrder)[nx+m];i<nx+m;++i)//Invert
					SI[*SO++]=i;
			}
		}
		if(!sparseDA->empty())sparseDA->erase(sparseDA->begin(),sparseDA->end());
		if(!sparseIA->empty())sparseIA->erase(sparseIA->begin(),sparseIA->end());
		AP=&vAP[0];
		*AP++=0;
		for(ii=0;ii<nx+m;ii++)//If we use ordering within SparseClass (useordering=1) then we have to pass a square sparse matrix
		{
			if(useordering==2)i=(*SolveOrder)[ii];
			else i=ii;
			if(i<nx)
			{
				dzerovec(nx,&cc1[0]);cc1[i]=1;
				W2trans(&cc1[0],&cc1[nx]);
				thetaScale(&cc1[nx],false,true);
				if(useordering!=0)
				{
					dcopy(m,A+i,nx,&cc1[2*nx],1);
					dnegvec(m,&cc1[2*nx]);
					if(useordering==2)Reorder(nx+m,&(*SolveOrder)[0],&cc1[nx]);
				}
				for(j=0,pA=&cc1[nx];j<nx+m;++j,pA++)
				{
					if(j>ii && useordering!=1)
						break;
					if(*pA != 0)
					{
						sparseDA->push_back(-*pA);
						sparseIA->push_back(j);//... first push back will reset sparseIA if 
						tot++;					// we use the first nnx+m+1 elements for AP..
					}
				}
				*AP++=tot;
			}
			else if(i>=nx)
			{
				if(useordering!=2)
				{
					pA=A+nx*(i-nx);
					for(j=0;j<nx;++j,pA++)
					{
						if(*pA != 0)
						{
							sparseDA->push_back(*pA);
							sparseIA->push_back(j);
							tot++;
						}
					}
					*AP++=tot;
				}
				else
				{
					pA=A+nx*(i-nx);
					dzerovec(m,&cc1[nx]);
					dcopyvec(nx,pA,&cc1[0]);
					Reorder(nx+m,&(*SolveOrder)[0],&cc1[0]);
					for(j=0,pA=&cc1[0];j<=ii;++j,pA++)
					{
						if(*pA != 0)
						{
							sparseDA->push_back(*pA);
							sparseIA->push_back(j);
							tot++;
						}
					}
					*AP++=tot;
				}
			}
		}
		if(useordering==1)
		{
/*			LDLObj.SetOrder(nx+m,&(*SolveOrder)[0])*/;
		}
/*		if((nx+m)!=LDLObj.Factor(&(sparseDA->front()),&vAP[0],&(sparseIA->front())))
		{
#define USEldlfailed
#ifndef USEldlfailed
			if(useordering==0)
			{
				useordering=2;
				AddLog((char*)"ERROR; reorder variables\n");
			}
			else
			{
				use_sparse=false;
				AddLog((char*)"ERROR; switch to non-sparse method\n");
			}
			sparseDA->erase(sparseDA->begin(),sparseDA->end());
			sparseIA->erase(sparseIA->begin(),sparseIA->end());
			getDirectionL();
#else
			ldlfailed=true;
#endif
			return;
		}
		sparseDA->erase(sparseDA->begin(),sparseDA->end());
		sparseIA->erase(sparseIA->begin(),sparseIA->end());*/
	}
#endif
#if defined (MYSPARSE) || defined (HARWELL)
	else if(updateAA && use_sparse)
	{
		AA->resize(nmnm);
//		AA_P->resize(nx+m);
		dzerovec(nmnm,&(*AA)[0]);
		for(i=0,pAA=&(*AA)[0];i<nx;i++)
		{
			dzerovec(nx,&cc1[0]);cc1[i]=1;
			W2trans(&cc1[0],&cc1[nx]);
			thetaScale(&cc1[nx],false,true);
			dcopyvec(i+1,&cc1[nx],pAA);
			pAA+=(i+1);
		}
		dnegvec(nx*(nx+1)/2,&(*AA)[0]);
		for(i=nx;i<nx+m;++i)
		{
			dcopyvec(nx,A+(i-nx)*nx,pAA);
			pAA+=(i+1);
		}
		put->n=nx+m;
		put->M=&(*AA)[0];
		put->Factor();
	}
#endif
#ifdef SPARSELIBTEST
	else if(updateAA && use_sparse)
	{
		CreateSparseA(&SparseInfo,nx+m);
		vector pA;
		for(i=0;i<nx;i++)
		{
			dzerovec(nx,&cc1[0]);cc1[i]=1;
			W2trans(&cc1[0],&cc1[nx]);
			thetaScale(&cc1[nx],false,true);
			for(j=0;j<=i;++j)
			{
				if(cc1[nx+j] != 0)
				{
					SetSparseA(SparseInfo,i,j,cc1[nx+j]);
				}
			}
		}
		for(i=0,pA=A;i<m;++i,pA+=nx)
		{
			for(j=0;j<nx;++j)
			{
				if(pA[j] != 0)
				{
					SetSparseA(SparseInfo,i+nx,j,pA[j]);
				}
			}
		}
		SparseFactor(SparseInfo,nx+m,lm_eps);
	}
#endif
	dcopyvec(nx,c,g1);
	dcopyvec(m,b,g2);
	if(!steep)
	{
		if(use_conj)
		{
			dcopyvec(nx+m,g1,&cc1[0]);
			conj_res=conj_solve(nx+m,&(*AA)[0],&cc1[0],g1,0,(pHmul)AmakeMul,this,0,1);
		}
#if !defined( SPARSELIBTEST)&&!defined(MYSPARSE)&&!defined(HARWELL)
		else if(use_sparse)
		{
/*			if(useordering==2)Reorder(nx+m,&(*SolveOrder)[0],g1);
			LDLObj.Solve(g1);
			if(useordering==2)Reorder(nx+m,&(*SolveOrder)[nx+m],g1)*/;
		}
#endif
#ifdef SPARSELIB
		else if(use_sparse)
		{
			SparseSolve(SparseInfo,nx+m,g1);
		}
#endif
#if defined (MYSPARSE) || defined (HARWELL)
		else if(use_sparse)
		{
			put->Solve1(g1);
		}
#endif
		else
		{
//			dsmxainv(nx+m,&(*AA)[0],&(*AA_P)[0],g1);//keep g1 and g2
			int info;
			info=dsptrs((char*)"U",nx+m,1,&(*AA)[0],&(*AA_P)[0],g1,nx+m);
			//info=trisolve(nx+m,&(*QDE)[0],&(*QDE)[(nx+m)*(nx+m)],&(*QDE)[(nx+m)*(nx+m)+nx+m],g1);
		}
//			spivsolve(nx+m,&(*AA)[0],g1);
	}
	
	applyXm1(xbar,r4,&cc1[0]);
	Wtrans(&cc1[0],h1);
	thetaScale(h1);
	dsubvec(nx,r2,h1,h1);
	dcopyvec(m,r1,h2);
	if(!steep)
	{
		if(use_conj)
		{
			dcopyvec(nx+m,h1,&cc1[0]);
			conj_res=conj_solve(nx+m,&(*AA)[0],&cc1[0],h1,0,(pHmul)AmakeMul,this,0,1);
		}
#if !defined( SPARSELIBTEST) && !defined(MYSPARSE) && !defined(HARWELL)
		else if(use_sparse)
		{
/*			if(useordering==2)Reorder(nx+m,&(*SolveOrder)[0],h1);
			LDLObj.Solve(h1);
			if(useordering==2)Reorder(nx+m,&(*SolveOrder)[nx+m],h1)*/;
		}
#endif
#ifdef SPARSELIB
		else if(use_sparse)
		{
			SparseSolve(SparseInfo,nx+m,h1);
			if(!updateAA)
				DeleteSparseA(SparseInfo);
		}
#endif
#if defined (MYSPARSE) || defined (HARWELL)
		else if(use_sparse)
		{
			put->Solve1(h1);
		}
#endif
		else
		{
//			dsmxainv(nx+m,&(*AA)[0],&(*AA_P)[0],h1);//keep g1 and g2
			int info;
			info=dsptrs((char*)"U",nx+m,1,&(*AA)[0],&(*AA_P)[0],h1,nx+m);
			//info=trisolve(nx+m,&(*QDE)[0],&(*QDE)[(nx+m)*(nx+m)],&(*QDE)[(nx+m)*(nx+m)+nx+m],h1);
		}
//			spivsolve(nx+m,&(*AA)[0],h1);
	}
	if(homog)*dtau=(*r3 + ddotvec(nx,h1,c) - ddotvec(m,h2,b) + *r5/tau)/
		(kappa/tau-ddotvec(nx,c,g1)+ddotvec(m,b,g2)); //keep tau
	dcopyvec(nx,h1,dx);
	daxpyvec(nx,homog?*dtau:1,g1,dx);//keep dx
	dcopyvec(m,h2,dy);
	daxpyvec(m,homog?*dtau:1,g2,dy);//keep dy
	Wtrans(dx,&cc1[0]);
	thetaScale(&cc1[0]);
	applyX(sbar,&cc1[0],&cc1[nx]);
	dsubvec(nx,r4,&cc1[nx],&cc1[nx]);
	applyXm1(xbar,&cc1[nx],&cc1[0]);
	Wtrans(&cc1[0],ds);
	thetaScale(ds);//keep ds
	if(homog)*dkappa = (*r5 - kappa* *dtau)/tau;//keep kappa
}
void SOCPhomog::getDirection(bool updateAA)
{
	long i,k;
	std::valarray<double>cc1(nx),cc2(nx);
	if(m<100)changetodouble=true;
//	vector pAA,pAi,pAj;

	if(updateAA)
	{
		std::valarray<double>pAproc;
		try
		{
			pAproc.resize(0);
			pAproc.resize(nx*m);
		}
		catch( ... )
		{
			pAproc.resize(0);
		}
		if(pAproc.size())
			Aproc=&pAproc[0];
		else
			Aproc=0;
		if(Aproc)
		{
#ifndef _OPENMP
			time_t t1=clock();
			AddLog((char*)" faster method\n");
			for(i=0;i<m;++i)
			{
				dcopyvec(nx,A+i*nx,&cc2[0]);
				Qmulvec(&cc2[0]);
				W2trans(&cc2[0],Aproc+i*nx);
				thetaScale(Aproc+i*nx,true,true);
				Qmulvec(Aproc+i*nx);
			}
			AddLog((char*)"Initial processing time %f\n",((double)(clock()-t1)/CLOCKS_PER_SEC));
#else
			long maxt=omp_get_max_threads(),nt;
			double t1=omp_get_wtime();
			std::valarray<double>cc2(nx*maxt);
			AddLog((char*)" faster method\n");
#pragma omp parallel
			{
#pragma omp for private(i,nt) schedule(dynamic) nowait
				for(i=0;i<m;++i)
				{
					nt=omp_get_thread_num();
					dcopyvec(nx,A+i*nx,&cc2[nt*nx]);
					Qmulvec(&cc2[nt*nx]);
					W2trans(&cc2[nt*nx],Aproc+i*nx);
					thetaScale(Aproc+i*nx,true,true);
					Qmulvec(Aproc+i*nx);
				}
			}
			AddLog((char*)"Initial processing time %f\n",((double)(omp_get_wtime()-t1)));
#endif
		}
#ifndef _OPENMP
		dzerovec(m*(m+1)/2,&(*AA)[0]);
		if(Aproc)
		{
			AddLog((char*)" faster method\n");
			time_t t1=clock();
#ifdef BLOCKED//This is correct but it's only  faster for large m and dense A
			double one=1,zero=0;
			Integer N=nx,M=m;
			dgemm_BITA((char*)"T",(char*)"N",&M,&M,&N,&one,A,&N,Aproc,&N,&zero,&(*AA)[0],&M);symm2packed(m,&(*AA)[0]);
#else
			dmx_transpose(nx,m,Aproc,Aproc);
			for(i=0;i<m;++i)
			{
				for(k=0;k<nx;++k)
				{
					if(A[i*nx+k]!=0)
//						BITA_daxpy(i+1,A[i*nx+k],Aproc+k,nx,&(*AA)[i*(i+1)/2],1);
						daxpyvec(i+1,A[i*nx+k],Aproc+k*m,&(*AA)[i*(i+1)>>1]);
				}
			}
#endif
			AddLog((char*)"Generating normal matrix time %f\n",((double)(clock()-t1)/CLOCKS_PER_SEC));
		}
		else
		{
			AddLog((char*)"Not enough memory to use faster method\n");
			time_t t1=clock();
			for(i=0;i<m;++i)
			{
				Qmulvec(A+i*nx);
				W2trans(A+i*nx,&cc2[0]);
				thetaScale(&cc2[0],true,true);
				Qmulvec(&cc2[0]);
				Qmulvec(A+i*nx);//change it back
				for(k=0;k<nx;++k)
				{
					if(cc2[k]!=0)
						BITA_daxpy(i+1,cc2[k],A+k,nx,&(*AA)[i*(i+1)/2],1);
				}
			}
			AddLog((char*)"Generating normal matrix time %f\n",((double)(clock()-t1)/CLOCKS_PER_SEC));
		}
#else
		long maxt=omp_get_max_threads();
		dzerovec((m*(m+1))>>1,&(*AA)[0]);
		if(Aproc)
		{
			AddLog((char*)" faster method\n");
			double t1=omp_get_wtime();
#ifdef BLOCKED//This is correct but it's only  faster for large m and dense A
			double one=1,zero=0;
			Integer N=nx,M=m;
			dgemm_BITA((char*)"T",(char*)"N",&M,&M,&N,&one,A,&N,Aproc,&N,&zero,&(*AA)[0],&M);symm2packed(m,&(*AA)[0]);
#else
			dmx_transpose(nx,m,Aproc,Aproc);
#pragma omp parallel
			{
#pragma omp for private(i,k) schedule(dynamic) nowait
				for(i=0;i<m;++i)
				{
					for(k=0;k<nx;++k)
					{
						if(A[i*nx+k])
							//						BITA_daxpy(i+1,A[i*nx+k],Aproc+k,nx,&(*AA)[i*(i+1)>>1],1);
							daxpyvec(i+1,A[i*nx+k],Aproc+k*m,&(*AA)[i*(i+1)>>1]);
					}
				}
			}
#endif
			AddLog((char*)"Generating normal matrix time %f\n",(omp_get_wtime()-t1));
		}
		else
		{
			AddLog((char*)"Not enough memory to use faster method\n");
			std::valarray<double> cc2(nx*maxt);
			std::valarray<double> temp1(nx*maxt);
			double t1=omp_get_wtime();
			long ii,nt;
#pragma omp parallel
			{
#pragma omp for private(i,ii,nt,k) schedule(dynamic) nowait
				for(i=0;i<m;++i)
				{
					nt=omp_get_thread_num();
					ii=i*(i+1)>>1;
					dcopyvec(nx,A+i*nx,&temp1[nx*nt]);
					Qmulvec(&temp1[nx*nt]);
					W2trans(&temp1[nx*nt],&cc2[nx*nt]);
					thetaScale(&cc2[nx*nt],true,true);
					Qmulvec(&cc2[nx*nt]);
					//		Qmulvec(A+i*nx);//change it back
					for(k=0;k<nx;++k)
					{
						if(cc2[k+nt*nx]!=0)
							BITA_daxpy(i+1,cc2[k+nt*nx],A+k,nx,&(*AA)[ii],1);
					}
				}
			}
			AddLog((char*)"Generating normal matrix time %f\n",(omp_get_wtime()-t1));
		}
		//	symm2packed(m,&(*AA)[0]);
#endif
		Aproc=0;pAproc.resize(0);
		
		if(!use_conj)
		{
#ifndef _OPENMP
			time_t t1=clock();
#else
			double t1=omp_get_wtime();
#endif
			//			dsmxfac(m,&(*AA)[0],&(*AA_P)[0]);//The expensive step!!!
			//			badindex=dsptrf((char*)"U",m,&(*AA)[0],&(*AA_P)[0]);
/*			if(num_zeros(m*(m+1)/2,&(*AA)[0]) > m)
				this->useSparse=true;
			else*/
				this->useSparse=false;
			if(useSparse)
			{
/*				LDLObj.n=m;
				LDLObj.CreateSparseIndices(&(*AA)[0]);
				badindex=LDLObj.Factor()!=m*/;
			}
			else
			{
#ifdef USE_SINGLE
				bool keepon=true;
				while(keepon)
				{
					if(changetodouble)usedouble=true;
					if(!usedouble)
					{
						float* AAAA=&(*AAsingle)[0];
						for(i=0;i<m*(m+1)>>1;++i)
							AAAA[i]=static_cast<float>((*AA)[i]);
		 				badindex=sbunchf(m,AAAA,&(*AA_P)[0]);
						packed2symm(m,&(*AA)[0]);
						if(badindex)
						{
							changetodouble=true;
							AddLog((char*)"Change to double precision option for factoring the normal matrix\n");
							symm2packed(m,&(*AA)[0]);
						}
						else keepon=false;
					}
					else
					{
						badindex=bunchf(m,&(*AA)[0],&(*AA_P)[0]);
						keepon=false;
					}
				}
#else
				badindex=bunchf(m,&(*AA)[0],&(*AA_P)[0]);
#endif
			}
			//badindex=trifact(m,&(*AA)[0],&(*QDE)[0],&(*QDE)[m*m],&(*QDE)[m*m+m]);
#ifndef _OPENMP
			AddLog((char*)"Factorise normal matrix time %f\n",((double)(clock()-t1)/CLOCKS_PER_SEC));
#else
			AddLog((char*)"Factorise normal matrix time %f\n",((omp_get_wtime()-t1)));
#endif
		}
		
		/*{
		this->LDLObj.CreateSparseIndices(&(*AA)[0]);
		this->LDLObj.Factor();
		}*/
	}
	AddLog((char*)"badindex %d\n",badindex);
	dcopyvec(nx,c,g1);
	dcopyvec(m,b,g2);
	AAsolve(g1,g2);//keep g1 and g2
	
	applyXm1(xbar,r4,&cc1[0]);
	Wtrans(&cc1[0],h1);
	thetaScale(h1);
	dsubvec(nx,r2,h1,h1);
	dcopyvec(m,r1,h2);
	AAsolve(h1,h2);//keep h1 and h2
	
	//	*dtau=(*r3 - ddotvec(nx,h1,c) + ddotvec(m,h2,b))/(kappa/tau+ddotvec(nx,c,g1)-ddotvec(m,b,g2));
	if(homog)*dtau=(*r3 + ddotvec(nx,h1,c) - ddotvec(m,h2,b) + *r5/tau)/
		(kappa/tau-ddotvec(nx,c,g1)+ddotvec(m,b,g2)); //keep tau
#pragma omp parallel
{
#pragma omp sections nowait
{
#pragma omp section
{
	dcopyvec(nx,h1,dx);
	daxpyvec(nx,homog?*dtau:1,g1,dx);//keep dx
}
#pragma omp section
{
	dcopyvec(m,h2,dy);
	daxpyvec(m,homog?*dtau:1,g2,dy);//keep dy
}
}
}
	Wtrans(dx,&cc1[0]);
	thetaScale(&cc1[0]);
	applyX(sbar,&cc1[0],&cc2[0]);
	dsubvec(nx,r4,&cc2[0],&cc2[0]);
	applyXm1(xbar,&cc2[0],&cc1[0]);
	Wtrans(&cc1[0],ds);
	thetaScale(ds);//keep ds
	if(homog)*dkappa = (*r5 - kappa* *dtau)/tau;//keep kappa
}
double SOCPhomog::getStepsize(double gamma,double beta)
{
	std::valarray<double> vx1(n),vx2(n),vx3(n);
	std::valarray<double> vs1(n),vs2(n),vs3(n);
	std::valarray<double> cc1(nx),cc2(nx),cc3(nx),cc4(nx);
	int* nncone;
	size_t i;
	vector px,pdx,pQdx,pQx;
	vector ps,pds,pQds,pQs;

	dcopyvec(nx,s,&cc1[0]);
	this->Qmulvec(&cc1[0]);
	dcopyvec(nx,ds,&cc2[0]);
	this->Qmulvec(&cc2[0]);
	for(i=0,nncone=ncone,ps=s,pQs=&cc1[0],pQds=&cc2[0],pds=ds;i<n;
	ps+=*nncone,pQs+=*nncone,pds+=*nncone,pQds+=*nncone,i++,nncone++)
	{
		vs1[i]=ddotvec(*nncone,ps,pQs);
		vs2[i]=2*ddotvec(*nncone,pds,pQs);
		vs3[i]=ddotvec(*nncone,pds,pQds);
	}

	dcopyvec(nx,x,&cc3[0]);
	this->Qmulvec(&cc3[0]);
	dcopyvec(nx,dx,&cc4[0]);
	this->Qmulvec(&cc4[0]);
	for(i=0,nncone=ncone,px=x,pQx=&cc3[0],pQdx=&cc4[0],pdx=dx;i<n;
	px+=*nncone,pQx+=*nncone,pdx+=*nncone,pQdx+=*nncone,i++,nncone++)
	{
		vx1[i]=ddotvec(*nncone,px,pQx);
		vx2[i]=2*ddotvec(*nncone,pdx,pQx);
		vx3[i]=ddotvec(*nncone,pdx,pQdx);
	}
	double alpha=1,lowest=.05;
	for(i=0,nncone=ncone,pQs=&cc1[0],pQds=&cc2[0],pQx=&cc3[0],pQdx=&cc4[0];i<n;
	pQs+=*nncone,pQds+=*nncone,pQx+=*nncone,pQdx+=*nncone,i++,nncone++)
	{
		if(pQdx[*nncone-1]<0) alpha=dmin((1-lowest)*(-pQx[*nncone-1]) / pQdx[*nncone-1],alpha);
		if(pQds[*nncone-1]<0) alpha=dmin((1-lowest)*(-pQs[*nncone-1]) / pQds[*nncone-1],alpha);
	}
	for(i=0,nncone=ncone,ps=s,pds=ds,px=x,pdx=dx;i<n;
	ps+=*nncone,pds+=*nncone,px+=*nncone,pdx+=*nncone,i++,nncone++)
	{
		if(pdx[*nncone-1]<0) alpha=dmin((1-lowest)*(-px[*nncone-1]) / pdx[*nncone-1],alpha);
		if(pds[*nncone-1]<0) alpha=dmin((1-lowest)*(-ps[*nncone-1]) / pds[*nncone-1],alpha);
	}
	if(homog&&*dtau<0) alpha=dmin((1-lowest)*-tau/ *dtau,alpha);
	if(homog&&*dkappa<0) alpha=dmin((1-lowest)*-kappa/ *dkappa,alpha);
	double inner,testxs,r1,r2;
	for(i=0,nncone=ncone,pdx=dx,pds=ds;i<n;pdx+=*nncone,pds+=*nncone,nncone++,++i)
	{
		if((testxs=vs1[i]+alpha*(vs2[i]+alpha*vs3[i]))<0)
		{
			if(fabs(vs3[i])<lm_eps)
			{
				if(vs2[i]<0)
					alpha=dmin((1-lowest)*-vs1[i]/vs2[i],alpha);
			}
			else if((inner=vs2[i]*vs2[i]-4*vs3[i]*vs1[i])>0)
			{
				inner=sqrt(inner);
				r1=(-vs2[i]-inner)/2./vs3[i];r2=(-vs2[i]+inner)/2./vs3[i];
				if(vs3[i]<0)
				{
					alpha = dmin((1-lowest)*(-vs2[i]-inner)/2./vs3[i],alpha);
				}
				else if(vs3[i]>0)
				{
					alpha = dmin((1-lowest)*(-vs2[i]-inner)/2./vs3[i],alpha);
				}
			}
			else
				printf((char*)"still negative\n");
		}
/*		else if(testxs<1e-16 && testxs<vs1[i])
		{
			for(j=0;j<*nncone;++j)
				pds[j]=0;
		}*/
		if((testxs=vx1[i]+alpha*(vx2[i]+alpha*vx3[i]))<0)
		{
			if(fabs(vx3[i])<lm_eps)
			{
				if(vx2[i]<0)
					alpha=dmin((1-lowest)*-vx1[i]/vx2[i],alpha);
			}
			else if((inner=vx2[i]*vx2[i]-4*vx3[i]*vx1[i])>0)
			{
				inner=sqrt(inner);
				r1=(-vx2[i]-inner)/2./vx3[i];r2=(-vx2[i]+inner)/2./vx3[i];
				if(vx3[i]<0)
				{
					alpha = dmin((1-lowest)*(-vx2[i]-inner)/2./vx3[i],alpha);
				}
				else if(vx3[i]>0)
				{
					alpha = dmin((1-lowest)*(-vx2[i]-inner)/2./vx3[i],alpha);
				}
			}
			else
				printf((char*)"still negative\n");
		}
/*		else if(testxs<1e-16 && testxs<vx1[i])
		{
			for(j=0;j<*nncone;++j)
				pdx[j]=0;
		}*/
	}
	size_t l;
	double rhs,gamma1=1-gamma,test1,test2=1;
	for(l=0;l<1000;++l)
	{
		rhs=beta*(1-alpha*gamma1)*mu;
		if(homog)test2=(tau+alpha* *dtau)*(kappa+alpha* *dkappa);
		test1=0;
		for(i=0;i<n;++i)
		{
			test1+=(vx1[i]+alpha*(vx2[i]+alpha*vx3[i]))*(vs1[i]+alpha*(vs2[i]+alpha*vs3[i]));
		}
		test1=sqrt(test1);
		if(test1>=rhs&&test2>=rhs)break;
		alpha*=(1-lm_eps);
	}
/*	for(i=0;i<n;++i)
	{
		while((testxs=vx1[i]+alpha*(vx2[i]+alpha*vx3[i]))<0)
			alpha*=.95;
		while((testxs=vs1[i]+alpha*(vs2[i]+alpha*vs3[i]))<0)
			alpha*=.95;
	}*/
/*	double gap=ddotvec(nx,c,x)-ddotvec(m,b,y);
	double dgap=ddotvec(nx,c,dx)-ddotvec(m,b,dy);
	if(gap+alpha*dgap<0)
	{
		printf((char*)"Stop gap going negative gap=%20.8e dgap=%20.8e\n",gap,dgap);
		alpha=min(-(1-lowest)*gap/dgap,alpha);
	}*/
	return alpha;
}
extern "C" DLLEXPORT void testSOCPinf()
{
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	size_t n=3,nn=n*(n+1)/2;
	double v[]={1,-1,1};
	std::valarray<double>V(nn);
	SOCPhomog test;
	test.mat(n,v,&V[0]);
	test.inv(n,v,&V[0]);
	test.diag(n,v,&V[0]);
	std::valarray<double>Q(nn),q(n);
	std::valarray<double>T(nn);
	test.q(n,&q[0]);
	test.Q(n,&Q[0]);
	test.T(n,&T[0]);
	double s[]={-.1,.031,1};
	double x[]={.21,-.01,1};
	double theta=test.gettheta(n,s,x,&Q[0]);
	theta=test.gettheta(n,s,x);
	std::valarray<double> w(n),W(nn),Wm1(nn),W2(nn);
	test.getw(n,s,x,theta,&Q[0],&w[0]);
	test.getw(n,s,x,theta,&w[0]);
	test.W(n,&w[0],&W[0]);
	test.Wm1(n,&q[0],&W[0],&Wm1[0]);
	test.W2(n,&w[0],&Q[0],&W2[0]);
	test.thetaWm2(n,&q[0],&W2[0],theta,&W[0]);
}
const double loww=1e-10;
inline void signset(size_t n,vector w,bool* ss)
{
	while(n--)
	{
		if(*w>loww)*ss=true;
		else if(*w<loww)*ss=false;
		w++;ss++;
	}
}
inline size_t signcheck(size_t n,bool*s1,bool*s2)
{
	size_t back=0;
	while(n--)
	{
		if(*s1++!=*s2++) back++;
	}
	return back;
}
/*void AddLog(std::stringstream* logprint,const char* mess)
{
	if(!logprint)return;
	*logprint<<mess;
#if defined( MSDOSS ) || defined( _DEBUG ) || defined( __linux__ )
	std::cout<<mess;std::cout.flush();
#endif
}*/
void AddLog(std::stringstream* logprint,char *mess, ...)
{
	if(!logprint) return;
	char mm[200];
	va_list ttt;
	va_start(ttt,mess);
	int i = vsprintf(mm, mess, ttt);
	if(i>0)
	{
		*logprint<<mm;
#if defined( MSDOSS ) || defined( _DEBUG ) || defined( __linux__ )
		std::cout<<mm;std::cout.flush();
#endif
	}
	va_end(ttt);
}
void PrintLog(std::stringstream* logprint,std::ofstream* outFile=0)
{
	if(logprint)
	{
		if(outFile)
		{
			*outFile<<(*logprint).str();
		}
		else
		{
			std::cout<<(*logprint).str();
		}
	}
}
/*void SOCPhomog::AddLog(const char* mess)
{
	if(!logprint)return;
	*logprint<<mess;
#if defined( MSDOSS ) || defined( _DEBUG ) || defined( __linux__ )
	std::cout<<mess;std::cout.flush();
#endif
}*/
void SOCPhomog::AddLog(const char *mess, ...)
{
	if(!logprint) return;
	char mm[200];
	va_list ttt;
	va_start(ttt,mess);
	int i = vsprintf(mm, mess, ttt);
	if(i>0)
	{
		*logprint<<mm;
#if defined( MSDOSS ) || defined( _DEBUG ) || defined( __linux__ )
		std::cout<<mm;std::cout.flush();
#endif
	}
	va_end(ttt);
}
void SOCPhomog::PrintLog(void)
{
	if(logprint)
		std::cout<<(*logprint).str();
}
void SOCPhomog::SetLog(std::stringstream* logprint)
{
	this->logprint=logprint;
}
inline bool ratiotest(double a,double b,double c,double d,int&log,std::stringstream&logprint,double top=2.0,double bot=.5)
{
	if(a==0)return false;
	double test;
	if(a==b)test=(fabs(c/a)+fabs(d/a))/2.;
	else test=(fabs(b/a)+fabs(c/a)+fabs(d/a))/3.;
	if(test > top || test < bot)
	{
		if(log)AddLog(&logprint,(char*)"Will break due to ratio test (%20.8f)\n",test);
		if(a!=b)return ratiotest(b,b,c,d,log,logprint,top,bot);
		if(a!=b)return ratiotest(a,a,c,d,log,logprint,top,bot);
		else return true;
	}
	return false;
}
bool matchnumber_sp(const char a)
{
	auto tt=(int)(a-'0');
	return (a=='e'||a=='E'||a==' '||a=='-'||a=='+'||(tt<=9&&tt>=0))?true:false;
}
#if !(_WINDOWS || __cplusplus >= 201402L)
template <typename T> DLLEXPORT void dumpvector(size_t n,const char* name,T* A,std::ofstream &file)
{
	file<<name<<std::endl;
	file.precision(17);
	if(A&&(n>0))
	{
		while(n--)
		{
			if(n)
				file<<*A++<<" ";
			else
				file<<*A++;
		}
	}
	file<<std::endl;
}
template <typename T> DLLEXPORT void dumpvector(size_t n,const char* name,T* A,std::ofstream &file,size_t lim)
{
	file<<name<<std::endl;
	file.precision(17);
	size_t i=0;
	bool end=true;
	if(A)
	{
		while(n--)
		{
			end=false;
			if(i++%lim==(lim-1))end=true;
			if(n&&!end)
				file<<*A++<<" ";
			else
				file<<*A++;
			if(end)file<<std::endl;
		}
	}
	if(!end)file<<std::endl;
}
template <class T> T* getvector(std::map<std::string,std::vector<T> >&vecmap,const char*name,T* back=0)
{
	if(vecmap.find(name)!=vecmap.end())
	{
		if(strcmp(vecmap.find(name)->first.c_str(),name)==0)
			back=&vecmap[name].front();
	}
	return back;
}
template <class T> T getscalar(std::map<std::string,std::vector<double> >&vecmap,const char*name,T init=0)
{
	T back=init;
	if(vecmap.find(name)!=vecmap.end())
	{
		if(strcmp(vecmap.find(name)->first.c_str(),name)==0)
			back=(T)vecmap[name][0];
	}
	return back;
}
#else
template <typename T> DLLEXPORT void dumpvector(size_t n,const char* name,T* A,std::ofstream &file)
{
	file<<name<<std::endl;
	file.precision(17);
	if(A&&(n>0))
	{
		while(n--)
		{
			if(n)
				file<<*A++<<" ";
			else
				file<<*A++;
		}
	}
	file<<std::endl;
}
template <typename T> DLLEXPORT void dumpvector(size_t n,const char* name,T* A,std::ofstream &file,size_t lim)
{
	file<<name<<std::endl;
	file.precision(17);
	auto i=0;
	auto end=true;
	if(A)
	{
		while(n--)
		{
			end=false;
			if(i++%lim==(lim-1))end=true;
			if(n&&!end)
				file<<*A++<<" ";
			else
				file<<*A++;
			if(end)file<<std::endl;
		}
	}
	if(!end)file<<std::endl;
}
template <typename T> auto getvector(std::map<std::string,std::vector<T> >&vecmap,const char*name,T* back=0)
{
	auto pos=vecmap.find(name);
	if(pos!=vecmap.end())
		back=&pos->second.front();
	return back;
}
template <typename T> auto getscalar(std::map<std::string,std::vector<double> >&vecmap,const char*name,T back=0)
{
	auto pos=vecmap.find(name);
	if(pos!=vecmap.end())
		back=pos->second[0];
	return back;
}
#endif
extern "C" DLLEXPORT void SOCPlsRobustlDUMP(size_t n,size_t m,vector w,vector A,
										long nf,vector SV,vector FL,vector FC,
										vector alpha,int full,double rmin,double rmax,
										vector L,vector U,double val,double TopRisk,
										vector dalpha,double MaxDalpha,vector covalpha,double MaxValpha,
										size_t nabs,vector Aabs,vector Labs,
										vector Uabs,
										vector bench,vector initialm,vector initials,
										int signtest,int fast=0,int maxrobust=0,char*outfile=0)
{
	size_t nn=n*(n+1)/2;
	std::ofstream outFile;
	if(outfile&&!strlen(outfile))//In case someone sends outfile=(char*)""
	{
		std::cout<<"No output file was given"<<std::endl;
		return;
	}
	if(outfile)
	{
		outFile.open(outfile,std::ios_base::out);
		if(outFile.fail())
		{
			std::cout<<"Cannot open "<<outfile<<std::endl;
			return;
		}
		dumpvector(1,(char*)"n",&n,outFile);
		dumpvector(1,(char*)"m",&m,outFile);
		dumpvector(n*m,(char*)"A",A,outFile);
		dumpvector(1,(char*)"nf",&nf,outFile);
		dumpvector(n,(char*)"SV",SV,outFile);
		dumpvector(n*nf,(char*)"FL",FL,outFile);
		if(TopRisk>0)
		{
			if(nf>=0)
				dumpvector(nf*(nf+1)/2,(char*)"FC",FC,outFile);
			else
				dumpvector(nn,(char*)"FC",FC,outFile);
		}
		dumpvector(n,(char*)"alpha",alpha,outFile);
		dumpvector(1,(char*)"full",&full,outFile);
		dumpvector(1,(char*)"rmin",&rmin,outFile);
		dumpvector(1,(char*)"rmax",&rmax,outFile);
		dumpvector(n+m,(char*)"L",L,outFile);
		dumpvector(n+m,(char*)"U",U,outFile);
		dumpvector(1,(char*)"val",&val,outFile);
		dumpvector(1,(char*)"TopRisk",&TopRisk,outFile);
		dumpvector(n,(char*)"dalpha",dalpha,outFile);
		dumpvector(1,(char*)"MaxDalpha",&MaxDalpha,outFile);
		dumpvector(nn,(char*)"covalpha",covalpha,outFile);
		dumpvector(1,(char*)"MaxValpha",&MaxValpha,outFile);
		dumpvector(1,(char*)"nabs",&nabs,outFile);
		dumpvector(n*nabs,(char*)"Aabs",Aabs,outFile);
		dumpvector(nabs,(char*)"Labs",Labs,outFile);
		dumpvector(nabs,(char*)"Uabs",Uabs,outFile);
		dumpvector(n,(char*)"bench",bench,outFile);
		dumpvector(n,(char*)"initialm",initialm,outFile);
		dumpvector(n,(char*)"initials",initials,outFile);
		dumpvector(1,(char*)"signtest",&signtest,outFile);
		dumpvector(1,(char*)"fast",&fast,outFile);
		dumpvector(1,(char*)"maxrobust",&maxrobust,outFile);
		outFile<<"-------------------------------------------------------------------------------------------";
		outFile.close();
		outFile.clear();
	}
	else
		std::cout<<"No output file was given"<<std::endl;
}
extern "C" DLLEXPORT void SOCPinfeasHomogtDUMP(size_t n,size_t m,int *ncone,vector c,vector A,
										 vector b,vector x,vector y,vector s,double *tau,
										 double *kappa,size_t maxit,double beta,double delta,double ccomp=1e-6,
										 double cgap=1e-6,int signtest=0,double changeratio=4,
										 double rhoconv=1e-8,int log=0,char*outfile=0)
{
	size_t i,nx;
	for(i=0,nx=0;i<n;nx+=ncone[i],++i);
	std::ofstream outFile;
	if(outfile&&!strlen(outfile))//In case someone sends outfile=(char*)""
	{
		std::cout<<"No output file was given"<<std::endl;
		return;
	}
	if(outfile)
	{
		outFile.open(outfile,std::ios_base::out);
		if(outFile.fail())
		{
			std::cout<<"Cannot open "<<outfile<<std::endl;
			return;
		}
		dumpvector(1,(char*)"n",&n,outFile);
		dumpvector(1,(char*)"m",&m,outFile);
		dumpvector(n,(char*)"ncone",ncone,outFile);
		dumpvector(nx,(char*)"c",c,outFile);
		dumpvector(nx*m,(char*)"A",A,outFile,100000);
		dumpvector(m,(char*)"b",b,outFile);
		dumpvector(1,(char*)"maxit",&maxit,outFile);
		dumpvector(1,(char*)"beta",&beta,outFile);
		dumpvector(1,(char*)"delta",&delta,outFile);
		dumpvector(1,(char*)"ccomp",&ccomp,outFile);
		dumpvector(1,(char*)"cgap",&cgap,outFile);
		dumpvector(1,(char*)"signtest",&signtest,outFile);
		dumpvector(1,(char*)"changeratio",&changeratio,outFile);
		dumpvector(1,(char*)"rhoconv",&rhoconv,outFile);
		dumpvector(1,(char*)"log",&log,outFile);
		outFile<<"-------------------------------------------------------------------------------------------";
		outFile.close();
		outFile.clear();
	}
	else
		std::cout<<"No output file was given"<<std::endl;
}
extern "C" DLLEXPORT short SOCPinfeasHomogt(size_t n,size_t m,int *ncone,vector c,vector A,
										 vector b,vector x,vector y,vector s,double *tau,
										 double *kappa,size_t maxit,double beta,double delta,double ccomp=1e-6,
										 double cgap=1e-6,int signtest=0,double changeratio=4,
										 double rhoconv=1e-8,int log=0,char*outfile=0,char*SOCPdump=0)
{
#ifdef PAS
//	UnlockBita((char*)"colincolin");
	if(!Optimise::bitago)
	{
		fprintf(stderr,(char*)"Bad PAS key\n");
		return -1;
	}
	return -1;
#endif
	{	//Now we ditch the original SOCPinfeasHomogt and use the more general Conic_General
		std::valarray<int>typecone(n);
		size_t i;
		double stepmax=1e-3;
		for(i=0;i<n;++i)
			typecone[i]=1;
		if(SOCPdump&&!strlen(SOCPdump))SOCPdump=0;
		if(outfile&&!strlen(outfile))outfile=0;
		if(!outfile&&SOCPdump)
			outfile=SOCPdump;
		if(SOCPdump)log=2;
		int fastbreak=0;
		int method=2;//Sparse Choleski (1) Bunch-Kaufman (0) Gram Schmidt conjugate basis (2)
		if(n>1000)method=0;//Bunch Kaufman .... makes more use of OMP
		int homog=1;//homogenous method
		method=2;//log=1;

		//log=1;outfile=(char*)"bigsean";
		return Conic_VeryGeneral(n,ncone,&typecone[0],m,x,s,y,A,b,
			c,tau,kappa,1e-9,1e-9,stepmax,0,fastbreak,log,outfile,method,homog,0,0,0,0,0);//Now try this instead of Conic_General
/*		return Conic_General(n,ncone,&typecone[0],m,x,s,y,A,b,
			c,tau,kappa,5e-9,5e-9,2e-2,0,fastbreak,log,outfile,method);*/
	}
	if(SOCPdump&&strlen(SOCPdump))
		SOCPinfeasHomogtDUMP(n,m,ncone,c,A,b,x,y,s,tau,kappa,maxit,beta,delta,ccomp,cgap,signtest,
			changeratio,rhoconv,log,SOCPdump);
#ifdef __SYSNT__
	_ASSERT(0);
#endif
//	changeratio=0;
	std::stringstream logprint;
	std::ofstream outFile;
	if(outfile&&!strlen(outfile))//In case someone sends outfile=(char*)""
	{
		outfile=0;
	}
	if(outfile)
	{
		outFile.open(outfile,std::ios_base::out|std::ios_base::app);
		if(outFile.fail())
		{
			std::cout<<"Cannot open "<<outfile<<std::endl;
		}
	}
	Optimise O;
	if(!O.licenced)return -1;
	size_t i,j;
	size_t nx;
	//Initialise------------------------------------------------------------
	vector pxx;
	vector pss;
	for(i=0,nx=0;i<n;nx+=ncone[i],++i);
	if(log)AddLog(&logprint,(char*)"Need to solve %d linear equations in each iteration\n",m);
//	if(log && (nx>changeratio*m)) AddLog(&logprint,(char*)"Initially %d at each step\n",m);
	if((ddotvec(nx,x,x)+ddotvec(nx,s,s))<0.5)
	{
		if(log)AddLog(&logprint,(char*)"No start guess given, setting here\n");
		dzerovec(nx,x);
		dzerovec(nx,s);
		dzerovec(m,y);
		for(i=0,pxx=x,pss=s;i<n;pxx+=ncone[i],pss+=ncone[i],i++)
		{
			pxx[ncone[i]-1]=1;
			pss[ncone[i]-1]=1;
		}
		*tau=1;
		*kappa=1;
		double gap=ddotvec(nx,c,x)-ddotvec(m,b,y);
		if(log)AddLog(&logprint,(char*)"Initial gap %20.8e\n",gap);
		if(gap < 0)
		{
			dsetvec(m,1,y);
			double dgap=ddotvec(m,b,y);
			double step=gap/dgap;
			dsetvec(m,(1+lm_rooteps)*step,y);
		}
		gap=ddotvec(nx,c,x)-ddotvec(m,b,y);
		if(log)AddLog(&logprint,(char*)"Initial gap %20.8e\n",gap);
	}
	//----------------------------------------------------------------------
	std::valarray<double> ex(nx),es(nx),ey(m);
	double etau,ekappa;
	double rhoA=1,rhoP=1,rhoP0,rhoD=1,rhoD0,rhoG=1,rhoG0,mu0;
	size_t differentsigns;

	SOCPhomog testv(n,m,ncone,c,A,b,x,y,s,*tau,*kappa);

	testv.changeratio=changeratio;
	testv.homog=true;
	//testv.use_conj=true;
	//testv.steep=true;
	testv.use_sparse=true;
//	testv.SetLog(&logprint);
//	testv.log=false;
	if(testv.homog)mu0=(ddotvec(nx,testv.x,testv.s)+testv.tau*testv.kappa)/(testv.n+1);
	else mu0=ddotvec(nx,testv.x,testv.s)/(testv.n);
	int badcount=0,badtop=200;
	double alphamax=2e-1;
	std::valarray<bool>ysign(2*m);
	size_t worsecount=0;
	bool restart=false;
	double resid=lm_max,residmin=lm_max;
	size_t maincount=0;
	while(badcount++<badtop)
	{
		long i;
		double inner;
#pragma omp parallel private(i,inner) 
{
#pragma omp sections nowait
{
#pragma omp section
{
		rhoP0=0;
		for(i=0;i<testv.m;++i)
		{
			inner=ddotvec(testv.nx,A+i*nx,testv.x)-testv.tau*testv.b[i];
			rhoP0+=inner*inner;
		}
		rhoP0=sqrt(rhoP0);
		rhoG0=fabs(-ddotvec(testv.nx,testv.c,testv.x)+ddotvec(testv.m,testv.b,testv.y)-testv.kappa);
}
#pragma omp section
{
		rhoD0=0;
		for(i=0;i<testv.nx;++i)
		{
			inner=BITA_ddot(testv.m,A+i,testv.nx,testv.y,1)+testv.s[i]-testv.tau*testv.c[i];
			rhoD0+=inner*inner;
		}
		rhoD0=sqrt(rhoD0);
}
}
}
		double gamma=0,alpha=1,alphat=0,comp=10,gap=10,testalpha;
		double rhoDlim=rhoconv,rhoGlim=rhoconv,rhoAlim=rhoconv,rhoPlim=rhoconv;
		//bool changed=0;
		testv.mu=mu0;
		testv.getw_and_theta();
		testv.makeResid(0);
		residmin=resid=ddotvec(2+m+2*nx,testv.r1,testv.r1);
		for(i=0;i<maxit&&(fabs(gap)>cgap||comp>ccomp||rhoD/testv.convscale()>rhoDlim||rhoG/testv.convscale()>rhoGlim||rhoP/testv.convscale()>rhoPlim||rhoA/testv.convscale()>rhoAlim);++i)
		{
			testv.clocker(1);
			if(testv.use_conj && testv.conj_res)
			{
				testv.AddLog((char*)"Switch off conjugate gradient method\n");
				testv.use_conj=false;
			}
			gamma=0;
			if(log)AddLog(&logprint,(char*)"========== i = %d ============ %d\n",i+1,maincount+1);maincount++;
			testv.AddLog((char*)"Current mu is\t\t%20.12e\n",testv.mu);
			testv.getDirectionL();if(log)AddLog(&logprint,(char*)"DirectionL time %20.12e\n",testv.clocker(0));
			if(testv.ldlfailed)break;
			if(testv.badindex)
			{
				if(log)AddLog(&logprint,(char*)"The Normal Equations are singular; cannot proceed\n");
				break;
			}
			if(!(testv.usedouble)&&testv.changetodouble&&log)AddLog(&logprint,(char*)"Use double precision when factoring the normal matrix\n");
			alpha=testv.getStepsize(gamma,beta);if(log)AddLog(&logprint,(char*)"Stepsize time %20.12e\n",testv.clocker(0));
			testv.AddLog((char*)"step length\t\t%20.12e\n",alpha);
			
#pragma omp parallel
{
#pragma omp sections nowait
{
#pragma omp section
{
			dcopyvec(nx,testv.x,&ex[0]);
			dcopyvec(nx,testv.s,&es[0]);
			daxpyvec(nx,alpha,testv.dx,&ex[0]);
			daxpyvec(nx,alpha,testv.ds,&es[0]);
			testv.conecheck(&ex[0],(char*)"x");
			testv.conecheck(&es[0],(char*)"s");
}
#pragma omp section
{
			dcopyvec(m,testv.y,&ey[0]);
			etau=testv.tau,ekappa=testv.kappa;
			daxpyvec(m,alpha,testv.dy,&ey[0]);
			if(testv.homog)etau+=alpha* *(testv.dtau);
			if(testv.homog)ekappa+=alpha* *(testv.dkappa);
}
}
}
			gamma=dmin(delta,(1-alpha)*(1-alpha))*(1-alpha);
			testv.AddLog((char*)"gamma is\t\t%20.12e\n",gamma);
			
			testv.makeResid(gamma,alpha);
			testv.getDirectionL(false);if(log)AddLog(&logprint,(char*)"DirectionL time %20.12e\n",testv.clocker(0));
			alphat=testv.getStepsize(gamma,beta);if(log)AddLog(&logprint,(char*)"Stepsize time %20.12e\n",testv.clocker(0));
			testv.AddLog((char*)"revised step length\t%20.12e\n",alphat);
			if(alphat>alpha)
			{		
#pragma omp parallel
{
#pragma omp sections nowait
{
#pragma omp section
{
				daxpyvec(nx,alphat,testv.dx,testv.x);
				daxpyvec(nx,alphat,testv.ds,testv.s);
				testv.conecheck(testv.x,(char*)"x");
				testv.conecheck(testv.s,(char*)"s");
}
#pragma omp section
{
				daxpyvec(m,alphat,testv.dy,testv.y);
				if(testv.homog)testv.tau+=alphat* *(testv.dtau);
				if(testv.homog)testv.kappa+=alphat* *(testv.dkappa);
}
}
}
				testv.getw_and_theta();
				if(testv.badtheta)
				{
#pragma omp parallel
{
#pragma omp sections nowait
{
#pragma omp section
{
					dcopyvec(testv.nx,&ex[0],testv.x);
					dcopyvec(testv.nx,&es[0],testv.s);
}
#pragma omp section
{
					dcopyvec(testv.m,&ey[0],testv.y);
					if(testv.homog)testv.tau=etau;
					if(testv.homog)testv.kappa=ekappa;
}
}
}
					testv.getw_and_theta();
					if(testv.badtheta)break;
				}
			}
			else
			{
#pragma omp parallel
{
#pragma omp sections nowait
{
#pragma omp section
{
				dcopyvec(testv.nx,&ex[0],testv.x);
				dcopyvec(testv.nx,&es[0],testv.s);
}
#pragma omp section
{
				dcopyvec(testv.m,&ey[0],testv.y);
				if(testv.homog)testv.tau=etau;
				if(testv.homog)testv.kappa=ekappa;
}
}
}
				testv.getw_and_theta();
				if(testv.badtheta)break;
			}
			testv.makeResid(0);
#pragma omp parallel
{
#pragma omp sections nowait
{
#pragma omp section
{
			resid=ddotvec(2+m+2*nx,testv.r1,testv.r1);
			gap=(ddotvec(nx,testv.c,testv.x)-ddotvec(m,testv.b,testv.y))/testv.tau;
}
#pragma omp section
{
			comp=ddotvec(nx,testv.s,testv.x)+testv.tau*testv.kappa;
}
}
}
			if(log)
			{
				if(testv.homog)AddLog(&logprint,(char*)"tau %20.12e\tkappa is %20.12e\n",testv.tau,testv.kappa);
				AddLog(&logprint,(char*)"Primal\t\t%20.12e\n",ddotvec(nx,testv.c,testv.x)/testv.tau);
				AddLog(&logprint,(char*)"Dual\t\t%20.12e\n",ddotvec(m,testv.b,testv.y)/testv.tau);
				AddLog(&logprint,(char*)"s.x\t\t%20.12e\n",ddotvec(nx,testv.s,testv.x)/testv.tau/testv.tau);
				AddLog(&logprint,(char*)"Gap\t\t%20.12e\n",gap);
				AddLog(&logprint,(char*)"Complementarity\t%20.12e\n",(comp));
			}
			*tau=testv.tau;
			*kappa=testv.kappa;
			memmove(&ysign[m],&ysign[0],testv.m*sizeof(bool));
			signset(testv.m,testv.y,&ysign[0]);
			differentsigns=signcheck(testv.m,&ysign[0],&ysign[m]);
			if(log)AddLog(&logprint,(char*)"Signcheck for dual %d\n",differentsigns);
			if(resid<residmin)
			{
#pragma omp parallel
{
#pragma omp sections nowait
{
#pragma omp section
{
				dcopyvec(testv.nx,testv.x,testv.xkeep);
}
#pragma omp section
{
				dcopyvec(testv.nx,testv.s,testv.skeep);
				dcopyvec(testv.m,testv.y,testv.ykeep);
				testv.taukeep=testv.tau;
				testv.kappakeep=testv.kappa;
}
}
}
				worsecount=0;
			}
			else if(0&&!testv.golong)
			{
				if(residmin>lm_eps)testv.golong=true;
/*				cgap=min(1e-5,cgap*10);
				ccomp=min(1e-5,ccomp*10);
				rhoPlim=min(1e-5,rhoPlim*10);
				rhoDlim=min(1e-5,rhoDlim*10);
				rhoAlim=min(1e-5,rhoAlim*10);
				rhoGlim=min(1e-5,rhoGlim*10);*/
				if(log)AddLog(&logprint,(char*)"\t\t\t\t\t\tResidual got worse!!!!!!\n");
				dcopyvec(testv.nx,testv.xkeep,testv.x);
				dcopyvec(testv.nx,testv.skeep,testv.s);
				dcopyvec(testv.m,testv.ykeep,testv.y);
				testv.tau=testv.taukeep;
				testv.kappa=testv.kappakeep;
				*tau=testv.tau;
				*kappa=testv.kappa;
				//testv.conecheck(testv.x,(char*)"x");
				//testv.conecheck(testv.s,(char*)"s");
				testv.getw_and_theta();
				worsecount++;
			}
			
			residmin=dmin(resid,residmin);if(log)AddLog(&logprint,(char*)"total residual squared\t%20.12e (%20.12e)\n",resid,residmin);
			/*		if(!changed && comp<1e-3 && testv.tau>1e-10)
			{
			testv.homog=false;changed=true;
			dscalvec(testv.nx,1.0/testv.tau,testv.x);
			dscalvec(testv.nx,1.0/testv.tau,testv.s);
			dscalvec(testv.m,1.0/testv.tau,testv.y);
		}*/
			if(testv.homog)testv.mu=(ddotvec(nx,testv.x,testv.s)+testv.tau*testv.kappa)/(testv.n+1);
			else testv.mu=ddotvec(nx,testv.x,testv.s)/(testv.n);
			for(j=0,rhoP=0;j<testv.m;++j)
			{
				inner=ddotvec(testv.nx,A+j*nx,testv.x)-testv.tau*testv.b[j];
				rhoP+=inner*inner;
			}
			rhoP=sqrt(rhoP);
			if(restart)rhoP0=rhoP;
			rhoP/=rhoP0;
			for(j=0,rhoD=0;j<testv.nx;++j)
			{
				inner=BITA_ddot(testv.m,A+j,testv.nx,testv.y,1)+testv.s[j]-testv.tau*testv.c[j];
				rhoD+=inner*inner;
			}
			rhoD=sqrt(rhoD);
			if(restart)rhoD0=rhoD;
			rhoD/=rhoD0;
			rhoG=fabs(-ddotvec(testv.nx,testv.c,testv.x)+
				ddotvec(testv.m,testv.b,testv.y)-testv.kappa);
			if(restart)rhoG0=rhoG;
			if(restart)mu0=testv.mu;
			rhoG/=rhoG0;
			restart=false;
			rhoA=fabs(ddotvec(testv.nx,testv.c,testv.x)-ddotvec(testv.m,testv.b,testv.y))/
				(testv.tau+fabs(ddotvec(testv.m,testv.b,testv.y)));
			if(log)
			{
				AddLog(&logprint,(char*)"relative primal residual\t\t\t%20.12f\n",rhoP);
				AddLog(&logprint,(char*)"relative dual residual\t\t\t\t%20.12f\n",rhoD);
				AddLog(&logprint,(char*)"relative gap residual\t\t\t\t%20.12f\n",rhoG);
				AddLog(&logprint,(char*)"relative complementarity residual\t\t%20.12f\n",rhoA);
				AddLog(&logprint,(char*)"mu/(first mu)\t\t\t\t\t%20.12f\n",testv.mu/mu0);
				AddLog(&logprint,(char*)"tau/kappa\t\t\t\t%20.12e\n",testv.tau/testv.kappa);
				AddLog(&logprint,(char*)"iteration needed %20.12e (steps %f %f)\n",testv.clocker(0),alpha,alphat);
			}
			if(ratiotest(rhoP,rhoD,rhoG,testv.mu/mu0,log,logprint))break;
			
			if(resid>residmin&&worsecount>5)
			{
				if(log){AddLog(&logprint,(char*)"Break at %d\n",__LINE__);}break;
			}
			if(testv.tau<rhoconv&&rhoD<rhoDlim&&rhoG<rhoGlim&&rhoP<rhoPlim)
			{
				if(log){AddLog(&logprint,(char*)"Break at %d\n",__LINE__);}break;
			}
			if(differentsigns<=4 && signtest/*&&(resid<1e-3)*/)//This makes a great saving in time but may mess up accuracy
			{
				if(log){AddLog(&logprint,(char*)"Break at %d\n",__LINE__);}break;
			}
//			if(differentsigns<=0 && signtest)break;
			//		if(comp<ccomp&&fabs(gap)<cgap&&resid<1e-6) break;
			if(testv.tau<1e-3)alphamax=dmin(alphamax,1e-1);
			if((testalpha=dmax(alpha,alphat))<alphamax && !testv.steep)
			{
				if(testv.tau/testv.kappa>1e3 &&testalpha>1e-2)//This is to stop too many restarts
				{
					alphamax=dmin(alphamax,dmax(testalpha,1e-2));if(log){AddLog(&logprint,(char*)"\t\t\tmax step length now %20.8f\n",alphamax);}
				}
				else
				{
					if(log){AddLog(&logprint,(char*)"Break at %d\n",__LINE__);}break;
				}
			}
			if(testv.steep && (dmax(alpha,alphat)<alphamax || resid!=residmin))testv.steep=false;
			if(testv.use_conj && resid==residmin && resid < 1e-4)testv.use_conj=false;
		}
		/*	if(changed)
		{
			dscalvec(testv.nx,testv.tau,testv.x);
			dscalvec(testv.nx,testv.tau,testv.s);
			dscalvec(testv.m,testv.tau,testv.y);
		}*/
		if(0)//resid>residmin && dmax(alpha,alphat)<alphamax&&residmin<1e-13)
		{
			AddLog(&logprint,(char*)"Copy result with total residual %20.12e\n",residmin);
			dcopyvec(testv.nx,testv.xkeep,testv.x);
			dcopyvec(testv.nx,testv.skeep,testv.s);
			dcopyvec(testv.m,testv.ykeep,testv.y);
			testv.tau=testv.taukeep;
			testv.kappa=testv.kappakeep;
			*tau=testv.tau;
			*kappa=testv.kappa;
		}
		if(log){if(testv.homog)AddLog(&logprint,(char*)"tau %20.12e\tkappa is %20.12e\n",testv.tau,testv.kappa);}

			testv.AddLog((char*)"dual constraints\n");
			for(j=0;j<nx;++j)
			{
				testv.AddLog((char*)"c%4d %20.12e\tr%4d %20.12e\ts%4d %20.12e\tx%4d %20.12e\n",j+1,BITA_ddot(m,testv.A+j,nx,testv.y,1)/testv.tau,j+1,BITA_ddot(m,testv.A+j,nx,testv.y,1)+testv.s[j]-testv.c[j]*testv.tau,j+1,testv.s[j]/testv.tau,j+1,testv.x[j]/testv.tau);
			}
			testv.AddLog((char*)"primal constraints\n");
			for(j=0;j<m;++j)
			{
				testv.AddLog((char*)"c%4d %20.12e\tr%4d %20.12e\ty%4d %20.12e\n",j+1,ddotvec(nx,testv.A+j*nx,testv.x)/testv.tau,j+1,ddotvec(nx,testv.A+nx*j,testv.x)-testv.b[j]*testv.tau,j+1,testv.y[j]/testv.tau);
			}

		gap=(ddotvec(nx,testv.c,testv.x)-ddotvec(m,testv.b,testv.y))/testv.tau;
		comp=ddotvec(nx,testv.s,testv.x)+testv.tau*testv.kappa;
		if(log)
		{
		AddLog(&logprint,(char*)"Primal\t\t%20.12e\n",ddotvec(nx,testv.c,testv.x)/testv.tau);
		AddLog(&logprint,(char*)"Dual\t\t%20.12e\n",ddotvec(m,testv.b,testv.y)/testv.tau);
		AddLog(&logprint,(char*)"Gap\t\t%20.12e\n",gap);
		AddLog(&logprint,(char*)"Complementarity\t%20.12e\n",comp);
		}
		testv.getw_and_theta();
		testv.makeResid(0);
		resid=ddotvec(2+m+2*nx,testv.r1,testv.r1);
		if(log)AddLog(&logprint,(char*)"total residual squared\t%20.12e (%20.12e)\n",resid,residmin);
//		if(signtest==0&&dmax(alphat,alpha)<alphamax)
		if(dmax(alphat,alpha)<alphamax)
		{
			if(log)AddLog(&logprint,(char*)"SOCP optimisation started to take very small steps %20.12e\n",dmax(alphat,alpha));
//			if(residmin<3e-8)break;
//			if(resid<1e-9)
//				testv.use_sparse=false;
//			else
			{
				double gap=ddotvec(nx,c,x)-ddotvec(m,b,y),oldmu=testv.mu,ext=1e-1*sqrt(fabs(gap))/n;
				if(badcount>2)ext=dmax(5e-2,ext);
				if(log)AddLog(&logprint,(char*)"Old gap %20.8e, mu %20.8e\t ext %20.8e \n",gap,testv.mu,ext);
				for(i=0,pxx=x,pss=s;i<n;pxx+=ncone[i],pss+=ncone[i],i++)
				{
					pxx[ncone[i]-1]+=ext;
					pss[ncone[i]-1]+=ext;
				}
				gap=ddotvec(nx,c,x)-ddotvec(m,b,y);
				if(testv.homog)testv.mu=(ddotvec(nx,testv.x,testv.s)+testv.tau*testv.kappa)/(testv.n+1);
				else testv.mu=ddotvec(nx,testv.x,testv.s)/(testv.n);
				if(testv.mu>oldmu&&oldmu>1e-4)
				{
					double pp=sqrt(oldmu/testv.mu);
					dscalvec(nx,pp,testv.x);
					dscalvec(nx,pp,testv.s);
					testv.tau*=pp;
					testv.kappa*=pp;
					gap=ddotvec(nx,c,x)-ddotvec(m,b,y);
					if(testv.homog)testv.mu=(ddotvec(nx,testv.x,testv.s)+testv.tau*testv.kappa)/(testv.n+1);
					else testv.mu=ddotvec(nx,testv.x,testv.s)/(testv.n);
				}
				if(log)AddLog(&logprint,(char*)"New gap %20.8e, mu %20.8e\n",gap,testv.mu);
				if(false&&gap<0)
				{
					double dgap=ddotvec(m,b,y),sdx=ddotvec(nx,s,x);
					dscalvec(m,(gap+dgap-sdx)/dgap,y);
					gap=ddotvec(nx,c,x)-ddotvec(m,b,y);
					if(testv.homog)testv.mu=(ddotvec(nx,testv.x,testv.s)+testv.tau*testv.kappa)/(testv.n+1);
					else testv.mu=ddotvec(nx,testv.x,testv.s)/(testv.n);
					if(log)AddLog(&logprint,(char*)"New gap %20.8e, mu %20.8e\n",gap,testv.mu);
				}
		//testv.getw_and_theta();
				//	printf((char*)"tau %20.8e kappa %20.8e\n",testv.tau,testv.kappa);
				//	testv.tau=1;
				//	testv.kappa=1;
			}
			restart=true;
#ifdef USE_SINGLE
	testv.usedouble=false;
	testv.changetodouble=false;
#endif
		}
		else if(false&&signtest==0&&(/*gap>1e-5||comp>1e-5||*/worsecount>5||resid>1e-5)&&*tau>*kappa)
//		else if((gap>1e-5||comp>1e-5||resid>1e-5)&&*tau>*kappa)
		{
			//		return 1;
			if(log)AddLog(&logprint,(char*)"Restart SOCP\n");
			for(i=0,pxx=x,pss=s;i<n;pxx+=ncone[i],pss+=ncone[i],i++)
			{
			//	printf((char*)"X %20.8e S %20.8e\n",pxx[ncone[i]-1],pss[ncone[i]-1]);
			//	if(pxx[ncone[i]-1]<.5 && pss[ncone[i]-1]<.5)
				{
					pxx[ncone[i]-1]+=.1;
					pss[ncone[i]-1]+=.1;
				}
			}
		//testv.getw_and_theta();
		//	printf((char*)"tau %20.8e kappa %20.8e\n",testv.tau,testv.kappa);
		//	testv.tau=1;
		//	testv.kappa=1;
			restart=true;
		}
		else
		{
			if(outfile)
			{
				PrintLog(&logprint,&outFile);
				outFile.close();
			}
			else
				PrintLog(&logprint);
			if(false&&(resid>residmin))
			{
				if(log)AddLog(&logprint,(char*)"Return lowest residual result\n");
#pragma omp parallel
{
#pragma omp sections nowait
{
#pragma omp section
{
				dcopyvec(testv.nx,testv.xkeep,testv.x);
}
#pragma omp section
{
				dcopyvec(testv.nx,testv.skeep,testv.s);
				dcopyvec(testv.m,testv.ykeep,testv.y);
				*tau=testv.tau=testv.taukeep;
				*kappa=testv.kappa=testv.kappakeep;
}
}
}
			}
			return 0;
		}
	}
	if(outfile)
	{
		PrintLog(&logprint,&outFile);
		outFile.close();
	}
	else
		PrintLog(&logprint,&outFile);
	if(resid>residmin)
	{
		if(log)AddLog(&logprint,(char*)"Return lowest residual result\n");
#pragma omp parallel
{
#pragma omp sections nowait
{
#pragma omp section
{
		dcopyvec(testv.nx,testv.xkeep,testv.x);
}
#pragma omp section
{
		dcopyvec(testv.nx,testv.skeep,testv.s);
		dcopyvec(testv.m,testv.ykeep,testv.y);
		*tau=testv.tau=testv.taukeep;
		*kappa=testv.kappa=testv.kappakeep;
}
}
}
			}
	return 1;
}
extern "C" DLLEXPORT int SOCPopt1(size_t n,size_t m,size_t *md,vector c,vector A,vector b,vector w,
								 double delt,double nu)
{
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	size_t nb=0,i,j,k;
	for(i=0;i<m;++i)nb+=md[i];
	std::valarray<double>z(nb);
	z=0;
	size_t tot=0;
	for(i=0;i<m-1;tot+=md[i],++i)z[tot+md[i]-1]=1;
	vector diff=&z[nb-md[m-1]];
	for(i=0;i<n;++i)
	{
		diff[i]=c[i];
		for(j=0,tot=0;j<m-1;tot+=md[j],++j)
		{
			for(k=0;k<md[j];++k)
			{
				diff[i]-=A[i+(tot+k)*n]*z[tot+k];
			}
		}
	}
	diff[n]=sqrt(ddotvec(n,diff,diff))+10;
	SOCP opt(n,m,md,c,A,b,w,nb,&z[0],delt,nu);
	return opt.SOCPsolve();
}

extern "C" DLLEXPORT int SOCPgenopt(size_t n,size_t m,size_t *md,vector c,vector A,vector b,
									vector w,size_t nb,vector z,double delt,double nu,size_t maxiter,
									double gapconv,int log=0)
{
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	SOCP opt(n,m,md,c,A,b,w,nb,z,delt,nu);
	opt.printfreq=1;
	opt.maxiter=maxiter;
	opt.gapconv=gapconv;
	if(log)opt.SetLog();
	short back=opt.SOCPsolve();
	if(log)opt.PrintLog();
	return back;
}

/*//To try to compare with Boyd's SOCP optimiser from the internet. It never worked!!
extern "C" void socp_getwork(int L,int *N,int n,int max_iter,int out_mode,
							 int *mhist,int *nhist,int *ndbl,int *nint);

extern "C" int socp(int L,int *N,int n,double *f,double *A,double *b,double *x,double *z,
					double abs_tol,double rel_tol,double target,int *iter,double Nu,
					int *info,int out_mode,
					double *hist,double *dblwork,int *intwork);

extern "C" int SOCPgenoptt(size_t n,size_t m,size_t *md,vector c,vector A,vector b,
									vector w,size_t nb,vector z,double delt,double nu,size_t maxiter,
									double gapconv,int log=0)
{
	int mhist,nhist,ndbl,nint,out_mode=0,max_iter=1000,info;
	double target=-1,abs_tol=1e-6,rel_tol=1e-6;
	size_t i;
	std::valarray<int>imd(m);
	for(i=0;i<m;++i)imd[i]=md[i];
	socp_getwork(m,&imd[0],n,max_iter,out_mode,&mhist,&nhist,&ndbl,&nint);
	std::valarray<double>hist(nhist*mhist),WORK(ndbl);
	std::valarray<int>INTW(nint);
	socp(m,&imd[0],n,c,A,b,w,z,abs_tol,rel_tol,target,&max_iter,nu,&info,out_mode,&hist[0],
		&WORK[0],&INTW[0]);
	return info;
}*/

extern "C" DLLEXPORT int SOCPopt(size_t n,size_t m,size_t *md,vector c,vector A,vector b,vector w,
								 double delt,double nu,size_t maxiter,double RR,double gapconv,int log=0)
{
/*
	minimise sum i<n c[i]*w[i] 
	s.t.
	|| sum i<n A[i+j*n+n*md[k-1]]*w[i] + b[j+md[k-1]] j<mj[k] || <= sum i<n A[n*mj[k]+i]*w[i] + b[mj[k]]
	k<m
	m is the number of cone constraints
	md[i] is the number of constraints in each cone (max n for all assets + 1 )

	This generates feasible primal and dual guesses then solves the required problem
*/
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	Optimise O;
	if(!O.licenced)return -1;
	double ballcheck=1e-3;
	size_t nb=0,i,j;
	for(i=0;i<m;++i)
		nb+=md[i];
	std::valarray<double> C(n+1);
	std::valarray<double> AA((nb+n+2)*(n+1));AA=0;
	std::valarray<double> WW(n+1);
	std::valarray<double> BB(nb+n+2);
	std::valarray<size_t> MD(m+1);
	C=0;C[n]=1;
	size_t tot;
	for(i=0;i<nb;++i)
	{
		dcopyvec(n,A+i*n,&AA[i*(n+1)]);
	}
	for(i=0,tot=0;i<m;tot+=md[i],++i)
	{
		AA[(tot+md[i]-1)*(n+1)+n]=1;
	}
	BB=0;dcopyvec(nb,b,&BB[0]);
	for(i=0;i<n+1;++i)
	{
		AA[(n+1)*(i+nb)+i]=1;
	}
/*	for(i=0;i<nb+n+2;++i)
	{
		printf((char*)"%2d ",i);
		for(j=0;j<n+1;++j)
		{
			printf((char*)"%10.3e ",AA[j+(n+1)*i]);
		}
		printf((char*)"\n");
	}*/
	BB[nb+n+1]=RR;
	std::valarray<double> ZZ(nb+n+2);ZZ=0;
	for(i=0;i<m;++i)MD[i]=md[i];
	MD[m]=n+2;
	for(i=0,tot=0;i<m;tot+=MD[i],++i)ZZ[tot+MD[i]-1]=1;
	vector diff=&ZZ[nb];
	double maxb=0,inner;
	for(i=0;i<n+1;++i)
	{
		diff[i]=C[i]-BITA_ddot(nb,&AA[i],n+1,&ZZ[0],1);
	}
/*	for(i=0;i<n+1;++i)
	{
		printf((char*)"%d %20.12e %20.12e\n",i+1,C[i],BITA_ddot(nb+n+2,&AA[i],n+1,&ZZ[0],1));
	}
	for(i=0;i<nb+n+2;++i)
	{
		printf((char*)"%d %20.12e %20.12e\n",i+1,BB[i],ZZ[i]);
	}*/
	diff[n+1]=sqrt(ddotvec(n+1,diff,diff))+10;
	WW=0;
	for(j=0,tot=0;j<m+1;tot+=MD[j],++j)
	{
		inner=sqrt(ddotvec(MD[j]-1,&BB[tot],&BB[tot]));
		maxb=max(inner-BB[tot+MD[j]-1],maxb);
	}
	if(BB[nb+n+1]<maxb)
		BB[nb+n+1]=maxb+1;
	WW[n]=0.5*(maxb+BB[nb+n+1]);
	short back;
	back=SOCPgenopt(n+1,m+1,&MD[0],&C[0],&AA[0],&BB[0],&WW[0],nb+n+2,&ZZ[0],delt,nu,maxiter,gapconv,log);
	printf((char*)"%20.12e %20.12e\n",ddotvec(n+1,&WW[0],&WW[0]),BB[nb+n+1]*BB[nb+n+1]);
	while(back&&(BB[nb+n+1]*BB[nb+n+1]-ddotvec(n+1,&WW[0],&WW[0])<ballcheck))
	{
		BB[nb+n+1]+=.5;
		back=SOCPgenopt(n+1,m+1,&MD[0],&C[0],&AA[0],&BB[0],&WW[0],nb+n+2,&ZZ[0],delt,nu,maxiter,gapconv,log);
	//	printf((char*)"%20.12e %20.12e\n",ddotvec(n+1,&WW[0],&WW[0]),BB[nb+n+1]*BB[nb+n+1]);
	}
	RR=BB[nb+n+1];
	if(WW[n]>0)
	{
		printf((char*)"Infeasible\n");
		return 1;
	}
	AA=0;
	for(i=0;i<nb;++i)
	{
		dcopyvec(n,A+i*n,&AA[i*n]);
	}
	BB=0;dcopyvec(nb,b,&BB[0]);
	for(i=0;i<n+1;++i)
	{
		AA[n*(i+nb)+i]=1;
	}
	BB[nb+n]=RR;
	ZZ=0;
	for(i=0;i<m;++i)MD[i]=md[i];
	MD[m]=n+1;
	for(i=0,tot=0;i<m;tot+=MD[i],++i)ZZ[tot+MD[i]-1]=1e4;
	diff=&ZZ[nb];
	for(i=0;i<n;++i)
	{
		diff[i]=c[i]-BITA_ddot(nb,&AA[i],n,&ZZ[0],1);
	}
/*	for(i=0;i<n;++i)
	{
		printf((char*)"%d %20.12e %20.12e %20.12e\n",i+1,WW[i],c[i],BITA_ddot(nb+n+1,&AA[i],n,&ZZ[0],1));
	}*/
	diff[n]=sqrt(ddotvec(n,diff,diff))+10;
/*	for(i=0;i<nb+n+1;++i)
	{
		printf((char*)"%d %20.12e %20.12e\n",i+1,BB[i],ZZ[i]);
	}*/
	std::valarray<double>z(nb+n+1);
	while(1)
	{
		dcopyvec(n,&WW[0],w);
		dcopyvec(nb+n+1,&ZZ[0],&z[0]);
		back=SOCPgenopt(n,m+1,&MD[0],c,&AA[0],&BB[0],w,nb+n+1,&z[0],delt,nu,maxiter,gapconv,log);
//		printf((char*)"%20.12e %20.12e\n",ddotvec(n,w,w),BB[nb+n]*BB[nb+n]);
		if(back&&(BB[nb+n]*BB[nb+n]-ddotvec(n,w,w)<ballcheck))BB[nb+n]+=.5;
		else break;
	}
	for(i=0;i<n;++i)
	{
		printf((char*)"%3ld %20.12e %20.12e\n",i+1,c[i],BITA_ddot(nb,A+i,n,&z[0],1));
	}
	back=SOCPgenopt(n,m,md,c,A,b,w,nb,&z[0],delt,nu,maxiter,gapconv,log);
	return back;
}

extern "C" DLLEXPORT void RootQold(size_t n,vector Q,vector RQ,vector RQm1)
{
	size_t nn=n*(n+1)/2,i;
	std::valarray<double> Qcopy(nn);
	std::valarray<short_scl> P(n);
	vector v1,v2;
	dcopyvec(nn,Q,&Qcopy[0]);
	if(_dsmxmpd_check(n,Q,&Qcopy[0],&P[0],0,0))
	{
#ifdef _DEBUG
		printf((char*)"The matrix was not properly positive definite\n");
#endif
	}
	for(i = 0,v1 = RQ,v2 = RQm1;i < n;i++,v1 += n,v2 += n)
	{
		if(RQ)
		{
			dzerovec(n,v1);v1[i]=1;
			dsmxasrt(n,&Qcopy[0],&P[0],0,v1);
		}
		if(RQm1)
		{
			dzerovec(n,v2);v2[i]=1;
			dsmxainvsqrt(n,&Qcopy[0],&P[0],0,v2);
		}
	}
//	dmx_transpose(n,n,RQ,RQ);
//	dmx_transpose(n,n,RQm1,RQm1);
}
extern "C" DLLEXPORT void RootQ(size_t n,vector Q,vector RQ,vector RQm1)
{
	if(!RQ && !RQm1)return;
	size_t nn=n*(n+1)/2,i,n2=n*n;
	std::valarray<double> Qcopy(nn);
	std::valarray<short_scl> P(n);
	vector v1,v2;
	dcopyvec(nn,Q,&Qcopy[0]);
	bunchf(n,&Qcopy[0],&P[0]);
	if(RQ)dzerovec(n2,RQ);
	if(RQm1)dzerovec(n2,RQm1);
	for(i = 0,v1 = RQ,v2 = RQm1;i < n;i++,v1 += n,v2 += n)
	{
		if(RQ)v1[i]=1;
		if(RQm1)v2[i]=1;
	}
	if(RQ)
	{
		applyrootA(n,n,&Qcopy[0],&P[0],RQ,n);
		dmx_transpose(n,n,RQ,RQ);
	}
	if(RQm1)
	{
		applyinverserootA(n,n,&Qcopy[0],&P[0],RQm1,n);
		dmx_transpose(n,n,RQm1,RQm1);
	}
}
extern "C" DLLEXPORT void RootQgram(size_t n,vector Q,vector RQ,vector RQm1)
{
	if(!RQ && !RQm1)return;
	size_t nn=n*(n+1)/2,i,n2=n*n;
	vector e=RQ,em1=RQm1;
	std::valarray<double>d(n);
	size_t *order=0;
	if(!RQ)e=em1;
	if(true)
	{
		std::valarray<double>w(n);
		vector q;
		for(i=0,q=Q;i<n;++i,q+=i)
			w[i]=q[i];
		order=new size_t[2*n];
		getorder(n,&w[0],order,0);
		//printx(n,&w[0]);
		for(i=0;i<n;++i)
			order[n+order[i]]=i;
		ReorderS(n,order,Q);
	}
	short back=gramS(n,Q,e,&d[0]); //e.Q.e' = d
	if(order)
		ReorderS(n,order+n,Q);
	if(RQ)
	{
		if(RQm1)
		{
			dcopyvec(n2,RQ,RQm1);
			inverseT(n,RQm1,RQ);
		}
		else
		{
			std::valarray<double>ww(n2);
			dcopyvec(n2,RQ,&ww[0]);
			inverseT(n,&ww[0],RQ);
		}
		for(i=0;i<n;++i)
		{
			if(d[i]>lm_eps)d[i]=sqrt(d[i]);
		}
		for(i=0,e=RQ;i<n;++i,e+=n)
			ddmxmul(n,&d[0],e,e);
		if(order)
			Reorder_gen(n,order+n,RQ,n);
		dmx_transpose(n,n,RQ,RQ);
	}
	if(RQm1)
	{
		if(RQ)
		{
			for(i=0;i<n;++i)
			{
				if(d[i]!=0)d[i]=1.0/d[i];
			}
		}
		else
		{
			for(i=0;i<n;++i)
			{
				if(d[i]!=0)d[i]=1.0/sqrt(d[i]);
			}
		}
		for(i=0,e=RQm1;i<n;++i)
			ddmxmulv(n,&d[0],1,e+i,n);
		dmx_transpose(n,n,RQm1,RQm1);
		if(order)
			Reorder_gen(n,order+n,RQm1,n);
		dmx_transpose(n,n,RQm1,RQm1);//This is RQm1' really. So RQ.RQm1'=I
	}
	if(order)delete[] order;
}
extern "C" DLLEXPORT void RootProcessQ(size_t n,vector Q,vector RQ,vector RQm1)
{
	/* 
	Use matrix diagonalisation to find square representations of
	the square root of a positive (semi) definite symmetric matrix
	and its inverse square root.
	*/
	size_t n2=n*n,itmax=1000,i,j,l;
	double p,pm;
	std::valarray<double> S(n2),v(n);
	vector pQ;
	for(i=0,pQ=Q;i<n;++i)
	{
		for(j=0;j<=i;++j)
		{
			S[i+n*j]=*pQ;
			if(i!=j)
				S[i*n+j]=*pQ;
			pQ++;
		}
	}
	eigendecomp(n,&S[0],&v[0],itmax);
	if(RQ)dzerovec(n2,RQ);
	if(RQm1)dzerovec(n2,RQm1);
	for(l=0;l<n;++l)
	{
		if(v[l]>lm_eps8)
		{
			v[l]=sqrt(v[l]);
			for(i=0;i<n;++i)
			{
				p=S[l*n+i]*v[l];
				pm=S[l*n+i]/v[l];
				for(j=0;j<=i;++j)
				{
					if(RQ)RQ[i+j*n]+=p*S[l*n+j];
					if(RQm1)RQm1[i+j*n]+=pm*S[l*n+j];
				}
			}
		}
	}
	for(i=0;i<n;++i)
	{
		for(j=0;j<i;++j)
		{
//			if(fabs(RQ[i+j*n])<lm_eps)RQ[i+j*n]=0;
//			if(fabs(RQm1[i+j*n])<lm_eps)RQm1[i+j*n]=0;
			if(RQ)RQ[j+i*n]=RQ[i+j*n];
			if(RQm1)RQm1[j+i*n]=RQm1[i+j*n];
		}
	}
}
void ProcessRQ(size_t n,size_t nextra,size_t*iid,vector RQ)
{
/* "Double up" the root of the covariances

	RQ	->	RQ RQ
	and NOT
	RQ RQ
	RQ RQ
	*/
	size_t i,j,*jd,*id,ne=n+nextra;
	vector pQ,pQj,pQjd;
	dmx_transpose(n,n,RQ,RQ);
	dmx_transpose(n,ne,RQ,RQ);
	for(i=0,pQ=RQ+n,id=iid;i<n;++i,pQ+=ne)
	{
		if(id&&*id==i)
		{
			for(j=0,pQjd=pQ-n,pQj=pQ,jd=iid;j<nextra;++j,pQj++)
			{
				*pQj=*(pQjd+*jd++);
			}
			id++;
		}
		else dzerovec(nextra,pQ);
	}
}
void ProcessQ(size_t n,vector Q,vector QQ,size_t nextra=0,size_t*id=0)
{
	//"Double up" the covariances
	vector pQi,pQj,pQk,pQQk;
	size_t i,j,nn=n*(n+1)/2,k;
	if(!id||nextra==n)
	{
		dcopyvec(nn,Q,QQ);
		for(i=0,pQj=Q,pQi=QQ+nn;i<n;++i,pQj+=i,pQi+=(n+i))
		{
			dcopyvec(i+1,pQj,pQi);
			dcopyvec(i+1,pQj,pQi+n);
			for(j=i+1,pQk=Q+j*(j+1)/2+i;j<n;++j,pQk+=j)
				*(pQi+j)=*pQk;
		}
	}
	else
	{
		dcopyvec(nn,Q,QQ);
		for(i=0,j=n;i<n;++i)
		{
			if(i==*id)
			{
				for(k=0,pQQk=QQ,pQk=Q,pQi=Q+i*(i+1)/2,pQj=QQ+j*(j+1)/2;k<=j;++k,pQQk+=k,
					pQk+=k,pQi++,pQj++)
				{
					if(k<=i)
						*pQj=*pQi;
					else if(k<n)
						*pQj=*(pQk+i);
					else
						*pQj=*(pQQk+i);
				}
				j++;
				id++;

			}
		}
	}
}
extern "C" DLLEXPORT short SOCPlstest(size_t n,size_t m,vector w,vector A,vector Q,
									 vector alpha,int full,double rmin,double rmax,
									 vector L,vector U,double val,double TopRisk,
									 vector dalpha,double MaxDalpha,size_t nabs,vector Aabs,
									 vector Uabs,vector bench,vector initial)
{
/*		
	Robust Optimisation version 1.
	Maximise alpha.w subject to
	Li<=wi<=Ui
	Li+n<=(A.w)i<=Ui+n
	sqrt(w'.Q.w) <= TopRisk
	sqrt(sum(wi.dalphai.wi))<=MaxDalpha

	and also if val is not zero attempt the specialised long-short constraints
	sum(wi)<=val only if wi>0 (=val if full is 1)
	(sum(abs(wi)) <= val if full is 2)
	sum(wi short)/sum(wi long) <= rmax if rmax>0
	sum(wi short)/sum(wi long) >= rmin if rmin>0

	There is no mechanism here to guarantee to get these extra constraints to work by adding
	non-convex terms to the utility.
*/
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	Optimise O;
	if(!O.licenced)return -1;
	std::vector<size_t> iid;
	size_t*id,nextra,mextra=(val==0?0:1);
	if(rmin>=-lm_eps)mextra++;
	if(rmax>=-lm_eps&&rmin!=rmax)mextra++;
	mextra+=nabs;
	size_t i,j,k;
	for(i=0;i<n;++i)
	{
		if(L[i]<0&&U[i]>0)
			iid.push_back(i);
	}
	id=0;
	nextra=iid.size();
	if(nextra)
		id=&(iid.front());
	std::valarray<double>LL(n+nextra),UU(n+nextra),//WW(n+nextra),
		Als(mextra*(n+nextra)),Lls(mextra),Uls(mextra);
	size_t mmextra;
	Als=0;
	if(nabs>1)dmx_transpose(nabs,n,Aabs,Aabs);
	for(i=0,j=n;i<n;++i)
	{
		mmextra=0;
		if(id&&i == *id)
		{
			LL[i]=L[i];
			UU[i]=0;
			LL[j]=0;
			UU[j]=U[i];
			if(mextra)
			{
				if(val!=0)
				{
					Als[i+mmextra*(n+nextra)]=0;
					Als[j+mmextra*(n+nextra)]=1;
					mmextra++;
				}
				if(rmin>=-lm_eps)
				{
					Als[i+mmextra*(n+nextra)]=1;
					Als[j+mmextra*(n+nextra)]=rmin;
					mmextra++;
					if(rmax>=-lm_eps&&rmin!=rmax)
					{
						Als[i+mmextra*(n+nextra)]=-1;
						Als[j+mmextra*(n+nextra)]=-rmax;
						mmextra++;
					}
				}
				else if(rmax>=-lm_eps)
				{
					Als[i+mmextra*(n+nextra)]=-1;
					Als[j+mmextra*(n+nextra)]=-rmax;
					mmextra++;
				}
				if(nabs)
				{
					vector pabs;
					for(k=0,pabs=Aabs;k<nabs;++k,pabs+=n)
					{
						Als[i+mmextra*(n+nextra)]=-*(pabs+i);
						Als[j+mmextra*(n+nextra)]=*(pabs+i);
						mmextra++;
					}
				}
			}
			j++;
			id++;
		}
		else
		{
			LL[i]=L[i];
			UU[i]=U[i];
			if(mextra)
			{
				if(val!=0)
				{
					if(L[i]<0)
					{
						Als[i+mmextra*(n+nextra)]=0;
					}
					else
					{
						Als[i+mmextra*(n+nextra)]=1;
					}
					mmextra++;
				}
				if(rmin>=-lm_eps)
				{
					if(L[i]<0)
					{
						Als[i+mmextra*(n+nextra)]=1;
					}
					else
					{
						Als[i+mmextra*(n+nextra)]=rmin;
					}
					mmextra++;
					if(rmax>=-lm_eps&&rmin!=rmax)
					{
						if(L[i]<0)
						{
							Als[i+mmextra*(n+nextra)]=-1;
						}
						else
						{
							Als[i+mmextra*(n+nextra)]=-rmax;
						}
						mmextra++;
					}
				}
				else if(rmax>=0)
				{
					if(L[i]<0)
					{
						Als[i+mmextra*(n+nextra)]=-1;
					}
					else
					{
						Als[i+mmextra*(n+nextra)]=-rmax;
					}
					mmextra++;
				}
				if(nabs)
				{
					vector pabs;
					for(k=0,pabs=Aabs+i;k<nabs;++k,pabs+=n)
					{
						Als[i+mmextra*(n+nextra)]=(L[i]<0?-*pabs:*pabs);
						mmextra++;
					}					
				}
			}
		}
	}
	if(nabs>1)dmx_transpose(n,nabs,Aabs,Aabs);
	mmextra=0;
	if(mextra)
	{
		if(val!=0)
		{
			Lls[mmextra]=(full==1)?val:0;
			Uls[mmextra++]=val;
		}
		if(rmin>=-lm_eps)
		{
			Lls[mmextra]=(rmin==rmax)?0:-1e4;
			Uls[mmextra++]=0;
			if(rmax>0&&rmax!=rmin)
			{
				Lls[mmextra]=-1e4;
				Uls[mmextra++]=0;
			}
		}
		else if(rmax>=-lm_eps)
		{
			Lls[mmextra]=-1e4;
			Uls[mmextra++]=0;
		}
		if(nabs)
		{
			for(k=0;k<nabs;++k)
			{
				Lls[mmextra]=0;
				Uls[mmextra++]=Uabs[k];
			}
		}
	}

	if(m>1)dmx_transpose(m,n,A,A);
	std::valarray<double> QQ((n+nextra)*(n+nextra+1)/2);
	if(nextra)ProcessQ(n,Q,&QQ[0],nextra,&(iid.front()));
	else dcopyvec(n*(n+1)/2,Q,&QQ[0]);
/*	size_t ij;
	for(i=0,ij=0;i<n+nextra;++i)
	{
		printf((char*)"QQ %d ",i);
		for(j=0;j<=i;++j)
		{
			printf((char*)"%12.3e ",QQ[ij++]);
		}
		printf((char*)"\n");
	}*/
	std::valarray<double>RQ((n+nextra)*n);
	RootQ(n,Q,&RQ[0],0);
	std::valarray<double> rbench(n);
	if(bench)
	{
		dmxtmulv(n,n,&RQ[0],bench,&rbench[0]);
	}

/*	for(i=0;i<n;++i)
	{
		printf((char*)"R %d ",i);
		for(j=0;j<n;++j)
		{
			printf((char*)"%12.3e ",RQ[i*n+j]);
		}
		printf((char*)"\n");
	}*/
	if(nextra)ProcessRQ(n,nextra,&(iid.front()),&RQ[0]);
/*	for(i=0;i<n;++i)
	{
		printf((char*)"RR %d ",i);
		for(j=0;j<n+nextra;++j)
		{
			printf((char*)"%12.3e ",RQ[i*(n+nextra)+j]);
		}
		printf((char*)"\n");
	}*/
	/*
	n+nextra+m  linear constraints		n+nextra+m  2-d cones
	mextra linear constraints			mextra 1- or 2-d cones
	2   quadratic constraints			2 n+1-d cones
	*/
	std::valarray<int> CONES;
	std::valarray<double> SA,Sc,Sb,Sx,Sy,Ss;
	size_t ncone,ndual=n+nextra,nn;
	double tau,kappa;
	ncone=n+nextra+m+mextra;
	if(TopRisk>0)ncone++;
	if(MaxDalpha>0)ncone++;
	CONES.resize(ncone);
	for(i=0,nn=0;i<n+nextra+m;++i)
	{
		nn+=CONES[i]=2;
	}
	for(i=0;i<mextra;++i)
	{
		if(Lls[i]==-1e4)
			nn+=CONES[n+nextra+m+i]=1;//-S/L ratio
		else
			nn+=CONES[n+nextra+m+i]=2;//Cover constraint or equality -S/L constraint
	}
	size_t q_xon=0;
	if(TopRisk>0)
		nn+=CONES[n+nextra+m+mextra+q_xon++]=n+1;
	if(MaxDalpha>0)
		nn+=CONES[n+nextra+m+mextra+q_xon++]=n+1;
	SA.resize(nn*ndual);
	Sc.resize(nn);
	SA=0;
	Sc=0;
	size_t ic;
	for(i=0,ic=0;i<n+nextra;++i)
	{
		SA[i+ic*ndual]=1;
		Sc[ic++]=.5*(LL[i]+UU[i]);
//		SA[i+ic*ndual]=0;
		Sc[ic++]=.5*(UU[i]-LL[i]);
	}
	for(i=0;i<m;++i)
	{
		dcopyvec(n,A+i*n,&SA[ic*ndual]);
		id=0;
		if(iid.size())
			id=&(iid.front());
		for(j=0,k=n;j<n;++j)
		{
			if(id&&*id==j)
			{
				SA[ic*ndual+k]=A[i*n+j];
				k++;
				id++;
			}
		}
		Sc[ic++]=.5*(L[i+n]+U[i+n]);
//		SA[i+ic*ndual]=0;
		Sc[ic++]=.5*(U[i+n]-L[i+n]);
	}
/*	for(i=0;i<mextra;++i)
	{
		printf((char*)"Extra %d L %12.3e U %12.3e",i,Lls[i],Uls[i]);
		for(j=0;j<ndual;++j)
		{
			printf((char*)"%12.3e ",Als[i*ndual+j]);
		}
		printf((char*)"\n");
	}*/
	for(i=0;i<mextra;++i)
	{
		dcopyvec(ndual,&Als[i*ndual],&SA[ic*ndual]);
		if(Lls[i]==-1e4)
		{
			Sc[ic++]=0;
		}
		else
		{
			Sc[ic++]=.5*(Lls[i]+Uls[i]);
			//		SA[i+ic*ndual]=0;
			Sc[ic++]=.5*(Uls[i]-Lls[i]);
		}
	}
	if(TopRisk>0)
	{
		dcopyvec(ndual*n,&RQ[0],&SA[ic*ndual]);
		if(bench)dcopyvec(n,&rbench[0],&Sc[ic]);
		ic+=n;
		Sc[ic++]=TopRisk;
	}
	if(MaxDalpha>0)
	{
		id=0;
		if(iid.size())
			id=&(iid.front());
		for(i=0,j=n;i<n;++i)
		{
			SA[ic*ndual+i]=dalpha[i];
			if(id&&i==*id)
			{
				SA[ic*ndual+j]=dalpha[i];
				j++;
				id++;
			}
			if(initial)Sc[ic]=dalpha[i]*initial[i];
			ic++;
		}
		Sc[ic++]=MaxDalpha;
	}
	/*	for(i=0;i<nn;++i)
	{
		printf((char*)"b %12.3e C %d ",Sc[i],i);
		for(j=0;j<ndual;++j)
		{
			printf((char*)"%12.3e ",SA[i*ndual+j]);
		}
		printf((char*)"\n");
	}*/
	dmx_transpose(ndual,nn,&SA[0],&SA[0]);
	if(m>1)dmx_transpose(n,m,A,A);//Change it back
	Sb.resize(ndual);
	id=0;
	if(iid.size())
		id=&(iid.front());
	for(i=0,j=n;i<n;++i)
	{
		Sb[i]=alpha[i];
		if(id&&*id==i)
		{
			Sb[j]=alpha[i];
			j++;
			id++;
		}
	}
	Sx.resize(nn);
	Sy.resize(ndual);
	Ss.resize(nn);
	bool bad=0;
	short back;
	double checktol=100000*lm_eps;
	if(!(back=SOCPinfeasHomogt(ncone,ndual,&CONES[0],&Sc[0],&SA[0],&Sb[0],&Sx[0],&Sy[0],
		&Ss[0],&tau,&kappa,100,1e-8,.5)))
	{
		if(tau>kappa)
		{
			id=0;
			if(iid.size())
				id=&(iid.front());
			{
				if(id&&i==*id)
				{
					w[i]=(Sy[i]+Sy[j])/ tau;
					if(fabs(Sy[i]*Sy[j]/tau/tau)>checktol)bad=true;
					id++;j++;
				}
				else
					w[i]=Sy[i]/ tau;
			}
			back+=(short)bad;
		}
		else
		{
			double tt;
			if((tt=ddotvec(ndual,&Sb[0],&Sy[0]))>0)
				printf((char*)"b dot y %20.12e primal is infeasible\n",tt);
			if((tt=ddotvec(nn,&Sc[0],&Sx[0]))<0)
				printf((char*)"c dot x %20.12e dual is infeasible\n",tt);
			back=2;
		}
	}
	else
	{
		printf((char*)"SOCP failed\n");back = 3;
	}
	

	if(bad)printf((char*)"The long short value condition was not met correctly\n");
	return back;
}

char* SOCPlstestMessages[]=
{
	(char*)"Optimal solution found",
	(char*)"Extra constraints for long short and/or buy sell failed",
	(char*)"Infeasible primal or dual problem",
	(char*)"SOCP failed to converge or min step length is too large",
	(char*)"No free variables to optimise"
};

extern "C" DLLEXPORT void DroppingOut(size_t N,size_t n,vector Q,vector initial,double *modVar,
									  vector centre_shift,vector w=0)
{
/*
				w=(w' 0)
				wi=(wi' i)
				Q=(Q'  QI
				   IQ  II)

				(w-wi)Q(w-wi)


				=  (w'-wi').Q'(w'-wi') - 2(w'-wi').C  + wi.Q.wi
				where C=Q.(0
						   i)

				then this can all be written

				||R(w'-wi' - centre_shift)||**2 - C.centre_shift + wi.Q.wi

				where centre_shift = Q-1.C and R'R=Q
*/
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	std::valarray<double> zi(N*2),A(n*(n+1)/2);
	std::valarray<short_scl> P(n);
	dcopyvec(N-n,initial+n,&zi[n]);
	if(w)dsubvec(N-n,&zi[n],w+n,&zi[n]);
	dzerovec(n,&zi[0]);//initial with first n entries zeroed out
	dsmxmulv(N,Q,&zi[0],&zi[N]);//the first n in &zi[N] are the "implied alphas for the drop"
	*modVar=ddotvec(N,&zi[N],&zi[0]);//add variance of end of initial
	dcopyvec(N,&zi[N],&zi[0]);
	dcopyvec(n*(n+1)/2,Q,&A[0]);
	dsmxfac(n,&A[0],&P[0]);
	dsmxainv(n,&A[0],&P[0],&zi[N]);//the implied shift in centre due to the drop
	dcopyvec(n,&zi[N],centre_shift);
	dzerovec(N-n,centre_shift+n);
	*modVar-=ddotvec(n,&zi[0],&zi[N]);//subtract the variance of the "centre portfolio"
}
#define equalboundslim lm_10minus14
inline short Pythag(double& c,double a,double b,bool plus=true)
{
	short back=0;
	if(plus)c=sqrt(a*a+b);
	else
	{
		if(a*a<b)back=6;
		c=sqrt(a*a-b);
	}
	return back;
}
int RePositionFixed(size_t n,size_t m,size_t nabs,vector w,vector L,vector U,
								vector A,vector initialM,vector initialS,vector Q,
								vector benchmark,vector alpha,vector Aabs,vector M,
								vector S,double& maxRisk,double& maxM,double& maxS,size_t fixed_bounds,
								size_t& Nvab,double& modVarM,double& modVarS,double& modVarB,
								vector centre_shiftI,vector centre_shiftB,size_t* neworder,
								bool forward=true)
{
	int back=0;
	size_t i;
	if(forward)
	{
		modVarM=0;modVarS=0;modVarB=0;
		for(i=0;i<n;++i)
		{
			neworder[i]=i;
		}
		long sofar;
		Nvab=n-fixed_bounds;
		double testcon;
		sofar = n-1;
		for(i = 0;sofar>=(long)i;++i)
		{
			while(sofar>=0&&fabs(L[neworder[sofar]] - U[neworder[sofar]]) < equalboundslim){sofar--;}
			if(sofar > (long)i && fabs(L[neworder[i]] - U[neworder[i]]) < equalboundslim)
			{
				std::swap(neworder[i],neworder[sofar]);
			}
		}
		Reorder_gen(n,neworder,w,1);
		Reorder_gen(n,neworder,L,1);
		Reorder_gen(n,neworder,U,1);
		Reorder_gen(n,neworder,benchmark,1);
		Reorder_gen(n,neworder,initialS,1);
		Reorder_gen(n,neworder,initialM,1);
		Reorder_gen(n,neworder,alpha,1);
		Reorder_gen(n,neworder,A,m);
		Reorder_gen(n,neworder,Aabs,nabs);
		Reorder_gen(n,neworder,M,1);
		ReorderS(n,neworder,Q);
		ReorderS(n,neworder,S);
		dcopyvec(fixed_bounds,L+Nvab,w+Nvab);
		for(i=0;i<m;++i)//We have to check that fixed stocks don't violate linear constraints
		{
			if(BITA_ddot(Nvab,A+i,m,A+i,m) <lm_eps)//This is zero if only the fixed stocks are in the constraint
			{
				testcon=BITA_ddot(n-Nvab,&A[i+Nvab*m],m,&w[Nvab],1);
				if(testcon<L[n+i] || testcon>U[n+i])
					back=6;
			}
		}
		bound_reorganise(1,n,Nvab,m,L);
		bound_reorganise(1,n,Nvab,m,U);
		for(i = Nvab;i < n;++i)
		{
			daxpyvec(m,-w[i],A+i * m,L+Nvab);
			daxpyvec(m,-w[i],A+i * m,U+Nvab);
		}
		if(maxM>0)
		{
			double pp=maxM;
			for(i=Nvab,modVarM=0;i<n;++i) modVarM+=M[i]*M[i]*(initialM[i]-w[i])*(initialM[i]-w[i]);
			back=max(back,Pythag(maxM,pp,modVarM,false));
		}
		if(maxS>0)
		{
			double pp=maxS;
			DroppingOut(n,Nvab,S,initialS,&modVarS,centre_shiftI,w);
			back=max(back,Pythag(maxS,pp,modVarS,false));
			daddvec(Nvab,initialS,centre_shiftI,initialS);
		}
		if(maxRisk>0)
		{
			double pp=maxRisk;
			DroppingOut(n,Nvab,Q,benchmark,&modVarB,centre_shiftB,w);
			back=max(back,Pythag(maxRisk,pp,modVarB,false));
			daddvec(Nvab,benchmark,centre_shiftB,benchmark);
		}
	}
	else
	{
		if(maxM>0)
		{
			double pp=maxM;
			Pythag(maxM,pp,modVarM);
		}
		if(maxS>0)
		{
			double pp=maxS;
			Pythag(maxS,pp,modVarS);
			dsubvec(Nvab,initialS,centre_shiftI,initialS);
		}
		if(maxRisk>0)
		{
			double pp=maxRisk;
			Pythag(maxRisk,pp,modVarB);
			dsubvec(Nvab,benchmark,centre_shiftB,benchmark);
		}
		for(i = Nvab;i < n;++i)
		{
			daxpyvec(m,w[i],A+i * m,L+Nvab);
			daxpyvec(m,w[i],A+i * m,U+Nvab);
		}
		bound_reorganise(0,n,Nvab,m,L);
		bound_reorganise(0,n,Nvab,m,U);
		Reorder_gen(n,neworder,w,1);
		Reorder_gen(n,neworder,L,1);
		Reorder_gen(n,neworder,U,1);
		Reorder_gen(n,neworder,benchmark,1);
		Reorder_gen(n,neworder,initialS,1);
		Reorder_gen(n,neworder,initialM,1);
		Reorder_gen(n,neworder,alpha,1);
		Reorder_gen(n,neworder,A,m);
		Reorder_gen(n,neworder,Aabs,nabs);
		Reorder_gen(n,neworder,M,1);
		ReorderS(n,neworder,Q);
		ReorderS(n,neworder,S);
	}
	
	return back;
}

short SOCPlsRobust1(size_t n,size_t m,vector w,vector A,
										long nf,vector SV,vector FL,vector FC,
										vector alpha,int full,double rmin,double rmax,
										vector L,vector U,double val,double TopRisk,
										vector dalpha,double MaxDalpha,vector covalpha,double MaxValpha,
										size_t nabs,vector Aabs,vector Labs,
										vector Uabs,vector bench,vector initialm,vector initials,int signtest,
										double ratmzero,double ratMzero,int maxrobust=1,char*SOCPdump=0)
{
	//SOCPdump will hold the inputs to SOCPinfeaseHomogt
	if(MaxDalpha<0)maxrobust=0;//Ready for when we want to use it
/*		
	Robust Optimisation version 1.
	Maximise alpha.w subject to
	Li<=wi<=Ui
	Li+n<=(A.w)i<=Ui+n
	sqrt((w-bench)'.Q.(w-bench)) <= TopRisk
	sqrt(sum((w-initialm)i.dalphai.dalphai.(w-initialm)i)) <= MaxDalpha
	sqrt((w-initials)'.covalpha.(w-initials)) <= MaxValpha

	and also if val is not zero attempt the specialised long-short constraints
	sum(wi)<=val only if wi>0 (=val if full is 1)
	(sum(abs(wi)) <= val if full is 2)
	sum(wi short)/sum(wi long) <= rmax if rmax>0
	sum(wi short)/sum(wi long) >= rmin if rmin>0

	There is no mechanism here to guarantee to get these extra constraints to work by adding
	non-convex terms to the utility.
	If maxrobust is 1 and MaxDalpha>=0
	then solve

	Maximise alpha.w - sqrt(sum((w-initialm)i.dalphai.dalphai.(w-initialm)i) subject to

	Li<=wi<=Ui
	Li+n<=(A.w)i<=Ui+n
	sqrt((w-bench)'.Q.(w-bench)) <= TopRisk
	sqrt((w-initials)'.covalpha.(w-initials)) <= MaxValpha

	and also if val is not zero attempt the specialised long-short constraints
	sum(wi)<=val only if wi>0 (=val if full is 1)
	(sum(abs(wi)) <= val if full is 2)
	sum(wi short)/sum(wi long) <= rmax if rmax>0
	sum(wi short)/sum(wi long) >= rmin if rmin>0
*/
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	Optimise O;
	if(!O.licenced)return -1;
	std::valarray<double>pQ;
	vector Q=0,pA,ppA;
	if(nf>-1 && TopRisk>0)
	{
		pQ.resize(n*(n+1)/2);
		Q=&pQ[0];
		Factor2Cov(n,nf,FC,FL,SV,Q);
	}
	else if(TopRisk>0)Q=FC;	//Input covariances in FC for non-factor model
	size_t i,j,fixed_bounds=0;
	for(i=0;i<n;++i){if(fabs(U[i]-L[i])<equalboundslim)fixed_bounds++;}
	if(fixed_bounds)
	{
		std::valarray<double>centreI(n),centreB(n);
		std::valarray<size_t>neworder(n);
		double ratMzero=0,ratmzero=0;
		size_t Nvab;
		double modVarM,modVarS,modVarB;
		int back=RePositionFixed(n,m,nabs,w,L,U,A,initialm,initials,Q,bench,alpha,Aabs,dalpha,
			covalpha,TopRisk,MaxDalpha,MaxValpha,fixed_bounds,Nvab,modVarM,modVarS,modVarB,
			&centreI[0],&centreB[0],&neworder[0]);
		for(i=Nvab;i<n;++i)
		{
			if(val!=0)val-=fabs(w[i]);
			for(j=0;j<nabs;++j)
			{
				if(Labs)Labs[j]-=fabs(w[i])*Aabs[i*nabs+j];
				Uabs[j]-=fabs(w[i])*Aabs[i*nabs+j];
			}
			ratMzero-=(w[i]>0?-rmax*w[i]:-w[i]);
			ratmzero-=(w[i]>0?rmin*w[i]:w[i]);
		}
		if(back!=6)
		back=SOCPlsRobust1(Nvab,m,w,A,-1,0,0,Q,alpha,full,rmin,rmax,L,U,val,TopRisk,dalpha,MaxDalpha,
			covalpha,MaxValpha,nabs,Aabs,Labs,Uabs,bench,initialm,initials,signtest,ratmzero,ratMzero,
			maxrobust,SOCPdump);
		std::valarray<size_t> inverse(n);
		for(i=0;i<n;++i){inverse[neworder[i]]=i;}
		for(i=Nvab;i<n;++i)
		{
			if(val!=0)val+=fabs(w[i]);
			for(j=0;j<nabs;++j)
			{
				if(Labs)Labs[j]+=fabs(w[i])*Aabs[i*nabs+j];
				Uabs[j]+=fabs(w[i])*Aabs[i*nabs+j];
			}
			ratMzero+=(w[i]>0?-rmax*w[i]:-w[i]);
			ratmzero+=(w[i]>0?rmin*w[i]:w[i]);
		}
		RePositionFixed(n,m,nabs,w,L,U,A,initialm,initials,Q,bench,alpha,Aabs,dalpha,
			covalpha,TopRisk,MaxDalpha,MaxValpha,fixed_bounds,Nvab,modVarM,modVarS,modVarB,
			&centreI[0],&centreB[0],&inverse[0],false);
		return back;
	}
	std::vector<size_t> iid;
	size_t*id,nextra,mextra=(val==0?0:1);
	if(rmin>=-lm_eps)mextra++;
	if(rmax>=-lm_eps&&rmin!=rmax)mextra++;
	mextra+=nabs;
	size_t k;
	for(i=0;i<n;++i)
	{
		if(L[i]<0&&U[i]>0)
			iid.push_back(i);
	}
	id=0;
	nextra=iid.size();
	if(nextra)
		id=&(iid.front());
	std::valarray<double>LL(n+nextra),UU(n+nextra),//WW(n+nextra),
		Als(mextra*(n+nextra)),Lls(mextra),Uls(mextra);
	size_t mmextra;
	Als=0;
	if(nabs>1)dmx_transpose(nabs,n,Aabs,Aabs);
	for(i=0,j=n;i<n;++i)
	{
		mmextra=0;
		if(id&&i == *id)
		{
			LL[i]=L[i];
			UU[i]=0;
			LL[j]=0;
			UU[j]=U[i];
			if(mextra)
			{
				if(val!=0)
				{
					Als[i+mmextra*(n+nextra)]=0;
					Als[j+mmextra*(n+nextra)]=1;
					mmextra++;
				}
				if(rmin>=-lm_eps)
				{
					Als[i+mmextra*(n+nextra)]=1;
					Als[j+mmextra*(n+nextra)]=rmin;
					mmextra++;
					if(rmax>=-lm_eps&&rmin!=rmax)
					{
						Als[i+mmextra*(n+nextra)]=-1;
						Als[j+mmextra*(n+nextra)]=-rmax;
						mmextra++;
					}
				}
				else if(rmax>=-lm_eps)
				{
					Als[i+mmextra*(n+nextra)]=-1;
					Als[j+mmextra*(n+nextra)]=-rmax;
					mmextra++;
				}
				if(nabs)
				{
					vector pabs;
					for(k=0,pabs=Aabs;k<nabs;++k,pabs+=n)
					{
						Als[i+mmextra*(n+nextra)]=-*(pabs+i);
						Als[j+mmextra*(n+nextra)]=*(pabs+i);
						mmextra++;
					}
				}
			}
			j++;
			id++;
		}
		else
		{
			LL[i]=L[i];
			UU[i]=U[i];
			if(mextra)
			{
				if(val!=0)
				{
					if(L[i]<0)
					{
						Als[i+mmextra*(n+nextra)]=0;
					}
					else
					{
						Als[i+mmextra*(n+nextra)]=1;
					}
					mmextra++;
				}
				if(rmin>=-lm_eps)
				{
					if(L[i]<0)
					{
						Als[i+mmextra*(n+nextra)]=1;
					}
					else
					{
						Als[i+mmextra*(n+nextra)]=rmin;
					}
					mmextra++;
					if(rmax>=-lm_eps&&rmin!=rmax)
					{
						if(L[i]<0)
						{
							Als[i+mmextra*(n+nextra)]=-1;
						}
						else
						{
							Als[i+mmextra*(n+nextra)]=-rmax;
						}
						mmextra++;
					}
				}
				else if(rmax>=0)
				{
					if(L[i]<0)
					{
						Als[i+mmextra*(n+nextra)]=-1;
					}
					else
					{
						Als[i+mmextra*(n+nextra)]=-rmax;
					}
					mmextra++;
				}
				if(nabs)
				{
					vector pabs;
					for(k=0,pabs=Aabs+i;k<nabs;++k,pabs+=n)
					{
						Als[i+mmextra*(n+nextra)]=(L[i]<0?-*pabs:*pabs);
						mmextra++;
					}					
				}
			}
		}
	}
	if(nabs>1)dmx_transpose(n,nabs,Aabs,Aabs);
	mmextra=0;
	if(mextra)
	{
		if(val!=0)
		{
			Lls[mmextra]=(full==1)?val:0;
			Uls[mmextra++]=val;
		}
		if(rmin>=-lm_eps)
		{
			Lls[mmextra]=(rmin==rmax)?0:-1e4+ratmzero;
			Uls[mmextra++]=ratmzero;
			if(rmax>0&&rmax!=rmin)
			{
				Lls[mmextra]=-1e4+ratMzero;
				Uls[mmextra++]=ratMzero;
			}
		}
		else if(rmax>=-lm_eps)
		{
			Lls[mmextra]=-1e4+ratMzero;
			Uls[mmextra++]=ratMzero;
		}
		if(nabs)
		{
			for(k=0;k<nabs;++k)
			{
				Lls[mmextra]=(Labs?Labs[k]:0);
				Uls[mmextra++]=Uabs[k];
			}
		}
	}

	size_t bad_a=0;
	for(i=0;i<m;++i)
	{
		if(BITA_ddot(n,A+i,m,A+i,m)<=lm_eps)
		{
			bad_a++;
			fprintf(stderr,(char*)"Linear constraint %d is NULL\n",i+1);
		}
	}
	if(m>1)dmx_transpose(m,n,A,A);
	std::valarray<double>RQ;
	std::valarray<double>RcovA;
	std::valarray<double> rbench;
	std::valarray<double> rinit;
	if(TopRisk>0)
	{
		RQ.resize((n+nextra)*n);
		RootQ(n,Q,&RQ[0],0);
		rbench.resize(n);
		if(bench)
		{
			dmxtmulv(n,n,&RQ[0],bench,&rbench[0]);
		}
		if(nextra)ProcessRQ(n,nextra,&(iid.front()),&RQ[0]);
	}
	if(MaxValpha>0)
	{
		RcovA.resize((n+nextra)*n);
		RootQ(n,covalpha,&RcovA[0],0);
		rinit.resize(n);
		if(initials)
		{
			dmxtmulv(n,n,&RcovA[0],initials,&rinit[0]);
		}
		if(nextra)ProcessRQ(n,nextra,&(iid.front()),&RcovA[0]);
	}

	/*
	n+nextra+m  linear constraints		n+nextra+m  2-d cones
	mextra linear constraints			mextra 1- or 2-d cones
	2   quadratic constraints			2 n+1-d cones
	*/
	std::valarray<int> CONES;
	std::valarray<double> SA,Sc,Sb,Sx,Sy,Ss;
	size_t ncone,ndual=n+nextra+maxrobust,nn;
	double tau,kappa;
	ncone=n+nextra+m-bad_a+mextra;
	if(TopRisk>0)ncone++;
	if(MaxDalpha>0)ncone++;
	if(MaxValpha>0)ncone++;
	CONES.resize(ncone);
	for(i=0,nn=0;i<n+nextra+m-bad_a;++i)
	{
		nn+=CONES[i]=2;
	}
	for(i=0;i<mextra;++i)
	{
		if(Lls[i]==-1e4)
			nn+=CONES[n+nextra+m-bad_a+i]=1;//-S/L ratio
		else
			nn+=CONES[n+nextra+m-bad_a+i]=2;//Cover constraint or equality -S/L constraint
	}
	size_t q_xon=0;
	if(TopRisk>0)
		nn+=CONES[n+nextra+m-bad_a+mextra+q_xon++]=n+1;
	if(MaxDalpha>0)
		nn+=CONES[n+nextra+m-bad_a+mextra+q_xon++]=n+1;
	if(MaxValpha>0)
		nn+=CONES[n+nextra+m-bad_a+mextra+q_xon++]=n+1;
	SA.resize(nn*ndual);
	Sc.resize(nn);
	SA=0;
	Sc=0;
	size_t ic;
	for(i=0,ic=0;i<n+nextra;++i)
	{
		SA[i+ic*ndual]=1;
		Sc[ic++]=.5*(LL[i]+UU[i]);
//		SA[i+ic*ndual]=0;
		Sc[ic++]=.5*(UU[i]-LL[i]);
	}
	for(i=0,pA=A;i<m;++i,pA+=n)
	{
		if(ddotvec(n,pA,pA)>lm_eps)
		{
			dcopyvec(n,pA,&SA[ic*ndual]);
			id=0;
			if(iid.size())
				id=&(iid.front());
			for(j=0,ppA=pA,k=n;j<n;++j,ppA++)
			{
				if(id&&*id==j)
				{
					SA[ic*ndual+k]=*ppA;
					k++;
					id++;
				}
			}
			Sc[ic++]=.5*(L[i+n]+U[i+n]);
			//		SA[i+ic*ndual]=0;
			Sc[ic++]=.5*(U[i+n]-L[i+n]);
		}
		else if(L[i+n]>0||U[i+n]<0)
		{
			fprintf(stderr,(char*)"NULL constraint %d has infeasible bounds %f %f\n",i+1,L[i+n],U[i+n]);
			return 6;
		}
	}
	for(i=0;i<mextra;++i)
	{
		dcopyvec(ndual-maxrobust,&Als[i*(ndual-maxrobust)],&SA[ic*ndual]);
		if(Lls[i]==-1e4)
		{
			Sc[ic++]=0;
		}
		else
		{
			Sc[ic++]=.5*(Lls[i]+Uls[i]);
			//		SA[i+ic*ndual]=0;
			Sc[ic++]=.5*(Uls[i]-Lls[i]);
		}
	}
	if(TopRisk>0)
	{
		for(i=0;i<n;++i)dcopyvec((ndual-maxrobust),&RQ[i*(ndual-maxrobust)],&SA[(ic+i)*ndual]);
		if(bench)dcopyvec(n,&rbench[0],&Sc[ic]);
		ic+=n;
		Sc[ic++]=TopRisk;
	}
	if(MaxValpha>0)
	{
		for(i=0;i<n;++i)dcopyvec((ndual-maxrobust),&RcovA[i*(ndual-maxrobust)],&SA[(ic+i)*ndual]);
		if(initials)dcopyvec(n,&rinit[0],&Sc[ic]);
		ic+=n;
		Sc[ic++]=MaxValpha;
	}
	if(MaxDalpha>0)
	{
		id=0;
		if(iid.size())
			id=&(iid.front());
		for(i=0,j=n;i<n;++i)
		{
			SA[ic*ndual+i]=dalpha[i];
			if(id&&i==*id)
			{
				SA[ic*ndual+j]=dalpha[i];
				j++;
				id++;
			}
			if(initialm)Sc[ic]=dalpha[i]*initialm[i];
			ic++;
		}
		if(maxrobust)
		{
			id=0;
			if(iid.size())
				id=&(iid.front());
			for(i=0,j=n;i<n;++i)
			{
				SA[ic*ndual+i]=-alpha[i];
				if(id&&i==*id)
				{
					SA[ic*ndual+j]=-alpha[i];
					j++;
					id++;
				}
			}
			SA[ic++*ndual+ndual-1]=1;
		}
		else
			Sc[ic++]=MaxDalpha;
	}
	dmx_transpose(ndual,nn,&SA[0],&SA[0]);
	if(m>1)dmx_transpose(n,m,A,A);//Change it back
	Sb.resize(ndual);
	id=0;
	if(iid.size())
		id=&(iid.front());
	for(i=0,j=n;i<n;++i)
	{
		Sb[i]=(maxrobust?0:alpha[i]);
		if(id&&*id==i)
		{
			Sb[j]=(maxrobust?0:alpha[i]);
			j++;
			id++;
		}
	}
	if(maxrobust) Sb[ndual-1]=1;
	Sx.resize(nn);
	Sy.resize(ndual);
	Ss.resize(nn);
	bool bad=0;
	short back;
	double checktol=100000*lm_eps;
	double rhoconv=std::pow(lm_eps,.45);
	RQ.resize(0);
	RcovA.resize(0);
	pQ.resize(0);
	LL.resize(0);
	UU.resize(0);
	Als.resize(0);
	Lls.resize(0);
	Uls.resize(0);
	double changeratio=4;
	int log=0;
	char* logfile=0;
	if(!(back=SOCPinfeasHomogt(ncone,ndual,&CONES[0],&Sc[0],&SA[0],&Sb[0],&Sx[0],&Sy[0],
		&Ss[0],&tau,&kappa,100,1e-8,.5,1e-8,1e-8,signtest,changeratio,rhoconv,log,logfile,SOCPdump)))
	{
		if(tau>kappa||(signtest && tau>lm_rooteps))
		{
			checktol *= (tau*tau);
			id=0;
			if(iid.size())
				id=&(iid.front());
			for(i=0,j=n;i<n;++i)
			{
				if(id&&i==*id)
				{
					w[i]=(Sy[i]+Sy[j])/ tau;
					if(fabs(Sy[i]*Sy[j])>checktol)bad=true;
					id++;j++;
				}
				else
					w[i]=Sy[i]/ tau;
			}
			back+=(short)bad;
			if(signtest&&!back)back=1;
			if(0)
			{
				printf((char*)"%5s %20s %20s\t%20s %20s\n",(char*)"Cone",(char*)"X top",(char*)"S top",(char*)"X inequality",(char*)"S inequality");
				for(i=0,j=0;i<ncone;++i)
				{
					j+=CONES[i];
					printf((char*)"%5u %20.8e %20.8e\t%20.8e %20.8e\n",i+1,Sx[j-1]/tau,Ss[j-1]/tau,
						(Sx[j-1]-sqrt(ddotvec(CONES[i]-1,&Sx[j-CONES[i]],&Sx[j-CONES[i]])))/tau,
						(Ss[j-1]-sqrt(ddotvec(CONES[i]-1,&Ss[j-CONES[i]],&Ss[j-CONES[i]])))/tau);
				}
			}
		}
		else
		{
			double tt;
			if((tt=ddotvec(ndual,&Sb[0],&Sy[0]))>0)
				printf((char*)"b dot y %20.12e primal is infeasible\n",tt);
			if((tt=ddotvec(nn,&Sc[0],&Sx[0]))<0)
				printf((char*)"c dot x %20.12e dual is infeasible\n",tt);
			back=2;
		}
	}
	else
	{
		printf((char*)"SOCP failed\n");back = 3;
	}
	

	//if(bad)printf((char*)"The long short value condition was not met correctly this time\n");
	return back;
}

extern "C" DLLEXPORT char*	SOCPlstestMessage(int ifail)
{
	if(ifail<5)return SOCPlstestMessages[ifail];
	else return (char*)"Only 5 messages";
}
extern "C" DLLEXPORT short SOCPRobust(size_t n,size_t m,vector w,vector A,vector L,vector U,
									  long nf,vector SV,vector FL,vector FC,vector alpha,
									  vector meanFE,vector covFE,double maxmeanFE,
									  double maxstderrorFE,double gamma,double maxRisk,
									  vector bench,vector initial,int mFE,int rFE,vector sectors)
{
#ifdef PAS
//	UnlockBita((char*)"colincolin");
	if(!Optimise::bitago)
	{
		fprintf(stderr,(char*)"Bad PAS key\n");
		return -1;
	}
	return -1;
#endif
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	std::valarray<size_t>order;
	size_t i,nsect=0;
	if(sectors)
	{
		double csct=-1;
		order.resize(2*n);
		getorder(n,sectors,&order[0],0);
		Reorder(n,&order[0],sectors);
		Reorder_gen(n,&order[0],A,m);
		Reorder(n,&order[0],L);
		Reorder(n,&order[0],U);
		Reorder(n,&order[0],alpha);
		Reorder(n,&order[0],meanFE);
		if(bench)Reorder(n,&order[0],bench);
		if(initial)Reorder(n,&order[0],initial);
		ReorderS(n,&order[0],covFE);
		if(nf!=-1)
		{
			Reorder(n,&order[0],SV);
			for(i=0;i<(size_t)nf;++i)
				Reorder(n,&order[0],FL+n*i);
		}
		else
		{
			ReorderS(n,&order[0],FC);
		}
		for(i=0;i<n;++i)
		{
			order[n+order[i]]=i;
			if(csct!=sectors[i])
			{
				csct=sectors[i];
				nsect++;
			}
		}
	}
	/*
	We set this optimisation up using the dual of the SOCP. The constraints here
	written in Boyd's notation are;
	max a.x st || b - Ax || < d - cx ***
	rather than the problem he solves which has
	min a.x st || b + Ax || < d + cx

	E.g. to set the risk constraint (x-x')C(x-x') < r*r
	b=Rx' A=R d=r where RTR=C
	*/
	Optimise O;
	if(!O.licenced)return -1;
	short back=0;
	size_t ndual;
	std::valarray<double>pQ;
	vector Q;
	if(nf>-1)
	{
		pQ.resize(n*(n+1)/2);
		Q=&pQ[0];
		Factor2Cov(n,nf,FC,FL,SV,Q);
	}
	else Q=FC;	//Input covariances in FC for non-factor model
	std::valarray<double> pRQ,pRcov(n*n);
	RootQ(n,covFE,&pRcov[0],0);
	vector rQ=0,rQm1=0;
	size_t ncone,nn=0;
	std::valarray<int> CONES;
	std::valarray<double> SA,Sc,Sb,Sx,Sy,Ss;
	if(maxRisk<0)//Utility is BITA utility
	{
		pRQ.resize(2*n*n);
		rQ=&pRQ[0];
		rQm1=rQ+n*n;
		RootQ(n,Q,rQ,rQm1);//rQm1 is transpose inverse rQ
		std::valarray<double> rbench,rinitial;
		if(bench)rbench.resize(2*n);
		else rbench.resize(n);
		dmxtmulv(n,n,rQm1,alpha,&rbench[0]);
		dscalvec(n,gamma/(1-gamma),&rbench[0]);
		if(bench)
		{
			dmxtmulv(n,n,rQ,bench,&rbench[n]);
			daddvec(n,&rbench[n],&rbench[0],&rbench[0]);
		}
		if(initial)
		{
			rinitial.resize(n);
			dmxtmulv(n,n,&pRcov[0],initial,&rinitial[0]);
		}
		/*
		Maximise -wn
		subject to
		Li<=wi<=Ui							0<=i<n
		Li+n<=(Aw)i<=Ui+n					0<=i<m
***		sqrt(-gamma/(1-gamma)alpha.w+0.5*(w-bench).Q.(w-bench))	<= 0-wn
		sqrt((w-initial).meanFE.meanFE.(w-initial))		<=maxmeanFE
		sqrt((w-initial).covFE.(w-initial))				<=maxstderrorFE
		We need n+m 2d cones and 3 (ndual+1)d cones
		*/
		ndual=n+1;
		ncone=n+m+3;
		if(maxmeanFE<0)
			ncone--;
		if(maxstderrorFE<0)
			ncone--;
		CONES.resize(ncone);
		for(i=0;i<n+m;++i)
		{
			nn+=CONES[i]=2;
		}
		for(i=n+m;i<ncone;++i)
		{
			nn+=CONES[i]=n+1;
		}
		SA.resize(nn*ndual);
		Sc.resize(nn);
		SA=0;Sc=0;
		if(m>1)dmx_transpose(m,n,A,A);
		size_t ic;
		for(i=0,ic=0;i<n;++i)
		{
			SA[i+ic*ndual]=1;
			Sc[ic++]=.5*(L[i]+U[i]);
			//		SA[i+ic*ndual]=0;
			Sc[ic++]=.5*(U[i]-L[i]);
		}
		for(i=0;i<m;++i)
		{
			dcopyvec(n,A+i*n,&SA[ic*ndual]);
			Sc[ic++]=.5*(L[i+n]+U[i+n]);
			//		SA[i+ic*ndual]=0;
			Sc[ic++]=.5*(U[i+n]-L[i+n]);
		}
		if(m>1)dmx_transpose(n,m,A,A);
		if(bench)dcopyvec(n,&rbench[0],&Sc[ic]);
		for(i=0;i<n;++i)
		{
			dcopyvec(n,rQ+i*n,&SA[ic*ndual]);
			ic+=1;
		}
		SA[ic*ndual+n]=-1;//- the last variable
		Sc[ic++]=0;
		
		if(maxstderrorFE>=0)
		{
			for(i=0;i<n;++i)
			{
				dcopyvec(n,&pRcov[i*n],&SA[ic*ndual]);
				if(initial&&rFE)Sc[ic]=rinitial[i];
				ic++;
			}
			Sc[ic++]=maxstderrorFE;
		}
		if(maxmeanFE>=0)
		{
			for(i=0;i<n;++i)
			{
				SA[ic*ndual+i]=meanFE[i];
				if(initial&&mFE)Sc[ic]=meanFE[i]*initial[i];
				ic++;
			}
			Sc[ic++]=maxmeanFE;
		}
		dmx_transpose(ndual,nn,&SA[0],&SA[0]);
		Sb.resize(ndual);
		Sb=0;
		Sb[n]=-1;//-1 is the coef of last variable in b since we want to minimise (maximise -wn)
		Sx.resize(nn);
		Sy.resize(ndual);
		Ss.resize(nn);
	}
	else		//Utility is return
	{
		pRQ.resize(n*n);
		rQ=&pRQ[0];
		RootQ(n,Q,rQ,rQm1);
		std::valarray<double> rbench,rinitial;
		if(bench)
		{
			rbench.resize(n);
			dmxtmulv(n,n,rQ,bench,&rbench[0]);
		}
		if(initial)
		{
			rinitial.resize(n);
			dmxtmulv(n,n,&pRcov[0],initial,&rinitial[0]);
		}
		/*
		Maximise alpha.w
		subject to
		Li<=wi<=Ui							0<=i<n
		Li+n<=(Aw)i<=Ui+n					0<=i<m
		sqrt((w-bench).Q.(w-bench))	<=maxRisk
		sqrt((w-initial).meanFE.meanFE.(w-initial))		<=maxmeanFE
		sqrt((w-initial).covFE.(w-initial))				<=maxstderrorFE
		We need n+m 2d cones and 3 (n+1)d cones
		*/
		ncone=n+m+3;
		if(maxmeanFE<0)
			ncone--;
		if(maxstderrorFE<0)
			ncone--;
		CONES.resize(ncone);
		for(i=0;i<n+m;++i)
		{
			nn+=CONES[i]=2;
		}
		for(i=n+m;i<ncone;++i)
		{
			nn+=CONES[i]=n+1;
		}
		SA.resize(nn*n);
		Sc.resize(nn);
		SA=0;Sc=0;
		if(m>1)dmx_transpose(m,n,A,A);
		size_t ic;
		for(i=0,ic=0;i<n;++i)
		{
			SA[i+ic*n]=1;
			Sc[ic++]=.5*(L[i]+U[i]);
			//		SA[i+ic*ndual]=0;
			Sc[ic++]=.5*(U[i]-L[i]);
		}
		for(i=0;i<m;++i)
		{
			dcopyvec(n,A+i*n,&SA[ic*n]);
			Sc[ic++]=.5*(L[i+n]+U[i+n]);
			//		SA[i+ic*ndual]=0;
			Sc[ic++]=.5*(U[i+n]-L[i+n]);
		}
		if(m>1)dmx_transpose(n,m,A,A);
		dcopyvec(n*n,rQ,&SA[ic*n]);
		if(bench)dcopyvec(n,&rbench[0],&Sc[ic]);
		ic+=n;
		Sc[ic++]=maxRisk;
		
		if(maxstderrorFE>=0)
		{
			dcopyvec(n*n,&pRcov[0],&SA[ic*n]);
			if(initial&&rFE)dcopyvec(n,&rinitial[0],&Sc[ic]);
			ic+=n;
			Sc[ic++]=maxstderrorFE;
		}
		if(maxmeanFE>=0)
		{
			for(i=0;i<n;++i)
			{
				SA[ic*n+i]=meanFE[i];
				if(initial&&mFE)Sc[ic]=meanFE[i]*initial[i];
				ic++;
			}
			Sc[ic++]=maxmeanFE;
		}
		dmx_transpose(n,nn,&SA[0],&SA[0]);
		Sb.resize(n);
		for(i=0;i<n;++i)
		{
			Sb[i]=alpha[i];
		}
		Sx.resize(nn);
		Sy.resize(n);
		Ss.resize(nn);
		ndual=n;	
	}
	pRcov.resize(0);
	pRQ.resize(0);
	double tau,kappa,changeratio=4;
	if(!(back=SOCPinfeasHomogt(ncone,ndual,&CONES[0],&Sc[0],&SA[0],&Sb[0],&Sx[0],&Sy[0],
		&Ss[0],&tau,&kappa,100,1e-8,.5)))
	{
		if(tau>kappa)
		{
			dsccopyvec(n,1./tau,&Sy[0],w);
		}
		else
		{
			double tt;
			if((tt=ddotvec(n,&Sb[0],&Sy[0]))>0)
				printf((char*)"b dot y %20.12e primal is infeasible\n",tt);
			if((tt=ddotvec(nn,&Sc[0],&Sx[0]))<0)
				printf((char*)"c dot x %20.12e dual is infeasible\n",tt);
			back=2;
		}
	}
	else
	{
		printf((char*)"SOCP failed\n");back = 3;
	}
	if(sectors)
	{
		Reorder(n,&order[n],w);
		Reorder(n,&order[n],sectors);
		Reorder_gen(n,&order[n],A,m);
		Reorder(n,&order[n],L);
		Reorder(n,&order[n],U);
		Reorder(n,&order[n],alpha);
		Reorder(n,&order[n],meanFE);
		if(bench)Reorder(n,&order[n],bench);
		if(initial)Reorder(n,&order[n],initial);
		ReorderS(n,&order[n],covFE);
		if(nf!=-1)
		{
			Reorder(n,&order[n],SV);
			for(i=0;i<(size_t)nf;++i)
				Reorder(n,&order[n],FL+n*i);
		}
		else
		{
			ReorderS(n,&order[n],FC);
		}
	}
	return back;
}
short FastCompromise(size_t n,long nfac,vector w,size_t m,vector A,vector L,vector U,
					 vector alpha,vector benchmark,vector Q,int full,double rmin,double rmax,
					 double value,size_t nabs,vector Aabs,vector Labs,vector Uabs,vector FC,vector FL,
					 vector SV,double maxRisk)
{
	int ls;
	double gamma=1,ogamma;
	bool doubleup=false;
	size_t i;
	for(i=0;i<n;++i)
	{
		if(L[i]<=-lm_eps&&U[i]>=lm_eps)
			doubleup=true;
	}
	if(doubleup)
	{
		if(value==0)
		{
			ls=2;
			value=10;
		}
		else
			ls=1;
	}
	else
		ls=0;
	short back=Optimise_internalCVPAFbl(n,nfac,0,w,m,A,L,U,alpha,benchmark,Q,gamma,0,2,0,0,.5,
		-1,-1,0,0,-1,-1,ls,full,rmin,rmax,0,0,0,0,0,0,value,0,0,
		0,nabs,Aabs,0,0,Uabs,FC,FL,SV,0,maxRisk,&ogamma,0,0,0,0,
		0,-1,-1,-1,-1,1,1,1,0,Labs);
	return back;
}
extern "C" DLLEXPORT short SOCPlsRobustl(size_t n,size_t m,vector w,vector A,
										long nf,vector SV,vector FL,vector FC,
										vector alpha,int full,double rmin,double rmax,
										vector L,vector U,double val,double TopRisk,
										vector dalpha,double MaxDalpha,vector covalpha,double MaxValpha,
										size_t nabs,vector Aabs,vector Labs,
										vector Uabs,
										vector bench,vector initialm,vector initials,
										int signtest,int fast=0,int maxrobust=0,char*SOCPdump=0)
{
#ifdef PAS
//	UnlockBita((char*)"colincolin");
	if(!Optimise::bitago)
	{
		fprintf(stderr,(char*)"Bad PAS key\n");
		return -1;
	}
	return -1;
#endif
#ifdef __SYSNT__
	_ASSERT(0);
#endif
/*	//To get a dump of this call
	SOCPlsRobustlDUMP(n,m,w,A,nf,SV,FL,FC,alpha,full,rmin,rmax,L,U,val,TopRisk,dalpha,
		MaxDalpha,covalpha,MaxValpha,nabs,Aabs,Labs,Uabs,bench,initialm,initials,
		signtest,fast,maxrobust,(char*)"s:/robkeep.txt");*/
	bool ls=false,allshort=false,alllong=false;
	std::valarray<double> extrabench,extrainitialm,extrainitials;
	if(!bench)
	{
		extrabench.resize(n);
		extrabench=0;
		bench=&extrabench[0];
	}
	if(!initialm)
	{
		extrainitialm.resize(n);
		extrainitialm=0;
		initialm=&extrainitialm[0];
	}
	if(!initials)
	{
		extrainitials.resize(n);
		extrainitials=0;
		initials=&extrainitials[0];
	}
	int back=0;
	size_t topn=n,i;
	std::valarray<size_t> order;
	std::valarray<double> Q,centre_shiftB,centre_shiftI;
	double modVarM=0,modVarS,modVarB;
	size_t fixed_bounds=0;
	for(i=0;i<n;++i)
	{
		if(fabs(U[i]-L[i])<equalboundslim){fixed_bounds++;}
		else 
		{
			if(L[i]<0){allshort=true;}
			if(U[i]>0){alllong=true;}
		}
	}
	if(allshort&&alllong)
	{
		ls=true;
		alllong=false;
		allshort=false;
	}
	if(!ls) signtest=0;
	if((n-fixed_bounds)>200&&fast)//Change order of things and only optimise the "best" topn variables
	{
		bool finished=true;
		if(nf>-1)back=FastCompromise(n,nf,w,m,A,L,U,alpha,bench,0,full,rmin,rmax,val,nabs,Aabs,Labs,Uabs,FC,FL,SV,TopRisk);
		else back=FastCompromise(n,nf,w,m,A,L,U,alpha,bench,FC,full,rmin,rmax,val,nabs,Aabs,Labs,Uabs,0,0,0,TopRisk);
		if(back>1&&back!=12)return 2;
		back=0;
		if(finished&&MaxDalpha>0)
		{
			for(i=0,modVarM=0;i<n;++i) modVarM+=dalpha[i]*dalpha[i]*(w[i]-initialm[i])*
				(w[i]-initialm[i]);
			if(modVarM>MaxDalpha*MaxDalpha)finished=false;
		}
		if(finished&&MaxValpha>0)
		{
			centre_shiftI.resize(n);
			dsubvec(n,w,initials,w);
			dsmxmulv(n,covalpha,w,&centre_shiftI[0]);
			modVarS=ddotvec(n,w,&centre_shiftI[0]);
			daddvec(n,w,initials,w);
			if(modVarS>MaxValpha*MaxValpha)finished=false;
		}
		if(finished)return 0;
		order.resize(n);
		getorder(n,w,&order[0],0,0);
		Reorder_gen(n,&order[0],w,1);
		for(topn=0;topn<n;++topn){if(dabs(w[topn])<=1e-9)break;}
		printf((char*)"Size of risk constrained result %d\n",topn);
#define INITIAL_WAY
#ifdef ALPHA_WAY
		Reorder_gen(n,&order[0],alpha,1);
		{
			double amn,amx;
			vecminmax(n-topn,alpha+topn,amx,amn);
			std::valarray<size_t> init_order;	//Here we rearrange just the bottom of the list 
			init_order.resize(n);				//using the bottom alphas
			if(ls){getorder(n-topn,alpha+topn,&init_order[topn],0,0.5*(amn+amx));}
			else if(alllong){getorder(n-topn,alpha+topn,&init_order[topn],0,amn);}
			else if(allshort){getorder(n-topn,alpha+topn,&init_order[topn],0,amx);}
			for(i=topn;i<n;++i){init_order[i]+=topn;}
			for(i=0;i<topn;++i){init_order[i]=i;}//Keep the topn the same
			centre_shiftI.resize(n);
			for(i=0;i<n;++i){centre_shiftI[i]=order[i];}
			Reorder_gen(n,&init_order[0],&centre_shiftI[0],1);//Combine orderings
			for(i=0;i<n;++i){init_order[order[i]]=i;}//Get inverse for original order and transform back
			Reorder_gen(n,&init_order[0],w,1);
			Reorder_gen(n,&init_order[0],alpha,1);
			for(i=0;i<n;++i){order[i]=centre_shiftI[i];}//set new order
			Reorder_gen(n,&order[0],w,1);
			Reorder_gen(n,&order[0],alpha,1);
		}
		Reorder_gen(n,&order[0],initialm,1);
		Reorder_gen(n,&order[0],initials,1);
#endif
#ifdef INITIAL_WAY
		Reorder_gen(n,&order[0],initialm,1);
		Reorder_gen(n,&order[0],initials,1);
		{
			size_t topi,Topn=topn;
			std::valarray<size_t>init_order(n);
			getorder(n-topn,initials+topn,&init_order[topn],0,0);
			for(topi=0;topi<n-topn;++topi){if(fabs(initials[init_order[topi+topn]+topn])<=1e-9)break;}
			for(i=topn;i<n;++i){init_order[i]+=topn;}
			for(i=0;i<topn;++i){init_order[i]=i;}//Keep the topn the same
			centre_shiftI.resize(n);
			for(i=0;i<n;++i){centre_shiftI[i]=order[i];}
			Reorder_gen(n,&init_order[0],&centre_shiftI[0],1);//Combine orderings
			for(i=0;i<n;++i){init_order[order[i]]=i;}//Get inverse for original order and transform back
			Reorder_gen(n,&init_order[0],w,1);
			Reorder_gen(n,&init_order[0],initials,1);
			Reorder_gen(n,&init_order[0],initialm,1);
			for(i=0;i<n;++i){order[i]=(size_t)centre_shiftI[i];}//set new order
			Reorder_gen(n,&order[0],w,1);
			Reorder_gen(n,&order[0],initialm,1);
			Reorder_gen(n,&order[0],initials,1);
			topn+=topi;
			getorder(n-topn,initialm+topn,&init_order[topn],0,0);
			for(topi=0;topi<n-topn;++topi){if(fabs(initialm[init_order[topi+topn]+topn])<=1e-9)break;}
			for(i=topn;i<n;++i){init_order[i]+=topn;}
			for(i=0;i<topn;++i){init_order[i]=i;}//Keep the topn the same
			for(i=0;i<n;++i){centre_shiftI[i]=order[i];}
			Reorder_gen(n,&init_order[0],&centre_shiftI[0],1);//Combine orderings
			for(i=0;i<n;++i){init_order[order[i]]=i;}//Get inverse for original order and transform back
			Reorder_gen(n,&init_order[0],w,1);
			Reorder_gen(n,&init_order[0],initials,1);
			Reorder_gen(n,&init_order[0],initialm,1);
			for(i=0;i<n;++i){order[i]=(size_t)centre_shiftI[i];}//set new order
			Reorder_gen(n,&order[0],w,1);
			topn+=topi;
			printf((char*)"Maximum number of variables in the optimisation; %d\n",topn);
			if(topn-Topn<100)
			{
				printf((char*)"Add extra variables due to alpha size\n");
				Reorder_gen(n,&order[0],alpha,1);
				{
					double amn,amx;
					vecminmax(n-topn,alpha+topn,amx,amn);
					std::valarray<size_t> init_order;	//Here we rearrange just the bottom of the list 
					init_order.resize(n);				//using the bottom alphas
					if(ls){getorder(n-topn,alpha+topn,&init_order[topn],0,0.5*(amn+amx));}
					else if(alllong){getorder(n-topn,alpha+topn,&init_order[topn],0,amn);}
					else if(allshort){getorder(n-topn,alpha+topn,&init_order[topn],0,amx);}
					for(i=topn;i<n;++i){init_order[i]+=topn;}
					for(i=0;i<topn;++i){init_order[i]=i;}//Keep the topn the same
					centre_shiftI.resize(n);
					for(i=0;i<n;++i){centre_shiftI[i]=order[i];}

					Reorder_gen(n,&init_order[0],&centre_shiftI[0],1);//Combine orderings
					for(i=0;i<n;++i){init_order[order[i]]=i;}//Get inverse for original order and transform back
					Reorder_gen(n,&init_order[0],w,1);
					Reorder_gen(n,&init_order[0],alpha,1);
					for(i=0;i<n;++i){order[i]=(size_t)centre_shiftI[i];}//set new order
					Reorder_gen(n,&order[0],w,1);
				}
				topn=min(n,Topn+100-fixed_bounds-1);
				printf((char*)"Maximum number of variables in the optimisation; %d\n",topn);
			}
			Reorder_gen(n,&order[0],initialm,1);
			Reorder_gen(n,&order[0],initials,1);
		}
		Reorder_gen(n,&order[0],alpha,1);
#endif
		Reorder_gen(n,&order[0],L,1);
		Reorder_gen(n,&order[0],U,1);
		Reorder_gen(n,&order[0],bench,1);
		if(MaxDalpha>0)Reorder_gen(n,&order[0],dalpha,1);
		Reorder_gen(n,&order[0],A,m);
		Reorder_gen(n,&order[0],Aabs,nabs);
		if(MaxValpha>0)ReorderS(n,&order[0],covalpha);
		if(nf>-1&&TopRisk>0)
		{
			Q.resize(n*(n+1)/2);
			Factor2Cov(n,nf,FC,FL,SV,&Q[0]);
			FC=&Q[0];
			nf=-1;
		}
		if(TopRisk>0)ReorderS(n,&order[0],FC);
#ifdef ALPHA_WAY
		topn=min(n,topn+100-fixed_bounds-1);
#endif
		bound_reorganise(1,n,topn,m,L);
		bound_reorganise(1,n,topn,m,U);
		for(i = topn;i < n;++i)
		{
			daxpyvec(m,-w[i],A+i * m,L+topn);
			daxpyvec(m,-w[i],A+i * m,U+topn);
		}
		if(MaxDalpha>0)//Don't need to be relative to w since w[i]=0 for i>=topn
		{
			double pp=MaxDalpha;
			for(i=topn,modVarM=0;i<n;++i) modVarM+=dalpha[i]*dalpha[i]*initialm[i]*initialm[i];
			back=max(Pythag(MaxDalpha,pp,modVarM,false),back);
		}
		if(MaxValpha>0)
		{
			double pp=MaxValpha;
			if(centre_shiftI.size()<n)centre_shiftI.resize(n);
			DroppingOut(n,topn,covalpha,initials,&modVarS,&centre_shiftI[0]);
			back=max(Pythag(MaxValpha,pp,modVarS,false),back);
			daddvec(topn,initials,&centre_shiftI[0],initials);
		}
		if(TopRisk>0)
		{
			double pp=TopRisk;
			if(centre_shiftB.size()<n)centre_shiftB.resize(n);
			DroppingOut(n,topn,FC,bench,&modVarB,&centre_shiftB[0]);
			back=max(Pythag(TopRisk,pp,modVarB,false),back);
			daddvec(topn,bench,&centre_shiftB[0],bench);
		}
	}
	if(back==0)
		back=SOCPlsRobust1(topn,m,w,A,nf,SV,FL,FC,alpha,full,rmin,rmax,L,U,val,TopRisk,
		dalpha,MaxDalpha,covalpha,MaxValpha,nabs,Aabs,Labs,Uabs,bench,initialm,initials,
		signtest,0,0,maxrobust,SOCPdump);
	if(back==1)
	{
		std::valarray<double> LL(n+m),UU(n+m);
		dcopyvec(n+m,L,&LL[0]);
		dcopyvec(n+m,U,&UU[0]);
		for(i=0;i<topn;++i)
		{
			if(w[i]>0&&L[i]<0)
				LL[i]=0;
			if(w[i]<0&&U[i]>0)
				UU[i]=0;
			if(UU[i]<=LL[i])
				UU[i]=LL[i];
		}
		signtest=0;
		back=SOCPlsRobust1(topn,m,w,A,nf,SV,FL,FC,alpha,full,rmin,rmax,&LL[0],&UU[0],val,TopRisk,
			dalpha,MaxDalpha,covalpha,MaxValpha,nabs,Aabs,Labs,Uabs,bench,initialm,initials,
			signtest,0,0,maxrobust,SOCPdump);
	}
	if((n-fixed_bounds)>200&&fast)//Return things to the way they were
	{
		if(MaxDalpha>0)
		{
			double pp=MaxDalpha;
			Pythag(MaxDalpha,pp,modVarM);
		}
		if(MaxValpha>0)
		{
			double pp=MaxValpha;
			dsubvec(topn,initials,&centre_shiftI[0],initials);
			Pythag(MaxValpha,pp,modVarS);
		}
		if(TopRisk>0)
		{
			double pp=TopRisk;
			dsubvec(topn,bench,&centre_shiftB[0],bench);
			Pythag(TopRisk,pp,modVarB);
		}
		for(i = topn;i < n;++i)
		{
			daxpyvec(m,w[i],A+i * m,L+topn);
			daxpyvec(m,w[i],A+i * m,U+topn);
		}
		bound_reorganise(0,n,topn,m,L);
		bound_reorganise(0,n,topn,m,U);
		std::valarray<size_t> inverse(n);
		for(i=0;i<n;++i){inverse[order[i]]=i;}
		Reorder_gen(n,&inverse[0],w,1);
		Reorder_gen(n,&inverse[0],L,1);
		Reorder_gen(n,&inverse[0],U,1);
		Reorder_gen(n,&inverse[0],alpha,1);
		Reorder_gen(n,&inverse[0],initialm,1);
		Reorder_gen(n,&inverse[0],initials,1);
		Reorder_gen(n,&inverse[0],bench,1);
		if(MaxDalpha>0)Reorder_gen(n,&inverse[0],dalpha,1);
		Reorder_gen(n,&inverse[0],A,m);
		Reorder_gen(n,&inverse[0],Aabs,nabs);
		if(MaxValpha>0)ReorderS(n,&inverse[0],covalpha);
		if(TopRisk>0)ReorderS(n,&inverse[0],FC);
	}
	if(back==6)back=2;
	return back;
}
class RobustVar
{
public:
	vector A;
	vector FC;
	vector alpha;
	int full;
	double rmax;
	double rmin;
	double val;
	double TopRisk;
	vector dalpha;
	double MaxDalpha;
	size_t nabs;
	vector Aabs;
	vector Labs;
	vector Uabs;
	vector bench;
	vector initial;
	int signtest;
	int fast;
	int maxrobust;
};
short InnerRobustOpt(void*info)
{
	OptParamRound* OP=(OptParamRound*)info;
	RobustVar*RV=(RobustVar*)OP->MoreInfo;
	vector A=RV->A;
	vector FC=RV->FC;
	vector alpha=RV->alpha;
	int full=RV->full;
	double rmax=RV->rmax;
	double rmin=RV->rmin;
	double val=RV->val;
	double TopRisk=RV->TopRisk;
	vector dalpha=RV->dalpha;
	double MaxDalpha=RV->MaxDalpha;
	size_t nabs=RV->nabs;
	vector Aabs=RV->Aabs;
	vector Labs=RV->Labs;
	vector Uabs=RV->Uabs;
	vector bench=RV->bench;
	vector initial=RV->initial;
	int signtest=RV->signtest;
	int fast=RV->fast;
	int maxrobust=RV->maxrobust;
	OP->back=SOCPlsRobustl(OP->n,OP->m,OP->x,A,-1,0,0,FC,alpha,full,rmin,rmax,OP->lower,OP->upper,val,
		TopRisk,dalpha,MaxDalpha,0,-1,nabs,Aabs,Labs,
		Uabs,bench,initial,0,signtest,fast,maxrobust,OP->dump);
	clean_w(OP->n,OP->x);
	return OP->back;
}
double InnerUtility(void*info)
{
	OptParamRound* OP=(OptParamRound*)info;
	RobustVar*RV=(RobustVar*)OP->MoreInfo;
	vector alpha=RV->alpha;
	return -ddotvec(OP->n,alpha,OP->x);
}
extern "C" DLLEXPORT short SOCPlsRobustlC(size_t n,size_t m,vector w,vector A,
										long nf,vector SV,vector FL,vector FC,
										vector alpha,int full,double rmin,double rmax,
										vector L,vector U,double val,double TopRisk,
										vector dalpha,double MaxDalpha,
										size_t nabs,vector Aabs,vector Labs,
										vector Uabs,
										vector bench,vector initial,
										int signtest,int fast=0,int maxrobust=0,char*SOCPdump=0,
										size_t ncomp=0,vector Composites=0,double mintrade=-1)
{
#ifdef PAS
//	UnlockBita((char*)"colincolin");
	if(!Optimise::bitago)
	{
		fprintf(stderr,(char*)"Bad PAS key\n");
		return -1;
	}
	return -1;
#endif
	size_t nn=n*(n+1)/2,i,j,ncnc=(n-ncomp)*(n-ncomp+1)/2;
	std::valarray<double>Q(nn),Qc(n-ncomp),Dalpha(n),Alpha(n);
	Q=0;
	Dalpha=0;
	vector Qextra,Ci,Cj;
	double da;
	if(nf>-1)
	{
		Factor2Cov(n-ncomp,nf,FC,FL,SV,&Q[0]);
		nf=-1;
	}
	else if(FC)dcopyvec(ncnc,FC,&Q[0]);
	if(dalpha)dcopyvec(n-ncomp,dalpha,&Dalpha[0]);
	for(i=0,Qextra=&Q[ncnc],Ci=Composites;i<ncomp;++i,Ci+=(n-ncomp))
	{
		dsmxmulv(n-ncomp,&Q[0],Ci,&Qc[0]);
		dcopyvec(n-ncomp,&Qc[0],Qextra);
		Qextra+=(n-ncomp);
		for(j=0,Cj=Composites;j<=i;++j,Cj+=(n-ncomp))
		{
			*Qextra++=ddotvec(n-ncomp,&Qc[0],Cj);
		}
	}
	if(dalpha)
	{
		for(j=0,Cj=Composites,Ci=&Dalpha[n-ncomp];j<ncomp;++j)
		{
			da=0;
			for(i=0;i<n-ncomp;++i)
			{
				da+=square(dalpha[i])* *Cj++;
			}
			*Ci++=sqrt(da);
		}
	}
	dcopyvec(n-ncomp,alpha,&Alpha[0]);
	for(j=0,Cj=Composites,Ci=&Alpha[n-ncomp];j<ncomp;++j)
	{
		da=0;
		for(i=0;i<n-ncomp;++i)
		{
			da+=alpha[i]* *Cj++;
		}
		*Ci++=da;
	}
	size_t need_for_comp_only=0;
	for(i=0;i<n-ncomp;++i)
	{
		if(L[i]==0&&U[i]==0&&(initial&&initial[i]==0)&&(bench&&bench[i]==0))
			need_for_comp_only++;
	}
	std::valarray<size_t>neworder;
//need_for_comp_only=0;
	size_t	Nvab=n-need_for_comp_only;
	if(need_for_comp_only)
	{
		dzerovec(n,w);
		neworder.resize(2*n);
		size_t* inverse=&neworder[n];
		for(i=0;i<n;++i)
		{
			neworder[i]=i;
		}
		long sofar;
		sofar = n-1;
		for(i = 0;sofar>=(long)i;++i)
		{
			while(sofar>=0&&L[neworder[sofar]]==0&&U[neworder[sofar]]==0&&(initial&&initial[neworder[sofar]]==0)&&(bench&&bench[neworder[sofar]]==0))
			{sofar--;}
			if(sofar > (long)i && L[i]==0&&U[i]==0&&(initial&&initial[i]==0)&&(bench&&bench[i]==0))
			{
				std::swap(neworder[i],neworder[sofar]);
			}
		}
		Reorder_gen(n,&neworder[0],A,m);
		Reorder_gen(n,&neworder[0],&Alpha[0],1);
		if(bench)Reorder_gen(n,&neworder[0],bench,1);
		if(initial)Reorder_gen(n,&neworder[0],initial,1);
		if(dalpha)Reorder_gen(n,&neworder[0],&Dalpha[0],1);
		ReorderS(n,&neworder[0],&Q[0]);
		Reorder_gen(n,&neworder[0],L,1);
		Reorder_gen(n,&neworder[0],U,1);
		bound_reorganise(1,n,Nvab,m,L);
		bound_reorganise(1,n,Nvab,m,U);
		for(i=0;i<n;++i)
			inverse[neworder[i]]=i;
	}

	if(mintrade<=0)
	{
		short back;
		back= SOCPlsRobustl(Nvab,m,w,A,-1,0,0,&Q[0],&Alpha[0],full,rmin,rmax,L,U,val,TopRisk,
			(dalpha?&Dalpha[0]:0),MaxDalpha,0,-1,nabs,Aabs,Labs,Uabs,bench,
			initial,0,signtest,fast,maxrobust,SOCPdump);
		if(need_for_comp_only)
		{
			Reorder_gen(n,&neworder[n],A,m);
			Reorder_gen(n,&neworder[n],w,1);
			Reorder_gen(n,&neworder[n],&Alpha[0],1);
			if(bench)Reorder_gen(n,&neworder[n],bench,1);
			if(initial)Reorder_gen(n,&neworder[n],initial,1);
			if(dalpha)Reorder_gen(n,&neworder[n],&Dalpha[0],1);
			ReorderS(n,&neworder[n],&Q[0]);
			bound_reorganise(0,n,Nvab,m,L);
			bound_reorganise(0,n,Nvab,m,U);
			Reorder_gen(n,&neworder[n],L,1);
			Reorder_gen(n,&neworder[n],U,1);
		}
		return back;
	}
	std::valarray<double>min_trade(Nvab),x(Nvab);
//To make mintrade work with maxrobust option we need to add a maxrobust
//property to OptParamRound and modify the utility to add in dalpha term
	min_trade=mintrade;
	OptParamRound OP;
	OP.SetLog();
	RobustVar RV;
	OP.MoreInfo=&RV;
	OP.n=Nvab;
	OP.m=m;
	OP.lower=L;
	OP.upper=U;
	OP.x=&x[0];
	OP.OptFunc=InnerRobustOpt;
	OP.UtilityFunc=InnerUtility;
	OP.dump=SOCPdump;
	RV.A=A;
	RV.Aabs=Aabs;
	RV.alpha=&Alpha[0];
	RV.bench=bench;
	RV.fast=fast;
	RV.FC=&Q[0];
	RV.full=full;
	RV.initial=initial;
	RV.Labs=Labs;
	RV.MaxDalpha=MaxDalpha;
	RV.dalpha=(dalpha?&Dalpha[0]:0);
	RV.maxrobust=maxrobust;
	RV.nabs=nabs;
	RV.rmax=rmax;
	RV.rmin=rmin;
	RV.signtest=signtest;
	RV.TopRisk=TopRisk;
	RV.Uabs=Uabs;
	RV.val=val;
	Thresh(&OP,initial,&min_trade[0],w);
	if(need_for_comp_only)
	{
		Reorder_gen(n,&neworder[n],A,m);
		Reorder_gen(n,&neworder[n],w,1);
		Reorder_gen(n,&neworder[n],&Alpha[0],1);
		if(bench)Reorder_gen(n,&neworder[n],bench,1);
		if(initial)Reorder_gen(n,&neworder[n],initial,1);
		if(dalpha)Reorder_gen(n,&neworder[n],&Dalpha[0],1);
		ReorderS(n,&neworder[n],&Q[0]);
		bound_reorganise(0,n,Nvab,m,L);
		bound_reorganise(0,n,Nvab,m,U);
		Reorder_gen(n,&neworder[n],L,1);
		Reorder_gen(n,&neworder[n],U,1);
	}
	return OP.back;
}
extern "C" DLLEXPORT short SOCPlsRobust(size_t n,size_t m,vector w,vector A,
										long nf,vector SV,vector FL,vector FC,
										vector alpha,int full,double rmin,double rmax,
										vector L,vector U,double val,double TopRisk,
										vector dalpha,double MaxDalpha,vector covalpha,double MaxValpha,
										size_t nabs,vector Aabs,
										vector Uabs,vector bench,vector initialm,vector initials,int signtest,int fast=0)
{
	return SOCPlsRobustl(n,m,w,A,nf,SV,FL,FC,alpha,full,rmin,rmax,L,U,val,TopRisk,dalpha,MaxDalpha,
		covalpha,MaxValpha,nabs,Aabs,0,Uabs,bench,initialm,initials,signtest,fast);
}
extern "C" DLLEXPORT short SOCPRanked(size_t n,size_t m,vector w,vector A,vector L,
									vector U,long nf,vector SV,vector FL,vector FC,
									vector alpha,double maxRisk,
									vector bench,int justalpha=0)
{
#ifdef PAS
//	UnlockBita((char*)"colincolin");
	if(!Optimise::bitago)
	{
		fprintf(stderr,(char*)"Bad PAS key\n");
		return -1;
	}
	return -1;
#endif
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	std::valarray<size_t>order;
	size_t i;
	/*
	* alpha contains ranks (integers 0 to n-1)
	* We maximise alpha.(w-b) - sum (dalpha.(w-b))**2
	* where dalpha[i]=.5 for all i
	* subject to risk <=maxrisk and linear constraints
	*/
	Optimise O;
	if(!O.licenced)return -1;
	short back=0;
	size_t ndual;
	std::valarray<double>pQ;//,pDalpha(n);
//	pDalpha=.5;
	vector Q;//dalpha=&pDalpha[0];
	if(nf>-1)
	{
		pQ.resize(n*(n+1)/2);
		Q=&pQ[0];
		Factor2Cov(n,nf,FC,FL,SV,Q);
	}
	else Q=FC;	//Input covariances in FC for non-factor model
	std::valarray<double> pRQ,pRcov(n*n);
	vector rQ=0;
	size_t ncone,nn=0;
	std::valarray<int> CONES;
	std::valarray<double> SA,Sc,Sb,Sx,Sy,Ss;
	pRQ.resize(n*n);
	rQ=&pRQ[0];
	RootQ(n,Q,rQ,0);
	std::valarray<double> rbench,rinitial;
	if(bench)rbench.resize(n);
	else rbench.resize(n);
	if(bench)
	{
		dmxtmulv(n,n,rQ,bench,&rbench[0]);
	}
	/*
	Maximise wn
	subject to
	Li<=wi<=Ui							0<=i<n
	Li+n<=(Aw)i<=Ui+n					0<=i<m
***		||dalpha.(w-b))||	<= alpha.(w-b)-wn
	sqrt((w-bench).Q.(w-bench))		<=maxRisk
	We need n+m 2d cones and 2 (n+1)d cones
	*/
	ndual=n+1;
	ncone=n+m+2;
	CONES.resize(ncone);
	for(i=0;i<n+m;++i)
	{
		nn+=CONES[i]=2;
	}
	for(i=n+m;i<ncone;++i)
	{
		nn+=CONES[i]=n+1;
	}
	SA.resize(nn*ndual);
	Sc.resize(nn);
	SA=0;Sc=0;
	if(m>1)dmx_transpose(m,n,A,A);
	size_t ic;
	for(i=0,ic=0;i<n;++i)
	{
		SA[i+ic*ndual]=1;
		Sc[ic++]=.5*(L[i]+U[i]);
		//		SA[i+ic*ndual]=0;
		Sc[ic++]=.5*(U[i]-L[i]);
	}
	for(i=0;i<m;++i)
	{
		dcopyvec(n,A+i*n,&SA[ic*ndual]);
		Sc[ic++]=.5*(L[i+n]+U[i+n]);
		//		SA[i+ic*ndual]=0;
		Sc[ic++]=.5*(U[i+n]-L[i+n]);
	}
	if(m>1)dmx_transpose(n,m,A,A);
	if(bench)dcopyvec(n,&rbench[0],&Sc[ic]);
	for(i=0;i<n;++i)//Risk constraint
	{
		dcopyvec(n,rQ+i*n,&SA[ic*ndual]);
		ic++;
	}
	Sc[ic++]=maxRisk;
	
	if(justalpha)
		ic+=n;
	else
	{
		for(i=0;i<n;++i)//alpha-dalpha > t i.e ||dalpha||<alpha - t
		{
			SA[ic*ndual+i]=0.5;//dalpha[i];
			if(bench)Sc[ic]=0.5/*dalpha[i]*/ *bench[i];
			ic++;
		}
	}
	for(i=0;i<n;++i)
	{
		SA[ic*ndual+i]=-alpha[i];
	}
	if(bench)Sc[ic]=-ddotvec(n,bench,alpha);
	SA[ic*ndual+n]=1;//the last variable t
	ic++;
	dmx_transpose(ndual,nn,&SA[0],&SA[0]);
	Sb.resize(ndual);
	Sb=0;
	Sb[n]=1;//Maximise alpha-dalpha
	Sx.resize(nn);
	Sy.resize(ndual);
	Ss.resize(nn);
	pRcov.resize(0);
	pRQ.resize(0);
	double tau,kappa;
	if(!(back=SOCPinfeasHomogt(ncone,ndual,&CONES[0],&Sc[0],&SA[0],&Sb[0],&Sx[0],&Sy[0],
		&Ss[0],&tau,&kappa,100,1e-8,.5,1e-3,1e-3,0,1)))
	{
		if(tau>kappa)
		{
			dsccopyvec(n,1./tau,&Sy[0],w);
		}
		else
		{
			double tt;
			if((tt=ddotvec(n,&Sb[0],&Sy[0]))>0)
				printf((char*)"b dot y %20.12e primal is infeasible\n",tt);
			if((tt=ddotvec(nn,&Sc[0],&Sx[0]))<0)
				printf((char*)"c dot x %20.12e dual is infeasible\n",tt);
			back=2;
		}
	}
	else
	{
		printf((char*)"SOCP failed\n");back = 3;
	}
	return back;
}
extern "C" DLLEXPORT void Projection(size_t n,size_t m,vector A,vector x,vector s,vector M)
{
/*Grassmanian Paper.
The M matrix is the projection DA'inv(ADDA')AD
where D is diag([x[i]/s[i] for i in range(len(x))])
Note the A matrix here is our usual A transposed!
*/
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	size_t i,j;
	std::valarray<double>AD(2*n*m),ADDA(m*(m+1)/2);
	vector pAD,pA,px,ps,pADDA,pADi,pADj;
	double term;
	for(i=0;i<n;++i)
	{
		pAD=&AD[i];
		pA=A+i;
		px=x;
		ps=s;
		term=sqrt(*px/ *ps);
		for(j=0;j<m;++j,pAD+=n,pA+=n)
		{
			*pAD=*pA*term;
		}
	}
	for(i=0,pADDA=&ADDA[0],pAD=&AD[0];i<m;++i,pAD+=n)
	{
		for(j=0,pADj=&AD[0];j<=i;++j,pADj+=n)
		{
			*pADDA++=ddotvec(n,pAD,pADj);
		}
	}
	pAD=&AD[0];
	dmx_transpose(n,m,&AD[0],&AD[0]);
	std::valarray<short_scl>P(n);
	dsmxfac(m,&ADDA[0],&P[0]);
	for(i=0,pAD=&AD[0],pADi=&AD[n*m];i<n;i++,pAD+=m,pADi+=m)
	{
		dcopyvec(m,pAD,pADi);
		dsmxainv(m,&ADDA[0],&P[0],pADi);
		for(j=0,pADj=&AD[n*m];j<=i;++j,pADj+=m)
			*M++=ddotvec(m,pAD,pADj);
	}
}

extern "C" DLLEXPORT void CovarianceInverter(size_t n,vector Q,vector Qm1,vector y,vector x)
{
	size_t i,nn=n*(n+1)/2;
	std::valarray<double> Qcopy(nn),unit(n);
	std::valarray<short_scl>P(n);
	dcopyvec(nn,Q,&Qcopy[0]);
//	dsmxfac(n,&Qcopy[0],&P[0]);was this
	bunchf(n,&Qcopy[0],&P[0]);
	if(y&&x)
	{
		dcopyvec(n,y,x);
		//dsmxainv(n,&Qcopy[0],&P[0],x);was this
		dsptrs((char*)"U",n,1,&Qcopy[0],&P[0],x,n);
	}
	unit=0;
	for(i=0;i<n;++i)
	{
		unit[i]=1;
		//dsmxainv(n,&Qcopy[0],&P[0],&unit[0]);was this
		dsptrs((char*)"U",n,1,&Qcopy[0],&P[0],&unit[0],n);
		dcopyvec(i+1,&unit[0],Qm1);
		unit=0;
		Qm1+=(i+1);
	}
}
inline void	facmodmul(size_t nvab,size_t nfac,vector H,vector x,vector y)
{
	vector	SV = H;
	vector	FF = SV + nvab;
	size_t	i;
	if(nfac)
	{
									dsccopy(nvab,BITA_ddot(nvab,FF,nfac,x,1),FF,nfac,y,1);
		for(i = 1;i < nfac;i++) {BITA_daxpy(nvab,BITA_ddot(nvab,FF + i,nfac,x,1),FF + i,nfac,y,1);}
	}
	else	{dzerovec(nvab,y);}

	for(i = 0;i < nvab;++i)	{y[i] += SV[i] * x[i];}
}
extern "C" DLLEXPORT void RankingConstraints(size_t n,vector Q,vector rank,vector A,long nf,
											 vector FL,vector SV)
{
/*
	We want to make sure that the implied alphas are in the order given in rank.

	The constraints are   A.w > 0 where

	A = ranks.covariances
*/
	vector pA;
	std::valarray<size_t>order(2*n);
	getorder(n,rank,&order[0],0,0);
	size_t i;
	for(i=0;i<n;++i)order[n+order[i]]=i;
	dsetvec(n,1,A);
	for(i=0,pA=A+n;i<n-1;++i)// rank matrix setup
	{
		if(i)
		{
			dzerovec(i,pA);
			pA+=i;
		}
		*pA++=1;//Order is "greater than"
		*pA++=-1;
		if(n-i-2)
		{
			dzerovec(n-i-2,pA);
			pA+=n-i-2;
		}
	}
	dmx_transpose(n,n,A,A);
	Reorder_gen(n,&order[n],A,n);
	if(Q)
	{
		dmx_transpose(n,n,A,A);
		std::valarray<double>aa(n);
		if(nf==-1)
		{
			for(i=0,pA=A+n;i<n-1;++i,pA+=n)
			{
				dsmxmulv(n,Q,pA,&aa[0]);
				dcopyvec(n,&aa[0],pA);
			}
		}
		else
		{
			std::valarray<double>QQ((nf+1)*n);
			factor_model_process(n,nf,FL,Q,SV,&QQ[0]);
			for(i=0,pA=A+n;i<n-1;++i,pA+=n)
			{
				facmodmul(n,nf,&QQ[0],pA,&aa[0]);
				dcopyvec(n,&aa[0],pA);
			}
		}
		dmx_transpose(n,n,A,A);
	}
}
void Increasel(size_t n,size_t ncomp,vector L,vector Comp)
{
	/*Get the values for composites*/
	size_t i;
	vector cw,Li;
	for(i=0,Li=L+n-ncomp,cw=Comp;i<ncomp;++i,cw+=(n-ncomp),Li++)
	{
		*Li=ddotvec(n-ncomp,cw,L);
	}
}
extern "C" DLLEXPORT void IncreaseL(size_t n,size_t m,size_t ncomp,vector L,vector Comp)
{
	while(m--)
	{
		Increasel(n,ncomp,L,Comp);
		L+=n;
	}
}
void ModifyCentres(size_t nprime,size_t ndual,
				   vector A,vector C,vector L,size_t fixed_bounds)
{
	std::valarray<double>fw(ndual+fixed_bounds),RC(nprime);
	dzerovec(ndual,&fw[0]);
	dcopyvec(fixed_bounds,L+ndual,&fw[ndual]);
	dmx_transpose(nprime,ndual+fixed_bounds,A,A);
	dmxtmulv(ndual+fixed_bounds,nprime,A,&fw[0],&RC[0]);
	dsubvec(nprime,C,&RC[0],C);
	dmx_transpose(ndual+fixed_bounds,nprime,A,A);	
}
short RobustOpt1(size_t n,size_t m,vector w,vector alpha,vector A,
				vector L,vector U,
				int full,double rmin,double rmax,double val,
				size_t nabs,vector Aabs,vector Labs,vector Uabs,
				int signtest,size_t nquad,int*qtype,vector cov,vector Uq,
				vector centres,size_t* baseorder,size_t ncomp=0,vector Comps=0,
				int fillin=1,vector Ualpha=0,vector lagrange=0)
{
	//Ready for the constraint ||A.centres - A.x|| < Uabs-Ualpha.x
	Optimise O;
	if(!O.licenced)return -1;
	size_t i,j,ii,fixed_bounds=0;
	for(i=0;i<n;++i){if(fabs(U[i]-L[i])<equalboundslim)fixed_bounds++;}
	
	
	std::vector<size_t> iid;
	size_t*id,nextra,mextra=(val==0?0:1);
	if(rmin>=-lm_eps)mextra++;
	if(rmax>=-lm_eps&&rmin!=rmax)mextra++;
	mextra+=nabs;
	size_t k;
	for(i=0;i<n;++i)
	{
		if(L[i]<0&&U[i]>0)
			iid.push_back(i);
	}
	id=0;
	nextra=iid.size();
	if(nextra)
		id=&(iid.front());
	std::valarray<double>LL(n+nextra),UU(n+nextra),
		Als(mextra*(n+nextra)),Lls(mextra),Uls(mextra);
	size_t mmextra;
	Als=0;
	if(nabs>1)dmx_transpose(nabs,n,Aabs,Aabs);
	for(i=0,j=n;i<n;++i)
	{
		mmextra=0;
		if(id&&i == *id)
		{
			LL[i]=L[i];
			UU[i]=0;
			LL[j]=0;
			UU[j]=U[i];
			if(mextra)
			{
				if(val!=0)
				{
					Als[i+mmextra*(n+nextra)]=0;
					Als[j+mmextra*(n+nextra)]=1;
					mmextra++;
				}
				if(rmin>=-lm_eps)
				{
					Als[i+mmextra*(n+nextra)]=1;
					Als[j+mmextra*(n+nextra)]=rmin;
					mmextra++;
					if(rmax>=-lm_eps&&rmin!=rmax)
					{
						Als[i+mmextra*(n+nextra)]=-1;
						Als[j+mmextra*(n+nextra)]=-rmax;
						mmextra++;
					}
				}
				else if(rmax>=-lm_eps)
				{
					Als[i+mmextra*(n+nextra)]=-1;
					Als[j+mmextra*(n+nextra)]=-rmax;
					mmextra++;
				}
				if(nabs)
				{
					vector pabs;
					for(k=0,pabs=Aabs;k<nabs;++k,pabs+=n)
					{
						Als[i+mmextra*(n+nextra)]=-*(pabs+i);
						Als[j+mmextra*(n+nextra)]=*(pabs+i);
						mmextra++;
					}
				}
			}
			j++;
			id++;
		}
		else
		{
			LL[i]=L[i];
			UU[i]=U[i];
			if(mextra)
			{
				if(val!=0)
				{
					if(L[i]<0)
					{
						Als[i+mmextra*(n+nextra)]=0;
					}
					else
					{
						Als[i+mmextra*(n+nextra)]=1;
					}
					mmextra++;
				}
				if(rmin>=-lm_eps)
				{
					if(L[i]<0)
					{
						Als[i+mmextra*(n+nextra)]=1;
					}
					else
					{
						Als[i+mmextra*(n+nextra)]=rmin;
					}
					mmextra++;
					if(rmax>=-lm_eps&&rmin!=rmax)
					{
						if(L[i]<0)
						{
							Als[i+mmextra*(n+nextra)]=-1;
						}
						else
						{
							Als[i+mmextra*(n+nextra)]=-rmax;
						}
						mmextra++;
					}
				}
				else if(rmax>=0)
				{
					if(L[i]<0)
					{
						Als[i+mmextra*(n+nextra)]=-1;
					}
					else
					{
						Als[i+mmextra*(n+nextra)]=-rmax;
					}
					mmextra++;
				}
				if(nabs)
				{
					vector pabs;
					for(k=0,pabs=Aabs+i;k<nabs;++k,pabs+=n)
					{
						Als[i+mmextra*(n+nextra)]=(L[i]<0?-*pabs:*pabs);
						mmextra++;
					}					
				}
			}
		}
	}
	if(nabs>1)dmx_transpose(n,nabs,Aabs,Aabs);
	mmextra=0;
	if(mextra)
	{
		if(val!=0)
		{
			Lls[mmextra]=(full==1)?val:0;
			Uls[mmextra++]=val;
		}
		if(rmin>=-lm_eps)
		{
			Lls[mmextra]=(rmin==rmax)?0:-1e4;
			Uls[mmextra++]=0;
			if(rmax>0&&rmax!=rmin)
			{
				Lls[mmextra]=-1e4;
				Uls[mmextra++]=0;
			}
		}
		else if(rmax>=-lm_eps)
		{
			Lls[mmextra]=-1e4;
			Uls[mmextra++]=0;
		}
		if(nabs)
		{
			for(k=0;k<nabs;++k)
			{
				Lls[mmextra]=(Labs?Labs[k]:0);
				Uls[mmextra++]=Uabs[k];
			}
		}
	}
	
	if(m>1)dmx_transpose(m,n,A,A);
	/*
	n+nextra+m  linear constraints			n+nextra+m  2-d cones
	mextra linear constraints			mextra 1- or 2-d cones
	nquad   quadratic constraints			nquad (n or qtype[i])+1-d cones
	*/
	std::valarray<int> CONES;
	std::valarray<double> SA,Sc,Sb,Sx,Sy,Ss;
	size_t ncone,ndual=n+nextra,nn;
	double tau,kappa;
	ncone=n+nextra+m+mextra-fixed_bounds;
	for(i=0;i<nquad;++i)
	{
		if(Uq[i]>0||Ualpha)
			ncone++;
	}
	CONES.resize(ncone);
	for(i=0,nn=0;i<n+nextra+m-fixed_bounds;++i)
	{
		nn+=CONES[i]=2;
	}
	for(i=0;i<mextra;++i)
	{
		if(Lls[i]==-1e4)
			nn+=CONES[n+nextra+m+i-fixed_bounds]=1;//-S/L ratio
		else
			nn+=CONES[n+nextra+m+i-fixed_bounds]=2;//Cover constraint or equality -S/L constraint
	}
	size_t q_xon=0;
	for(i=0;i<nquad;++i)
	{
		if(Uq[i]>0||Ualpha)
		{
			if(qtype[i]==-1||qtype[i]==0)
				nn+=CONES[n+nextra+m+mextra+q_xon++-fixed_bounds]=n-ncomp*fillin+1;
			else
				nn+=CONES[n+nextra+m+mextra+q_xon++-fixed_bounds]=qtype[i]+1;
		}
	}
	SA.resize(nn*ndual);
	Sc.resize(nn);
	SA=0;
	Sc=0;
	size_t ic;
	vector pA,ppA;
	for(i=0,ic=0;i<n+nextra-fixed_bounds;++i)
	{
		SA[i+ic*ndual]=1;
		Sc[ic++]=.5*(LL[i]+UU[i]);
		//		SA[i+ic*ndual]=0;
		Sc[ic++]=.5*(UU[i]-LL[i]);
	}
	for(i=0,pA=A;i<m;++i,pA+=n)
	{
		dcopyvec(n,pA,&SA[ic*ndual]);
		id=0;
		if(iid.size())
			id=&(iid.front());
		for(j=0,ppA=pA,k=n;j<n;++j,ppA++)
		{
			if(id&&*id==j)
			{
				SA[ic*ndual+k]=*ppA;
				k++;
				id++;
			}
		}
		Sc[ic++]=.5*(L[i+n]+U[i+n]);
		//		SA[i+ic*ndual]=0;
		Sc[ic++]=.5*(U[i+n]-L[i+n]);
	}
	for(i=0;i<mextra;++i)
	{
		dcopyvec(ndual,&Als[i*ndual],&SA[ic*ndual]);
		if(Lls[i]==-1e4)
		{
			Sc[ic++]=0;
		}
		else
		{
			Sc[ic++]=.5*(Lls[i]+Uls[i]);
			//		SA[i+ic*ndual]=0;
			Sc[ic++]=.5*(Uls[i]-Lls[i]);
		}
	}
	vector pQ,pQj,pQjd;
	size_t* jd;
	std::valarray<size_t>lagrange_i(nquad);
	for(i=0;i<nquad;++i)
	{
		if(qtype[i]==-1)
		{
			if(Uq[i]>0||Ualpha)
			{
				for(j=0,pQ=&SA[ic*ndual];j<(n-ncomp*fillin);++j,pQ+=n-ncomp*fillin)
				{
					pQ[j]=*cov++;
				}
				if(ncomp*fillin)
				{
					dmx_transpose(n-ncomp,n-ncomp,&SA[ic*ndual],&SA[ic*ndual]);
					dmx_transpose(n-ncomp,n,&SA[ic*ndual],&SA[ic*ndual]);
					IncreaseL(n,n-ncomp,ncomp,&SA[ic*ndual],Comps);
				}
				dmxtmulv(n,n-ncomp*fillin,&SA[ic*ndual],centres,&Sc[ic]);
				dmx_transpose(n,n-ncomp*fillin,&SA[ic*ndual],&SA[ic*ndual]);
				Reorder_gen(n,baseorder,&SA[ic*ndual],n-ncomp*fillin);
				dmx_transpose(n-ncomp*fillin,n,&SA[ic*ndual],&SA[ic*ndual]);
				if(nextra)
				{
					dmx_transpose(n,n-ncomp*fillin,&SA[ic*ndual],&SA[ic*ndual]);
					dmx_transpose(n-ncomp*fillin,nextra+n,&SA[ic*ndual],&SA[ic*ndual]);
					for(ii=0,pQ=&SA[ic*ndual+n];ii<n;++ii,pQ+=(n+nextra))
					{
						for(j=0,pQjd=pQ-n,pQj=pQ,jd=&iid[0];j<nextra;++j,pQj++)
						{
							*pQj=*(pQjd+*jd++);
						}
					}
				}
				ic+=n-ncomp*fillin;
				if(Ualpha)
				{
					dcopyvec(n-ncomp*fillin,Ualpha,&SA[ic*ndual]);
					if(ncomp*fillin)
					{
						IncreaseL(n,1,ncomp,&SA[ic*ndual],Comps);
					}
					Reorder_gen(n,baseorder,&SA[ic*ndual],1);
					if(nextra)
					{
						for(ii=0,pQ=&SA[ic*ndual+n];ii<1;++ii,pQ+=(n+nextra))
						{
							for(j=0,pQjd=pQ-n,pQj=pQ,jd=&iid[0];j<nextra;++j,pQj++)
							{
								*pQj=*(pQjd+*jd++);
							}
						}
					}
				}
				lagrange_i[i]=ic;
				Sc[ic++]=(Uq[i]>=0)?Uq[i]:0;
			}
			else
			{
				cov+=n-ncomp*fillin;
			}
			centres+=n;
			if(Ualpha)Ualpha+=n;
		}
		else if(qtype[i]==0)
		{
			if(Uq[i]>0||Ualpha)
			{
				RootQ(n-ncomp*fillin,cov,&SA[ic*ndual],0);
				if(ncomp*fillin)
				{
					dmx_transpose(n-ncomp,n-ncomp,&SA[ic*ndual],&SA[ic*ndual]);
					dmx_transpose(n-ncomp,n,&SA[ic*ndual],&SA[ic*ndual]);
					IncreaseL(n,n-ncomp,ncomp,&SA[ic*ndual],Comps);
				}
				dmxtmulv(n,n-ncomp*fillin,&SA[ic*ndual],centres,&Sc[ic]);
				dmx_transpose(n,n-ncomp*fillin,&SA[ic*ndual],&SA[ic*ndual]);
				Reorder_gen(n,baseorder,&SA[ic*ndual],n-ncomp*fillin);
				dmx_transpose(n-ncomp*fillin,n,&SA[ic*ndual],&SA[ic*ndual]);
				if(nextra)
				{
					dmx_transpose(n,n-ncomp*fillin,&SA[ic*ndual],&SA[ic*ndual]);
					dmx_transpose(n-ncomp*fillin,nextra+n,&SA[ic*ndual],&SA[ic*ndual]);
					for(ii=0,pQ=&SA[ic*ndual+n];ii<n;++ii,pQ+=(n+nextra))
					{
						for(j=0,pQjd=pQ-n,pQj=pQ,jd=&iid[0];j<nextra;++j,pQj++)
						{
							*pQj=*(pQjd+*jd++);
						}
					}
				}
				ic+=n-ncomp*fillin;
				if(Ualpha)
				{
					dcopyvec(n-ncomp*fillin,Ualpha,&SA[ic*ndual]);
					if(ncomp*fillin)
					{
						IncreaseL(n,1,ncomp,&SA[ic*ndual],Comps);
					}
					Reorder_gen(n,baseorder,&SA[ic*ndual],1);
					if(nextra)
					{
						for(ii=0,pQ=&SA[ic*ndual+n];ii<1;++ii,pQ+=(n+nextra))
						{
							for(j=0,pQjd=pQ-n,pQj=pQ,jd=&iid[0];j<nextra;++j,pQj++)
							{
								*pQj=*(pQjd+*jd++);
							}
						}
					}
				}
				lagrange_i[i]=ic;
				Sc[ic++]=(Uq[i]>=0)?Uq[i]:0;
			}
			cov+=(n-ncomp*fillin)*(n-ncomp*fillin+1)/2;
			centres+=n;
			if(Ualpha)Ualpha+=n;
		}
		else if(qtype[i]>0)
		{
			if(Uq[i]>0||Ualpha)
			{
				std::valarray<double>rc(qtype[i]*(1+qtype[i])/2);
				std::valarray<short_scl>P(qtype[i]);
				vector v;
				dcopyvec(qtype[i]*(1+qtype[i])/2,cov,&rc[0]);
				dsmxfac(qtype[i], &rc[0], &P[0] );
				cov+=qtype[i]*(qtype[i]+1)/2;
				dmx_transpose(n-ncomp*fillin,qtype[i],cov,&SA[ic*ndual]);
				for(j = 0,v = &SA[ic*ndual];j < n-ncomp*fillin;j++,v += qtype[i])
				{
					dsmxasrt(qtype[i],&rc[0],&P[0],SMXFAC_LEFT_ROOT,v);
				}
				dmx_transpose(qtype[i],n,&SA[ic*ndual],&SA[ic*ndual]);
				if(ncomp*fillin)
				{
					IncreaseL(n,qtype[i],ncomp,&SA[ic*ndual],Comps);
				}
				dmxtmulv(n,qtype[i],&SA[ic*ndual],centres,&Sc[ic]);
				dmx_transpose(n,qtype[i],&SA[ic*ndual],&SA[ic*ndual]);
				Reorder_gen(n,baseorder,&SA[ic*ndual],qtype[i]);
				dmx_transpose(qtype[i],n,&SA[ic*ndual],&SA[ic*ndual]);
				if(nextra)
				{
					dmx_transpose(n,qtype[i],&SA[ic*ndual],&SA[ic*ndual]);
					dmx_transpose(qtype[i],nextra+n,&SA[ic*ndual],&SA[ic*ndual]);
					for(ii=0,pQ=&SA[ic*ndual+n];ii<qtype[i];++ii,pQ+=(n+nextra))
					{
						for(j=0,pQjd=pQ-n,pQj=pQ,jd=&iid[0];j<nextra;++j,pQj++)
						{
							*pQj=*(pQjd+*jd++);
						}
					}
				}
				ic+=qtype[i];
				if(Ualpha)
				{
					dcopyvec(n-ncomp*fillin,Ualpha,&SA[ic*ndual]);
					if(ncomp*fillin)
					{
						IncreaseL(n,1,ncomp,&SA[ic*ndual],Comps);
					}
					Reorder_gen(n,baseorder,&SA[ic*ndual],1);
					if(nextra)
					{
						for(ii=0,pQ=&SA[ic*ndual+n];ii<1;++ii,pQ+=(n+nextra))
						{
							for(j=0,pQjd=pQ-n,pQj=pQ,jd=&iid[0];j<nextra;++j,pQj++)
							{
								*pQj=*(pQjd+*jd++);
							}
						}
					}
				}
				lagrange_i[i]=ic;
				Sc[ic++]=(Uq[i]>=0)?Uq[i]:0;
				cov+=qtype[i]*(n-ncomp*fillin);
			}
			else
				cov+=qtype[i]*(qtype[i]+1)/2+qtype[i]*(n-ncomp*fillin);
			centres+=n;
			if(Ualpha)Ualpha+=n;
		}
	}
	dmx_transpose(ndual,nn,&SA[0],&SA[0]);
	if(m>1)dmx_transpose(n,m,A,A);//Change it back
	Sb.resize(ndual);
	id=0;
	if(iid.size())
		id=&(iid.front());
	for(i=0,j=n;i<n;++i)
	{
		Sb[i]=alpha[i];
		if(id&&*id==i)
		{
			Sb[j]=alpha[i];
			j++;
			id++;
		}
	}
	Sx.resize(nn);
	Sy.resize(ndual);
	Ss.resize(nn);
	std::valarray<size_t>order;
	if(fixed_bounds&&nextra)
	{
		order.resize(2*(n+nextra));
		size_t* backorder=&order[n+nextra];
		for(i=0;i<n+nextra;++i)order[i]=i;
		long sofar;
		size_t Nvab=n+nextra-fixed_bounds;
		sofar = n+nextra-1;
		for(i = 0;sofar>=(long)i;++i)
		{
			while(sofar>=0&&fabs(LL[order[sofar]] - UU[order[sofar]]) < equalboundslim){sofar--;}
			if(sofar > (long)i && fabs(LL[order[i]] - UU[order[i]]) < equalboundslim)
			{
				std::swap(order[i],order[sofar]);
			}
		}
		for(i=0;i<n+nextra;++i)backorder[order[i]]=i;
		Reorder_gen(ndual,&order[0],&SA[0],nn);
		Reorder_gen(ndual,&order[0],&Sb[0],1);
		Reorder_gen(ndual,&order[0],&LL[0],1);
	}
	if(fixed_bounds)ModifyCentres(nn,ndual-fixed_bounds,&SA[0],&Sc[0],&LL[0],fixed_bounds);
	bool bad=0;
	short back;
	double checktol=100000*lm_eps;
	double rhoconv=1e-6;//std::pow(lm_eps,.45);
	Als.resize(0);
	Lls.resize(0);
	Uls.resize(0);
	double changeratio=4;
	int log=0;
	char* logfile=0;
#ifndef NO_NORM_SCAL
		double normdata=sqrt(ddotvec((ndual-fixed_bounds)*nn,&SA[0],&SA[0])+ddotvec((ndual-fixed_bounds),&Sb[0],&Sb[0])+ddotvec(nn,&Sc[0],&Sc[0]));
		dscalvec((ndual-fixed_bounds)*nn,1./normdata,&SA[0]);
		dscalvec((ndual-fixed_bounds),1./normdata,&Sb[0]);
		dscalvec(nn,1./normdata,&Sc[0]);
#endif
		if(!(back=SOCPinfeasHomogt(ncone,ndual-fixed_bounds,&CONES[0],&Sc[0],&SA[0],&Sb[0],&Sx[0],&Sy[0],
		&Ss[0],&tau,&kappa,100,1e-6,.5,1e-2,1e-2,signtest,changeratio,rhoconv,log,logfile,(char*)""/*"SeriousDump"*/)))
	{
#ifndef NO_NORM_SCAL
		dscalvec((ndual-fixed_bounds)*nn,normdata,&SA[0]);
		dscalvec((ndual-fixed_bounds),normdata,&Sb[0]);
		dscalvec(nn,normdata,&Sc[0]);
#endif
		dcopyvec(fixed_bounds,L+n-fixed_bounds,&Sy[ndual-fixed_bounds]);
		if(nextra&&fixed_bounds)
		{
			Reorder_gen(ndual,&order[ndual],&Sy[0],1);
			Reorder_gen(ndual,&order[ndual],&Sb[0],1);
		}
		if(tau>kappa||(signtest && tau>lm_rooteps))
		{
			checktol *= (tau*tau);
			id=0;
			if(iid.size())
				id=&(iid.front());
			for(i=0,j=n;i<n;++i)
			{
				if(id&&i==*id)
				{
					w[i]=(Sy[i]+Sy[j])/ tau;
					if(fabs(Sy[i]*Sy[j])>checktol)bad=true;
					id++;j++;
				}
				else
					w[i]=Sy[i]/ tau;
			}
			dcopyvec(fixed_bounds,&Sy[n-fixed_bounds],w+n-fixed_bounds);
			back+=(short)bad;
			if(lagrange){for(i=0;i<nquad;++i)lagrange[i]=Sx[lagrange_i[i]]/tau;}
		}
		else
		{
			double tt;
			if((tt=ddotvec(ndual,&Sb[0],&Sy[0]))>0)
				printf((char*)"b dot y %20.12e primal is infeasible\n",tt);
			if((tt=ddotvec(nn,&Sc[0],&Sx[0]))<0)
				printf((char*)"c dot x %20.12e dual is infeasible\n",tt);
			back=2;
		}
	}
	else
	{
#ifndef NO_NORM_SCAL
		dscalvec((ndual-fixed_bounds)*nn,normdata,&SA[0]);
		dscalvec((ndual-fixed_bounds),normdata,&Sb[0]);
		dscalvec(nn,normdata,&Sc[0]);
#endif
		printf((char*)"SOCP failed\n");back = 3;
	}
	return back;
}
extern "C" DLLEXPORT void RobustOptUDump(size_t n,size_t m,vector w,vector alpha,vector A,
									 vector L,vector U,
									 int full,double rmin,double rmax,double val,
									 size_t nabs,vector Aabs,vector Labs,vector Uabs,
									 int signtest,size_t nquad,int*qtype,vector cov,vector Uq,
									 vector centres,size_t ncomp,vector Comps,int fillin,vector Ualpha,char*outfile)
{
	std::ofstream outFile;
	outFile.open(outfile,std::ios_base::out);
	if(outFile.fail())
	{
		std::cout<<"Cannot open "<<outfile<<std::endl;
	}
	else
	{
		dumpvector(1,(char*)"n",&n,outFile);
		dumpvector(1,(char*)"m",&m,outFile);
		dumpvector(n,(char*)"alpha",alpha,outFile);
		dumpvector(n*m,(char*)"A",A,outFile);
		dumpvector(n+m,(char*)"L",L,outFile);
		dumpvector(n+m,(char*)"U",U,outFile);
		dumpvector(1,(char*)"full",&full,outFile);
		dumpvector(1,(char*)"rmin",&rmin,outFile);
		dumpvector(1,(char*)"rmax",&rmax,outFile);
		dumpvector(1,(char*)"val",&val,outFile);
		dumpvector(1,(char*)"nabs",&nabs,outFile);
		dumpvector(nabs*n,(char*)"Aabs",Aabs,outFile);
		dumpvector(nabs,(char*)"Labs",Labs,outFile);
		dumpvector(nabs,(char*)"Uabs",Uabs,outFile);
		dumpvector(1,(char*)"signtest",&signtest,outFile);
		dumpvector(1,(char*)"nquad",&nquad,outFile);
		dumpvector(nquad,(char*)"qtype",qtype,outFile);
		size_t nnn=0;
		for(size_t i=0;i<nquad;++i)
		{
			if(qtype[i]==-1) nnn+=n-fillin*ncomp;
			else if(qtype[i]==0) nnn+=(n-fillin*ncomp)*(n+1-fillin*ncomp)/2;
			else nnn+=qtype[i]*(n-fillin*ncomp)+qtype[i]*(qtype[i]+1)/2;
		}
		dumpvector(nnn,(char*)"cov",cov,outFile);
		dumpvector(nquad,(char*)"Uq",Uq,outFile);
		dumpvector(n*nquad,(char*)"centres",centres,outFile);
		if(Ualpha)dumpvector(n*nquad,(char*)"Ualpha",Ualpha,outFile);
		dumpvector(1,(char*)"ncomp",&ncomp,outFile);
		dumpvector((n-ncomp)*ncomp,(char*)"Comps",Comps,outFile);
		dumpvector(1,(char*)"fillin",&fillin,outFile);
		outFile<<"-------------------------------------------------------------------------------------------";
		outFile.close();
		outFile.clear();
	}
}
extern "C" DLLEXPORT void RobustOptDump(size_t n,size_t m,vector w,vector alpha,vector A,
									 vector L,vector U,
									 int full,double rmin,double rmax,double val,
									 size_t nabs,vector Aabs,vector Labs,vector Uabs,
									 int signtest,size_t nquad,int*qtype,vector cov,vector Uq,
									 vector centres,size_t ncomp,vector Comps,int fillin,char*outfile)
{
	RobustOptUDump(n,m,w,alpha,A,L,U,full,rmin,rmax,val,nabs,Aabs,Labs,Uabs,signtest,
			nquad,qtype,cov,Uq,centres,ncomp,Comps,fillin,0,outfile);
}
extern "C" DLLEXPORT short RobustOptU(size_t n,size_t m,vector w,vector alpha,vector A,
									 vector L,vector U,
									 int full,double rmin,double rmax,double val,
									 size_t nabs,vector Aabs,vector Labs,vector Uabs,
									 int signtest,size_t nquad,int*qtype,vector cov,vector Uq,
									 vector centres,size_t ncomp,vector Comps,int fillin,
									 vector Ualpha)
{
//	RobustOptDump(n,m,w,alpha,A,L,U,full,rmin,rmax,val,nabs,Aabs,Labs,Uabs,signtest,nquad,qtype,cov,Uq,centres,ncomp,Comps,fillin,(char*)"s:/checkrobust");
// fillin = 1 means generate the parts in the quadratic contraints for
// composites using their defining weights.
// Otherwise expect the user to have given then in covs
	//Ready for the constraint ||A.x - c|| < |Ualpha.x - Uq|
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	size_t i,fixed_bounds=0;
	std::valarray<size_t>order;
	bool ls=false;
	for(i=0;i<n;++i)
	{
		if(fabs(U[i]-L[i])<equalboundslim)fixed_bounds++;
		else if(L[i]<0)ls=true;
	}
	if(!ls)
	{
		val=0;
		nabs=0;
		rmin=-1;
		rmax=-1;
		signtest=0;
	}
	if(fixed_bounds)
	{
		order.resize(2*n);
		size_t* backorder=&order[n];
		for(i=0;i<n;++i)
		{
			order[i]=i;
		}
		long sofar;
		size_t Nvab=n-fixed_bounds;
		sofar = n-1;
		for(i = 0;sofar>=(long)i;++i)
		{
			while(sofar>=0&&fabs(L[order[sofar]] - U[order[sofar]]) < equalboundslim){sofar--;}
			if(sofar > (long)i && fabs(L[order[i]] - U[order[i]]) < equalboundslim)
			{
				std::swap(order[i],order[sofar]);
			}
		}
		for(i=0;i<n;++i)
			backorder[order[i]]=i;
		Reorder_gen(n,&order[0],alpha,1);
		Reorder_gen(n,&order[0],A,m);
		if(nabs)Reorder_gen(n,&order[0],Aabs,nabs);
		Reorder_gen(n,&order[0],L,1);
		Reorder_gen(n,&order[0],U,1);
	}
	short back= RobustOpt1(n,m,w,alpha,A,L,U,full,rmin,rmax,val,nabs,Aabs,Labs,
		Uabs,signtest,nquad,qtype,cov,Uq,centres,&order[0],ncomp,Comps,fillin,Ualpha);
	if(back==1||signtest)
	{
		signtest=0;
		std::valarray<double>bounds(2*(n+m));
		vector LL=&bounds[0];
		vector UU=&bounds[n+m];
		dcopyvec(m,L+n,LL+n);
		dcopyvec(m,U+n,UU+n);
		for(i=0;i<n;++i)
		{
			if(w[i]<0)
			{
				LL[i]=L[i];
				UU[i]=dmin(0,U[i]);
			}
			else
			{
				LL[i]=dmax(0,L[i]);
				UU[i]=U[i];
			}
		}
		back= RobustOpt1(n,m,w,alpha,A,LL,UU,full,rmin,rmax,val,nabs,Aabs,Labs,
			Uabs,signtest,nquad,qtype,cov,Uq,centres,&order[0],ncomp,Comps,fillin,Ualpha);
	}
	if(fixed_bounds)
	{
		size_t* backorder=&order[n];
		Reorder_gen(n,backorder,alpha,1);
		Reorder_gen(n,backorder,A,m);
		if(nabs)Reorder_gen(n,backorder,Aabs,nabs);
		Reorder_gen(n,backorder,L,1);
		Reorder_gen(n,backorder,U,1);
		Reorder_gen(n,backorder,w,1);
	}
	return back;
}
extern "C" DLLEXPORT short RobustOpt(size_t n,size_t m,vector w,vector alpha,vector A,
									 vector L,vector U,
									 int full,double rmin,double rmax,double val,
									 size_t nabs,vector Aabs,vector Labs,vector Uabs,
									 int signtest,size_t nquad,int*qtype,vector cov,vector Uq,
									 vector centres,size_t ncomp,vector Comps,int fillin)
{
	return RobustOptU(n,m,w,alpha,A,L,U,full,rmin,rmax,val,nabs,Aabs,Labs,Uabs,signtest,nquad,qtype,cov,Uq,centres,
		ncomp,Comps,fillin,0);
}
extern "C" DLLEXPORT void QuadCVals(size_t n,vector w,vector alpha,double*areturn,size_t nquad,int*qtype,vector cov,vector Uq,
									 vector centres,vector U,size_t ncomp=0,vector Comps=0,int fillin=1)
{
#ifdef __SYSNT__
	_ASSERT(0);
#endif

	size_t i,j;
	std::valarray<double>R(n*(n-ncomp*fillin)),active(n),implied(n);
	*areturn=ddotvec(n,alpha,w);
	for(i=0;i<nquad;++i)
	{
		dsubvec(n,w,centres,&active[0]);
		R=0;
		if(qtype[i]==-1)
		{
			for(j=0;j<(n-ncomp*fillin);++j)
				R[j+j*(n-ncomp*fillin)]=cov[j];
			if(ncomp*fillin)
			{
				dmx_transpose(n-ncomp,n-ncomp,&R[0],&R[0]);
				dmx_transpose(n-ncomp,n,&R[0],&R[0]);
				IncreaseL(n,n-ncomp,ncomp,&R[0],Comps);
			}
			dmxtmulv(n,n-ncomp*fillin,&R[0],&active[0],&implied[0]);
			U[i]=sqrt(ddotvec(n-ncomp*fillin,&implied[0],&implied[0]));					
			cov+=(n-ncomp*fillin);
			centres+=n;
		}
		else if(qtype[i]==0)
		{
			RootQ(n-ncomp*fillin,cov,&R[0],0);
			if(ncomp*fillin)
			{
				dmx_transpose(n-ncomp,n-ncomp,&R[0],&R[0]);
				dmx_transpose(n-ncomp,n,&R[0],&R[0]);
				IncreaseL(n,n-ncomp,ncomp,&R[0],Comps);
			}
			implied=0;
			dmxtmulv(n,n-ncomp*fillin,&R[0],&active[0],&implied[0]);
			U[i]=sqrt(ddotvec(n-ncomp*fillin,&implied[0],&implied[0]));	
			cov+=(n-ncomp*fillin)*(n-ncomp*fillin+1)/2;
			centres+=n;
		}
		else if(qtype[i]>0)
		{
			std::valarray<double>rc(qtype[i]*(1+qtype[i])/2);
			std::valarray<short_scl>P(qtype[i]);
			vector v;
			dcopyvec(qtype[i]*(1+qtype[i])/2,cov,&rc[0]);
			dsmxfac(qtype[i], &rc[0], &P[0] );
			cov+=qtype[i]*(qtype[i]+1)/2;
			dmx_transpose(n-ncomp*fillin,qtype[i],cov,&R[0]);
			for(j = 0,v = &R[0];j < n-ncomp*fillin;j++,v += qtype[i])
			{
				dsmxasrt(qtype[i],&rc[0],&P[0],SMXFAC_LEFT_ROOT,v);
			}
			dmx_transpose(qtype[i],n,&R[0],&R[0]);
			if(ncomp*fillin)
			{
				IncreaseL(n,qtype[i],ncomp,&R[0],Comps);
			}
			dmxtmulv(n,qtype[i],&R[0],&active[0],&implied[0]);
			U[i]=sqrt(ddotvec(qtype[i],&implied[0],&implied[0]));					
			cov+=qtype[i]*(n-ncomp*fillin);
			centres+=n;
		}
	}
}
extern void lineprint(FILE* I,const char* name,size_t n,vector data);
extern "C" DLLEXPORT short LPbySOCPp(size_t n,size_t m,vector w,vector c,vector A,vector b)
{
#ifdef LPlog
	FILE*OOO=fopen((char*)"lplog",(char*)"w");
		fprintf(OOO,(char*)"n\n%d\n",n);
		fprintf(OOO,(char*)"m\n%d\n",m);
		lineprint(OOO,(char*)"c",n,c);
		lineprint(OOO,(char*)"A",n*m,A);
		lineprint(OOO,(char*)"b",m,b);
		fclose(OOO);
#endif
	short back;
	short ncone=n;
	std::valarray<double> SA(n*m),Sx(n),Sy(m),Ss(n);
	std::valarray<int> CONES(ncone);
	double tau,kappa;
	double rhoconv=std::pow(lm_eps,.45);
	double changeratio=1;
	size_t i,j;
	int log=1;
	char* logfile=0;
	char* SOCPdump=0;
	int signtest=0;
	CONES=1;
	dmx_transpose(m,n,A,&SA[0]);
	if(!(back=SOCPinfeasHomogt(ncone,m,&CONES[0],c,&SA[0],b,&Sx[0],&Sy[0],
		&Ss[0],&tau,&kappa,100,1e-8,.5,1e-8,1e-8,signtest,changeratio,rhoconv,log,logfile,SOCPdump)))
	{
		if(tau>kappa||(signtest && tau>lm_rooteps))
		{
			for(i=0;i<n;++i)
			{
				w[i]=Sx[i]/ tau;
			}
			if(1)
			{
				printf((char*)"%5s %20s %20s\t%20s %20s\n",(char*)"Cone",(char*)"X top",(char*)"S top",(char*)"X inequality",(char*)"S inequality");
				for(i=0,j=0;i<ncone;++i)
				{
					j+=CONES[i];
					printf((char*)"%5u %20.8e %20.8e\t%20.8e %20.8e\n",i+1,Sx[j-1]/tau,Ss[j-1]/tau,
						(Sx[j-1]-sqrt(ddotvec(CONES[i]-1,&Sx[j-CONES[i]],&Sx[j-CONES[i]])))/tau,
						(Ss[j-1]-sqrt(ddotvec(CONES[i]-1,&Ss[j-CONES[i]],&Ss[j-CONES[i]])))/tau);
				}
			}
		}
		else
		{
			double tt;
			if((tt=ddotvec(m,b,&Sy[0]))>0)
				printf((char*)"b dot y %20.12e primal is infeasible\n",tt);
			if((tt=ddotvec(n,c,&Sx[0]))<0)
				printf((char*)"c dot x %20.12e dual is infeasible\n",tt);
			back=2;
		}
	}
	else
	{
		printf((char*)"SOCP failed\n");back = 3;
	}
	return back;	
}
extern "C" short LPFullNewton(size_t n,size_t m,vector w,vector c,vector A,vector b,double xci=1,double tau=0.125,double eps=0);
extern "C" DLLEXPORT short LPbySOCP(size_t n,size_t m,vector w,vector c,vector A,vector L,vector U)
{
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	size_t i,j,k,l;
	std::valarray<double>LU(n+m);
	dsubvec(n+m,U,L,&LU[0]);
	std::vector<size_t> sx,sA;
	for(i=0;i<n;++i)
	{
		if(LU[i]>1e-14)sx.push_back(i);
	}
	for(i=0;i<m;++i)
	{
		if(LU[i+n]>1e-14)sA.push_back(i);
	}
	size_t N=n+sx.size()+2*sA.size();
	size_t M=m+sA.size()+sx.size();
	std::valarray<double>AA(N*M),C(N),W(N);AA=0,C=0;
	dcopyvec(n,c,&C[0]);
	for(i=0,k=0;i<n;++i)
	{
		for(j=0,l=0;j<m;++j)
		{
			AA[i*M+j]=A[i*m+j];
			if(sA[l]==j)
				AA[i*M+l++ +m]=A[i*m+j];
		}
		if(sx[k]==i)
		{
			AA[(k+n+2*sA.size())*M+k +m+sA.size()]=1e3;
			AA[i*M+k +m+sA.size()]=1;k++;
		}
	}
	for(j=0,l=0;j<m;++j)
	{
		if(sA[l]==j)
		{
			AA[(l+n)*M+j]=1e4;//Upper
			AA[(l+n+sA.size())*M+l+m]=-1e4;l++;//Lower
		}
	}
	std::valarray<double>LL(m),UU(M);
	dmxtmultv(n,m,A,L,&LL[0]);
	for(i=0,k=0;i<n;++i)
	{
		if(sx[k]==i)
		{
			UU[k+m+sA.size()]=U[i]-L[i];
			k++;
		}
	}
	for(i=0,l=0;i<m;++i)
	{
		UU[i]=U[i+n]-LL[i];
		if(sA[l]==i)
		{
			UU[l++ +m]=L[i+n]-LL[i];
		}
	}

	//short back=LPFullNewton(N,M,&W[0],&C[0],&AA[0],&UU[0]);
	short back=LPbySOCPp(N,M,&W[0],&C[0],&AA[0],&UU[0]);
//	Lsmooth(N,M,&W[0],&C[0],&AA[0],&UU[0],1);short back=0;
	daddvec(n,L,&W[0],w);
	return back;
}
extern "C" DLLEXPORT short QPbySOCP(size_t n,size_t m,vector w,vector A,vector L,vector U,
						  vector alpha,vector Q,vector S,double tRad)
{
#ifdef __SYSNT__
	_ASSERT(0);
#endif
/*	Maximise alpha'.w - 0.5*w'.Q.w

	subject to
	L[i] <= w[i] <= U[i]
	L[j+m] <= sum(A[j+m*i]*w[i]) <=U[j+m]
	w'.S'S.w <= tRad*tRad (S is diagonal)
	if(tRad<0) ignore last constraint
*/
	bool linear=(!Q||(Q&&trace(n,Q)<(n+1)*lm_rooteps));
	size_t i,j;
	if(m>1)dmx_transpose(m,n,A,A);
	std::valarray<double>RQ,RQm1;
	std::valarray<double>RScal;
	std::valarray<double> ralpha;
	if(!linear)
	{
		RQ.resize(n*n);
		RQm1.resize(n*n);
		RootQ(n,Q,&RQ[0],&RQm1[0]);
		ralpha.resize(n);
		dmxtmulv(n,n,&RQm1[0],alpha,&ralpha[0]);
	}
	if(tRad>0)
	{
		RScal.resize(n*n);
		RScal=0;
		for(i=0;i<n;++i)RScal[i+i*n]=S[i];
	}


	/*
	n+m  linear constraints				n+m  2-d cones
	0,1 or 2   quadratic constraints		0,1 or 2 n+1-d cones
	*/


	std::valarray<int> CONES;
	std::valarray<double> SA,Sc,Sb,Sx,Sy,Ss;
	size_t ncone,ndual=n+(size_t)(!linear),nn;
	double tau,kappa;
	ncone=n+m+(tRad>0)+(size_t)(!linear);
	CONES.resize(ncone);
	for(i=0,nn=0;i<n+m;++i)
	{
		nn+=CONES[i]=2;
	}
	if(!linear)nn+=CONES[n+m]=n+1;
	if(tRad>0)nn+=CONES[n+m+(size_t)(!linear)]=n+1;
	SA.resize(nn*ndual);
	Sc.resize(nn);
	SA=0;
	Sc=0;
	size_t ic;
	vector pA;
	//Variable bounds
	for(i=0,ic=0;i<n;++i)
	{
		SA[i+ic*ndual]=1;
		Sc[ic++]=.5*(L[i]+U[i]);
//		SA[i+ic*ndual]=0;
		Sc[ic++]=.5*(U[i]-L[i]);
	}
	//General linear constraints
	for(i=0,pA=A;i<m;++i,pA+=n)
	{
		dcopyvec(n,pA,&SA[ic*ndual]);
		Sc[ic++]=.5*(L[i+n]+U[i+n]);
//		SA[i+ic*ndual]=0;
		Sc[ic++]=.5*(U[i+n]-L[i+n]);
	}
	//-alphaw+.5*wQw<t+something
	if(!linear)
	{
		for(i=0;i<n;++i)dcopyvec((ndual-1),&RQ[i*(ndual-1)],&SA[(ic+i)*ndual]);
		dcopyvec(n,&ralpha[0],&Sc[ic]);
		ic+=n;
		SA[ic*ndual+ndual-1]=1;
		Sc[ic++]=0;
	}
	//||Sw||<tRad
	if(tRad>0)
	{
		for(i=0;i<n;++i)dcopyvec((ndual-(size_t)(!linear)),&RScal[i*(ndual-(size_t)(!linear))],&SA[(ic+i)*ndual]);
		ic+=n;
		Sc[ic++]=tRad;
	}
	dmx_transpose(ndual,nn,&SA[0],&SA[0]);
	if(m>1)dmx_transpose(n,m,A,A);//Change it back
	Sb.resize(ndual);
	if(linear)//maximise alphaw
		dcopyvec(n,alpha,&Sb[0]);
	else//maximise t
	{
		Sb=0;
		Sb[ndual-1]=1;
	}
	Sx.resize(nn);
	Sy.resize(ndual);
	Ss.resize(nn);
	bool bad=0;
	short back;
	double checktol=100000*lm_eps;
	double rhoconv=std::pow(lm_eps,.45);
	RQ.resize(0);
	RScal.resize(0);
	double changeratio=4;
	int log=1;
	char* logfile=0;
	char* SOCPdump=0;
	int signtest=0;
	if(!(back=SOCPinfeasHomogt(ncone,ndual,&CONES[0],&Sc[0],&SA[0],&Sb[0],&Sx[0],&Sy[0],
		&Ss[0],&tau,&kappa,100,1e-8,.5,1e-8,1e-8,signtest,changeratio,rhoconv,log,logfile,SOCPdump)))
	{
		if(tau>kappa||(signtest && tau>lm_rooteps))
		{
			checktol *= (tau*tau);
			for(i=0,j=n;i<n;++i)
			{
					w[i]=Sy[i]/ tau;
			}
			back+=(short)bad;
			if(0)
			{
				printf((char*)"%5s %20s %20s\t%20s %20s\n",(char*)"Cone",(char*)"X top",(char*)"S top",(char*)"X inequality",(char*)"S inequality");
				for(i=0,j=0;i<ncone;++i)
				{
					j+=CONES[i];
					printf((char*)"%5u %20.8e %20.8e\t%20.8e %20.8e\n",i+1,Sx[j-1]/tau,Ss[j-1]/tau,
						(Sx[j-1]-sqrt(ddotvec(CONES[i]-1,&Sx[j-CONES[i]],&Sx[j-CONES[i]])))/tau,
						(Ss[j-1]-sqrt(ddotvec(CONES[i]-1,&Ss[j-CONES[i]],&Ss[j-CONES[i]])))/tau);
				}
			}
		}
		else
		{
			double tt;
			if((tt=ddotvec(ndual,&Sb[0],&Sy[0]))>0)
				printf((char*)"b dot y %20.12e primal is infeasible\n",tt);
			if((tt=ddotvec(nn,&Sc[0],&Sx[0]))<0)
				printf((char*)"c dot x %20.12e dual is infeasible\n",tt);
			back=2;
		}
	}
	else
	{
		printf((char*)"SOCP failed\n");back = 3;
	}
	

	//if(bad)printf((char*)"The long short value condition was not met correctly this time\n");
	return back;	
}
extern "C" DLLEXPORT int AQAmake(size_t n,size_t m,vector A,vector Q,vector X,vector S,vector MAT)
{
	/*
	Find the symmetric matrix A*inverse(Q+S/X)*AT
	*/
	size_t nn=n*(n+1)>>1;
	size_t mm=m*(m+1)>>1;
	std::valarray<double>QQ(nn);
	std::valarray<double>Acopy(n*m);
	std::valarray<short_scl>QQ_P(n);
	dcopyvec(nn,Q,&QQ[0]);
	long i,ii,k;
	vector pQ,pX,pS;
	for(i=0,pQ=&QQ[0],pS=S,pX=X;i<n;++i)
	{
		*pQ+=*pS/ *pX;
		pQ+=i+2;
		pS++;
		pX++;
	}
	int badindex=bunchf(n,&QQ[0],&QQ_P[0]);
	dzerovec(mm,MAT);
	dmx_transpose(m,n,A,&Acopy[0]);
	for(i=0;i<m;++i) dsptrs((char*)"U",n,1,&QQ[0],&QQ_P[0],&Acopy[i*n],n);
	dmx_transpose(n,m,&Acopy[0],&Acopy[0]);
#pragma omp parallel
	{
#pragma omp for private(i,ii,k) schedule(dynamic) nowait
		for(i=0;i<m;++i)
		{
			ii=i*(i+1)>>1;
			for(k=0;k<n;++k)
			{
				if(A[i+k*m])
				{
					daxpyvec(i+1,A[i+k*m],&Acopy[k*m],MAT+ii);
				}
			}
		}
	}
	return badindex;
}
extern "C" DLLEXPORT void AAmake(size_t n,size_t m,vector A,vector MAT)
{
	size_t mm=m*(m+1)>>1;
	long i,ii,k;
	dzerovec(mm,MAT);
#pragma omp parallel
	{
#pragma omp for private(i,ii,k) schedule(dynamic) nowait
		for(i=0;i<m;++i)
		{
			ii=i*(i+1)>>1;
			for(k=0;k<n;++k)
			{
				if(A[i+k*m])
				{
					daxpyvec(i+1,A[i+k*m],A+k*m,MAT+ii);
				}
			}
		}
	}
}
extern  "C" DLLEXPORT int FixedAtEnd(size_t n,vector L,vector U,size_t *order)
{
//Find the order that puts the fixed stocks at the end with high index
	size_t i,fixed_bounds=0,*ord;
	for(i=0;i<n;++i)
	{
		if(fabs(U[i]-L[i])<equalboundslim){fixed_bounds++;}
	}
	if(fixed_bounds)
	{
		for(i=0;i<n;++i)order[i]=i;
		long sofar;
		sofar = n-1;
		for(i = 0,ord=order;sofar>=(long)i;++i,ord++)
		{
			while(sofar>=0&&fabs(L[order[sofar]] - U[order[sofar]]) < equalboundslim){sofar--;}
			if(sofar > (long)i && fabs(L[*ord] - U[*ord]) < equalboundslim){std::swap(*ord,order[sofar]);}
		}
	}
	return fixed_bounds;
}
void error_here(char*mess,bool&err)
{
	printf((char*)"%s\n",mess);
	err=true;
}
short SOCPportinnerT(void*info);
short SOCPportinnerB(void*info);
short SOCPportinner(void*info);
short SOCPportinnerBT(void*info);
double SOCPportutil(void*info);
void SOCPportgrad(void*info);
bool treestart(class OptParamRound*info,bool passedfromthresh,vector initial,vector minlot,
						vector sizelot,vector roundw,vector thresh=0);

extern "C" short SOCPportfolio_internal(size_t n,size_t m,vector w,vector L,vector U,vector A,vector alpha,
		vector benchmark=0,vector initial=0,vector buy=0,vector sell=0,int costs=0,double delta=-1,
		double psum=-1,double psumL=-1,double nsum=1,double nsumU=1,double rmax=-1,double rmin=-1,
		size_t mabs=0,vector A_abs=0,vector L_abs=0,
		vector U_abs=0,vector FC=0,long nfac=-1,vector FL=0,vector SV=0,double maxrisk=-1,double maxarisk=-1,
		int meanstd=0,double meanstdl=0,double*lambda1=0,double*lambda2=0,double*lambda3=0,double*optvalue=0,
		char*inputData=(char*)"log1",int log=1,char*logfile=0,vector min_trade=0,vector min_hold=0,long basket=-1,long trades=-1,
		vector minlot=0,vector sizelot=0)
{
/*	printf((char*)"%s\n",inputData);
	printf((char*)"%d\n",log);
	printf((char*)"%s\n",logfile);*/
	std::ofstream outFile;
	std::valarray<double>facQ;
	double infolambda=.5;

	if(inputData && strlen(inputData))
	{
		outFile.open(inputData,std::ios_base::out);
		if(outFile.fail())
		{
			std::cout<<"Cannot open "<<inputData<<std::endl;
		}
		else
		{
			dumpvector(1,(char*)"n",&n,outFile);
			dumpvector(1,(char*)"m",&m,outFile);
			dumpvector(n+m,(char*)"L",L,outFile);
			dumpvector(n+m,(char*)"U",U,outFile);
			dumpvector(n*m,(char*)"A",A,outFile);
			dumpvector(n,(char*)"alpha",alpha,outFile);
			dumpvector(n,(char*)"benchmark",benchmark,outFile);
			dumpvector(n,(char*)"initial",initial,outFile);
			dumpvector(n,(char*)"buy",buy,outFile);
			dumpvector(n,(char*)"sell",sell,outFile);
			dumpvector(1,(char*)"costs",&costs,outFile);
			dumpvector(1,(char*)"delta",&delta,outFile);
			dumpvector(1,(char*)"psum",&psum,outFile);
			dumpvector(1,(char*)"psumL",&psumL,outFile);
			dumpvector(1,(char*)"nsum",&nsum,outFile);
			dumpvector(1,(char*)"nsumU",&nsumU,outFile);
			dumpvector(1,(char*)"rmax",&rmax,outFile);
			dumpvector(1,(char*)"rmin",&rmin,outFile);
			dumpvector(1,(char*)"mabs",&mabs,outFile);
			dumpvector(1,(char*)"basket",&basket,outFile);
			dumpvector(1,(char*)"trades",&trades,outFile);
			dumpvector(n*mabs,(char*)"A_abs",A_abs,outFile);
			dumpvector(mabs,(char*)"L_abs",L_abs,outFile);
			dumpvector(mabs,(char*)"U_abs",U_abs,outFile);
			if(nfac>-1&&!FL&&!SV&&FC)
				dumpvector(n*(nfac+1),(char*)"FC",FC,outFile);
			else
				dumpvector((nfac>-1?nfac*(nfac+1)/2:n*(n+1)/2),(char*)"FC",FC,outFile);
			dumpvector(1,(char*)"nfac",&nfac,outFile);
			dumpvector((nfac>-1?nfac*n:0),(char*)"FL",FL,outFile);
			dumpvector((nfac>-1?n:0),(char*)"SV",SV,outFile);
			dumpvector(1,(char*)"maxrisk",&maxrisk,outFile);
			dumpvector(1,(char*)"maxarisk",&maxarisk,outFile);
			dumpvector(1,(char*)"meanstd",&meanstd,outFile);
			dumpvector(1,(char*)"meanstdl",&meanstdl,outFile);
			dumpvector(n,(char*)"min_trade",min_trade,outFile);
			dumpvector(n,(char*)"min_hold",min_hold,outFile);
			dumpvector(n,(char*)"minlot",minlot,outFile);
			dumpvector(n,(char*)"sizelot",sizelot,outFile);
			outFile<<"-------------------------------------------------------------------------------------------";
			outFile.close();
			outFile.clear();
		}
	}
	if(minlot&&sizelot==0)
	{
		minlot=0;
		printf((char*)"Roundlots ignored as sizelot array has not been allocated\n");
	}
	if(minlot)
	{
		std::valarray<double>xx(n);
		OptParamRound ThOpt;
		ExtraR SOCPo;
		ThOpt.MoreInfo=(void*)&SOCPo;
		if(log)ThOpt.SetLog();
		ThOpt.n=n;
		ThOpt.m=m;
		ThOpt.basket=basket;
		ThOpt.trades=trades;
		ThOpt.upper=U;
		ThOpt.lower=L;
		ThOpt.x=&xx[0];
		ThOpt.OptFunc=SOCPportinnerBT;
		ThOpt.UtilityFunc=SOCPportutil;
		ThOpt.GradFunc=SOCPportgrad;
		ThOpt.mabs=mabs;
		ThOpt.lp=false;
		ThOpt.longbasket=-1;
		ThOpt.shortbasket=-1;
		ThOpt.tradebuy=-1;
		ThOpt.tradesell=-1;
		ThOpt.initial=initial;
		ThOpt.equalbounds=equalboundslim;
		ThOpt.dropfac=.5;
		SOCPo.A=A;
		SOCPo.alpha=alpha;
		SOCPo.benchmark=benchmark;
		SOCPo.initial=initial;
		SOCPo.buy=buy;
		SOCPo.sell=sell;
		SOCPo.costs=costs;
		SOCPo.delta=delta;
		SOCPo.psum=psum;
		SOCPo.psumL=psumL;
		SOCPo.nsum=nsum;
		SOCPo.nsumU=nsumU;
		SOCPo.rmax=rmax;
		SOCPo.rmin=rmin;
		SOCPo.mabs=mabs;
		SOCPo.A_abs=A_abs;
		SOCPo.L_abs=L_abs;
		SOCPo.U_abs=U_abs;
		SOCPo.FC=FC;
		SOCPo.nfac=nfac;
		SOCPo.FL=FL;
		SOCPo.SV=SV;
		SOCPo.maxrisk=maxrisk;
		SOCPo.maxarisk=maxarisk;
		SOCPo.meanstd=meanstd;
		SOCPo.meanstdl=meanstdl;
		SOCPo.lambda1=lambda1;
		SOCPo.lambda2=lambda2;
		SOCPo.lambda3=lambda3;
		SOCPo.optvalue=optvalue;
		SOCPo.log=log;
		SOCPo.logfile=logfile;
		SOCPo.min_trade=min_trade;
		SOCPo.min_hold=min_hold;
		SOCPo.longbasket=-1;
		SOCPo.shortbasket=-1;
		SOCPo.tradebuy=-1;
		SOCPo.tradesell=-1;
		SOCPo.equalbounds=equalboundslim;
		ThOpt.dropfac=.5;
		short back,back1;
		bool bad=false,changed=false;
		for(size_t i=0;i<n;++i)
		{
			double init=(initial?initial[i]:0);
			if(ThOpt.upper[i] < minlot[i]+init) 
			{
				if(init<ThOpt.upper[i]){ThOpt.upper[i]=dmin(ThOpt.upper[i],(dmax(init,ThOpt.lower[i])));changed=1;}
				else if (init>ThOpt.upper[i]){ThOpt.upper[i]=dmin(ThOpt.upper[i],(dmax(init-minlot[i],ThOpt.lower[i])));changed=1;}
			}
			if(ThOpt.lower[i] > init-minlot[i]) 
			{
				if(init>ThOpt.lower[i]){ThOpt.lower[i]=dmax(ThOpt.lower[i],(dmin(init,ThOpt.upper[i])));changed=1;}
				else if(init < ThOpt.lower[i]){ThOpt.lower[i]=dmax(ThOpt.lower[i],(dmin(init+minlot[i],ThOpt.upper[i])));changed=1;}
			}
			if(ThOpt.lower[i]>ThOpt.upper[i])bad=true;
		}
		if(bad) return 2;
		back=back1=SOCPportinnerBT(&ThOpt);
		bool rounded=treestart(&ThOpt,false,initial,minlot,sizelot,w);
		ThOpt.back=(ThOpt.back==6?2:ThOpt.back);
		if(rounded)return ThOpt.back;
		else return 2;
	}
	for(int way=1,route;way<=2;way++)
	{
		route=3-way;		//Basket then thresh
		//		route=way;			//Thresh then basket
		if(route==1)
		{
			if(min_trade && min_hold)
			{
				std::valarray<double>xx(n);
				OptParamRound ThOpt;
				ExtraR SOCPo;
				ThOpt.MoreInfo=(void*)&SOCPo;
				ThOpt.n=n;
				ThOpt.m=m;
				ThOpt.upper=U;
				ThOpt.lower=L;
				ThOpt.x=&xx[0];
				ThOpt.OptFunc=(way==1?SOCPportinnerB:SOCPportinner);
				ThOpt.UtilityFunc=SOCPportutil;
				ThOpt.GradFunc=SOCPportgrad;
				if(log)ThOpt.SetLog();
				SOCPo.A=A;
				SOCPo.alpha=alpha;
				SOCPo.benchmark=benchmark;
				SOCPo.initial=initial;
				SOCPo.buy=buy;
				SOCPo.sell=sell;
				SOCPo.costs=costs;
				SOCPo.delta=delta;
				SOCPo.psum=psum;
				SOCPo.psumL=psumL;
				SOCPo.nsum=nsum;
				SOCPo.nsumU=nsumU;
				SOCPo.rmax=rmax;
				SOCPo.rmin=rmin;
				SOCPo.mabs=mabs;
				SOCPo.A_abs=A_abs;
				SOCPo.L_abs=L_abs;
				SOCPo.U_abs=U_abs;
				SOCPo.FC=FC;
				SOCPo.nfac=nfac;
				SOCPo.FL=FL;
				SOCPo.SV=SV;
				SOCPo.maxrisk=maxrisk;
				SOCPo.maxarisk=maxarisk;
				SOCPo.meanstd=meanstd;
				SOCPo.meanstdl=meanstdl;
				SOCPo.lambda1=lambda1;
				SOCPo.lambda2=lambda2;
				SOCPo.lambda3=lambda3;
				SOCPo.optvalue=optvalue;
				SOCPo.log=log;
				SOCPo.logfile=logfile;
				SOCPo.min_trade=min_trade;
				SOCPo.min_hold=min_hold;
				SOCPo.longbasket=-1;
				SOCPo.shortbasket=-1;
				SOCPo.tradebuy=-1;
				SOCPo.tradesell=-1;
				SOCPo.basket=basket;
				SOCPo.trades=trades;
				SOCPo.equalbounds=equalboundslim;
				ThOpt.dropfac=.5;
				Thresh(&ThOpt,initial,min_trade,w,min_hold);
				return (ThOpt.back==6?2:ThOpt.back);
			}
			else if(min_trade)
			{
				std::valarray<double>xx(n);
				OptParamRound ThOpt;
				ExtraR SOCPo;
				ThOpt.MoreInfo=(void*)&SOCPo;
				if(log)ThOpt.SetLog();
				ThOpt.n=n;
				ThOpt.m=m;
				ThOpt.upper=U;
				ThOpt.lower=L;
				ThOpt.x=&xx[0];
				ThOpt.OptFunc=(way==1?SOCPportinnerB:SOCPportinner);
				ThOpt.UtilityFunc=SOCPportutil;
				SOCPo.A=A;
				SOCPo.alpha=alpha;
				SOCPo.benchmark=benchmark;
				SOCPo.initial=initial;
				SOCPo.buy=buy;
				SOCPo.sell=sell;
				SOCPo.costs=costs;
				SOCPo.delta=delta;
				SOCPo.psum=psum;
				SOCPo.psumL=psumL;
				SOCPo.nsum=nsum;
				SOCPo.nsumU=nsumU;
				SOCPo.rmax=rmax;
				SOCPo.rmin=rmin;
				SOCPo.mabs=mabs;
				SOCPo.A_abs=A_abs;
				SOCPo.L_abs=L_abs;
				SOCPo.U_abs=U_abs;
				SOCPo.FC=FC;
				SOCPo.nfac=nfac;
				SOCPo.FL=FL;
				SOCPo.SV=SV;
				SOCPo.maxrisk=maxrisk;
				SOCPo.maxarisk=maxarisk;
				SOCPo.meanstd=meanstd;
				SOCPo.meanstdl=meanstdl;
				SOCPo.lambda1=lambda1;
				SOCPo.lambda2=lambda2;
				SOCPo.lambda3=lambda3;
				SOCPo.optvalue=optvalue;
				SOCPo.log=log;
				SOCPo.logfile=logfile;
				SOCPo.min_trade=min_trade;
				SOCPo.min_hold=min_hold;
				SOCPo.longbasket=-1;
				SOCPo.shortbasket=-1;
				SOCPo.tradebuy=-1;
				SOCPo.tradesell=-1;
				SOCPo.basket=basket;
				SOCPo.trades=trades;
				SOCPo.equalbounds=equalboundslim;
				ThOpt.dropfac=.5;
				Thresh(&ThOpt,initial,min_trade,w);
				return (ThOpt.back==6?2:ThOpt.back);
			}
			else if(min_hold)
			{
				std::valarray<double>xx(n);
				OptParamRound ThOpt;
				ExtraR SOCPo;
				ThOpt.MoreInfo=(void*)&SOCPo;
				if(log)ThOpt.SetLog();
				ThOpt.n=n;
				ThOpt.m=m;
				ThOpt.upper=U;
				ThOpt.lower=L;
				ThOpt.x=&xx[0];
				ThOpt.OptFunc=(way==1?SOCPportinnerB:SOCPportinner);
				ThOpt.UtilityFunc=SOCPportutil;
				SOCPo.A=A;
				SOCPo.alpha=alpha;
				SOCPo.benchmark=benchmark;
				SOCPo.initial=initial;
				SOCPo.buy=buy;
				SOCPo.sell=sell;
				SOCPo.costs=costs;
				SOCPo.delta=delta;
				SOCPo.psum=psum;
				SOCPo.psumL=psumL;
				SOCPo.nsum=nsum;
				SOCPo.nsumU=nsumU;
				SOCPo.rmax=rmax;
				SOCPo.rmin=rmin;
				SOCPo.mabs=mabs;
				SOCPo.A_abs=A_abs;
				SOCPo.L_abs=L_abs;
				SOCPo.U_abs=U_abs;
				SOCPo.FC=FC;
				SOCPo.nfac=nfac;
				SOCPo.FL=FL;
				SOCPo.SV=SV;
				SOCPo.maxrisk=maxrisk;
				SOCPo.maxarisk=maxarisk;
				SOCPo.meanstd=meanstd;
				SOCPo.meanstdl=meanstdl;
				SOCPo.lambda1=lambda1;
				SOCPo.lambda2=lambda2;
				SOCPo.lambda3=lambda3;
				SOCPo.optvalue=optvalue;
				SOCPo.log=log;
				SOCPo.logfile=logfile;
				SOCPo.min_trade=min_trade;
				SOCPo.min_hold=min_hold;
				SOCPo.longbasket=-1;
				SOCPo.shortbasket=-1;
				SOCPo.tradebuy=-1;
				SOCPo.tradesell=-1;
				SOCPo.basket=basket;
				SOCPo.trades=trades;
				SOCPo.equalbounds=equalboundslim;
				ThOpt.dropfac=.5;
				Thresh(&ThOpt,0,min_hold,w);
				return (ThOpt.back==6?2:ThOpt.back);
			}
		}
		else if(route==2)
		{
			if(basket>0||trades>0)
			{
				std::valarray<double>xx(n);
				OptParamRound ThOpt;
				if(log)ThOpt.SetLog();
				ExtraR SOCPo;
				ThOpt.MoreInfo=(void*)&SOCPo;
				ThOpt.n=n;
				ThOpt.m=m;
				ThOpt.upper=U;
				ThOpt.lower=L;
				ThOpt.x=&xx[0];
				ThOpt.OptFunc=(way==2?SOCPportinner:SOCPportinnerT);
				ThOpt.UtilityFunc=SOCPportutil;
				ThOpt.GradFunc=SOCPportgrad;
				ThOpt.mabs=mabs;
				ThOpt.lp=false;
				ThOpt.longbasket=-1;
				ThOpt.shortbasket=-1;
				ThOpt.tradebuy=-1;
				ThOpt.tradesell=-1;
				ThOpt.initial=initial;
				ThOpt.equalbounds=equalboundslim;
				ThOpt.dropfac=.5;
				SOCPo.A=A;
				SOCPo.alpha=alpha;
				SOCPo.benchmark=benchmark;
				SOCPo.initial=initial;
				SOCPo.buy=buy;
				SOCPo.sell=sell;
				SOCPo.costs=costs;
				SOCPo.delta=delta;
				SOCPo.psum=psum;
				SOCPo.psumL=psumL;
				SOCPo.nsum=nsum;
				SOCPo.nsumU=nsumU;
				SOCPo.rmax=rmax;
				SOCPo.rmin=rmin;
				SOCPo.mabs=mabs;
				SOCPo.A_abs=A_abs;
				SOCPo.L_abs=L_abs;
				SOCPo.U_abs=U_abs;
				SOCPo.FC=FC;
				SOCPo.nfac=nfac;
				SOCPo.FL=FL;
				SOCPo.SV=SV;
				SOCPo.maxrisk=maxrisk;
				SOCPo.maxarisk=maxarisk;
				SOCPo.meanstd=meanstd;
				SOCPo.meanstdl=meanstdl;
				SOCPo.lambda1=lambda1;
				SOCPo.lambda2=lambda2;
				SOCPo.lambda3=lambda3;
				SOCPo.optvalue=optvalue;
				SOCPo.log=log;
				SOCPo.logfile=logfile;
				SOCPo.min_trade=min_trade;
				SOCPo.min_hold=min_hold;
				SOCPo.longbasket=-1;
				SOCPo.shortbasket=-1;
				SOCPo.tradebuy=-1;
				SOCPo.tradesell=-1;
				SOCPo.equalbounds=equalboundslim;
				short back,back1;
				ThOpt.OptFunc(&ThOpt);
				back=back1=ThOpt.back;
				if(back>1)return 2;
				std::valarray<double>first(ThOpt.n);
				dcopyvec(ThOpt.n,ThOpt.x,&first[0]);
				back=back1=Droptwo(&ThOpt,(dimen)basket,(dimen)(trades),true);
				double u,u1=SOCPportutil(&ThOpt);
				std::valarray<double>interim(ThOpt.n);
				dcopyvec(ThOpt.n,ThOpt.x,&interim[0]);
				ThOpt.AddLog((char*)"Drop2 stage 1 back %d u=%20.8e\n",back,u1);
				if((basket<ThOpt.n&&(long)basket>=0)&&(trades<ThOpt.n&&(long)trades>=0))
				{
					dcopyvec(ThOpt.n,&first[0],ThOpt.x);ThOpt.back=0;
					if(Droptwo(&ThOpt,(dimen)basket,(dimen)(-1),true)<2)
					{
						back=Droptwo(&ThOpt,(dimen)basket,(dimen)(trades),true);
						u=SOCPportutil(&ThOpt);
						ThOpt.AddLog((char*)"Drop2 stage 2 back %d u=%20.8e\n",back,u);
						if(back1<2&&(u>u1||back>1))
						{
							ThOpt.AddLog((char*)"Keep solution with u=%20.8e\n",u1);
							dcopyvec(ThOpt.n,&interim[0],ThOpt.x);
							back=back1;
						}
						else
						{
							back1=back;//David Jessop's quick solution is best
							u1=u;
							ThOpt.AddLog((char*)"Keep solution with u=%20.8e\n",u1);
							dcopyvec(ThOpt.n,ThOpt.x,&interim[0]);
						}
					}
					dcopyvec(ThOpt.n,&first[0],ThOpt.x);ThOpt.back=0;
					if(Droptwo(&ThOpt,(dimen)-1,(dimen)(trades),true)<2)
					{
						back=Droptwo(&ThOpt,(dimen)basket,(dimen)(trades),true);
						u=SOCPportutil(&ThOpt);
						ThOpt.AddLog((char*)"Drop2 stage 3 back %d u=%20.8e\n",back,u);
						if(back1<2&&(u>u1||back>1))
						{
							ThOpt.AddLog((char*)"Use solution with u=%20.8e\n",u1);
							dcopyvec(ThOpt.n,&interim[0],ThOpt.x);
							back=back1;
						}
					}
					else
					{
						ThOpt.AddLog((char*)"Use solution with u=%20.8e\n",u1);
						dcopyvec(ThOpt.n,&interim[0],ThOpt.x);
						back=back1;
					}
				}
				dcopyvec(ThOpt.n,ThOpt.x,w);
				return (back==6?2:back);
			}
		}
	}
	int maxinfo=0;
	std::valarray<double>keepw;

	/*
	If meanstd is given the value 2 the sharp ratio is maximised (if no benchmark) or the information ration (if there is a benchmark)
	This is done by varying the mean std lambda, optimising the weights esach time so as to maximise the ratio. At the maximum the ratio is
	equal to the mean std lambda.

	When there is no benchmark and there are no fixing constraints we note that return(w)/risk(w) = return(kw)/risk(kw) for any k > 0.
	So there is a trick, change the optimisation variable to ww=k*w, constrain return(ww) to 1, add a dummy variable ww[N+1], change the 
	constraints to A.ww - b*ww[N+1] = 0
	Optimise once
	ww[N+1] has an optimal value of k, so now we know what k is
	so w = ww / k
	If there is a benchmark we find return(ww - kb)/risk(ww - kb) = return(kw - kb)/risk(kw - wb) works as long as the benchmark is not feasible. 
	If the benchmark is feasible then the ratio is not well defined and the method will fail.
	*/

	if(meanstd==2)
	{
		maxrisk=-1;
		maxarisk=-1;
		maxinfo=1;
		meanstd=0;
		if(benchmark&&ddotvec(n,benchmark,benchmark)<=lm_eps8)
			benchmark=0;
		if(initial&&ddotvec(n,initial,initial)<=lm_eps8)
			initial=0;
	}
	if(maxinfo&&nfac>-1)
	{
		facQ.resize(n*(nfac+1));
		factor_model_process(n,nfac,FL,FC,SV,&facQ[0]);
	}
	if(meanstdl < 0)meanstd=0;
	bool errors=false;

	std::valarray<size_t>order(2*n);
	std::valarray<double>Q,R,benchtr,fixedrisk;
	size_t *backorder=&order[n],i,nn=n*(n+1)>>1,j,ij,k;
	int fixed=FixedAtEnd(n,L,U,&order[0]);

	if(maxinfo/*&&!benchmark*//*&&!initial*/&&!buy&&!sell&&!costs/*&&delta==-1*//*&&mabs==0*//*&&fixed==0*//*&&m<n*/)
	{
		bool feas=false;
		if(benchmark)
		{
			feas=true;
/*			if(fixed)//This is more restrictive but can be necessary if the SOC optimisation below does not converge
			{
				for(j=0;j<n-fixed;++j)
				{
					i=order[j];
					if(!(benchmark[i]+equalboundslim>=L[i] && benchmark[i]-equalboundslim<=U[i]))
						feas=false;
				}
			}
			else*/
			{
				for(i=0;i<n;++i)
				{
					if(!(benchmark[i]+equalboundslim>=L[i] && benchmark[i]-equalboundslim<=U[i]))
					{
						feas=false;break;
					}
				}
				if(m)
				{
					std::valarray<double>Ab(m);
					dmxmulv(m,n,A,benchmark,&Ab[0]);
					for(i=0;i<m;++i)
					{
						if(!(Ab[i]+equalboundslim>=L[i+n] && Ab[i]-equalboundslim<=U[i+n]))
						{
							feas=false;break;
						}
					}
				}
			}
		}
		else if(m)
		{
			feas=true;
			for(i=0;i<m;++i)
			{
				if(!(equalboundslim>=L[i+n] && -equalboundslim<=U[i+n]))
				{
					feas=false;break;
				}
			}
		}
		if(!feas)
		{
			maxinfo=2;//We can only use the fast method if we're lucky!
			infolambda=1;
		}
	}
	if(maxinfo==1)
		keepw.resize(n);
/*
	if(fixed)//The simple minded way to "fix" a variable
	{
		for(i=0;i<n;++i)
		{
			if(L[i]==U[i])U[i]+=lm_rooteps;
		}
		fixed=0;
	}
*/

	size_t N=n-fixed;
	if(!N)
	{
		return 4;
	}
	vector RQ=0;
	size_t l1,l2,l3,lturn;
	if(maxrisk>0||meanstd>0||benchmark&&maxinfo)benchtr.resize(n);
	if(fixed)
	{
		for(i=0;i<n;++i)backorder[order[i]]=i;
		if(m)
		{
			if(!A)error_here((char*)"No Constraints",errors);
			Reorder_gen(n,&order[0],A,m);
		}
		if(mabs)
		{
			if(!A_abs)error_here((char*)"No Absolute Constraints",errors);
			Reorder_gen(n,&order[0],A_abs,mabs);
		}
		Reorder(n,&order[0],L);
		Reorder(n,&order[0],U);
		Reorder(n,&order[0],alpha);
		if(benchmark)Reorder(n,&order[0],benchmark);
		if(initial)Reorder(n,&order[0],initial);
		if(buy)Reorder(n,&order[0],buy);
		if(sell)Reorder(n,&order[0],sell);
		if(maxrisk>0 || maxarisk>0||meanstd>0||maxinfo>0)
		{
			fixedrisk.resize(n);
		}
		if(m)
		{
			if(!L)error_here((char*)"No Lower bounds",errors);
			if(!U)error_here((char*)"No Upper bounds",errors);
			for(i=N;i<n;++i)
			{
				daxpyvec(m,-L[i],A+i*m,L+n);
				daxpyvec(m,-U[i],A+i*m,U+n);
			}
		}
		if(mabs)
		{
			if(!L_abs)error_here((char*)"No Absolute Lower bounds",errors);
			if(!U_abs)error_here((char*)"No Absolute Upper bounds",errors);
			for(i=N;i<n;++i)
			{
				daxpyvec(mabs,-fabs(L[i]),A_abs+i*mabs,L_abs);
				daxpyvec(mabs,-fabs(U[i]),A_abs+i*mabs,U_abs);
			}
		}
	}
	else
	{
		order.resize(0);
		backorder=0;
	}

	if(maxarisk > 0 || maxrisk > 0||meanstd>0||maxinfo)
	{
		double scaler=dmin(maxarisk,maxrisk);
		if(scaler<0)scaler=maxrisk>0?maxrisk:maxarisk;
		if(scaler<0)scaler=1;
		scaler=1;
		double scalec=scaler*scaler;
		if(nfac>0)
		{
			if(!SV&&FL)error_here((char*)"No Specific Variances",errors);
			Q.resize(nn);
			Factor2Cov(n,nfac,FC,FL,SV,&Q[0]);//if nfac>0 and FL and SV are null then FC was passed in as compressed factor risk matrix
			R.resize(n*n);
			if(scaler!=1)
			{
				maxarisk/=scaler;
				maxrisk/=scaler;
				dscalvec(nn,1./scalec,&Q[0]);
			}
			RootQgram(n,&Q[0],&R[0],0);//RootQ uses Bunch Kaufman, RootProcessQ uses diagonalisation. RootProcessQ is slower makes fewer zeros but may be more stable. RootQgram Gram Schmidt
			Q.resize(0);
		}
		else if(nfac<0)
		{
			R.resize(n*n);
			if(scaler!=1)
			{
				maxarisk/=scaler;
				maxrisk/=scaler;
				dscalvec(nn,1./scalec,FC);
			}
			RootQgram(n,FC,&R[0],0);//RootQ uses Bunch Kaufman, RootProcessQ uses diagonalisation. RootProcessQ is slower makes fewer zeros but may be more stable. RootQgram Gram Schmidt
			if(scaler!=1)
			{
				dscalvec(nn,scalec,FC);
			}
		}
		else
		{
			if(!SV)error_here((char*)"No Specific Variances",errors);
			R.resize(n*n);R=0;
			if(scaler!=1)
			{
				maxarisk/=scaler;
				maxrisk/=scaler;
				dscalvec(n,1./scalec,SV);
			}
			for(i=0,ij=0;i<n;++i,ij+=i+1)
				R[ij]=sqrt(SV[i]);
			if(scaler!=1)
			{
				dscalvec(n,scalec,SV);
			}
		}
		RQ=&R[0];
		if(fixed)
		{
			std::valarray<double> ww(n);ww=0;
			dcopyvec(fixed,L+N,&ww[N]);
			dmx_transpose(n,n,RQ,RQ);
			Reorder_gen(n,&order[0],RQ,n);
			dmx_transpose(n,n,RQ,RQ);
			dmxtmulv(n,n,RQ,&ww[0],&fixedrisk[0]);
		}
		if(maxrisk > 0||meanstd>0||(benchmark&&maxinfo))
		{
			if(benchmark)dmxtmulv(n,n,RQ,benchmark,&benchtr[0]);
			else dzerovec(n,&benchtr[0]);
		}
	}
	if(m)dmx_transpose(m,N,A,A);//Ready to use constraints in SOCP
	if(mabs)dmx_transpose(mabs,N,A_abs,A_abs);//Ready to use absolute constraints in SOCP
//_________________________________________________________________________________

	short back=0;
	std::vector<size_t>lsi,revi;
	for(i=0;i<N;++i)
	{
		if(L[i]<0&&U[i]>0)lsi.push_back(i);
		if(initial&&(L[i]<initial[i]&&U[i]>initial[i]))revi.push_back(i);
	}
	size_t lsextra=lsi.size();		//number of variables for ||w[i]||
	size_t revextra=revi.size();	//number of variables for ||w[i]-initial[i]||
	if(delta<0 && !costs)revextra=0;
	if(psum<0 &&nsum>0 && rmax<0 && rmin<0 &&!mabs)lsextra=0;
/*	if(!lsextra)
		printf((char*)"Don't need extra variables for long short\n");
	if(!revextra)
		printf((char*)"Don't need extra variables for buy sell\n");*/

	size_t nprimal,ndual,ncone;
	ndual=N+lsextra+revextra+(meanstd>0)+(maxinfo>0)+(maxinfo==2);
	bool equalrminrmax=false;
	if(rmax>0 && rmin>0 && rmax==rmin)
		equalrminrmax=true;
	ncone=N+lsextra+revextra+m+(maxinfo==2)+mabs+(psum>0)+(nsum<0)+(rmax>0)+(rmin>0)-equalrminrmax+(delta>0)+(maxrisk>0)+(maxarisk>0)+(meanstd>0)+(maxinfo>0);
	std::valarray<int>cone(ncone);
	for(i=0,nprimal=0;i<ncone;++i)
	{
		if(i<N+lsextra+revextra+m+(maxinfo==2))cone[i]=2;
		else if(i<N+lsextra+revextra+m+(maxinfo==2)+mabs)cone[i]=2;
		else if(i<N+lsextra+revextra+m+(maxinfo==2)+mabs+(psum>0)+(nsum<0))cone[i]=2;
		else if(i<N+lsextra+revextra+m+(maxinfo==2)+mabs+(psum>0)+(nsum<0)+(rmax>0)+(rmin>0)-equalrminrmax)
		{
			if(equalrminrmax)cone[i]=2;
			else cone[i]=1;
		}
		else if(i<N+lsextra+revextra+m+(maxinfo==2)+mabs+(psum>0)+(nsum<0)+(rmax>0)+(rmin>0)-equalrminrmax+(delta>0))cone[i]=2;
		else if(i<N+lsextra+revextra+m+(maxinfo==2)+mabs+(psum>0)+(nsum<0)+(rmax>0)+(rmin>0)-equalrminrmax+(delta>0)+(maxrisk>0)+(maxarisk>0)+(meanstd>0)+(maxinfo>0))cone[i]=n+1;
		nprimal+=cone[i];
	}
	std::valarray<double>x(nprimal),s(nprimal),y(ndual),c(nprimal),b(ndual),AA(ndual*nprimal);

	AA=0,b=0,c=0;
	dcopyvec(N,alpha,&b[0]);
	if(meanstd>0)b[N+lsextra+revextra]=-meanstdl;
	else if(maxinfo==1)b[N+lsextra+revextra]=-infolambda;
	if(maxinfo==2)
	{
		dzerovec(N,&b[0]);//This isn't necessary as alpha is introduced in the constraints so this bit in the utility is constant
		b[N+lsextra+revextra]=-1;
		b[N+lsextra+revextra+1]=0;
	}
	if(costs)
	{
		if(!buy)error_here((char*)"No buy vector",errors);
		if(!sell)error_here((char*)"No sell vector",errors);
		for(i=0;i<N;++i)
		{
			if(L[i]>=initial[i])b[i]-=buy[i];
			else if(U[i]<=initial[i])b[i]+=sell[i];
		}
	}
	vector Anext=&AA[0];
	ij=0;
	size_t icone=0;
	double reciproot2=1.;//sqrt(.5);
	for(i=0;i<N;++i)//Stocks
	{
		Anext[i]=1;
		if(maxinfo<2)
			c[ij]=0.5*(L[i]+U[i]);
		else
		{
			Anext[N+lsextra+revextra+1]=-0.5*(L[i]+U[i]);
		}
		Anext+=ndual;
		ij++;
		if(maxinfo<2)
			c[ij]=0.5*(U[i]-L[i]);
		else
		{
			Anext[N+lsextra+revextra+1]=-0.5*(U[i]-L[i]);
		}
		Anext+=ndual;
		ij++;
		if(cone[icone]!=2)printf((char*)"ERROR in cone number line %d %d %d\n",__LINE__,cone[icone],2);
		cone[icone]=2;
		icone++;
	}
	for(j=0;j<lsextra;++j)//long short
	{
		i=lsi[j];
		Anext[i]=reciproot2;
		//c[ij]=0;
		Anext+=ndual;
		ij++;
		Anext[j+N]=-reciproot2;
		//c[ij]=0;
		Anext+=ndual;
		ij++;
		if(cone[icone]!=2)printf((char*)"ERROR in cone number line %d %d %d\n",__LINE__,cone[icone],2);
		cone[icone]=2;
		icone++;
	}
	for(j=0;j<revextra;++j)//buy sell
	{
		i=revi[j];
		if(costs)
		{
			b[j+N+lsextra]-=(buy[i]+sell[i])*.5;
			b[i]-=(buy[i]-sell[i])*.5;
		}
		Anext[i]=reciproot2;
		if(maxinfo<2)
			c[ij]=initial[i]*reciproot2;
		else
			Anext[N+lsextra+revextra+1]=-initial[i]*reciproot2;
		Anext+=ndual;
		ij++;
		Anext[j+N+lsextra]=-reciproot2;
		//c[ij]=0;
		Anext+=ndual;
		ij++;
		if(cone[icone]!=2)printf((char*)"ERROR in cone number line %d %d %d\n",__LINE__,cone[icone],2);
		cone[icone]=2;
		icone++;
	}
	if(maxinfo==2)
	{
		dcopyvec(N,alpha,Anext);
		if(benchmark)Anext[N+lsextra+revextra+1]=-ddotvec(N,alpha,benchmark);
		if(fixed)Anext[N+lsextra+revextra+1]+=ddotvec(fixed,alpha+N,L+N);
		c[ij]=1;
		Anext+=ndual;
		ij++;
		Anext+=ndual;
		ij++;
		if(cone[icone]!=2)printf((char*)"ERROR in cone number line %d %d %d\n",__LINE__,cone[icone],2);
		cone[icone]=2;
		icone++;
	}
	for(j=0;j<m;++j)//constraints
	{
		dcopyvec(N,A+j*N,Anext);
		if(maxinfo<2)
			c[ij]=0.5*(U[n+j]+L[n+j]);
		else
		{
			Anext[N+lsextra+revextra+1]=-0.5*(U[n+j]+L[n+j]);
		}
		Anext+=ndual;
		ij++;
		if(maxinfo<2)
			c[ij]=0.5*(U[n+j]-L[n+j]);
		else
		{
			Anext[N+lsextra+revextra+1]=-0.5*(U[n+j]-L[n+j]);
		}
		Anext+=ndual;
		ij++;
		if(cone[icone]!=2)printf((char*)"ERROR in cone number line %d %d %d\n",__LINE__,cone[icone],2);
		cone[icone]=2;
		icone++;
	}
	for(j=0;j<mabs;++j)//absolute constraints
	{
		for(i=0;i<N;++i)
		{
			if(L[i]>=-lm_eps)Anext[i]=A_abs[j*N+i];
			else if(U[i]<=lm_eps)Anext[i]=-A_abs[j*N+i];
		}
		for(i=0;i<lsextra;++i)
		{
			k=lsi[i];
			Anext[N+i]=A_abs[j*N+k];
		}
		if(maxinfo<2)
			c[ij]=0.5*(U_abs[j]+L_abs[j]);
		else
			Anext[N+lsextra+revextra+1]=-0.5*(U_abs[j]+L_abs[j]);
		Anext+=ndual;
		ij++;
		if(maxinfo<2)
			c[ij]=0.5*(U_abs[j]-L_abs[j]);
		else
			Anext[N+lsextra+revextra+1]=-0.5*(U_abs[j]-L_abs[j]);
		Anext+=ndual;
		ij++;
		if(cone[icone]!=2)printf((char*)"ERROR in cone number line %d %d %d\n",__LINE__,cone[icone],2);
		cone[icone]=2;
		icone++;
	}
	if(psum>0)
	{
		if(psumL<0)psumL=psum;
		double palready=0;
		for(j=N;j<n;++j)
		{
			if(L[j]>0)palready+=L[j];
		}
		if(palready>psum)error_here((char*)"psum is too small",errors);
		for(j=0;j<N;++j)
		{
			if(L[j]>=-lm_eps)Anext[j]=1;
		}
		for(j=0;j<lsextra;++j)
		{
			i=lsi[j];
			Anext[i]=.5;
			Anext[N+j]=.5;
		}
		if(maxinfo<2)
			c[ij]=(psum+psumL)*.5-palready;
		else
			Anext[N+lsextra+revextra+1]=-((psum+psumL)*.5-palready);
		Anext+=ndual;
		ij++;
		if(maxinfo<2)
			c[ij]=0.5*(psum-psumL);
		else
			Anext[N+lsextra+revextra+1]=-0.5*(psum-psumL);
		Anext+=ndual;
		ij++;
		if(cone[icone]!=2)printf((char*)"ERROR in cone number line %d %d %d\n",__LINE__,cone[icone],2);
		cone[icone]=2;
		icone++;
	}
	if(nsum<0)
	{
		if(nsumU>0)nsumU=nsum;
		double nalready=0;
		for(j=N;j<n;++j)
		{
			if(L[j]<0)nalready+=L[j];
		}
		if(nalready<nsum)error_here((char*)"nsum is not negative enough",errors);
		for(j=0;j<N;++j)
		{
			if(U[j]<=lm_eps)Anext[j]=1;
		}
		for(j=0;j<lsextra;++j)
		{
			i=lsi[j];
			Anext[i]=.5;
			Anext[N+j]=-.5;
		}
		if(maxinfo<2)
			c[ij]=0.5*(nsumU+nsum)-nalready;
		else
			Anext[N+lsextra+revextra+1]=-(0.5*(nsumU+nsum)-nalready);
		Anext+=ndual;
		ij++;
		if(maxinfo<2)
			c[ij]=0.5*(nsumU-nsum);
		else
			Anext[N+lsextra+revextra+1]=-0.5*(nsumU-nsum);
		Anext+=ndual;
		ij++;
		if(cone[icone]!=2)printf((char*)"ERROR in cone number line %d %d %d\n",__LINE__,cone[icone],2);
		cone[icone]=2;
		icone++;
	}
	if(rmax>0&&!equalrminrmax)
	{
		double rready=0;
		for(j=N;j<n;++j)
		{
			if(L[j]>0)rready-=2*rmax*L[j];
			else if(L[j]<0)rready-=2*L[j];
		}
		for(j=0;j<N;++j)
		{
			if(U[j]<=lm_eps)Anext[j]=-2;
			else if(L[j]>=-lm_eps)Anext[j]=-2*rmax;
		}
		for(j=0;j<lsextra;++j)
		{
			i=lsi[j];
			Anext[i]=-rmax-1;
			Anext[N+j]=-rmax+1;
		}
		if(maxinfo<2)
			c[ij]=-rready;
		else
			Anext[N+lsextra+revextra+1]=rready;
		Anext+=ndual;
		ij++;
		if(cone[icone]!=1)printf((char*)"ERROR in cone number line %d %d %d\n",__LINE__,cone[icone],1);
		cone[icone]=1;
		icone++;
	}
	if(rmin>0&&!equalrminrmax)
	{
		double rready=0;
		for(j=N;j<n;++j)
		{
			if(L[j]>0)rready+=2*rmin*L[j];
			else if(L[j]<0)rready+=2*L[j];
		}
		for(j=0;j<N;++j)
		{
			if(U[j]<=lm_eps)Anext[j]=2;
			else if(L[j]>=-lm_eps)Anext[j]=2*rmin;
		}
		for(j=0;j<lsextra;++j)
		{
			i=lsi[j];
			Anext[i]=rmin+1;
			Anext[N+j]=rmin-1;
		}
		if(maxinfo<2)
			c[ij]=-rready;
		else
			Anext[N+lsextra+revextra+1]=rready;
		Anext+=ndual;
		ij++;
		if(cone[icone]!=1)printf((char*)"ERROR in cone number line %d %d %d\n",__LINE__,cone[icone],1);
		cone[icone]=1;
		icone++;
	}
	if(equalrminrmax)
	{
		double rready=0;
		for(j=N;j<n;++j)
		{
			if(L[j]>0)rready+=2*rmin*L[j];
			else if(L[j]<0)rready+=2*L[j];
		}
		for(j=0;j<N;++j)
		{
			if(U[j]<=lm_eps)Anext[j]=2;
			else if(L[j]>=-lm_eps)Anext[j]=2*rmin;
		}
		for(j=0;j<lsextra;++j)
		{
			i=lsi[j];
			Anext[i]=rmin+1;
			Anext[N+j]=rmin-1;
		}
		if(maxinfo<2)
			c[ij]=-rready;
		else
			Anext[N+lsextra+revextra+1]=rready;
		Anext+=ndual;
		ij++;
		c[ij]=0;
		Anext+=ndual;
		ij++;
		if(cone[icone]!=2)printf((char*)"ERROR in cone number line %d %d %d\n",__LINE__,cone[icone],2);
		cone[icone]=2;
		icone++;
	}
	if(delta>0)
	{
		double dalready=0;
		for(i=N;i<n;++i)
		{
			if(L[i]>initial[i])dalready+=L[i]-initial[i];
			else if(L[i]<initial[i])dalready-=L[i]-initial[i];
		}
		dalready*=.5;
		if(dalready>delta)error_here((char*)"turnover cannot be made low enough",errors);
		for(i=0;i<N;++i)
		{
			if(L[i]>=(initial[i]-lm_eps))Anext[i]=1;
			else if(U[i]<=(initial[i]+lm_eps))Anext[i]=-1;
		}
		double delta_base=ddotvec(N,initial,Anext);
		for(j=0;j<revextra;++j)
		{
			Anext[N+lsextra+j]=1;
		}
		if(maxinfo<2)
			c[ij]=delta-dalready+delta_base;
		else
			Anext[N+lsextra+revextra+1]=-(delta-dalready+delta_base);
		Anext+=ndual;
		ij++;
		if(maxinfo<2)
			c[ij]=delta-dalready;
		else
			Anext[N+lsextra+revextra+1]=-(delta-dalready);
		Anext+=ndual;
		ij++;
		if(cone[icone]!=2)printf((char*)"ERROR in cone number line %d %d %d\n",__LINE__,cone[icone],2);
		cone[icone]=2;
		lturn=icone;
		icone++;
	}
	if(maxrisk>0)
	{
		for(i=0;i<n;++i)
		{
			dcopyvec(N,RQ+i*n,Anext);
			if(maxinfo<2)
			{
				c[ij]=benchtr[i];
				if(fixed)c[ij]-=fixedrisk[i];
			}
			else
			{
				Anext[N+lsextra+revextra+1]=-benchtr[i];
				if(fixed)Anext[N+lsextra+revextra+1]+=fixedrisk[i];
			}
			Anext+=ndual;
			ij++;
		}
		if(maxinfo<2)
			c[ij]=maxrisk;
		else
			Anext[N+lsextra+revextra+1]=-maxrisk;
		Anext+=ndual;
		ij++;
		if(cone[icone]!=(n+1))printf((char*)"ERROR in cone number line %d %d %d\n",__LINE__,cone[icone],n+1);
		cone[icone]=n+1;
		l1=icone;
		icone++;
	}
	if(maxarisk>0)
	{
		for(i=0;i<n;++i)
		{
			dcopyvec(N,RQ+i*n,Anext);
			if(maxinfo<2)
			{
				if(fixed)c[ij]-=fixedrisk[i];
			}
			else
			{
				if(fixed)Anext[N+lsextra+revextra+1]+=fixedrisk[i];
			}
			Anext+=ndual;
			ij++;
		}
		if(maxinfo<2)
			c[ij]=maxarisk;
		else
			Anext[N+lsextra+revextra+1]=-maxarisk;
		Anext+=ndual;
		ij++;
		if(cone[icone]!=(n+1))printf((char*)"ERROR in cone number line %d %d %d\n",__LINE__,cone[icone],n+1);
		cone[icone]=n+1;
		l2=icone;
		icone++;
	}
	if(meanstd>0)
	{
		for(i=0;i<n;++i)
		{
			dcopyvec(N,RQ+i*n,Anext);
			c[ij]=benchtr[i];
			if(fixed)c[ij]-=fixedrisk[i];
			Anext+=ndual;
			ij++;
		}
		c[ij]=0;
		Anext[N+lsextra+revextra]=-1;
		Anext+=ndual;
		ij++;
		if(cone[icone]!=(n+1))printf((char*)"ERROR in cone number line %d %d %d\n",__LINE__,cone[icone],n+1);
		cone[icone]=n+1;
		l3=icone;
		icone++;
	}
	if(maxinfo>0)
	{
		for(i=0;i<n;++i)
		{
			dcopyvec(N,RQ+i*n,Anext);
			if(maxinfo==1)
			{
				if(benchmark)c[ij]=benchtr[i];
				if(fixed)c[ij]-=fixedrisk[i];
			}
			else if(maxinfo==2)
			{
				if(benchmark)Anext[N+lsextra+revextra+1]=-benchtr[i];
				if(fixed)Anext[N+lsextra+revextra+1]+=fixedrisk[i];
			}
			Anext+=ndual;
			ij++;
		}
		c[ij]=0;
		Anext[N+lsextra+revextra]=-1;
		Anext+=ndual;
		ij++;
		if(cone[icone]!=(n+1))printf((char*)"ERROR in cone number line %d %d %d\n",__LINE__,cone[icone],n+1);
		cone[icone]=n+1;
		l3=icone;
		icone++;
	}
	double tau=1,kappa=1;
	double rhoconv=1e-8;
	double ccomp=1e-2;
	double cgap=1e-2;
	double changeratio=4;
	double beta=1e-6,ddelta=.5;
	char*SOCPdump=(char*)"portf";
	if(lsextra||revextra)SOCPdump=(char*)"portflarge";
	int logSOCP=0;
	if(!logSOCP)SOCPdump=0;
	int signtest=0,maxit=100;
	double maxinforat=-lm_max,Unow;
	x=0,y=0,s=0;
	for(i=0,ij=0;i<ncone;++i)
	{
		ij+=cone[i];
		x[ij-1]=s[ij-1]=1;
	}

	/*if(lsextra)signtest=1;*/		//This works OK
//	size_t abs_errn;
	dmx_transpose(ndual,nprimal,&AA[0],&AA[0]);
	int infocount=0;
	do
	{
		if(maxinfo==1&&infocount>0)
		{
			b[N+lsextra+revextra]=-infolambda;
			tau=kappa=1;
			x=0,y=0,s=0;
			for(i=0,ij=0;i<ncone;++i)
			{
				ij+=cone[i];
				x[ij-1]=s[ij-1]=1;
			}
		}
		if(!errors)
		{
#ifndef NO_NORM_SCAL
			double normdata=sqrt(ddotvec(ndual*nprimal,&AA[0],&AA[0])+ddotvec(ndual,&b[0],&b[0])+ddotvec(nprimal,&c[0],&c[0]));
			double toll=10;
			if(normdata<toll&&normdata>1./toll)normdata=1;
			dscalvec(ndual*nprimal,1./normdata,&AA[0]);
			dscalvec(ndual,1./normdata,&b[0]);
			dscalvec(nprimal,1./normdata,&c[0]);
#endif
			if(!(back=SOCPinfeasHomogt(ncone,ndual,&cone[0],&c[0],&AA[0],&b[0],&x[0],&y[0],
				&s[0],&tau,&kappa,maxit,beta,ddelta,ccomp,cgap,signtest,changeratio,rhoconv,logSOCP,logfile,SOCPdump)))
			{
#ifndef NO_NORM_SCAL
				dscalvec(ndual*nprimal,normdata,&AA[0]);
				dscalvec(ndual,normdata,&b[0]);
				dscalvec(nprimal,normdata,&c[0]);
#endif
				//double primal=ddotvec(nprimal,&c[0],&x[0]);
				//double dual=ddotvec(ndual,&b[0],&y[0]);
				//double myinfease=fabs((primal-dual)/dmin(primal,dual));
				if(1e-3*kappa>tau||tau<1e-4/*&&myinfease>2e-2*/)
				{
					/*	double tt;
					if((tt=ddotvec(ndual,&b[0],&y[0]))>0)
					printf((char*)"b dot y %20.12e primal is infeasible\n",tt);
					if((tt=ddotvec(nprimal,&c[0],&x[0]))<0)
					printf((char*)"c dot x %20.12e dual is infeasible\n",tt);*/
					back=2;
				}
				else
				{
					dscalvec(nprimal,1./tau,&x[0]);
					dscalvec(nprimal,1./tau,&s[0]);
					dscalvec(ndual,1./tau,&y[0]);
					dcopyvec(N,&y[0],w);
					if(maxinfo==2)
					{
						dscalvec(N,1./y[N+lsextra+revextra+1],w);
					}
					for(i=0;i<N;++i)
					{
						if(fabs(w[i]-L[i])<=Conic_featol||w[i]<L[i])//1e-7 is 5* too big I think it should really be lm_rooteps*2
							w[i]=L[i];
						else if(fabs(w[i]-U[i])<=Conic_featol||w[i]>U[i])
							w[i]=U[i];
						if(initial&&fabs(w[i]-initial[i])<=Conic_featol)
							w[i]=initial[i];
						if(fabs(w[i])<=Conic_featol)
							w[i]=0;
					}
					double lagrange;
					for(i=0,ij=0;i<ncone;ij+=(cone[i]),i++)
					{
						if(cone[i]==1)
						{
							lagrange=x[ij];
							//	printf((char*)"Lagrange cone %4d,   %e %e\n",i,lagrange,x[ij+1]);
						}
						else if(cone[i]>1)
						{
							lagrange=sqrt(ddotvec(cone[i]-1,&x[ij],&x[ij]));
							//	printf((char*)"Lagrange cone %4d,   %e %e\n",i,lagrange,x[ij+cone[i]-1]);
						}
						else
						{
							lagrange=x[ij];
							//	printf((char*)"Lagrange cone %4d,      %e\n",i,x[ij+cone[i]-1]);
						}
						if(maxrisk>0&&l1==i&&lambda1)*lambda1=lagrange;
						else if(maxarisk>0&&l2==i&&lambda2)*lambda2=lagrange;
						else if(meanstd>0&&l3==i&&lambda3)*lambda3=lagrange;
						//else if(delta>0&&lturn==i)printf((char*)"Lagrange multiplier for turnover %f\n",lagrange);
					}
					if(meanstd)
					{
						//	printf((char*)"optimisation variable for meanstd term %20.8e\n",y[ndual-1]);
						if(optvalue)*optvalue=y[ndual-1];//should be the same as y[N+lsextra+revextra]
					}
					double badmod=0,kb;
					for(i=0;i<lsextra;++i)
					{
						if(badmod<(kb=fabs(fabs(y[lsi[i]])-y[N+i])))
						{
							//						abs_errn=lsi[i];
							badmod=kb;
						}
						//badmod=dmax(badmod,(fabs(fabs(y[lsi[i]])-y[N+i])));
					}
					if(badmod>lm_rooteps)
					{
						//					printf((char*)"Max error in extra absolute optimisation variables %20.8e (asset %d)\n",badmod,abs_errn);back=1;
						//printf((char*)"Max error in extra absolute optimisation variables %20.8e\n",badmod);
						back=1;
					}
					badmod=0;
					for(i=0;i<revextra;++i)
					{
						badmod=dmax(badmod,(fabs(fabs(y[revi[i]]-initial[revi[i]])-y[N+i+lsextra])));
					}
					if(badmod>lm_rooteps)
					{
						//printf((char*)"Max error in extra revision optimisation variables %20.8e\n",badmod);
						back=1;
					}
				}
			}
			else
			{
#ifndef NO_NORM_SCAL
				dscalvec(ndual*nprimal,normdata,&AA[0]);
				dscalvec(ndual,normdata,&b[0]);
				dscalvec(nprimal,normdata,&c[0]);
#endif
				dscalvec(nprimal,1./tau,&x[0]);
				dscalvec(nprimal,1./tau,&s[0]);
				dscalvec(ndual,1./tau,&y[0]);
				dcopyvec(N,&y[0],w);
				back=3;
			}
		}
		else
			back=2;
		//	printf((char*)"%s\n",SOCPlstestMessage(back));

		//_________________________________________________________________________________
		if(infocount==0)
		{
			if(m)dmx_transpose(N,m,A,A);//Change back constraints
			if(mabs)dmx_transpose(N,mabs,A_abs,A_abs);//Change back absolute constraints
		}
		if(fixed)
		{
			//		abs_errn=order[abs_errn];
			//		printf((char*)"abs_errn is %d\n",abs_errn);
			dcopyvec(fixed,L+N,w+N);
			if(m)
			{
				for(i=N;i<n;++i)
				{
					daxpyvec(m,L[i],A+i*m,L+n);
					daxpyvec(m,U[i],A+i*m,U+n);
				}
			}
			if(mabs)
			{
				for(i=N;i<n;++i)
				{
					daxpyvec(mabs,fabs(L[i]),A_abs+i*mabs,L_abs);
					daxpyvec(mabs,fabs(U[i]),A_abs+i*mabs,U_abs);
				}
			}
			if(m)Reorder_gen(n,backorder,A,m);
			if(mabs)Reorder_gen(n,backorder,A_abs,mabs);
			if(L)Reorder(n,backorder,L);
			if(U)Reorder(n,backorder,U);
			if(alpha)Reorder(n,backorder,alpha);
			if(benchmark)Reorder(n,backorder,benchmark);
			if(initial)Reorder(n,backorder,initial);
			if(buy)Reorder(n,backorder,buy);
			if(sell)Reorder(n,backorder,sell);
			Reorder(n,backorder,w);
			//		printf((char*)"%d fixed bounds\n",fixed);
		}
		if(back==1 || back==3 || signtest)
		{
			signtest=0;
			std::valarray<double>LL(n+m),UU(n+m);
			vector L1,U1;
			dcopyvec(n+m,L,&LL[0]);
			dcopyvec(n+m,U,&UU[0]);
			L1=&LL[0];
			U1=&UU[0];
			for(i=0;i<n;++i)
			{

				if(L1[i]==U1[i]){continue;}
				if(initial)
				{
					if(initial[i]>0 && w[i]>initial[i]+lm_eps8){L1[i]=dmax(initial[i],L1[i]);}
					else if(initial[i]>0 && w[i]<initial[i]-lm_eps8 && w[i]>-lm_eps8){L1[i]=dmax(0,L1[i]);U1[i]=dmin(initial[i],U1[i]);}
					else if(initial[i]>0 && w[i]<=-lm_eps8){U1[i]=dmin(0,U1[i]);}
					else if(initial[i]<0 && w[i]<initial[i]-lm_eps8){U1[i]=dmin(initial[i],U1[i]);}
					else if(initial[i]<0 && w[i]>initial[i]+lm_eps8 && w[i]<-lm_eps8){U1[i]=dmin(0,U1[i]);L1[i]=dmax(initial[i],L1[i]);}
					else if(initial[i]<0 && w[i]>=lm_eps8){L1[i]=dmax(0,L1[i]);}
					else if(initial[i]==0 && w[i]>initial[i]+lm_eps8){L1[i]=dmax(initial[i],L1[i]);}
					else if(initial[i]==0 && w[i]<initial[i]-lm_eps8){U1[i]=dmin(initial[i],U1[i]);}
					else if(initial[i]==0 && fabs(w[i])<=initial[i]){L1[i]=U1[i]=initial[i];U1[i]+=lm_eps256;}
					else if(fabs(w[i]-initial[i])<=lm_eps8){L1[i]=U1[i]=initial[i];U1[i]+=lm_eps256;}
					else if(fabs(w[i])<=lm_eps8){L1[i]=U1[i]=0;U1[i]+=lm_eps256;}
				}
				else if(w[i]>lm_eps8){L1[i]=dmax(0,L1[i]);}
				else if(w[i]<-lm_eps8){U1[i]=dmin(0,U1[i]);}
				else if(fabs(w[i])<=lm_eps8){L1[i]=U1[i]=0;U1[i]+=lm_eps256;}

				/*
							//Just to check the bounds have been found correctly
				if(L1[i]<0&&U1[i]>0)printf((char*)"L1[%d] = %f U1[%d] = %f\t\tw = %f\n",i,L1[i],i,U1[i],w[i]);
				if(initial&&L1[i]<initial[i]&&U1[i]>initial[i])printf((char*)"initial[%d] = %f;\tL1[%d] = %f U1[%d] = %f\t\tw = %f\n",i,initial[i],i,L1[i],i,U1[i],w[i]);
				*/
				

			}
			if(back!=3)
			{
				std::string input2;
				if(inputData&&strlen(inputData))
				{
					input2=inputData;
					input2 += (char*)".2";inputData=(char*)input2.c_str();
				}
				back=SOCPportfolio_internal(n,m,w,L1,U1,A,alpha,benchmark,initial,buy,sell,costs,delta,psum,psumL,nsum,nsumU,rmax,rmin,
					mabs,A_abs,L_abs,U_abs,FC,nfac,FL,SV,maxrisk,maxarisk,maxinfo>0?2:meanstd,meanstdl,lambda1,lambda2,lambda3,optvalue,inputData,log,logfile);
			}
		}
		if(maxinfo==1&&back==0)
		{
			infocount++;
			std::valarray<double>implied(2*n);
			if(benchmark)dsubvec(n,w,benchmark,&implied[n]);
			else dcopyvec(n,w,&implied[n]);
			double ratiotest,risk,ret;
			if(nfac>-1)
				facmulold(n,nfac,&facQ[0],&implied[n],&implied[0]);
			else
				dsmxmulv(n,FC,&implied[n],&implied[0]);
			risk=sqrt(ddotvec(n,&implied[n],&implied[0]));
			ret=ddotvec(n,&implied[n],alpha);
			ratiotest=ret/risk;
			Unow=ret-infolambda*risk;
			if(maxinforat<ratiotest)
			{
				maxinforat=ratiotest;
				dcopyvec(n,w,&keepw[0]);
			}
			/*
			If ratiotest and maxinforat are not the same it means the optimisation includes more than just risk and return (e.g. costs)
			*/
			if(maxinforat>ratiotest &&  fabs(infolambda/ratiotest-1)<1e-7)
			{
				dcopyvec(n,&keepw[0],w);
				break;
			}
			if(fabs(infolambda/ratiotest-1)>lm_rooteps)
			{
				infolambda+=Unow/risk;
				if(maxinforat>0 && risk<lm_rooteps&&fabs(ret)<lm_rooteps)
				{
					dcopyvec(n,&keepw[0],w);
					break;
				}
			}
			else 
			{
				dcopyvec(n,&keepw[0],w);
				break;
			}
			if(infolambda<=0) infolambda=lm_rooteps;
			if(fixed)
			{
				if(m)Reorder_gen(n,&order[0],A,m);
				if(mabs)Reorder_gen(n,&order[0],A_abs,mabs);
				if(L)Reorder(n,&order[0],L);
				if(U)Reorder(n,&order[0],U);
				if(alpha)Reorder(n,&order[0],alpha);
				if(benchmark)Reorder(n,&order[0],benchmark);
				if(initial)Reorder(n,&order[0],initial);
				if(buy)Reorder(n,&order[0],buy);
				if(sell)Reorder(n,&order[0],sell);
				if(m)
				{
					for(i=N;i<n;++i)
					{
						daxpyvec(m,-L[i],A+i*m,L+n);
						daxpyvec(m,-U[i],A+i*m,U+n);
					}
				}
				if(mabs)
				{
					for(i=N;i<n;++i)
					{
						daxpyvec(mabs,-fabs(L[i]),A_abs+i*mabs,L_abs);
						daxpyvec(mabs,-fabs(U[i]),A_abs+i*mabs,U_abs);
					}
				}
			}
		}
		else if(maxinfo==2||back>0)
		{
			break;
		}
	}
	while(maxinfo>0&&infocount<30);
	return back;
}

short AccumulateOptSOCP(void*info)
{
	OptParamAccum*OP=(OptParamAccum*)info;
	ExtraR*opt=(ExtraR*)OP->MoreInfo;
	opt->back=SOCPportfolio_internal(opt->n,opt->m,opt->x,opt->lower,opt->upper,opt->A,opt->alpha,opt->benchmark,opt->initial,opt->buy,opt->sell,
	opt->costs,opt->delta,opt->psum,opt->psumL,opt->nsum,opt->nsumU,
	opt->rmax,opt->rmin,opt->mabs,opt->A_abs,opt->L_abs,opt->U_abs,
	opt->FC,opt->nfac,opt->FL,opt->SV,opt->maxrisk,opt->maxarisk,
	opt->meanstd,opt->meanstdl,opt->lambda1,opt->lambda2,opt->lambda3,opt->optvalue,
	opt->inputData,opt->log,opt->logfile,opt->min_trade,opt->min_hold,opt->basket,opt->trades,opt->minlot,opt->sizelot);
	return opt->back;
}
double AccumulateUSOCP(void*info)		//For Optimise class only
{
	OptParamAccum*OP=(OptParamAccum*)info;
	ExtraR*opt=(ExtraR*)OP->MoreInfo;
	double U= -ddotvec(opt->n,opt->x,opt->alpha);
	if(opt->meanstd)//if we use meanstd we need to include lambda3*actualrisk
		U+=*(opt->lambda3)* *(opt->optvalue);
	if(opt->costs)
	{
		size_t i;
		for(i=0;i<opt->n;++i)
		{
			if(opt->x[i]>opt->initial[i])U+=(opt->x[i]-opt->initial[i])*opt->buy[i];
			else if(opt->x[i]<opt->initial[i])U-=(opt->x[i]-opt->initial[i])*opt->sell[i];
		}
	}
	return U;
}
void AccumulateGSOCP(void *info)	//For Optimise class only
{
	OptParamAccum*OP=(OptParamAccum*)info;
	ExtraR*opt=(ExtraR*)OP->MoreInfo;
	dcopyvec(opt->n,opt->alpha,OP->grad);
	dnegvec(opt->n,OP->grad);
	if(opt->costs)
	{
		size_t i;
		for(i=0;i<opt->n;++i)
		{
			if(opt->x[i]>opt->initial[i])OP->grad[i]+=opt->buy[i];
			else if(opt->x[i]<opt->initial[i])OP->grad[i]-=opt->sell[i];
		}
	}
}
extern "C" DLLEXPORT short SOCPportfolio(size_t n,size_t m,vector w,vector L,vector U,vector A,vector alpha,
		vector benchmark=0,vector initial=0,vector buy=0,vector sell=0,int costs=0,double delta=-1,
		double psum=-1,double psumL=-1,double nsum=1,double nsumU=1,double rmax=-1,double rmin=-1,
		size_t mabs=0,vector A_abs=0,vector L_abs=0,
		vector U_abs=0,vector FC=0,long nfac=-1,vector FL=0,vector SV=0,double maxrisk=-1,double maxarisk=-1,
		int meanstd=0,double meanstdl=0,double*lambda1=0,double*lambda2=0,double*lambda3=0,double*optvalue=0,
		char*inputData=(char*)"log1",int log=1,char*logfile=0,vector min_trade=0,vector min_hold=0,long basket=-1,long trades=-1,
		vector minlot=0,vector sizelot=0,double five=-1,double ten=-1,double forty=-1,int*issues=0)
{
	std::ofstream outFile;
	if(inputData && strlen(inputData))
	{
		outFile.open(inputData,std::ios_base::out);
		if(outFile.fail())
		{
			std::cout<<"Cannot open "<<inputData<<std::endl;
		}
		else
		{
			dumpvector(1,(char*)"n",&n,outFile);
			dumpvector(1,(char*)"m",&m,outFile);
			dumpvector(n+m,(char*)"L",L,outFile);
			dumpvector(n+m,(char*)"U",U,outFile);
			dumpvector(n*m,(char*)"A",A,outFile);
			dumpvector(n,(char*)"alpha",alpha,outFile);
			dumpvector(n,(char*)"benchmark",benchmark,outFile);
			dumpvector(n,(char*)"initial",initial,outFile);
			dumpvector(n,(char*)"buy",buy,outFile);
			dumpvector(n,(char*)"sell",sell,outFile);
			dumpvector(1,(char*)"costs",&costs,outFile);
			dumpvector(1,(char*)"delta",&delta,outFile);
			dumpvector(1,(char*)"psum",&psum,outFile);
			dumpvector(1,(char*)"psumL",&psumL,outFile);
			dumpvector(1,(char*)"nsum",&nsum,outFile);
			dumpvector(1,(char*)"nsumU",&nsumU,outFile);
			dumpvector(1,(char*)"rmax",&rmax,outFile);
			dumpvector(1,(char*)"rmin",&rmin,outFile);
			dumpvector(1,(char*)"mabs",&mabs,outFile);
			dumpvector(1,(char*)"basket",&basket,outFile);
			dumpvector(1,(char*)"trades",&trades,outFile);
			dumpvector(n*mabs,(char*)"A_abs",A_abs,outFile);
			dumpvector(mabs,(char*)"L_abs",L_abs,outFile);
			dumpvector(mabs,(char*)"U_abs",U_abs,outFile);
			if(nfac>-1&&!FL&&!SV&&FC)
				dumpvector(n*(nfac+1),(char*)"FC",FC,outFile);
			else
				dumpvector((nfac>-1?nfac*(nfac+1)/2:n*(n+1)/2),(char*)"FC",FC,outFile);
			dumpvector(1,(char*)"nfac",&nfac,outFile);
			dumpvector((nfac>-1?nfac*n:0),(char*)"FL",FL,outFile);
			dumpvector((nfac>-1?n:0),(char*)"SV",SV,outFile);
			dumpvector(1,(char*)"maxrisk",&maxrisk,outFile);
			dumpvector(1,(char*)"maxarisk",&maxarisk,outFile);
			dumpvector(1,(char*)"meanstd",&meanstd,outFile);
			dumpvector(1,(char*)"meanstdl",&meanstdl,outFile);
			dumpvector(n,(char*)"min_trade",min_trade,outFile);
			dumpvector(n,(char*)"min_hold",min_hold,outFile);
			dumpvector(n,(char*)"minlot",minlot,outFile);
			dumpvector(n,(char*)"sizelot",sizelot,outFile);
			dumpvector(1,(char*)"five",&five,outFile);
			dumpvector(1,(char*)"ten",&five,outFile);
			dumpvector(1,(char*)"forty",&five,outFile);
			dumpvector(n,(char*)"issues",issues,outFile);
			outFile<<"-------------------------------------------------------------------------------------------";
			outFile.close();
			outFile.clear();
			inputData=0;
		}
	}
	ExtraR Opt;
	OptParamAccum OP(&Opt);

	Opt.n = n;
	Opt.m = m;
	Opt.x = w;
	Opt.lower = L;
	Opt.upper = U;
	Opt.A = A;
	Opt.alpha = alpha;
	Opt.benchmark = benchmark;
	Opt.initial = initial;
	Opt.buy = buy;
	Opt.sell = sell;
	Opt.costs = costs;
	Opt.delta = delta;
	Opt.psum = psum;
	Opt.psumL = psumL;
	Opt.nsum = nsum;
	Opt.nsumU = nsumU;
	Opt.rmax = rmax;
	Opt.rmin = rmin;
	Opt.mabs = mabs;
	Opt.A_abs = A_abs;
	Opt.L_abs = L_abs;
	Opt.U_abs = U_abs;
	Opt.FC = FC;
	Opt.nfac = nfac;
	Opt.FL = FL;
	Opt.SV = SV;
	Opt.maxrisk = maxrisk;
	Opt.maxarisk = maxarisk;
	Opt.meanstd = meanstd;
	Opt.meanstdl = meanstdl;
	Opt.lambda1 = lambda1;
	Opt.lambda2 = lambda2;
	Opt.lambda3 = lambda3;
	Opt.optvalue = optvalue;
	Opt.inputData = inputData;
	Opt.log = log;
	Opt.logfile = logfile;
	Opt.min_trade = min_trade;
	Opt.min_hold = min_hold;
	Opt.basket = basket;
	Opt.trades = trades;
	Opt.minlot = minlot;
	Opt.sizelot = sizelot;

	Opt.five=five;
	Opt.ten=ten;
	Opt.forty=forty;
	Opt.issues=issues;

	Opt.KagOpt = AccumulateOptSOCP;
	Opt.KagUtil = AccumulateUSOCP;
	Opt.KagGrad = AccumulateGSOCP;
	

	return Accumulation5_10_40(&Opt,-1,-1,2);
}

short SOCPportinner(void*info)
{
	size_t i;
	OptParamRound*RR=(OptParamRound*)info;
	ExtraR*Opt=(ExtraR*)RR->MoreInfo;
	RR->back=SOCPportfolio_internal(RR->n,RR->m,RR->x,RR->lower,RR->upper,
	Opt->A,Opt->alpha,Opt->benchmark,Opt->initial,Opt->buy,Opt->sell,
	Opt->costs,Opt->delta,Opt->psum,Opt->psumL,Opt->nsum,Opt->nsumU,
	Opt->rmax,Opt->rmin,Opt->mabs,Opt->A_abs,Opt->L_abs,Opt->U_abs,
	Opt->FC,Opt->nfac,Opt->FL,Opt->SV,Opt->maxrisk,Opt->maxarisk,
	Opt->meanstd,Opt->meanstdl,Opt->lambda1,Opt->lambda2,Opt->lambda3,Opt->optvalue,
	0,Opt->log,Opt->logfile);
//	if(RR->back!=0 && RR->back!=2)printf((char*)"FAILURE DURING THRESHOLD %d\n",RR->back);
	if(RR->back==4)
	{
		for(i=0;i<RR->n;++i)
		{
			RR->upper[i]+=1e-7;
		}
//		printf((char*)"Avoid no variables\n");
		RR->back=SOCPportfolio_internal(RR->n,RR->m,RR->x,RR->lower,RR->upper,
			Opt->A,Opt->alpha,Opt->benchmark,Opt->initial,Opt->buy,Opt->sell,
			Opt->costs,Opt->delta,Opt->psum,Opt->psumL,Opt->nsum,Opt->nsumU,
			Opt->rmax,Opt->rmin,Opt->mabs,Opt->A_abs,Opt->L_abs,Opt->U_abs,
			Opt->FC,Opt->nfac,Opt->FL,Opt->SV,Opt->maxrisk,Opt->maxarisk,
			Opt->meanstd,Opt->meanstdl,Opt->lambda1,Opt->lambda2,Opt->lambda3,Opt->optvalue,
			0,Opt->log,Opt->logfile);
//		printf((char*)"%d\n",RR->back);
		for(i=0;i<RR->n;++i)
		{
			RR->upper[i]-=1e-7;
		}
		dcopyvec(RR->n,RR->lower,RR->x);
	}
	if(RR->back == 0)
	{
		for(i=0;i<RR->n;++i)
		{
			if(fabs(RR->x[i]-RR->lower[i])<=Conic_featol)
				RR->x[i]=RR->lower[i];
			else if(fabs(RR->x[i]-RR->upper[i])<=Conic_featol)
				RR->x[i]=RR->upper[i];
			if(Opt->initial&&fabs(RR->x[i]-Opt->initial[i])<=Conic_featol)
				RR->x[i]=Opt->initial[i];
			if(fabs(RR->x[i])<=Conic_featol)
				RR->x[i]=0;
		}
	}
	RR->back= ((RR->back==2||RR->back==3)?6:RR->back);//Sometimes very near infeasibility can cause the conic optimisation to require very small steps and 3 is returned
	return RR->back;
}
short SOCPportinnerBT(void*info)
{
	size_t i;
	OptParamRound*RR=(OptParamRound*)info;
	ExtraR*Opt=(ExtraR*)RR->MoreInfo;
	RR->back=SOCPportfolio_internal(RR->n,RR->m,RR->x,RR->lower,RR->upper,
	Opt->A,Opt->alpha,Opt->benchmark,Opt->initial,Opt->buy,Opt->sell,
	Opt->costs,Opt->delta,Opt->psum,Opt->psumL,Opt->nsum,Opt->nsumU,
	Opt->rmax,Opt->rmin,Opt->mabs,Opt->A_abs,Opt->L_abs,Opt->U_abs,
	Opt->FC,Opt->nfac,Opt->FL,Opt->SV,Opt->maxrisk,Opt->maxarisk,
	Opt->meanstd,Opt->meanstdl,Opt->lambda1,Opt->lambda2,Opt->lambda3,Opt->optvalue,
	0,Opt->log,Opt->logfile,Opt->min_trade,Opt->min_hold,RR->basket,RR->trades);
//	if(RR->back!=0 && RR->back!=2)printf((char*)"FAILURE DURING THRESHOLD %d\n",RR->back);
	if(RR->back==4)
	{
		for(i=0;i<RR->n;++i)
		{
			RR->upper[i]+=1e-7;
		}
//		printf((char*)"Avoid no variables\n");
		RR->back=SOCPportfolio_internal(RR->n,RR->m,RR->x,RR->lower,RR->upper,
			Opt->A,Opt->alpha,Opt->benchmark,Opt->initial,Opt->buy,Opt->sell,
			Opt->costs,Opt->delta,Opt->psum,Opt->psumL,Opt->nsum,Opt->nsumU,
			Opt->rmax,Opt->rmin,Opt->mabs,Opt->A_abs,Opt->L_abs,Opt->U_abs,
			Opt->FC,Opt->nfac,Opt->FL,Opt->SV,Opt->maxrisk,Opt->maxarisk,
			Opt->meanstd,Opt->meanstdl,Opt->lambda1,Opt->lambda2,Opt->lambda3,Opt->optvalue,
			0,Opt->log,Opt->logfile,Opt->min_trade,Opt->min_hold,RR->basket,RR->trades);
//		printf((char*)"%d\n",RR->back);
		for(i=0;i<RR->n;++i)
		{
			RR->upper[i]-=1e-7;
		}
		dcopyvec(RR->n,RR->lower,RR->x);
	}
	if(RR->back == 0)
	{
		for(i=0;i<RR->n;++i)
		{
			if((RR->x[i]-RR->lower[i])<=Conic_featol)
				RR->x[i]=RR->lower[i];
			else if((RR->x[i]-RR->upper[i])>=-Conic_featol)
				RR->x[i]=RR->upper[i];
			if((RR->x[i])<=Conic_featol)
				RR->x[i]=0;
		}
	}
	RR->back= ((RR->back==2||RR->back==3)?6:RR->back);
	return RR->back;
}
short SOCPportinnerB(void*info)
{
	size_t i;
	OptParamRound*RR=(OptParamRound*)info;
	ExtraR*Opt=(ExtraR*)RR->MoreInfo;
	RR->back=SOCPportfolio_internal(RR->n,RR->m,RR->x,RR->lower,RR->upper,
	Opt->A,Opt->alpha,Opt->benchmark,Opt->initial,Opt->buy,Opt->sell,
	Opt->costs,Opt->delta,Opt->psum,Opt->psumL,Opt->nsum,Opt->nsumU,
	Opt->rmax,Opt->rmin,Opt->mabs,Opt->A_abs,Opt->L_abs,Opt->U_abs,
	Opt->FC,Opt->nfac,Opt->FL,Opt->SV,Opt->maxrisk,Opt->maxarisk,
	Opt->meanstd,Opt->meanstdl,Opt->lambda1,Opt->lambda2,Opt->lambda3,Opt->optvalue,
	0,Opt->log,Opt->logfile,0,0,Opt->basket,Opt->trades);
//	if(RR->back!=0 && RR->back!=2)printf((char*)"FAILURE DURING THRESHOLD %d\n",RR->back);
	if(RR->back==4)
	{
		for(i=0;i<RR->n;++i)
		{
			RR->upper[i]+=1e-7;
		}
//		printf((char*)"Avoid no variables\n");
		RR->back=SOCPportfolio_internal(RR->n,RR->m,RR->x,RR->lower,RR->upper,
			Opt->A,Opt->alpha,Opt->benchmark,Opt->initial,Opt->buy,Opt->sell,
			Opt->costs,Opt->delta,Opt->psum,Opt->psumL,Opt->nsum,Opt->nsumU,
			Opt->rmax,Opt->rmin,Opt->mabs,Opt->A_abs,Opt->L_abs,Opt->U_abs,
			Opt->FC,Opt->nfac,Opt->FL,Opt->SV,Opt->maxrisk,Opt->maxarisk,
			Opt->meanstd,Opt->meanstdl,Opt->lambda1,Opt->lambda2,Opt->lambda3,Opt->optvalue,
			0,Opt->log,Opt->logfile,Opt->min_trade,Opt->min_hold,Opt->basket,Opt->trades);
//		printf((char*)"%d\n",RR->back);
		for(i=0;i<RR->n;++i)
		{
			RR->upper[i]-=1e-7;
		}
		dcopyvec(RR->n,RR->lower,RR->x);
	}
	if(RR->back == 0)
	{
		for(i=0;i<RR->n;++i)
		{
			if(fabs(RR->x[i]-RR->lower[i])<=Conic_featol)
				RR->x[i]=RR->lower[i];
			else if(fabs(RR->x[i]-RR->upper[i])<=Conic_featol)
				RR->x[i]=RR->upper[i];
			if((RR->x[i])<=Conic_featol)
				RR->x[i]=0;
		}
	}
	RR->back= ((RR->back==2||RR->back==3)?6:RR->back);
	return RR->back;
}
short SOCPportinnerT(void*info)
{
	size_t i;
	OptParamRound*RR=(OptParamRound*)info;
	ExtraR*Opt=(ExtraR*)RR->MoreInfo;
	RR->back=SOCPportfolio_internal(RR->n,RR->m,RR->x,RR->lower,RR->upper,
	Opt->A,Opt->alpha,Opt->benchmark,Opt->initial,Opt->buy,Opt->sell,
	Opt->costs,Opt->delta,Opt->psum,Opt->psumL,Opt->nsum,Opt->nsumU,
	Opt->rmax,Opt->rmin,Opt->mabs,Opt->A_abs,Opt->L_abs,Opt->U_abs,
	Opt->FC,Opt->nfac,Opt->FL,Opt->SV,Opt->maxrisk,Opt->maxarisk,
	Opt->meanstd,Opt->meanstdl,Opt->lambda1,Opt->lambda2,Opt->lambda3,Opt->optvalue,
	0,Opt->log,Opt->logfile,Opt->min_trade,Opt->min_hold);
//	if(RR->back!=0 && RR->back!=2)printf((char*)"FAILURE DURING THRESHOLD %d\n",RR->back);
	if(RR->back==4)
	{
		for(i=0;i<RR->n;++i)
		{
			RR->upper[i]+=1e-7;
		}
//		printf((char*)"Avoid no variables\n");
		RR->back=SOCPportfolio_internal(RR->n,RR->m,RR->x,RR->lower,RR->upper,
			Opt->A,Opt->alpha,Opt->benchmark,Opt->initial,Opt->buy,Opt->sell,
			Opt->costs,Opt->delta,Opt->psum,Opt->psumL,Opt->nsum,Opt->nsumU,
			Opt->rmax,Opt->rmin,Opt->mabs,Opt->A_abs,Opt->L_abs,Opt->U_abs,
			Opt->FC,Opt->nfac,Opt->FL,Opt->SV,Opt->maxrisk,Opt->maxarisk,
			Opt->meanstd,Opt->meanstdl,Opt->lambda1,Opt->lambda2,Opt->lambda3,Opt->optvalue,
			0,Opt->log,Opt->logfile,Opt->min_trade,Opt->min_hold,Opt->basket,Opt->trades);
//		printf((char*)"%d\n",RR->back);
		for(i=0;i<RR->n;++i)
		{
			RR->upper[i]-=1e-7;
		}
		dcopyvec(RR->n,RR->lower,RR->x);
	}
	if(RR->back == 0)
	{
		for(i=0;i<RR->n;++i)
		{
			if(fabs(RR->x[i]-RR->lower[i])<=Conic_featol)
				RR->x[i]=RR->lower[i];
			else if(fabs(RR->x[i]-RR->upper[i])<=Conic_featol)
				RR->x[i]=RR->upper[i];
			if(fabs(RR->x[i])<=Conic_featol)
				RR->x[i]=0;
		}
	}
	RR->back= ((RR->back==2||RR->back==3)?6:RR->back);
	return RR->back;
}
double SOCPportutil(void*info)
{
	OptParamRound*RR=(OptParamRound*)info;
	ExtraR*Opt=(ExtraR*)RR->MoreInfo;
	double U=-ddotvec(RR->n,Opt->alpha,RR->x);
	if(Opt->meanstd)//if we use meanstd we need to include lambda3*actualrisk
		U+=*(Opt->lambda3)* *(Opt->optvalue);
	if(Opt->costs)
	{
		size_t i;
		for(i=0;i<RR->n;++i)
		{
			if(RR->x[i]>Opt->initial[i])U+=(RR->x[i]-Opt->initial[i])*Opt->buy[i];
			else if(RR->x[i]<Opt->initial[i])U-=(RR->x[i]-Opt->initial[i])*Opt->sell[i];
		}
	}
	return U;
}
void SOCPportgrad(void*info)
{
	OptParamRound*RR=(OptParamRound*)info;
	ExtraR*Opt=(ExtraR*)RR->MoreInfo;
	dcopyvec(RR->n,Opt->alpha,RR->grad);
	dnegvec(RR->n,RR->grad);
	if(Opt->costs)
	{
		size_t i;
		for(i=0;i<RR->n;++i)
		{
			if(RR->x[i]>Opt->initial[i])RR->grad[i]+=Opt->buy[i];
			else if(RR->x[i]<Opt->initial[i])RR->grad[i]-=Opt->sell[i];
		}
	}
}

extern "C" DLLEXPORT void SDPsvec(size_t n,vector S,vector v)
{
	//Form a vector from symmetric matrix as a square in S
	vector pv,pS,D,lv;
	size_t i;
	for(i=1,lv=v+n*(n-1)/2,D=S,pS=S+n,pv=v;i<n;++i)
	{
		dcopyvec(i,pS,pv);
		dscalvec(i,lm_root2,pv);
		pS+=n;
		pv+=i;
		*lv=*D;
		lv++;
		D+=(n+1);
	}
	*lv=*D;
}


extern "C" DLLEXPORT void SDPsMat(size_t n,vector v,vector S)
{
	//Form symmetric matrix as a square in S from vector v (inverse of SDPsvec)
	vector pv,pS,D,lv,pp;
	size_t i;
	for(i=1,pp=S+1,lv=v+n*(n-1)/2,D=S,pS=S+n,pv=v;i<n;++i)
	{
		dcopyvec(i,pv,pS);
		dscalvec(i,lm_rroot2,pS);
		dcopy(i,pS,1,pp,n);
		*D=*lv;
		lv++;
		pS+=n;
		pv+=i;
		pp++;
		D+=(n+1);
	}
	*D=*lv;
}
inline void getZslow(size_t m,size_t n,double*tau,double*a,double*Z)
{
	size_t i,j,k,l;
	std::valarray<double> u(n),oZ(n*n);
	double sum=0,Sjl,tu;
	oZ=0;
	for(i=0;i<n;++i)
	{
		oZ[i+i*n]=Z[i+i*n]=1;
	}
	for(i=0;i<m;++i)
	{
		u=0;
		u[n-m+i]=1;
		for(j=0;j<n-m+i;++j)
			u[j]=a[i+m*j];
		for(j=0;j<n;++j)
		{
			for(k=0;k<n;++k)
			{
				tu=-tau[i]*u[k];
				sum=0;
				for(l=0;l<n;++l)
				{
					Sjl=oZ[j+l*n];
					if(k==l) sum+=Sjl;
					sum+=Sjl*tu*u[l];
				}
				Z[j+k*n]=sum;
			}
		}
		dcopyvec(n*n,Z,&oZ[0]);
	}
}

inline void getZ(size_t m,size_t n,double*tau,double*a,double*Z)
{//a bit faster
	size_t i,k,l;
	std::valarray<double> u(n),oZ(n*n);
	vector oz;
	double tu;
	oZ=0;
	for(i=0,oz=&oZ[0];i<n;++i,oz+=n)
	{
		*(oz+i)=1;
	}
	for(i=0;i<m;++i)
	{
		u=0;
		u[n-m+i]=1;
		dcopy(n-m+i,a+i,m,&u[0],1);
		dzerovec(n*n,Z);
		for(k=0;k<n;++k)
		{
			daddvec(n,&oZ[k*n],Z+k*n,Z+k*n);
		}
		if(tau[i])
		{
			for(k=0;k<n;++k)
			{
				tu=-tau[i]*u[k];
				if(tu)
				{
					for(l=0;l<n;++l)
					{
						daxpyvec(n,tu*u[l],&oZ[l*n],Z+k*n);
					}
				}
			}
		}
		dcopyvec(n*n,Z,&oZ[0]);
	}
}
inline void getZ1(size_t m,size_t n,double*tau,double*a,double*Z)
{//Hopeless
	size_t i,j,l;
	std::valarray<double> u(n),oZ(n*n);
	oZ=0;
	for(i=0;i<n;++i)
	{
		oZ[i+i*n]=Z[i+i*n]=1;
	}
	for(i=0;i<m;++i)
	{
		u=0;
		u[n-m+i]=1;
		for(j=0;j<n-m+i;++j)
			u[j]=a[i+m*j];
		dzerovec(n*n,Z);
		for(j=0;j<n;++j)
		{
			for(l=0;l<n;++l)
			{
				if(oZ[j+l*n])
				{
					Z[j+l*n]+=oZ[j+l*n];
					BITA_daxpy(n,oZ[j+l*n]*(-tau[i])*u[l],&u[0],1,Z+j,n);
				}
			}
		}
		dcopyvec(n*n,Z,&oZ[0]);
	}
}


extern "C" DLLEXPORT int nullA(size_t m,size_t n,double *A,double*Z)
{
//Remember that A gets changed to the compact form of R from the RQ factorisation
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	size_t i,j;
	vector tau=A+n*m;
	Integer M=(Integer)m,N=(Integer)n,lda=M,lwork=-1,info;
	std::valarray<double> work(1),z(N*N),acopy(n*m);
	dcopyvec(n*m,A,&acopy[0]);
	dgerqf_BITA(&M,&N,A,&lda,&tau[0],&work[0],&lwork,&info);	
	lwork=max((int)work[0],M);
	work.resize(lwork);
	dgerqf_BITA(&M,&N,A,&lda,&tau[0],&work[0],&lwork,&info);
	if(info)return info;
	Integer k=M,ldc=N;
	char*side=(char*)"L",*trans=(char*)"N";
	lwork=-1;
	z=0;
	for(i=0;i<n;++i)
		z[i+i*n]=1;
	dormrq_BITA(side,trans,&N,&N,&k,A,&lda,&tau[0],&z[0],&ldc,&work[0],&lwork,&info);
	lwork=max(N,(Integer)work[0]);
	work.resize(lwork);
	dormrq_BITA(side,trans,&N,&N,&k,A,&lda,&tau[0],&z[0],&ldc,&work[0],&lwork,&info);
//	getZ(m,n,&tau[0],A,&z[0]);
	dmx_transpose(n,n,&z[0],&z[0]);
	dcopyvec(n*(n-m),&z[0],Z);
	double maxorthog=0;
	for(i=0;i<n-m;++i)
	{
		for(j=0;j<m;++j)
		{
			maxorthog=dmax(maxorthog,BITA_ddot(n,&acopy[j],m,&z[i*n],1));
		}
	}
	if(maxorthog>1e-13)printf((char*)"Maximum othog value %20.8e\n",maxorthog);
	return maxorthog>1e-12;
}


/*	A voyage of discovery. Prof Henry Wolkowicz presents a robust method for SDP (opt  online nov 2010) in which
	he solves ZX - lI =0 using the least-square solution of the GAUS-NEWTON method. In principle we can do this for
	the equivalent equations in LP and SOCP....*/
inline double SolveIter(size_t n,size_t m,vector w,vector s,vector A,vector Q,
				   vector y,vector v,vector c,vector ww,
				   vector JJ,vector JR)
{
	std::valarray<double>rx(n),rd(n),R(n),Cx,rq;
	std::valarray<short_scl>JJP(n);
	long i,ii,k;
	double Aww,mu;

	for(i=0;i<n;++i)
	{
		rd[i]=s[i]-c[i]+ddotvec(m,y,A+i*m);
		rx[i]=w[i]-ww[i]-BITA_ddot(n-m,v,1,Q+i,n);
	}
	mu=0;//ddotvec(n,&s[0],&w[0])/n;
	for(i=0;i<n;++i)
	{
		R[i]=s[i]*w[i]-mu-s[i]*rx[i]-w[i]*rd[i];
	}
	dzerovec(n,JR);
	dzerovec(n*(n+1)>>1,JJ);
#pragma omp parallel for private(i,ii,k,Aww) schedule(dynamic)
	for(i=0;i<n;++i)//i runs over the opt variable, k runs over stocks
	{
		if(i<m)
		{
			ii=i*(i+1)>>1;
			for(k=0;k<n;++k)
			{
				JR[i]-=R[k]*A[i+k*m]*w[k];
				Aww=w[k]*w[k]*A[i+k*m];
				if(Aww)
				{
					daxpyvec(i+1,Aww,A+k*m,JJ+ii);
				}
			}
		}
		else
		{
			ii=i*(i+1)>>1;
			for(k=0;k<n;++k)
			{
				Aww=s[k]*s[k]*Q[(i-m)*n+k];
				JR[i]+=R[k]*Q[(i-m)*n+k]*s[k];
				if(Aww)
				{
					BITA_daxpy(i+1-m,Aww,Q+k,n,JJ+ii+m,1);
				}
				Aww=-w[k]*s[k]*Q[(i-m)*n+k];
				if(Aww)
				{
					daxpyvec(m,Aww,A+k*m,JJ+ii);
				}
			}
		}
	}
	dnegvec(n,JR);
	short badindex=bunchf(n,JJ,&JJP[0]);
	dsptrs((char*)"U",n,1,JJ,&JJP[0],JR,n);
	double stepw=1,steps=1;
	std::valarray<double>dww(n),ds(n);
	for(i=0;i<n;++i)//Find maximum steps for s and x that keep them both positive
	{
		dww[i]=BITA_ddot(n-m,JR+m,1,Q+i,n)-rx[i];
		if(dww[i]<0)
			stepw=dmin(stepw,(-w[i]/dww[i]));
	}
	if(stepw<1)stepw=stepw*(1-lm_rooteps);
	daxpyvec(n,stepw,&dww[0],w);
	for(i=0;i<n;++i)
	{
		ds[i]=-(ddotvec(m,JR,A+i*m)+rd[i]);
		if(ds[i]<0)
			steps=dmin(steps,(-s[i]/ds[i]));
	}
	if(steps<1)steps=steps*(1-lm_rooteps);
	daxpyvec(n,steps,&ds[0],s);
	daddvec(m,JR,y,y);
	daddvec(n-m,JR+m,v,v);
	return ddotvec(n,&R[0],&R[0]);
}

short LPQN(size_t n,size_t m, vector w,vector A,vector b,vector c)
{
	/*	
		Minimise c.w such that Aw=b w>=0
		Primal		min c.w Aw=b
		Dual		max b.y y.A+s=c s>=0


		Solve		y.A+s-c = 0
					A.w-b   = 0
					diag(w).diag(s)-muI = 0

		If A.w'=b then w=w'+Q.v where v is in the null space of A

		so we only need to solve

		diag(w'+Q.v).diag(c-y.A)-muI=0

		This has n*n equations but only n variables. Using GAUSS-NEWTON we can write

		diag(w'+Q.(v+dv)).diag(c-(y+dy).A) - muI =0

		and solve

		-(diag(w'+Q.v).diag(c-y.A)-muI) = diag(Q.dv).diag(c-y.A) - diag(w'+Q.v).diag(dy.A)

		to get dv and dy and iterate then repeat reducing mu. These equation assume a feasible
		start for y and v

		To allow a non-feasible start, put
		s - c + y.A = rd
		w - w' - Q.v = rx

		and linearise for s to s+ds and w to w+dw
		s+ds -c + (y+dy).A =0
		gives
		rd + ds + dy.A =0
		w+dw -w' - Q.(v+dv) = 0
		gives
		rx + dw -Q.dv=0

		Now we solve
		-(diag(w'+Q.v).diag(c-y.A)-muI)= diag(s)diag(dw) + diag(ds)diag(w)
		i.e.
		-(diag(w'+Q.v).diag(c-y.A)-muI)+diag(s)diag(rx)+diag(w)diag(rd)
		=diag(s)diag(Q.v)-diag(y.A)diag(w)
	*/

#ifdef __SYSNT__
	_ASSERT(0);
#endif
	size_t mm=m*(m+1)>>1,i;
	size_t nn=n*(n+1)>>1;

	std::valarray<double>yv(n),Q(n*(n-m)),R(n*m+m),ww(n),AA(mm),s(n),JJ(nn),JR(n),squareC;
	std::valarray<short_scl>AA_P(m);

	dcopyvec(n*m,A,&R[0]);
	if(nullA(m,n,&R[0],&Q[0])) //R holds the R part of the RQ factorisation and Q holds that part of the Q matrix associated with the null space of A
		return 6;

	AAmake(n,m,A,&AA[0]);

	int badindex=bunchf(m,&AA[0],&AA_P[0]);

	//Get the min norm solution of the constraints in ww
	dcopyvec(m,b,&yv[0]);
	dsptrs((char*)"U",m,1,&AA[0],&AA_P[0],&yv[0],m);//Don't need AA or AA_P any more
	for(i=0;i<n;++i)
		ww[i]=ddotvec(m,A+i*m,&yv[0]);

	yv=0;

	for(i=0;i<n;++i)//Initial guess
	{
		w[i]=dmax(1e-4,ww[i]);
		s[i]=1./n;
	}

	size_t count=0;
	double norm;

	while(true)
	{
		if((norm=SolveIter(n,m,w,&s[0],A,&Q[0],&yv[0],&yv[m],c,&ww[0],&JJ[0],&JR[0]))<lm_eps)break;
		printf((char*)"%d norm squared %20.8e\n",count,norm);
		count++;
	}


	
	printf((char*)"%d iterations to get %20.8e\n",count,norm);

	double primal=ddotvec(n,c,w);
	double dual=ddotvec(m,&yv[0],b);


	printf((char*)"Primal:\t%20.8e\n",primal);
	printf((char*)"Dual:\t%20.8e\n",dual);
	return 0;
}
extern "C" void MXopS(size_t ncone,size_t*cone,size_t*typecone,vector x,vector s,vector xs)
{
	size_t i;
	long j,l,k;
	vector X,S,XS,xm,sm;
	double inner;
	for(i=0,X=x,S=s,XS=xs;i<ncone;++i)
	{
		if(typecone[i]==0)
		{
			for(j=0;j<cone[i];++j)
				*XS++ = *X++ * *S++;
		}
		else if(typecone[i]==1)
		{
			inner=ddotvec(cone[i]-1,X,S);
			xm=X+cone[i]-1;
			sm=S+cone[i]-1;
			for(j=0;j<cone[i]-1;j++)
			{
				*XS++ = *xm * *S++ + *sm * *X++;
			}
			*XS++ = inner + *xm * *sm;
			S++;X++;
		}
		else if(typecone[i]==2)
		{
			size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[i]));
			std::valarray<double>SS(n*n),XXSS(n*n);
			SDPsMat(n,S,&SS[0]);
			XXSS=0;
			for(j=0;j<n;j++)
			{
				for(k=0;k<n;++k)
				{
					if((inner=(X[j+n*k]+X[k+n*j])))
					{
						inner*=.25;
						for(l=0;l<n;++l)
						{
							XXSS[j+l*n]+=inner*SS[k+n*l];
						}
					}
				}
				for(k=0;k<n;++k)
				{
					if((inner=SS[k+n*j]))
					{
						inner*=.25;
						for(l=0;l<n;++l)
						{
							XXSS[j+l*n]+=inner*(X[l+n*k]+X[k+n*l]);
						}
					}
				}
			}
			SDPsvec(n,&XXSS[0],XS);
			X+=n*n;
			S+=cone[i];
			XS+=cone[i];
		}
	}
}
extern "C" void XopSM(size_t ncone,size_t*cone,size_t*typecone,vector x,vector s,vector xs)
{
	size_t i;
	long j,l,k;
	vector X,S,XS,xm,sm;
	double inner;
	for(i=0,X=x,S=s,XS=xs;i<ncone;++i)
	{
		if(typecone[i]==0)
		{
			for(j=0;j<cone[i];++j)
				*XS++ = *X++ * *S++;
		}
		else if(typecone[i]==1)
		{
			inner=ddotvec(cone[i]-1,X,S);
			xm=X+cone[i]-1;
			sm=S+cone[i]-1;
			for(j=0;j<cone[i]-1;j++)
			{
				*XS++ = *xm * *S++ + *sm * *X++;
			}
			*XS++ = inner + *xm * *sm;
			S++;X++;
		}
		else if(typecone[i]==2)
		{
			size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[i]));
			std::valarray<double>XX(n*n),SS(n*n);
			SDPsMat(n,X,&XX[0]);
			SDPsMat(n,S,&SS[0]);
			dzerovec(n*n,XS);
			for(j=0;j<n;++j)
			{
				for(k=0;k<n;++k)
				{
					if((inner=XX[j+n*k]))
					{
						inner*=.5;
						for(l=0;l<n;++l)
						{
							XS[j+n*l]+=inner*SS[k+n*l];
						}
					}
				}
				for(k=0;k<n;++k)
				{
					if((inner=SS[j+n*k]))
					{
						inner*=.5;
						for(l=0;l<n;++l)
						{
							XS[j+n*l]+=inner*XX[k+n*l];
						}
					}
				}
			}
			X+=cone[i];
			S+=cone[i];
			XS+=n*n;
		}
	}
}
extern "C" double conedot(size_t n,vector x,vector y)
{
	double back=x[n-1]*y[n-1];
	n--;
	while(n--)
		back-=*x++ * *y++;
	return back;
}

extern "C" double stepcheck(double xlx,double xldx,double dxldx)
{
	double desc,step=1;
	if(fabs(xldx)>lm_eps)desc=1.-xlx*dxldx/xldx/xldx;
	else desc=-xlx*dxldx;
	if(fabs(xlx)<=lm_eps&&fabs(xldx)<=lm_eps)step=1;
	else if(fabs(xldx)>lm_eps&&fabs(dxldx)<=lm_eps)step=1;
	else if(xldx<-lm_eps&&fabs(dxldx)<=lm_eps)
		step=dmin(step,-xlx/(xldx));
	else if(desc<=lm_eps8&&dxldx>=-lm_eps)step=1;
	else
	{
		if(fabs(xldx)>lm_eps)desc=sqrt(desc)*fabs(xldx);
		else desc=sqrt(desc);
		step=dmin(step,(-(xldx)-desc)/dxldx);
	}
	if(step<0)step=1;
	return step;
}
extern "C" DLLEXPORT short GAUSS_NEWTON_Optimiser(size_t ncone,size_t*cone,size_t*typecone,size_t m,vector x,vector s,vector y,vector A,vector b,vector c)
{
#ifdef __SYSNT__
	_ASSERT(0);
#endif
#ifdef PAS
//	UnlockBita((char*)"colincolin");
	if(!Optimise::bitago)
	{
		fprintf(stderr,(char*)"Bad PAS key\n");
		return -1;
	}
	return -1;
#endif
	Optimise O;
	if(!O.licenced)return -1;
	/*	
	Primal:	Minimise c.x subject to A.x=b				and x is a stacked cone

	Dual:	Maximise b.y subject to A*.y + s =c			and s is a stacked cone

	if typecone[i] = 1 the subcone is a second order cone dimension cone[i]
	if typecone[i] = 0 the subcone is the set x>0 dimension cone[i]
	if typecone[i] = 2 the subcone is the of semi-definite matrices dimension n where cone[i]=n*(n+1)/2
	*/

	size_t nx=0,ix,maxiter=10000;
	Integer i,ii,j;
	for(i=0;i<ncone;++i)
	{
		nx+=cone[i];
	}
	size_t Rl=0;
	for(i=0;i<ncone;++i)
	{
		if(typecone[i]==2)
		{
			size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[i]));
			Rl+=n*n;
		}
		else
			Rl+=cone[i];
	}
	
	Integer N=nx,M=m,lwork,info;
	lwork=-1;
	/*
	A must be of size nx*m
	c x and s must be of size nx
	b and y must be of sixe m
	*/

	/*
	First we find the null space of A in compact form and as a matrix
	*/


	std::valarray<double> CompactQ(nx*m+m),Q((nx-m)*nx);
	dcopyvec(nx*m,A,&CompactQ[0]);
	if(nullA(m,nx,&CompactQ[0],&Q[0]))
		return 6;

	/*
	Next find the minimum norm solution ww for x (this will satisfy A.x=b)
	*/

	std::valarray<double>space(m*m),ww(nx);
	std::valarray<short_scl>AA_P(m);
	AAmake(nx,m,A,&space[0]);

	int badindex=bunchf(m,&space[0],&AA_P[0]);
	if(badindex)return 9;

	dcopyvec(m,b,y);
	dsptrs((char*)"U",m,1,&space[0],&AA_P[0],y,m);//Don't need space or AA_P any more
	for(i=0;i<nx;++i)
		ww[i]=ddotvec(m,A+i*m,y);
//	printx(nx,&ww[0]);

	/*
	Set up the initial guess
	*/

	dzerovec(m,y);
	dzerovec(nx,x);
	dzerovec(nx,s);
//	dcopyvec(nx,&ww[0],x);
//	dcopyvec(nx,&ww[0],s);
	for(i=0,ix=0;i<ncone;i++)
	{
		if(typecone[i]==1)
		{
			s[ix+cone[i]-1]=x[ix+cone[i]-1]=1;//+ddotvec(cone[i]-1,x+ix,x+ix);
			ix+=cone[i];
		}
		else if(typecone[i]==0)
		{
			for(j=ix;j<ix+cone[i];++j)
			{
				s[j]=x[j]=1;
			}
			ix+=cone[i];
		}
		else if(typecone[i]==2)
		{
			size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[i]));
			vector X=x+ix+cone[i]-n;
			vector wX=&ww[ix+cone[i]-n];
			vector S=s+ix+cone[i]-n;
			for(j=0;j<n;++j)
			{
				X[j]=dmax(1.,2*wX[j]);
				S[j]=1.;
			}
//			dsetvec(n,1.,s+ix+cone[i]-n);
//			dsetvec(n,1.,x+ix+cone[i]-n);
			ix+=cone[i];
		}
		else
			return 22;
	}
	if(ix!=nx)return 23;
	double gap=ddotvec(nx,c,x);
	if(gap < 0)
	{
		dsetvec(m,1,y);
		double dgap=ddotvec(m,b,y);
		double step=gap/dgap;
		dsetvec(m,(1+lm_rooteps)*step,y);
	}
	gap=ddotvec(nx,c,x)-ddotvec(m,b,y);

	//Main LOOP ITERATION

	std::valarray<double> Rd(nx),Rx(nx),v(nx-m);
	std::valarray<double> R(Rl);
	double sdx,mu,feasx,feass,feasR;
	std::valarray<double> xx(Rl),ss(Rl),xs(Rl),rx(nx),rs(nx),JR(nx),JJ(nx*(nx+1)/2),Transformed(nx*nx);
	std::valarray<double> dx(nx),ds(nx);
	v=0;
	size_t iter=0;
	while(iter<maxiter)
	{
		
	/*
	Find residuals for the s and x variables
		*/
		space.resize(Rl);
		sdx=ddotvec(nx,s,x);
		for(i=0;i<nx;++i)
		{
			Rd[i]=s[i]-c[i]+ddotvec(m,y,A+i*m);
			Rx[i]=x[i]-ww[i]-BITA_ddot(nx-m,&v[0],1,&Q[i],nx);
/*			if(fabs(Rx[i])>10)//Try to get the complementarity down artificially when a few residuals are large.
			{
				sdx-=Rx[i]*s[i];
				if(sdx>0)
				{
					x[i]-=Rx[i];
					Rx[i]=0;
				}
				else
					sdx+=Rx[i]*s[i];
			}
			if(fabs(Rd[i])>10)//Try to get the complementarity down artificially when a few residuals are large.
			{
				sdx-=Rd[i]*x[i];
				if(sdx>0)
				{
					s[i]-=Rd[i];
					Rd[i]=0;
				}
				else
					sdx+=Rd[i]*x[i];
			}*/
		}
//		sdx=ddotvec(nx,s,x);
		feasx=ddotvec(nx,&Rx[0],&Rx[0]);
		feass=ddotvec(nx,&Rd[0],&Rd[0]);
		
		if(feasx+feass < 1e-12)mu = 0.5*fabs(sdx/Rl);
		else mu=fabs(sdx/Rl);
		if(mu<lm_eps)mu=0;
		/*
		Residuals for complementarity equations
		*/
		
		
		XopSM(ncone,cone,typecone,s,x,&R[0]);
		XopSM(ncone,cone,typecone,s,&Rx[0],&space[0]);
		dsubvec(Rl,&R[0],&space[0],&R[0]);
		XopSM(ncone,cone,typecone,&Rd[0],x,&space[0]);
		dsubvec(Rl,&R[0],&space[0],&R[0]);
		
		for(i=0,ix=0;i<ncone;i++)
		{
			if(typecone[i]==1)
			{
				R[ix+cone[i]-1]-=mu;ix+=cone[i];
			}
			else if(typecone[i]==0)
			{
				for(j=ix;j<ix+cone[i];++j)
				{
					R[j]-=mu;
				}
				ix+=cone[i];
			}
			else if(typecone[i]==2)
			{
				size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[i])),j;
				for(j=0;j<n;++j)
				{
					R[ix+j+n*j]-=mu;
				}
				ix+=n*n;
			}
		}

		feasR=ddotvec(Rl,&R[0],&R[0]);
		if(feasR<lm_eps&&feass<lm_eps&&feasx<lm_eps&&fabs(sdx)<lm_eps*nx*10)
			break;
		
		/*
		Set up the GAUSS-NEWTON  equations
		*/
		
		XopSM(ncone,cone,typecone,x,x,&xx[0]);
		XopSM(ncone,cone,typecone,s,s,&ss[0]);
		XopSM(ncone,cone,typecone,s,x,&xs[0]);
		MXopS(ncone,cone,typecone,&R[0],s,&rs[0]);
		MXopS(ncone,cone,typecone,&R[0],x,&rx[0]);
		dmx_transpose(m,nx,A,A);
		JJ=0;
#pragma omp parallel for private(i,ii,j) schedule(dynamic)
		for(i=0;i<m;++i)
		{
			ii=i*(i+1)>>1;
			JR[i]=-ddotvec(nx,&rx[0],A+i*nx);
			MXopS(ncone,cone,typecone,&xx[0],A+i*nx,&Transformed[i*nx]);
			for(j=0;j<nx;++j)
			{
				if(A[j+i*nx])
					BITA_daxpy(i+1,A[j+i*nx],&Transformed[j],nx,&JJ[ii],1);
			}
		}
		//from here on need -xs
		dnegvec(Rl,&xs[0]);
#pragma omp parallel for private(i) schedule(dynamic)
		for(i=0;i<m;++i)
		{
			MXopS(ncone,cone,typecone,&xs[0],A+i*nx,&Transformed[i*nx]);
		}
		for(i=m;i<nx;++i)
		{
			ii=i*(i+1)>>1;
			JR[i]=ddotvec(nx,&rs[0],&Q[(i-m)*nx]);
			MXopS(ncone,cone,typecone,&ss[0],&Q[(i-m)*nx],&Transformed[i*nx]);
		}
		if(lwork==-1)
		{
			dormrq_BITA((char*)"L",(char*)"N",&N,&N,&M,&CompactQ[0],&M,&CompactQ[nx*m],&Transformed[0],&N,&space[0],&lwork,&info);
			lwork=max(N,(Integer)space[0]);
		}
		space.resize(lwork);
		dormrq_BITA((char*)"L",(char*)"N",&N,&N,&M,&CompactQ[0],&M,&CompactQ[nx*m],&Transformed[0],&N,&space[0],&lwork,&info);
		dmx_transpose(nx,nx,&Transformed[0],&Transformed[0]);
		for(i=m;i<nx;++i)
		{
			ii=i*(i+1)>>1;
			dcopyvec(i+1,&Transformed[(i-m)*nx],&JJ[ii]);
		}
		
		dmx_transpose(nx,m,A,A);

		dnegvec(nx,&JR[0]);
		
//		printx(nx,&JR[0]);
//		printsym(nx,&JJ[0]);
		AA_P.resize(nx);
#ifdef GET_JJ_EIG
		dcopyvec(nx*(nx+1)>>1,&JJ[0],&Transformed[0]);
		packed2symm(nx,&Transformed[0]);
		eigendecomp(nx,&Transformed[0],&space[0],100);
		printx(nx,&space[0]);
#endif
		badindex=bunchf(nx,&JJ[0],&AA_P[0]);
		if(badindex)
			return 1;
		
		//Solve the GAUSS-NEWTON equations
		dsptrs((char*)"U",nx,1,&JJ[0],&AA_P[0],&JR[0],nx);
		
		//Find the corrections for x and s
#pragma omp parallel for private(i) schedule(dynamic)
		for(i=0;i<nx;++i)
		{
			ds[i]=-(ddotvec(m,&JR[0],A+i*m)+Rd[i]);
			dx[i]=BITA_ddot(nx-m,&JR[m],1,&Q[i],nx)-Rx[i];
		}
		
		//Find the largest (hopefully) step upto full Newton step that maintains the cone constraints and complementarity
		double stepx=1,steps=1,step=1;
		double xds=ddotvec(nx,x,s),xdds=ddotvec(nx,x,&ds[0]),dxds=ddotvec(nx,&dx[0],s),dxdds=ddotvec(nx,&dx[0],&ds[0]);
		double desc;
		if(fabs(dxds+xdds)>lm_eps)desc=1.-4*xds*dxdds/(dxds+xdds)/(dxds+xdds);
		else desc=-4*xds*dxdds;
		if(fabs(xds)<=lm_eps&&fabs(dxdds)<=lm_eps)step=1;
		else if(fabs(dxds+xdds)>lm_eps&&fabs(dxdds)<=lm_eps)step=1;
		else if((dxds+xdds)<-lm_eps&&fabs(dxdds)<=lm_eps)
			step=dmin(step,-xds/(dxds+xdds));
		else if(desc<=lm_eps8&&dxdds>-lm_eps)step=1;
		else
		{
			if(fabs(dxds+xdds)>lm_eps)desc=sqrt(desc)*fabs(dxds+xdds);
			else desc=sqrt(desc);
			step=dmin(step,0.5*(-(dxds+xdds)-desc)/dxdds);
		}
		if(step<0)step=1;
		for(i=0,ix=0;i<ncone;i++)
		{
			if(typecone[i]==1)
			{
				stepx=dmin(stepx,stepcheck(conedot(cone[i],x+ix,x+ix),conedot(cone[i],x+ix,&dx[ix]),conedot(cone[i],&dx[ix],&dx[ix])));
				steps=dmin(steps,stepcheck(conedot(cone[i],s+ix,s+ix),conedot(cone[i],s+ix,&ds[ix]),conedot(cone[i],&ds[ix],&ds[ix])));
				ix+=cone[i];
			}
			else if(typecone[i]==0)
			{
				for(j=ix;j<ix+cone[i];++j)
				{
					if(x[j]>0&&dx[j]<0)
						stepx=dmin(stepx,(-x[j]/dx[j]));
					if(s[j]>0&&ds[j]<0)
						steps=dmin(steps,(-s[j]/ds[j]));
				}
				ix+=cone[i];
			}
			else if(typecone[i]==2)
			{
				size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[i])),j;
				std::valarray<double>XS(n*n),dXS(n*n);
				vector p,eig=&XS[0];

				SDPsMat(n,x+ix,&XS[0]);
				//printx(n*n,&XS[0]);
				SDPsMat(n,&dx[ix],&dXS[0]);
				symm2packed(n,&XS[0]);
				AA_P.resize(n);
				badindex=bunchf(n,&XS[0],&AA_P[0]);
				for(j=0,p=&dXS[0];j<n;j++,p+=n)
				{
					dsptrs((char*)"U",n,1,&XS[0],&AA_P[0],p,n);
				}
				square2sqsymm(n,&dXS[0]);//Forces dXS to be symmetric
				size_t r=eigendecomp(n,&dXS[0],eig,100);
				if(eig[n-1]<0)
					stepx=dmin((-1.0/eig[n-1]),stepx);
				
				SDPsMat(n,s+ix,&XS[0]);
				//printx(n*n,&XS[0]);
				SDPsMat(n,&ds[ix],&dXS[0]);
				symm2packed(n,&XS[0]);
				badindex=bunchf(n,&XS[0],&AA_P[0]);
				for(j=0,p=&dXS[0];j<n;j++,p+=n)
				{
					dsptrs((char*)"U",n,1,&XS[0],&AA_P[0],p,n);
				}
				square2sqsymm(n,&dXS[0]);
				r=eigendecomp(n,&dXS[0],eig,100);
				if(eig[n-1]<0)
					steps=dmin((-1.0/eig[n-1]),steps);
				
				ix+=cone[i];
			}
		}
		stepx=dmin(step,stepx);
		steps=dmin(step,steps);
		double reduc=.5,xds1,crat;
		
		if(stepx<1)stepx*=reduc;
		if(steps<1)steps*=reduc;
		
/*		if(false&&(stepx<1e-3||steps<1e-3))
		{
			//Reset x and s
			double ext=0.1*fabs((ddotvec(nx,c,x)-ddotvec(m,b,y)))/nx;
			vector X,S;
			
			for(i=0,X=x,S=s;i<ncone;++i)
			{
				if(typecone[i]==0)
				{
					for(j=0;j<cone[i];++j)
					{
						*X++ +=ext;
						*S++ +=ext;
					}
				}
				else if(typecone[i]==1)
				{
					X+=cone[i]-1;
					S+=cone[i]-1;
					*X++ +=ext;
					*S++ +=ext;
				}
				else if(typecone[i]==2)
				{
					size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[i]));
					X+=cone[i]-n;
					S+=cone[i]-n;
					for(j=0;j<n;++j)
					{
						*X++ +=ext;
						*S++ +=ext;
					}
				}
			}
		}
		else*/
		{
			//	Update all the variables
			daxpyvec(nx,stepx,&dx[0],x);
			daxpyvec(nx,steps,&ds[0],s);
			xds1=ddotvec(nx,x,s);crat=xds1/xds;
			printf((char*)"Iter %d step %e, stepx %e, steps %e, ratio %e, comp %e; feasx %e feass %e feas %e\n",iter,step,stepx,steps,crat,xds1,feasx,feass,feasR);
			if(stepx==1&&steps==1&&crat>100)
			{
				daxpyvec(nx,-.25*stepx,&dx[0],x);
				daxpyvec(nx,-.25*steps,&ds[0],s);
				xds1=ddotvec(nx,x,s);crat=xds1/xds;	
				printf((char*)"Iter %d step %e, stepx %e, steps %e, ratio %e, comp %e; feasx %e feass %e feas %e\n",iter,step,stepx,steps,crat,xds1,feasx,feass,feasR);
			}
			if(crat<0&&xds<lm_eps*nx*100)
			{
				daxpyvec(nx,-stepx,&dx[0],x);
				daxpyvec(nx,-steps,&ds[0],s);
				return 0;
			}
			daxpyvec(m,1.,&JR[0],y);
			daxpyvec(nx-m,1.,&JR[m],&v[0]);
		}
		iter++;
	}
	if(iter==maxiter&&sdx>lm_eps*nx)
		return 6;
	return 0;
}

bool checkzerov(size_t n,vector a)
{
	while(n--)
	{
#ifdef __SYSNT__
		if(disnan_BITA(a))
			_ASSERT(0);
#endif
		if(*a)
		{
			return false;
		}
		a++;
	}
	return true;
}
void Qmulvec(size_t ncone,vector A,bool rotate=false)
{
	if(!rotate)
	{
		if(ncone>1)
		{
			dnegvec(ncone-1,A);
		}
	}
	else
	{
		dnegvec(ncone-2,A);
		std::swap(A[ncone-2],A[ncone-1]);
	}
}
void Tmulvec(size_t ncone,vector A,bool rotate=false)
{
	if(rotate)
	{
		double a12=(-A[ncone-2]+A[ncone-1])*lm_rroot2;
		double a11=(A[ncone-2]+A[ncone-1])*lm_rroot2;
		A[ncone-1]=a11;
		A[ncone-2]=a12;
	}
}
void thetaScale(size_t ncone,vector A,double theta,bool recip=false,bool square=false)
{
	if((*A||ncone>1)&&theta!=1)
	{
		if(square)
			theta *= theta;
		if(recip)
			theta=1./theta;
		dscalvec(ncone,theta,A);
	}
}


void WtransR(size_t ncone,vector A,vector w,vector WA)
{
	vector wm,Am,pA=A,pWA=WA;
	size_t j;
	double wc,bot;
	Tmulvec(ncone,pA,true);
	wc=ddotvec(ncone-1,w,A);
	if(disnan_BITA(&wc))
		printf((char*)"nan wc in transR\n");
	wm=w+ncone-1;
	if(disnan_BITA(wm))
		printf((char*)"bad wm in WtransR %e\n",*wm);
	Am=A+ncone-1;
	bot=1+*wm;
	if(bot<lm_eps)
		printf((char*)"bad cone in WtransR %e\n",bot);
	for(j=0;j<ncone-1;++j,WA++,w++,A++)
	{
		if(wc) *WA=*w*wc/bot;
		else *WA=0;
		*WA += *A + *w * *Am;
	}
	*WA++=wc+*wm* *Am;
	Tmulvec(ncone,pA,true);
	Tmulvec(ncone,pWA,true);
}
extern "C" DLLEXPORT void Wtrans(size_t ncone,vector A,vector w,vector WA)
{
	vector wm,Am;
	size_t j;
	double wc,bot;
	if(ncone==1)
	{
		*WA++=*w++* *A++;
	}
	else
	{
		wc=ddotvec(ncone-1,w,A);
		if(disnan_BITA(&wc))
		{
			printf((char*)"nan wc in Wtrans\n");
		//	printnx(ncone,w,(char*)"w");
		//	printnx(ncone,A,(char*)"A");
		}
#ifdef __SYSNT__
		if(disnan_BITA(&wc))
			_ASSERT(0);
#endif
		wm=w+ncone-1;
		if(disnan_BITA(wm))
			printf((char*)"bad wm in Wtrans %e\n",*wm);
#ifdef __SYSNT__
		if(disnan_BITA(wm))
			_ASSERT(0);
#endif
		Am=A+ncone-1;
		bot=1.+*wm;
		if(bot<lm_eps)
			printf((char*)"bad cone in Wtrans %e\n",bot);
#ifdef __SYSNT__
		if(!bot)
			_ASSERT(0);
#endif
		for(j=0;j<ncone-1;++j,WA++,w++,A++)
		{
			if(wc) *WA=*w*wc/bot;
			else *WA=0;
			*WA += *A + *w * *Am;
		}
		*WA++=wc+*wm* *Am;
	}
}
extern "C" DLLEXPORT void WtransSDP(size_t n,vector A,vector w,vector WA,bool inv=false,bool squared=false)
{
	if(n==1)
	{
		if(!squared)
		{
			if(!inv)
				*WA=*w * *A;
			else
				*WA=*A/ *w;
		}
		else
		{
			if(!inv)
				*WA=*w * *w * *A;
			else
				*WA=*A/ *w/ *w;
		}
		return;
	}
	size_t i,n2=n*n;
	vector xx,pr;
	std::valarray<double>W(n2),RW(n2),TA(n2);
	SDPsMat(n,w,&W[0]);
	SDPsMat(n,A,&TA[0]);
	if(!squared)
	{
		symm2packed(n,&W[0]);
		if(inv)
			RootProcessQ(n,&W[0],0,&RW[0]);
		else
			RootProcessQ(n,&W[0],&RW[0],0);
	}
	else
	{
		if(inv)
		{
			symm2packed(n,&W[0]);
			RootProcessQ(n,&W[0],0,&RW[0]);
			for(i=0,xx=&RW[0],pr=&W[0];i<n;++i)
			{
				dmxmulv(n,n,&RW[0],xx,pr);
				xx+=n;
				pr+=n;
			}
		}
		dcopyvec(n2,&W[0],&RW[0]);
	}
	for(i=0,xx=&RW[0],pr=&W[0];i<n;++i)
	{
		dmxmulv(n,n,&TA[0],xx,pr);
		xx+=n;
		pr+=n;
	}
	for(i=0,xx=&W[0],pr=&TA[0];i<n;++i)
	{
		dmxmulv(n,n,&RW[0],xx,pr);
		xx+=n;
		pr+=n;
	}
	SDPsvec(n,&TA[0],WA);
}
extern "C" DLLEXPORT void W2trans(size_t ncone,vector A,vector w,vector W2A)
{
	size_t j;
	double wc;
	if(ncone==1)
	{
		if(*w&&*A)*W2A=*w* *w* *A;
		else *W2A=0;
		A++;w++;W2A++;
	}
	else
	{
		wc=ddotvec(ncone,w,A);
		if(disnan_BITA(&wc))
			printf((char*)"nan wc in W2trans\n");
#ifdef __SYSNT__
		if(disnan_BITA(&wc))
			_ASSERT(0);
#endif
		if(wc!=0.0)
		{
			for(j=0;j<ncone-1;++j)
			{
				*W2A=2* *w *wc +*A;
				A++;w++;W2A++;
			}
			*W2A=2* *w *wc- *A;
			A++;w++;W2A++;
		}
		else
		{
			dcopyvec(ncone-1,A,W2A);
			W2A+=ncone-1;w+=ncone;A+=ncone-1;
			*W2A=-*A;
			W2A++;A++;
		}
	}
}
void W2transR(size_t ncone,vector A,vector w,vector W2A)
{
	size_t j;
	vector pA=A,pW2A=W2A;
	double wc;
	Tmulvec(ncone,pA,true);
	wc=ddotvec(ncone,w,A);
	if(disnan_BITA(&wc))
		printf((char*)"nan wc in W2transR\n");
#ifdef __SYSNT__
	if(disnan_BITA(&wc))
		_ASSERT(0);
#endif
	if(wc!=0.0)
	{
		for(j=0;j<ncone-1;++j)
		{
			*W2A=2* *w *wc +*A;
			A++;w++;W2A++;
		}
		*W2A=2* *w *wc- *A;
		A++;w++;W2A++;
	}
	else
	{
		dcopyvec(ncone-1,A,W2A);
		W2A+=ncone-1;w+=ncone;A+=ncone-1;
		*W2A=-*A;
		W2A++;A++;
	}
	Tmulvec(ncone,pA,true);
	Tmulvec(ncone,pW2A,true);
}


void applyX(size_t ncone,vector x,vector A,vector XA)
{
	vector xm,rm;
	double inner;
	size_t j;
	if(ncone==1)
	{
		*XA++ = *A++* *x++;
	}
	else
	{
		inner=ddotvec(ncone-1,A,x);
#ifdef __SYSNT__
		if(disnan_BITA(&inner))
			_ASSERT(0);
#endif
		if(disnan_BITA(&inner))
			printf((char*)"inner is nan in applyX\n");
		for(j=0,rm=A+ncone-1,xm=x+ncone-1;j<ncone;++j,x++,A++,XA++)
		{
			if(j!=(ncone-1)){*XA=*xm* *A + *rm* *x;}
			else{*XA=inner+*rm* *xm;}
		}
	}
}
extern "C" DLLEXPORT void applyXSDPold(size_t n,vector x,vector a,vector xa)
{
	size_t i,n2=n*n;
	std::valarray<double>X(n2),A(n2),XA(n2);
	vector pp,qq;
	SDPsMat(n,x,&X[0]);
	SDPsMat(n,a,&A[0]);
	XA=0;
	for(i=0,pp=&A[0],qq=&XA[0];i<n;++i,pp+=n,qq+=n)
	{
		dmxmulv(n,n,&X[0],pp,qq);
	}
	square2sqsymm(n,&XA[0]);
	SDPsvec(n,&XA[0],xa);
}
extern "C" DLLEXPORT void applyXm1SDPold(size_t n,vector x,vector a,vector xa)
{
	size_t i,n2=n*n;
	std::valarray<double>X(n2),A(n2);
	std::valarray<short_scl>AA_P(n);
	vector pp;
	SDPsMat(n,x,&X[0]);
	SDPsMat(n,a,&A[0]);
	symm2packed(n,&X[0]);
	int badi=bunchf(n,&X[0],&AA_P[0]);
	if(badi)
	{
		for(i=0;i<n;++i)
		{
			if(fabs(X[i*(i+3)>>1])<lm_eps)
				X[i*(i+3)>>1]=lm_eps;
		}
	}
	for(i=0,pp=&A[0];i<n;++i,pp+=n)
		dsptrs((char*)"U",n,1,&X[0],&AA_P[0],pp,n);
	square2sqsymm(n,&A[0]);
	SDPsvec(n,&A[0],xa);
}
extern "C" DLLEXPORT void applyXm1SDP(size_t n,vector x,vector a,vector xa)
{
	if(n==1)
	{
		*xa = *a / *x;
		return;
	}
	size_t i,n2=n*n;
	std::valarray<double>X(n2),A(n2),RX(n2);
	SDPsMat(n,x,&X[0]);
	SDPsMat(n,a,&A[0]);
	symm2packed(n,&X[0]);
	RootProcessQ(n,&X[0],0,&RX[0]);
	vector xx,pr;
	for(i=0,xx=&RX[0],pr=&X[0];i<n;++i)//ArootXm1
	{
		dmxmulv(n,n,&A[0],xx,pr);
		xx+=n;
		pr+=n;
	}
	for(i=0,xx=&X[0],pr=&A[0];i<n;++i)//rootXm1ArootXm1...(symmetric AXm1)
	{
		dmxmulv(n,n,&RX[0],xx,pr);
		xx+=n;
		pr+=n;
	}
	SDPsvec(n,&A[0],xa);
}
extern "C" DLLEXPORT void applyXSDP(size_t n,vector x,vector a,vector xa)
{
	if(n==1)
	{
		*xa = *a * *x;
		return;
	}
	size_t i,n2=n*n;
	std::valarray<double>X(n2),A(n2),RX(n2);
	SDPsMat(n,x,&X[0]);
	SDPsMat(n,a,&A[0]);
	symm2packed(n,&X[0]);
	RootProcessQ(n,&X[0],&RX[0],0);
	vector xx,pr;
	for(i=0,xx=&RX[0],pr=&X[0];i<n;++i)//ArootX
	{
		dmxmulv(n,n,&A[0],xx,pr);
		xx+=n;
		pr+=n;
	}
	for(i=0,xx=&X[0],pr=&A[0];i<n;++i)//rootXArootX...(symmetric AX)
	{
		dmxmulv(n,n,&RX[0],xx,pr);
		xx+=n;
		pr+=n;
	}
	SDPsvec(n,&A[0],xa);
}
void applyXm1(size_t ncone,vector x,vector A,vector Xm1A)
{
	vector rr4=A,hh1=Xm1A,xx=x,xm,rm;
	double outer,inner;
	bool hh_nan=false;
	size_t j;
	if(ncone==1)
	{
		*hh1++ = *rr4++/ *xx++;
	}
	else
	{
		outer=xx[ncone-1]*xx[ncone-1]-ddotvec(ncone-1,xx,xx);
		if(outer<=0)
		{
			printf((char*)"outer is not positive in applyXm1 %e xx[ncone-1] %e\n",outer,xx[ncone-1]);
			if(xx[ncone-1]>lm_rooteps)
			{
				dscalvec(ncone-1,.95*xx[ncone-1]/sqrt(xx[ncone-1]*xx[ncone-1]-outer),xx);
			}
			else
			{
				dsetvec(ncone-1,lm_rooteps,xx);
				xx[ncone-1] = (1.+lm_rooteps)*lm_rooteps*sqrt(float(ncone));
			}
			outer=xx[ncone-1]*xx[ncone-1]-ddotvec(ncone-1,xx,xx);
			printf((char*)"fixed outer is now %e\n",outer);
		}
		if(disnan_BITA(&outer))
			printf((char*)"outer is nan in applyXm1\n");
		inner=ddotvec(ncone-1,rr4,xx);
		if(disnan_BITA(&inner))
			printf((char*)"inner is nan in applyXm1\n");
		rm=rr4+ncone-1;
		xm=xx+ncone-1;
		if(disnan_BITA(rm))
			printf((char*)"rm is nan in applyXm1\n");
		if(disnan_BITA(xm))
			printf((char*)"xm is nan in applyXm1\n");
		for(j=0,rm=rr4+ncone-1,xm=xx+ncone-1;j<ncone;++j,xx++,rr4++,hh1++)
		{
			if(j!=(ncone-1)){*hh1=*xx*inner/ *xm/outer+*rr4/ *xm-*rm* *xx/outer;}
			else{*hh1=(-inner+*rm* *xm)/outer;}
			if(disnan_BITA(hh1))
			{
			//	printf((char*)"j=%d hh1=%e rr4=%e xx=%e inner=%e outer=%e rm=%e xm=%e\n",j,*hh1,*rr4,*xx,inner,outer,*rm,*xm);
				hh_nan=true;
			}
		}
		if(hh_nan)
			printf((char*)"Output from applyXm1 contains nan inner=%e outer=%e\n",inner,outer);
	}
}
extern "C" DLLEXPORT void InitialiseGen(Integer n,void**work)
{
	class SparseChol *K=new class SparseChol(n);
	*work=(void*)K;
}
extern "C" DLLEXPORT Integer FactorGen(Integer n,double*M,void**work)
{
	class SparseChol *W1;
	if(*work)
	{
		W1=(SparseChol*)*work;
		W1->SetM(M);
	}
	else
	{
		W1=new class SparseChol(n,M);
		*work=(void*)W1;
	}
	W1->CreateSparseIndices();
	Integer back=W1->Symbolic();
	return W1->Factor();
}
extern "C" DLLEXPORT bool FactorSymm(dimen n,double*M,void**work)
{
	class SymmetricSolver *C;
	if(*work)
	{
		C=(SymmetricSolver *)*work;
		if(C->n!=n)
			C->~SymmetricSolver();
	}
	else
	{
		C=new class SymmetricSolver();
		*work=(void*)C;
	}
	return C->Factor(n,M);
}
extern "C" DLLEXPORT void SolveSymm(double*b,void**work)
{
	class SymmetricSolver *C=(SymmetricSolver*)*work;
	C->Solve(b);
}
extern "C" DLLEXPORT void SolveGen(double*b,void**work)
{
	class SparseChol *W=(SparseChol*)*work;
	W->Solve(b);
}
extern "C" DLLEXPORT void DeleteGen(void**work)
{
	class SparseChol *W=(SparseChol*)*work;
	*work=0;
	delete W;
}
extern "C" DLLEXPORT void DeleteSymm(void**work)
{
	class SymmetricSolver *W=(SymmetricSolver*)*work;
	*work=0;
	delete W;
}
void AAsolve(size_t nx,size_t m,size_t ncone,int* cone,int* typecone,vector w,vector theta,vector A,vector AA,short_scl*AA_P,vector qn,vector qm,short&changetodouble,bool&usedouble,float*AAAA,void**work,void**workQ,int method,
			 long nf=0,size_t ns=0,size_t Qstart=0,vector Q=0,vector LL=0,short_scl*Qpiv=0)
{
/*
Solve
	-(theta W)**2       AT  pn    qn
                               =
	A                   0   pm    qm
(overwriting qn and qm with pn and pm.)

We find;
pm = (A(theta W)**-2AT)**-1 (qm + A(theta W)**-2 qn)    ...(1)

pn = -(theta W)**-2 * (qn - ATpm)                       ...(2)
*/
	std::valarray<double> cc1(nx);
	size_t j,ix,k;
	for(j=0,ix=0;j<ncone;ix+=cone[j],j++)
	{
		if(typecone[j]==0)
		{
			if(ns&&ix==Qstart)
			{
				if(nf>0)facmul_and_inv(ns,nf,Q,qn+ix,&cc1[ix],1);
				else 
				{
					dcopyvec(cone[j],qn+ix,&cc1[ix]);
					if(*workQ)
						SolveGen(&cc1[0],workQ);
					else
						dsptrs((char *)"U",cone[j],1,Q,Qpiv,&cc1[ix],cone[j]);
				}
			}
			else
			{
				for(k=0;k<cone[j];++k)
				{
					WtransSDP(1,qn+ix+k,w+ix+k,&cc1[ix+k],true,true);
				}
			}
		}
		else if(typecone[j]==2)
		{
			size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[j]));
			WtransSDP(n,qn+ix,w+ix,&cc1[ix],true,true);
		}
		else if(typecone[j]==1)
		{
			if(ns&&ix==Qstart)
			{
				if(nf>0)lowrank_facmul_and_inv(cone[j],nf,LL,Q,qn+ix,&cc1[ix],1,Qpiv);
				else 
				{
					dcopyvec(cone[j],qn+ix,&cc1[ix]);
					if(*workQ)
						SolveGen(&cc1[ix],workQ);
					else
						dsptrs((char *)"U",cone[j],1,Q,Qpiv,&cc1[ix],cone[j]);
				}
			}
			else
			{
				Qmulvec(cone[j],qn+ix);
				W2trans(cone[j],qn+ix,w+ix,&cc1[ix]);
				Qmulvec(cone[j],qn+ix);
				Qmulvec(cone[j],&cc1[ix]);
				thetaScale(cone[j],&cc1[ix],theta[j],true,true);
			}
		}
		else if(typecone[j]==3)
		{
			if(ns&&ix==Qstart)
			{
				if(nf>0)lowrank_facmul_and_inv(cone[j],nf,LL,Q,qn+ix,&cc1[ix],1,Qpiv);
				else 
				{
					dcopyvec(cone[j],qn+ix,&cc1[ix]);
					if(*workQ)
						SolveGen(&cc1[ix],workQ);
					else
						dsptrs((char *)"U",cone[j],1,Q,Qpiv,&cc1[ix],cone[j]);
				}
			}
			else
			{
				Qmulvec(cone[j],qn+ix,typecone[j]==3);
				W2transR(cone[j],qn+ix,w+ix,&cc1[ix]);
				Qmulvec(cone[j],qn+ix,typecone[j]==3);
				Qmulvec(cone[j],&cc1[ix],typecone[j]==3);
				thetaScale(cone[j],&cc1[ix],theta[j],true,true);
			}
		}
	}
	size_t i;
	vector pq,pc,pA;
	bool nancheck=false;
	for(i=0,pq=qm,pc=&cc1[0],pA=A;i<m;++i,pq++,pA+=nx)
	{
		*pq+=ddotvec(nx,pA,pc);//                       ...(1)
		if(disnan_BITA(pq))
			nancheck=true;
	}
	if(nancheck)
			printf((char*)"nan before solve\n");
#ifdef USE_SINGLE
	if(!usedouble)
	{
		std::valarray<float>sqm(m);
		std::valarray<double>qmkeep(m);
		std::valarray<double>qmest(m);
		double resid;
//		float* AAAA=&(*AAsingle)[0];
		for(i=0;i<m;++i)
		{
			sqm[i]=static_cast<float>(qm[i]);
			qmkeep[i]=qm[i];//b
		}
		ssptrs((char*)"U",m,1,AAAA,AA_P,&sqm[0],m);
		for(i=0;i<m;++i)
		{
			qm[i]=static_cast<double>(sqm[i]);//estimate of x
		}
		newmult(m,AA,&qm[0],&qmest[0]);//Ax
		dsubvec(m,&qmkeep[0],&qmest[0],&qmest[0]);//b-Ax
		resid=lmod(m,&qmest[0])/m;
//				printf((char*)"Error in b-Ax %e\n",resid);
		double oldresid=resid;
		size_t single_count=0;
		while (resid>=lm_eps&&single_count<10)
		{
			std::valarray<double> dsqm(m);
			for(i=0;i<m;++i)
				sqm[i]=static_cast<float>(qmest[i]);
			ssptrs((char*)"U",m,1,AAAA,AA_P,&sqm[0],m);//A-1 (b-Ax)
			for(i=0;i<m;++i)
			{
				dsqm[i]=static_cast<double>(sqm[i]);//x+A-1(b-Ax) update x estimate
				qm[i]+=dsqm[i];
			}
			newmult(m,AA,&qm[0],&qmest[0]);
			dsubvec(m,&qmkeep[0],&qmest[0],&qmest[0]);
			resid=lmod(m,&qmest[0])/m;
//					printf((char*)"Error in b-Ax %e\n",resid);
			if(oldresid < resid)
			{
				for(i=0;i<m;++i)
				{
					qm[i]-=dsqm[i];//change it back
				}
				resid=oldresid;
				break;
			}
			oldresid=resid;
			single_count++;
		}
		if(resid >= lm_eps)
		{
			changetodouble=1;
		}
		else if(single_count>4)
		{
			changetodouble=2;
		}
	}
	else
		dsptrs((char*)"U",m,1,AA,AA_P,&qm[0],m);
#else
	switch(method)
	{
	case 0:
		dsptrs((char*)"U",m,1,AA,AA_P,&qm[0],m);
		break;
	case 1:
		SolveGen(&qm[0],work);
		break;
	case 2:
		SolveSymm(&qm[0],work);
		break;
	}
		/*//Choleski test
		{
			Integer NN=(Integer)m,LDB=NN,NRHS=1,info;
			dpptrs_BITA((char*)"U",&NN,&NRHS,AA,&qm[0],&LDB,&info);
		}
		*/

#endif
	nancheck=false;
	for(i=0,pq=qn,pc=&cc1[0],pA=A;i<nx;++i,pq++,pc++,pA++)
	{
		*pc=-*pq+BITA_ddot(m,pA,nx,qm,1);//                  ...(2)
		if(disnan_BITA(pc))
			nancheck=true;
	}
	if(nancheck)
			printf((char*)"nan after solve\n");
	for(j=0,ix=0;j<ncone;ix+=cone[j],j++)
	{
		if(typecone[j]==0)
		{
			if(ns&&ix==Qstart)
			{
				if(nf>0)facmul_and_inv(ns,nf,Q,&cc1[ix],qn+ix,1);
				else 
				{
					dcopyvec(cone[j],&cc1[ix],qn+ix);
					if(*workQ)
						SolveGen(qn+ix,workQ);
					else
						dsptrs((char *)"U",cone[j],1,Q,Qpiv,qn+ix,cone[j]);
				}
			}
			else
			{
				for(k=0;k<cone[j];++k)
				{
					WtransSDP(1,&cc1[ix+k],w+ix+k,qn+ix+k,true,true);
				}
			}
		}
		else if(typecone[j]==2)
		{
			size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[j]));
			WtransSDP(n,&cc1[ix],w+ix,qn+ix,true,true);
		}
		else if(typecone[j]==1)
		{
			if(ns&&ix==Qstart)
			{
				if(nf>0)lowrank_facmul_and_inv(cone[j],nf,LL,Q,&cc1[ix],qn+ix,1,Qpiv);
				else 
				{
					dcopyvec(cone[j],&cc1[ix],qn+ix);
					if(*workQ)
						SolveGen(qn+ix,workQ);
					else
						dsptrs((char *)"U",cone[j],1,Q,Qpiv,qn+ix,cone[j]);
				}
			}
			else
			{
				Qmulvec(cone[j],&cc1[ix]);
				W2trans(cone[j],&cc1[ix],w+ix,qn+ix);
				Qmulvec(cone[j],qn+ix);
				thetaScale(cone[j],qn+ix,theta[j],true,true);
			}
		}
		else if(typecone[j]==3)
		{
			if(ns&&ix==Qstart)
			{
				if(nf>0)lowrank_facmul_and_inv(cone[j],nf,LL,Q,&cc1[ix],qn+ix,1,Qpiv);
				else 
				{
					dcopyvec(cone[j],&cc1[ix],qn+ix);
					if(*workQ)
						SolveGen(qn+ix,workQ);
					else
						dsptrs((char *)"U",cone[j],1,Q,Qpiv,qn+ix,cone[j]);
				}
			}
			else
			{
				Qmulvec(cone[j],&cc1[ix],typecone[j]==3);
				W2transR(cone[j],&cc1[ix],w+ix,qn+ix);
				Qmulvec(cone[j],qn+ix,typecone[j]==3);
				thetaScale(cone[j],qn+ix,theta[j],true,true);
			}
		}
	}
}
double gettheta(size_t n,vector s,vector x)
{
	if(n==1)
	{
		//return sqrt(dprotdiv(s, x,0));
		return sqrt(*s/ *x);
	}
	vector sm=s+n-1,xm=x+n-1;
	double xQx=*xm* *xm - ddotvec(n-1,x,x);
	double sQs=*sm* *sm - ddotvec(n-1,s,s);
	if(xQx<=0)
	{
//		printf((char*)"xm=%20.10e xQx=%20.10e\n",*xm* *xm,xQx);
		if(*xm > lm_rooteps)
		{
			dscalvec(n-1,.95* *xm/sqrt(*xm * *xm-xQx),x);
		}
		else
		{
			dsetvec(n-1,lm_rooteps,x);
			*xm = (1.+lm_rooteps)*lm_rooteps*sqrt(float(n));
		}
		xQx=*xm* *xm - ddotvec(n-1,x,x);
//		printf((char*)"fixed, xm=%20.10e xQx=%20.10e\n",*xm* *xm,xQx);
	}
	if(sQs<=0)
	{
//		printf((char*)"sm=%20.10e sQs=%20.10e\n",*sm* *sm,sQs);
		if(*sm>lm_rooteps)
		{
			dscalvec(n-1,.95* *sm/sqrt(*sm * *sm-sQs),s);
		}
		else
		{
			dsetvec(n-1,lm_rooteps,s);
			*sm = (1.+lm_rooteps)*lm_rooteps*sqrt(float(n));
		}
		sQs=*sm* *sm - ddotvec(n-1,s,s);
//		printf((char*)"fixed, sm=%20.10e sQs=%20.10e\n",*sm* *sm,sQs);
	}
	//return sqrt(sqrt(dprotdiv(&sQs,&xQx,0)));
	double back= sqrt(sqrt(sQs/xQx));
	if(disnan_BITA(&back))
	{
		printf((char*)"nan in gettheta\n");
		if(disnan_BITA(&sQs))
		{
			printf((char*)"sm=%20.10e sQs=%20.10e\n",*sm* *sm,sQs);
			dsetvec(n-1,lm_rooteps,s);
			*sm = (1.+lm_rooteps)*lm_rooteps*sqrt(float(n));
			sQs=*sm* *sm - ddotvec(n-1,s,s);
			printf((char*)"fixed, sm=%20.10e sQs=%20.10e\n",*sm* *sm,sQs);
		}
		if(disnan_BITA(&xQx))
		{
			printf((char*)"xm=%20.10e xQx=%20.10e\n",*xm* *xm,xQx);
			dsetvec(n-1,lm_rooteps,x);
			*xm = (1.+lm_rooteps)*lm_rooteps*sqrt(float(n));
			xQx=*xm* *xm - ddotvec(n-1,x,x);
			printf((char*)"fixed, xm=%20.10e xQx=%20.10e\n",*xm* *xm,xQx);
		}
		back=sqrt(sqrt(sQs/xQx));
		printf((char*)"back now %20.10e\n",back);
	}
	return back;
}
double getthetaR(size_t n,vector s,vector x)
{
	vector sm1=s+n-2,xm1=x+n-2;
	vector sm=s+n-1,xm=x+n-1;
	double xQx=2* *xm* *xm1 - ddotvec(n-2,x,x);
	double sQs=2* *sm* *sm1 - ddotvec(n-2,s,s);
	if(sQs<=0)
	{
//		printf((char*)"2*sm*sm1=%20.10e sQs=%20.10e\n",2* *sm* *sm1,sQs);
		if(*sm * *sm1 *2 >lm_eps)
		{
			dscalvec(n-2,.95*sqrt(1.0 /(1.0-sQs/(*sm * *sm1 * 2))),s);
		}
		else
		{
			dsetvec(n-2,lm_rooteps,s);
			*sm1=*sm = (1.+lm_rooteps)*lm_rooteps*sqrt(float(n)/2.0);
		}
		sQs=2* *sm* *sm1 - ddotvec(n-2,s,s);
//		printf((char*)"fixed, 2*sm*sm1=%20.10e sQs=%20.10e\n",2* *sm* *sm1,sQs);
	}
	if(xQx<=0)
	{
//		printf((char*)"2*xm*xm1=%20.10e xQx=%20.10e\n",2* *xm* *xm1,xQx);
		if(*xm * *xm1 *2 > lm_eps)
		{
			dscalvec(n-2,.95*sqrt(1.0 /(1.0-xQx/(*xm * *xm1 * 2))),x);
		}
		else
		{
			dsetvec(n-2,lm_rooteps,x);
			*xm1=*xm = (1.+lm_rooteps)*lm_rooteps*sqrt(float(n)/2.0);
		}
		xQx=2* *xm* *xm1 - ddotvec(n-2,x,x);
//		printf((char*)"fixed, 2*xm*xm1=%20.10e xQx=%20.10e\n",2* *xm* *xm1,xQx);
	}
	//return sqrt(sqrt(dprotdiv(&sQs,&xQx,0)));
	double back= sqrt(sqrt(sQs/xQx));
	if(disnan_BITA(&back))
	{
		printf((char*)"nan in getthetaR\n");
		if(disnan_BITA(&sQs))
		{
			printf((char*)"2*sm*sm1=%20.10e sQs=%20.10e\n",2* *sm* *sm1,sQs);
			dsetvec(n-2,lm_rooteps,s);
			*sm1=*sm = (1.+lm_rooteps)*lm_rooteps*sqrt(float(n)/2.0);
			sQs=2* *sm* *sm1 - ddotvec(n-2,s,s);
			printf((char*)"fixed, 2*sm*sm1=%20.10e sQs=%20.10e\n",2* *sm* *sm1,sQs);
		}
		if(disnan_BITA(&xQx))
		{
			printf((char*)"2*xm*xm1=%20.10e xQx=%20.10e\n",2* *xm* *xm1,xQx);
			dsetvec(n-2,lm_rooteps,x);
			*xm1=*xm = (1.+lm_rooteps)*lm_rooteps*sqrt(float(n)/2.0);
			xQx=2* *xm* *xm1 - ddotvec(n-2,x,x);
			printf((char*)"fixed, 2*xm*xm1=%20.10e xQx=%20.10e\n",2* *xm* *xm1,xQx);
		}
		back= sqrt(sqrt(sQs/xQx));
		printf((char*)"back now %20.10e\n",back);
	}
	if(back==0)back=lm_eps;//shouldn't get to do this
	return back;
}
extern "C" DLLEXPORT void get_w(size_t n,vector s,vector x,vector w)//this is inverse(w) in Nesterov and Todd's original paper on NT scaling
{
	if(n==1)
	{
		*w=sqrt(dprotdiv(s,x,0));
		return;
	}
	//For positive semi-definite cone, swap s and x for inverse
	size_t i;
	std::valarray<double>SS(n*n),XX(n*n),rootSS(n*n),sp(n*n),WW(n*n);
	SDPsMat(n,s,&SS[0]);
	SDPsMat(n,x,&XX[0]);
	symm2packed(n,&SS[0]);
	RootProcessQ(n,&SS[0],&rootSS[0],0);
	vector xx,pr;
	for(i=0,xx=&rootSS[0],pr=&sp[0];i<n;++i)//Find XrootS
	{
		dmxmulv(n,n,&XX[0],xx,pr);
		xx+=n;
		pr+=n;
	}
	for(i=0,xx=&sp[0],pr=&XX[0];i<n;++i)//Find rootSXrootS in XX
	{
		dmxmulv(n,n,&rootSS[0],xx,pr);
		xx+=n;
		pr+=n;
	}
	symm2packed(n,&XX[0]);
	RootProcessQ(n,&XX[0],0,&sp[0]);//rootinv(rootSXrootS)
	for(i=0,xx=&rootSS[0],pr=&XX[0];i<n;++i)//Find rootinv.rootS
	{
		dmxmulv(n,n,&sp[0],xx,pr);
		xx+=n;
		pr+=n;
	}
	for(i=0,xx=&XX[0],pr=&WW[0];i<n;++i)//Find rootS.rootinv.rootS
	{
		dmxmulv(n,n,&rootSS[0],xx,pr);
		xx+=n;
		pr+=n;
	}
	SDPsvec(n,&WW[0],w);
}
void getw(size_t n,vector s,vector x,vector w)
{
	get_w(n,s,x,w);
}
void getinvw(size_t n,vector s,vector x,vector w)
{
	get_w(n,x,s,w);
}
void getw(size_t n,vector s,vector x,double theta,vector w)
{
	if(n==1)
	{
		*w=sqrt(dprotdiv(s,x,0))/theta;return;
	}
	vector sm=s+n-1,xm=x+n-1;
	double xs=ddotvec(n,s,x);
	double xQx=*xm* *xm - ddotvec(n-1,x,x);
	if(xQx<0)
		printf((char*)"xQx = %e in getw",xQx);//If this gets printed the fixup in gettheta didn't work
	double sQs=*sm* *sm - ddotvec(n-1,s,s);
	if(sQs<0)
		printf((char*)"sQs = %e in getw",sQs);//If this gets printed the fixup in gettheta didn't work
	double bot=sqrt((xs+sqrt(xQx*sQs))*2);
	if(disnan_BITA(&bot))
		printf((char*)"bot is nan in getw\n");
	double s1=theta/bot,s2=theta*bot;
	if(theta==lm_eps){s1=1.0;s2=lm_eps;}

	if(disnan_BITA(&s1))
		printf((char*)"s1 is nan in getw\n");
	if(disnan_BITA(&s2))
		printf((char*)"s2 is nan in getw\n");
	while(n-- > 1)
	{
		*w++ = -s1* *x++ + *s++/s2;
	}
	*w++ = s1* *x++ + *s++/s2;
}
void getwR(size_t n,vector s,vector x,double theta,vector w)
{
	vector sm1=s+n-2,xm1=x+n-2;
	vector sm=s+n-1,xm=x+n-1;
	double xs=ddotvec(n,s,x);
	double xQx=2* *xm* *xm1 - ddotvec(n-2,x,x);
	if(xQx<0)
		printf((char*)"xQx = %e in getwR",xQx);//If this gets printed the fixup in getthetaR didn't work
	double sQs=2* *sm* *sm1 - ddotvec(n-2,s,s);
	if(sQs<0)
		printf((char*)"sQs = %e in getwR",sQs);//If this gets printed the fixup in getthetaR didn't work
	double bot=sqrt((xs+sqrt(xQx*sQs))*2);
	double s1=theta/bot,s2=theta*bot;
	if(theta==lm_eps){s1=1.0;s2=lm_eps;}
	while(n-- > 2)
	{
		*w++ = -s1* *x++ + *s++/s2;
	}
	*w++ = s1* *xm + *sm1/s2;//(s1Qx+s/s2)
	*w++ = s1* *xm1 + *sm/s2;
}
bool getw_and_theta(size_t nx,size_t ncone,int*cone,int*typecone,vector x,vector s,vector theta,vector w,vector xbar,vector sbar)
{
	size_t i,ix,k;
	vector ww,xx,ss;
	for(i=0,ss=s,xx=x,ww=w;i<ncone;ww+=cone[i],
		ss+=cone[i],xx+=cone[i],i++)
	{
		if(typecone[i]==0)
		{
			for(k=0;k<cone[i];++k)
			{
				//theta[i+k]= don't need
				getw(1,xx+k,ss+k,ww+k);
			}
		}
		else if(typecone[i]==1)
		{
			theta[i]=gettheta(cone[i],ss,xx);
			if(!disnan_BITA(&theta[i])&&theta[i]>=0)getw(cone[i],ss,xx,theta[i],ww);
			else 
			{
				printf((char*)"Bad theta %20.8e\n",theta[i]);
				return false;
			}
		}
		else if(typecone[i]==3)
		{
			theta[i]=getthetaR(cone[i],ss,xx);
			if(!disnan_BITA(&theta[i])&&theta[i]>=0)getwR(cone[i],ss,xx,theta[i],ww);
			else 
			{
				printf((char*)"Bad theta %20.8e\n",theta[i]);
				return false;
			}
			Tmulvec(cone[i],ww,true);//We save w in unrotated cone form, More efficient for OMP
		}
		else if(typecone[i]==2)
		{
			size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[i]));
			theta[i]=1;
			getw(n,ss,xx,ww);
		}
	}
	for(i=0,ix=0;i<ncone;ix+=cone[i],i++)
	{
		if(typecone[i]==0)
		{
			for(k=0;k<cone[i];++k)
			{
				WtransSDP(1,x+ix+k,w+ix+k,xbar+ix+k);
			}
		}
		else if(typecone[i]==1)
		{
			Wtrans(cone[i],x+ix,w+ix,xbar+ix);
			thetaScale(cone[i],xbar+ix,theta[i]);
		}
		else if(typecone[i]==3)
		{
			WtransR(cone[i],x+ix,w+ix,xbar+ix);
			thetaScale(cone[i],xbar+ix,theta[i]);
		}
		else if(typecone[i]==2)
		{
			size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[i]));
			WtransSDP(n,x+ix,w+ix,xbar+ix);
		}
	}
	dcopyvec(nx,xbar,sbar);
	return true;
}

bool getDirection(bool updateAA,size_t m,size_t nx,size_t ncone,int*cone,int*typecone,vector c,vector b,
				  vector theta,vector w,vector A,vector AA,short_scl*AA_P,vector xbar,vector sbar,vector r1,vector r2,vector r3,
				  vector r4,vector r5,vector dx,vector dy,vector ds,vector dtau,vector dkappa,vector tau,vector kappa,short&changetodouble,
				  bool&usedouble,float*AAAA,bool&highcondition,bool regularise,void**work,void**workQ,int method,bool homog=true,
				  long nf=0,size_t ns=0,size_t Qstart=0,vector Qfac=0,vector QQ=0,vector LL=0,short_scl* QQpiv=0)
{
	long i,k,j,ix;
	std::valarray<double>cc1(nx),cc2(nx);
	vector Aproc;
#ifdef USE_SINGLE
	if(m<100)changetodouble=1;
#endif
	size_t badindex=0;
	//	vector pAA,pAi,pAj;
	
	if(updateAA)
	{
		std::valarray<double>pAproc;
		try
		{
			pAproc.resize(0);
			pAproc.resize(nx*m);
		}
		catch( ... )
		{
			printf((char*)"Aproc problem\n");
			pAproc.resize(0);
		}
		if(pAproc.size())
			Aproc=&pAproc[0];
		else
			Aproc=0;
		if(ns)
		{
			for(j=0,ix=0;j<ncone;ix+=cone[j],j++)
			{
				if(ix==Qstart)
				{
					if(typecone[j]==0)
					{
						//ns = cone[j] in this case
						size_t ii;
						for(ii=0;ii<ns;ii++)//Add the diag part of model variance to the "second derivative barrier term"
						{
							LL[ii]=w[ix+ii]*w[ix+ii];
						}
						if(nf>0)
						{
							daddvec(ns,Qfac,LL,Qfac);
							factor_model_process_inverse(ns,nf,Qfac,QQ);
							dsubvec(ns,Qfac,LL,Qfac);
						}
						else if(nf==-1)
						{
							dcopyvec(ns*(ns+1)/2,Qfac,QQ);
							for(ii=0;ii<ns;++ii)
								QQ[ii*(ii+3)/2]+=LL[ii];
							if(ns<20)
								/*dsptrf((char*)"U",cone[j],QQ,QQpiv);*/bunchf(cone[j],QQ,QQpiv);
							else
								FactorGen(ns,QQ,workQ);
						}
					}
					else if(typecone[j]==1)
					{
						size_t ii,jj;
						vector pQQ=QQ;
						if(nf>0)
						{
							vector SV=Qfac,FF=SV+ns;
							for(ii=0;ii<cone[j];ii++)//Add the diag part of model variance to the "second derivative barrier term"
							{//Use LL as work space here.
								dzerovec(2*cone[j],LL);
								LL[cone[j]+ii]=1;
								W2trans(cone[j],LL+cone[j],w+ix,LL);
								thetaScale(cone[j],LL,theta[j],false,true);
								for(jj=0;jj<=ii;++jj)
									*pQQ++=LL[jj]+((ii<ns)&&(ii==jj)?SV[ii]:0);
							}
							dzerovec(2*nf*cone[j],LL);//Now use LL as intended for inverse FF and FF
							//Now we need (Q+"barrier bit")^-1.&cc2[0] where Q is SV+FF'FF
							dcopyvec(ns*nf,FF,LL+cone[j]*nf);//Last nf entries are 0 so there are no factor bits for top of cone
							//Important that SV and FF are not changed
							process_lowrank_plus_symm_inverse(cone[j],nf,LL+cone[j]*nf,QQ,LL,QQpiv);
						}
						else if(nf==-1)
						{
							dcopyvec(ns*(ns+1)/2,Qfac,QQ);
							for(ii=0;ii<cone[j];++ii)
							{
								dzerovec(2*cone[j],LL);
								LL[cone[j]+ii]=1;
								W2trans(cone[j],LL+cone[j],w+ix,LL);
								thetaScale(cone[j],LL,theta[j],false,true);
								for(jj=0;jj<=ii;++jj)
								{
									if(ii<ns)
									*pQQ++ +=LL[jj];
									else
									*pQQ++ =LL[jj];
								}
							}
							if(ns<20)
								/*dsptrf((char*)"U",cone[j],QQ,QQpiv);*/bunchf(cone[j],QQ,QQpiv);
							else
								FactorGen(cone[j],QQ,workQ);
						}
					}
					else if(typecone[j]==3)
					{
						size_t ii,jj;
						vector pQQ=QQ;
						if(nf>0)
						{
							vector SV=Qfac,FF=SV+ns;
							for(ii=0;ii<cone[j];ii++)//Add the diag part of model variance to the "second derivative barrier term"
							{//Use LL as work space here.
								dzerovec(2*cone[j],LL);
								LL[cone[j]+ii]=1;
								W2transR(cone[j],LL+cone[j],w+ix,LL);
								thetaScale(cone[j],LL,theta[j],false,true);
								for(jj=0;jj<=ii;++jj)
									*pQQ++=LL[jj]+((ii<ns)&&(ii==jj)?SV[ii]:0);
							}
							dzerovec(2*nf*cone[j],LL);//Now use LL as intended for inverse FF and FF
							//Now we need (Q+"barrier bit")^-1.&cc2[0] where Q is SV+FF'FF
							dcopyvec(ns*nf,FF,LL+cone[j]*nf);//Last nf entries are 0 so there are no factor bits for top of cone
							//Important that SV and FF are not changed
							process_lowrank_plus_symm_inverse(cone[j],nf,LL+cone[j]*nf,QQ,LL,QQpiv);
						}
						else if(nf==-1)
						{
							dcopyvec(ns*(ns+1)/2,Qfac,QQ);
							for(ii=0;ii<cone[j];++ii)
							{
								dzerovec(2*cone[j],LL);
								LL[cone[j]+ii]=1;
								W2transR(cone[j],LL+cone[j],w+ix,LL);
								thetaScale(cone[j],LL,theta[j],false,true);
								for(jj=0;jj<=ii;++jj)
								{
									if(ii<ns)
									*pQQ++ +=LL[jj];
									else
									*pQQ++ =LL[jj];
								}
							}
							if(ns<20)
								/*dsptrf((char*)"U",cone[j],QQ,QQpiv);*/bunchf(cone[j],QQ,QQpiv);
							else
								FactorGen(cone[j],QQ,workQ);
						}
					}
				}
			}
		}
		if(Aproc)
		{
#ifndef _OPENMP
			std::valarray<double> Qm1A(ns);
			for(i=0;i<m;++i)
			{
				dcopyvec(nx,A+i*nx,&cc2[0]);
				for(j=0,ix=0;j<ncone;ix+=cone[j],j++)
				{
					if(!checkzerov(cone[j],&cc2[ix]))
					{
						if(typecone[j]==0)
						{
							if(ns&&ix==Qstart)
							{
								if(nf>0)facmul_and_inv(ns,nf,QQ,&cc2[ix],Aproc+i*nx+ix,1);
								else 
								{
									dcopyvec(cone[j],&cc2[ix],Aproc+i*nx+ix);
									if(*workQ)
										SolveGen(Aproc+i*nx+ix,workQ);
									else
										dsptrs((char *)"U",cone[j],1,QQ,QQpiv,Aproc+i*nx+ix,cone[j]);
								}
							}
							else
							{
								for(k=0;k<cone[j];++k)
								{
									WtransSDP(1,&cc2[ix+k],w+ix+k,Aproc+i*nx+ix+k,true,true);
								}
							}
						}
						else if(typecone[j]==1)
						{
							if(ns&&ix==Qstart)
							{
								if(nf>0)lowrank_facmul_and_inv(cone[j],nf,LL,QQ,&cc2[ix],Aproc+i*nx+ix,1,QQpiv);
								else 
								{
									dcopyvec(cone[j],&cc2[ix],Aproc+i*nx+ix);
									if(*workQ)
										SolveGen(Aproc+i*nx+ix,workQ);
									else
										dsptrs((char *)"U",cone[j],1,QQ,QQpiv,Aproc+i*nx+ix,cone[j]);
								}
							}
							else
							{
								Qmulvec(cone[j],&cc2[ix]);
								W2trans(cone[j],&cc2[ix],w+ix,Aproc+i*nx+ix);
								Qmulvec(cone[j],Aproc+ix+i*nx);
								thetaScale(cone[j],Aproc+i*nx+ix,theta[j],true,true);
							}
						}
						else if(typecone[j]==3)
						{
							if(ns&&ix==Qstart)
							{
								if(nf>0)lowrank_facmul_and_inv(cone[j],nf,LL,QQ,&cc2[ix],Aproc+i*nx+ix,1,QQpiv);
								else 
								{
									dcopyvec(cone[j],&cc2[ix],Aproc+i*nx+ix);
									if(*workQ)
										SolveGen(Aproc+i*nx+ix,workQ);
									else
										dsptrs((char *)"U",cone[j],1,QQ,QQpiv,Aproc+i*nx+ix,cone[j]);
								}
							}
							else
							{
								Qmulvec(cone[j],&cc2[ix],typecone[j]==3);
								W2transR(cone[j],&cc2[ix],w+ix,Aproc+i*nx+ix);
								Qmulvec(cone[j],Aproc+ix+i*nx,typecone[j]==3);
								thetaScale(cone[j],Aproc+i*nx+ix,theta[j],true,true);
							}
						}
						else if(typecone[j]==2)
						{
							size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[j]));
							WtransSDP(n,&cc2[ix],w+ix,Aproc+i*nx+ix,true,true);
						}
					}
					else dzerovec(cone[j],Aproc+i*nx+ix);
				}
			}
#else
			long maxt=omp_get_max_threads(),nt;
			std::valarray<double>cc2(nx*maxt);
			std::valarray<double> Qm1A(ns*maxt);
#pragma omp parallel
			{
#pragma omp for private(i,nt) schedule(dynamic) nowait
				for(i=0;i<m;++i)
				{
					size_t j,ix,k;
					nt=omp_get_thread_num();
					dcopyvec(nx,A+i*nx,&cc2[nt*nx]);
					for(j=0,ix=0;j<ncone;ix+=cone[j],j++)
					{
						if(!checkzerov(cone[j],&cc2[nt*nx+ix]))
						{
							if(typecone[j]==0)
							{
								if(ns&&ix==Qstart)
								{
									if(nf>0)facmul_and_inv(ns,nf,QQ,&cc2[nt*nx+ix],Aproc+i*nx+ix,1);
									else 
									{
										dcopyvec(cone[j],&cc2[nt*nx+ix],Aproc+i*nx+ix);
										if(*workQ)
											SolveGen(Aproc+i*nx+ix,workQ);
										else
											dsptrs((char *)"U",cone[j],1,QQ,QQpiv,Aproc+i*nx+ix,cone[j]);
									}
								}
								else
								{
									for(k=0;k<cone[j];++k)
									{
										WtransSDP(1,&cc2[nt*nx+ix+k],w+ix+k,Aproc+i*nx+ix+k,true,true);
									}
								}
							}
							else if(typecone[j]==2)
							{
								size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[j]));
								WtransSDP(n,&cc2[nt*nx+ix],w+ix,Aproc+i*nx+ix,true,true);
							}
							else if(typecone[j]==1)
							{
								if(ns&&ix==Qstart)
								{
									if(nf>0)lowrank_facmul_and_inv(cone[j],nf,LL,QQ,&cc2[nt*nx+ix],Aproc+i*nx+ix,1,QQpiv);
									else 
									{
										dcopyvec(cone[j],&cc2[nt*nx+ix],Aproc+i*nx+ix);
										if(*workQ)
											SolveGen(Aproc+i*nx+ix,workQ);
										else
											dsptrs((char *)"U",cone[j],1,QQ,QQpiv,Aproc+i*nx+ix,cone[j]);
									}
								}
								else
								{
									Qmulvec(cone[j],&cc2[nt*nx+ix]);
									W2trans(cone[j],&cc2[nt*nx+ix],w+ix,Aproc+i*nx+ix);
									Qmulvec(cone[j],Aproc+i*nx+ix);
									thetaScale(cone[j],Aproc+i*nx+ix,theta[j],true,true);
								}
							}
							else if(typecone[j]==3)
							{
								if(ns&&ix==Qstart)
								{
									if(nf>0)lowrank_facmul_and_inv(cone[j],nf,LL,QQ,&cc2[nt*nx+ix],Aproc+i*nx+ix,1,QQpiv);
									else 
									{
										dcopyvec(cone[j],&cc2[nt*nx+ix],Aproc+i*nx+ix);
										if(*workQ)
											SolveGen(Aproc+i*nx+ix,workQ);
										else
											dsptrs((char *)"U",cone[j],1,QQ,QQpiv,Aproc+i*nx+ix,cone[j]);
									}
								}
								else
								{
									Qmulvec(cone[j],&cc2[nt*nx+ix],typecone[j]==3);
									W2transR(cone[j],&cc2[nt*nx+ix],w+ix,Aproc+i*nx+ix);
									Qmulvec(cone[j],Aproc+i*nx+ix,typecone[j]==3);
									thetaScale(cone[j],Aproc+i*nx+ix,theta[j],true,true);
								}
							}
						}
						else dzerovec(cone[j],Aproc+i*nx+ix);
					}
				}
			}
#endif
		}
#ifndef _OPENMP
		dzerovec(m*(m+1)/2,AA);
		if(Aproc)
		{
#ifdef BLOCKED//This is correct but it's only  faster for large m and dense A
			double one=1,zero=0;
			Integer N=nx,M=m;
			dgemm_BITA((char*)"T",(char*)"N",&M,&M,&N,&one,A,&N,Aproc,&N,&zero,AA,&M);symm2packed(m,AA);
#else
			dmx_transpose(nx,m,Aproc,Aproc);
			for(i=0;i<m;++i)
			{
				for(k=0;k<nx;++k)
				{
					if(A[i*nx+k]!=0)
						//						BITA_daxpy(i+1,A[i*nx+k],Aproc+k,nx,&(*AA)[i*(i+1)/2],1);
						daxpyvec(i+1,A[i*nx+k],Aproc+k*m,AA+(i*(i+1)>>1));
				}
			}
#endif
		}
		else
		{
			std::valarray<double> Qm1A(ns);
			for(i=0;i<m;++i)
			{
				for(j=0,ix=0;j<ncone;ix+=cone[j],j++)
				{
					if(!checkzerov(cone[j],&cc2[ix]))
					{
						if(typecone[j]==0)
						{
							if(ns&&ix==Qstart)
							{
								if(nf>0)facmul_and_inv(ns,nf,QQ,A+i*nx+ix,&cc2[ix],1);
								else 
								{
									dcopyvec(cone[j],A+i*nx+ix,&cc2[ix]);
									if(*workQ)
										SolveGen(&cc2[ix],workQ);
									else
										dsptrs((char *)"U",cone[j],1,QQ,QQpiv,&cc2[ix],cone[j]);
								}
							}
							else
							{
								for(k=0;k<cone[j];++k)
								{
									WtransSDP(1,A+i*nx+ix+k,w+ix+k,&cc2[ix+k],true,true);
								}
							}
						}
						else if(typecone[j]==2)
						{
							size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[j]));
							WtransSDP(n,A+i*nx+ix,w+ix,&cc2[ix],true,true);
						}
						else if(typecone[j]==1)
						{
							if(ns&&ix==Qstart)
							{
								if(nf>0)lowrank_facmul_and_inv(cone[j],nf,LL,QQ,A+i*nx+ix,&cc2[ix],1,QQpiv);
								else 
								{
									dcopyvec(cone[j],A+i*nx+ix,&cc2[ix]);
									if(*workQ)
										SolveGen(&cc2[ix],workQ);
									else
										dsptrs((char *)"U",cone[j],1,QQ,QQpiv,&cc2[ix],cone[j]);
								}
							}
							else
							{
								Qmulvec(cone[j],A+i*nx+ix);
								W2trans(cone[j],A+i*nx+ix,w+ix,&cc2[ix]);
								Qmulvec(cone[j],&cc2[ix]);
								thetaScale(cone[j],&cc2[ix],theta[j],true,true);
								Qmulvec(cone[j],A+i*nx+ix);//change it back
							}
						}
						else if(typecone[j]==3)
						{
							if(ns&&ix==Qstart)
							{
								if(nf>0)lowrank_facmul_and_inv(cone[j],nf,LL,QQ,A+i*nx+ix,&cc2[ix],1,QQpiv);
								else 
								{
									dcopyvec(cone[j],A+i*nx+ix,&cc2[ix]);
									if(*workQ)
										SolveGen(&cc2[ix],workQ);
									else
										dsptrs((char *)"U",cone[j],1,QQ,QQpiv,&cc2[ix],cone[j]);
								}
							}
							else
							{
								Qmulvec(cone[j],A+i*nx+ix,typecone[j]==3);
								W2transR(cone[j],A+i*nx+ix,w+ix,&cc2[ix]);
								Qmulvec(cone[j],&cc2[ix],typecone[j]==3);
								thetaScale(cone[j],&cc2[ix],theta[j],true,true);
								Qmulvec(cone[j],A+i*nx+ix,typecone[j]==3);//change it back
							}
						}
					}
					else dzerovec(cone[j],A+i*nx+ix);
				}
				for(k=0;k<nx;++k)
				{
					if(cc2[k]!=0)
						BITA_daxpy(i+1,cc2[k],A+k,nx,AA+(i*(i+1)>>1),1);
				}
			}
		}
#else
		long maxt=omp_get_max_threads();
		dzerovec((m*(m+1))>>1,AA);
		if(Aproc)
		{
//			double t1=omp_get_wtime();
#ifdef BLOCKED//This is correct but it's only  faster for large m and dense A
			double one=1,zero=0;
			Integer N=nx,M=m;
			dgemm_BITA((char*)"T",(char*)"N",&M,&M,&N,&one,A,&N,Aproc,&N,&zero,AA,&M);symm2packed(m,AA);
#else
			dmx_transpose(nx,m,Aproc,Aproc);
#pragma omp parallel
			{
#pragma omp for private(i,k) schedule(dynamic) nowait
				for(i=0;i<m;++i)
				{
					for(k=0;k<nx;++k)
					{
						if(A[i*nx+k])
						{
							//						BITA_daxpy(i+1,A[i*nx+k],Aproc+k,nx,&(*AA)[i*(i+1)>>1],1);
							daxpyvec(i+1,A[i*nx+k],Aproc+k*m,AA+(i*(i+1)>>1));
						}
					}
				}
			}
#endif
		}
		else
		{
			std::valarray<double> cc2(nx*maxt);
			std::valarray<double> temp1(nx*maxt);
			std::valarray<double> Qm1A(ns*maxt);
			long ii,nt;
#pragma omp parallel 
			{
#pragma omp for private(i,ii,nt,k) schedule(dynamic) nowait
				for(i=0;i<m;++i)
				{
					size_t j,ix;
					nt=omp_get_thread_num();
					ii=i*(i+1)>>1;
					dcopyvec(nx,A+i*nx,&temp1[nx*nt]);
					for(j=0,ix=0;j<ncone;ix+=cone[j],j++)
					{
						if(!checkzerov(cone[j],&temp1[nx*nt+ix]))
						{
							if(typecone[j]==0)
							{
								if(ns&&ix==Qstart)
								{
									if(nf>0)facmul_and_inv(ns,nf,QQ,&temp1[nx*nt+ix],&cc2[nx*nt+ix],1);
									else 
									{
										dcopyvec(cone[j],&temp1[nx*nt+ix],&cc2[nx*nt+ix]);
										if(*workQ)
											SolveGen(&cc2[nx*nt+ix],workQ);
										else
											dsptrs((char *)"U",cone[j],1,QQ,QQpiv,&cc2[nx*nt+ix],cone[j]);
									}
								}
								else
								{
									for(k=0;k<cone[j];++k)
									{
										WtransSDP(1,&temp1[nx*nt+ix+k],w+ix+k,&cc2[nx*nt+ix+k],true,true);
									}
								}
							}
							else if(typecone[j]==2)
							{
								size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[j]));
								WtransSDP(n,&temp1[nx*nt+ix],w+ix,&cc2[nx*nt+ix],true,true);
							}
							else if(typecone[j]==1)
							{
								if(ns&&ix==Qstart)
								{
									if(nf>0)lowrank_facmul_and_inv(cone[j],nf,LL,QQ,&temp1[nx*nt+ix],&cc2[nx*nt+ix],1,QQpiv);
									else 
									{
										dcopyvec(cone[j],&temp1[nx*nt+ix],&cc2[nx*nt+ix]);
										if(*workQ)
											SolveGen(&cc2[nx*nt+ix],workQ);
										else
											dsptrs((char *)"U",cone[j],1,QQ,QQpiv,&cc2[nx*nt+ix],cone[j]);
									}
								}
								else
								{
									Qmulvec(cone[j],&temp1[nx*nt+ix]);
									W2trans(cone[j],&temp1[nx*nt+ix],w+ix,&cc2[nx*nt+ix]);
									Qmulvec(cone[j],&cc2[nx*nt+ix]);
									thetaScale(cone[j],&cc2[nx*nt+ix],theta[j],true,true);
								}
							}
							else if(typecone[j]==3)
							{
								if(ns&&ix==Qstart)
								{
									if(nf>0)lowrank_facmul_and_inv(cone[j],nf,LL,QQ,&temp1[nx*nt+ix],&cc2[nx*nt+ix],1,QQpiv);
									else 
									{
										dcopyvec(cone[j],&temp1[nx*nt+ix],&cc2[nx*nt+ix]);
										if(*workQ)
											SolveGen(&cc2[nx*nt+ix],workQ);
										else
											dsptrs((char *)"U",cone[j],1,QQ,QQpiv,&cc2[nx*nt+ix],cone[j]);
									}
								}
								else
								{
									Qmulvec(cone[j],&temp1[nx*nt+ix],typecone[j]==3);
									W2transR(cone[j],&temp1[nx*nt+ix],w+ix,&cc2[nx*nt+ix]);
									Qmulvec(cone[j],&cc2[nx*nt+ix],typecone[j]==3);
									thetaScale(cone[j],&cc2[nx*nt+ix],theta[j],true,true);
								}
							}
						}
						else dzerovec(cone[j],&cc2[nx*nt+ix]);
					}
					//		Qmulvec(A+i*nx);//change it back
					for(k=0;k<nx;++k)
					{
						if(cc2[k+nt*nx]!=0)
							BITA_daxpy(i+1,cc2[k+nt*nx],A+k,nx,AA+ii,1);
					}
				}
			}
		}
		//	symm2packed(m,&(*AA)[0]);
		//		}
#endif
		{
#ifdef USE_SINGLE
			bool keepon=true;
			while(keepon)
			{
				if(changetodouble)usedouble=true;
				if(!usedouble)
				{
					for(i=0;i<m*(m+1)>>1;++i)
						AAAA[i]=static_cast<float>((AA)[i]);
					badindex=sbunchf(m,AAAA,AA_P);
					packed2symm(m,AA);
					if(badindex)
					{
						changetodouble=1;
						symm2packed(m,AA);
					}
					else keepon=false;
				}
				else
				{
					badindex=bunchf(m,AA,AA_P);
					keepon=false;
				}
			}
#else
			if(regularise)
			{//Future research to try to regularise the normal equations
				std::valarray<double>diag(m);
				std::valarray<size_t>ord(m);
				for(j=0;j<m;++j)
				{
					diag[j]=AA[j*(j+3)/2];
				}
				getorder(m,&diag[0],&ord[0],0,0);
				size_t o1=max(ord[0],ord[1]),o2=min(ord[0],ord[1]);
				double a1=max(diag[o1],diag[o2]),a2=min(diag[o2],diag[o1]),a12=AA[o1*(o1+1)/2+o2];
				double cond=a1*(a1-a12*a12/a2),regulise=a1*lm_rooteps;//cond is a quick estimate of condition number using only 2 pivots.
				if(cond>lm_reps) //4503599627370496
				{
					highcondition=true;
					for(j=0;j<m;++j)
					{
						if(AA[j*(j+3)/2]<regulise)
						AA[j*(j+3)/2]+=regulise;
					}
				}
			}
			switch(method)
			{
			case 0:
				badindex=bunchf(m,AA,AA_P);
				for(j=0;j<m;++j)
				{
					if(AA_P[j]>0&&AA[j*(j+3)/2]<0)
						AA[j*(j+3)/2]=0;
				}
				break;
			case 1:
				badindex=FactorGen(m,AA,work);
				break;
			case 2:
				//clock_t time1=clock();
				badindex=0;//Always accept the solution
				FactorSymm(m,AA,work);
				//time1=clock()-time1;
				//printf((char*)"Time ticks for FactorSymm %ld\n",time1);
				break;
			}
			/*//Choleski test
			{
				Integer NN=(Integer)m,info;
				dpptrf_BITA((char*)"U",&NN,AA,&info);
				badindex=info;
			}
			*/
#endif
		}
	}
	std::valarray<double>g(nx+m),h(nx+m);
	vector g1=&g[0];
	vector g2=&g[nx];
	vector h1=&h[0];
	vector h2=&h[nx];
	if(homog)
	{
		dcopyvec(nx,c,g1);
		dcopyvec(m,b,g2);
		//printf((char*)"SOLVE 1\n");
		AAsolve(nx,m,ncone,cone,typecone,w,theta,A,AA,AA_P,g1,g2,changetodouble,usedouble,AAAA,work,workQ,method,nf,ns,Qstart,QQ,LL,QQpiv);
		//printf((char*)"SOLVE 1 out\n");
	}	
	for(j=0,ix=0;j<ncone;ix+=cone[j],j++)
	{
		if(typecone[j]==0)
		{
			for(k=0;k<cone[j];++k)
			{
				applyXm1SDP(1,xbar+ix+k,r4+ix+k,&cc1[ix+k]);
				WtransSDP(1,&cc1[ix+k],w+ix+k,h1+ix+k);
			}
		}
		else if(typecone[j]==2)
		{
			size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[j]));
			applyXm1SDP(n,xbar+ix,r4+ix,&cc1[ix]);
			WtransSDP(n,&cc1[ix],w+ix,h1+ix);
		}
		else if(typecone[j]==1)
		{
			applyXm1(cone[j],xbar+ix,r4+ix,&cc1[ix]);
			Wtrans(cone[j],&cc1[ix],w+ix,h1+ix);
			thetaScale(cone[j],h1+ix,theta[j]);
		}
		else if(typecone[j]==3)
		{
			Tmulvec(cone[j],xbar+ix,true);
			Tmulvec(cone[j],r4+ix,true);
			applyXm1(cone[j],xbar+ix,r4+ix,&cc1[ix]);
			Tmulvec(cone[j],xbar+ix,true);
			Tmulvec(cone[j],r4+ix,true);
			Tmulvec(cone[j],&cc1[ix],true);
			WtransR(cone[j],&cc1[ix],w+ix,h1+ix);
			thetaScale(cone[j],h1+ix,theta[j]);
		}
	}
	dsubvec(nx,r2,h1,h1);
	dcopyvec(m,r1,h2);
	//	printf((char*)"SOLVE 2\n");
	AAsolve(nx,m,ncone,cone,typecone,w,theta,A,AA,AA_P,h1,h2,changetodouble,usedouble,AAAA,work,workQ,method,nf,ns,Qstart,QQ,LL,QQpiv);
	//	printf((char*)"SOLVE 2 out\n");
	
	if(homog)
	{
		*dtau=(*r3 + ddotvec(nx,h1,c) - ddotvec(m,h2,b) + *r5/ *tau)/
			(*kappa/ *tau-ddotvec(nx,c,g1)+ddotvec(m,b,g2)); //keep dtau
	}
	dcopyvec(nx,h1,dx);
	dcopyvec(m,h2,dy);
	if(homog)
	{
		daxpyvec(nx,*dtau,g1,dx);//keep dx
		daxpyvec(m,*dtau,g2,dy);//keep dy
	}
	for(j=0,ix=0;j<ncone;ix+=cone[j],j++)
	{
		if(typecone[j]==0)
		{
			for(k=0;k<cone[j];++k)
			{
				WtransSDP(1,dx+ix+k,w+ix+k,&cc1[ix+k]);
				applyXSDP(1,sbar+ix+k,&cc1[ix+k],&cc2[ix+k]);
			}
		}
		else if(typecone[j]==2)
		{
			size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[j]));
			WtransSDP(n,dx+ix,w+ix,&cc1[ix]);
			applyXSDP(n,sbar+ix,&cc1[ix],&cc2[ix]);
		}
		else if(typecone[j]==1)
		{
			Wtrans(cone[j],dx+ix,w+ix,&cc1[ix]);
			thetaScale(cone[j],&cc1[ix],theta[j]);
			applyX(cone[j],sbar+ix,&cc1[ix],&cc2[ix]);
		}
		else if(typecone[j]==3)
		{
			WtransR(cone[j],dx+ix,w+ix,&cc1[ix]);
			thetaScale(cone[j],&cc1[ix],theta[j]);
			Tmulvec(cone[j],&cc1[ix],true);
			Tmulvec(cone[j],sbar+ix,true);
			applyX(cone[j],sbar+ix,&cc1[ix],&cc2[ix]);
			Tmulvec(cone[j],&cc1[ix],true);
			Tmulvec(cone[j],&cc2[ix],true);
			Tmulvec(cone[j],sbar+ix,true);
		}
	}
	dsubvec(nx,r4,&cc2[0],&cc2[0]);
	for(j=0,ix=0;j<ncone;ix+=cone[j],j++)
	{
		if(typecone[j]==0)
		{
			for(k=0;k<cone[j];++k)
			{
				applyXm1SDP(1,xbar+ix+k,&cc2[ix+k],&cc1[ix+k]);
				WtransSDP(1,&cc1[ix+k],w+ix+k,ds+ix+k);
			}
		}
		else if(typecone[j]==2)
		{
			size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[j]));
			applyXm1SDP(n,xbar+ix,&cc2[ix],&cc1[ix]);
			WtransSDP(n,&cc1[ix],w+ix,ds+ix);
		}
		else if(typecone[j]==1)
		{
			applyXm1(cone[j],xbar+ix,&cc2[ix],&cc1[ix]);
			Wtrans(cone[j],&cc1[ix],w+ix,ds+ix);
			thetaScale(cone[j],ds+ix,theta[j]);//keep ds
		}
		else if(typecone[j]==3)
		{
			Tmulvec(cone[j],xbar+ix,true);
			Tmulvec(cone[j],&cc2[ix],true);
			applyXm1(cone[j],xbar+ix,&cc2[ix],&cc1[ix]);
			Tmulvec(cone[j],&cc1[ix],true);
			Tmulvec(cone[j],&cc2[ix],true);
			Tmulvec(cone[j],xbar+ix,true);
			WtransR(cone[j],&cc1[ix],w+ix,ds+ix);
			thetaScale(cone[j],ds+ix,theta[j]);//keep ds
		}
	}
	if(homog)*dkappa = (*r5 - *kappa* *dtau)/ *tau;//keep kappa
	return (badindex!=0);
}
double maxstepSDP(size_t n,vector x,vector dx)
{
	/* If X + step dX is positive definite
	then step lowest  eigenvalue (X**-.5 dX X**-.5) = -1
	(also note that (X**-.5 dX X**-.5) is symmetric by construction)
	*/
	size_t i;
	std::valarray<double>X(n*n),dX(n*n),rootX(n*n),sp(n*n);
	SDPsMat(n,x,&X[0]);
	SDPsMat(n,dx,&dX[0]);
	symm2packed(n,&X[0]);
	RootProcessQ(n,&X[0],0,&rootX[0]);
	vector xx,pr;
	for(i=0,xx=&rootX[0],pr=&sp[0];i<n;++i)
	{
		dmxtmulv(n,n,&dX[0],xx,pr);
		xx+=n;
		pr+=n;
	}
	for(i=0,xx=&sp[0],pr=&X[0];i<n;++i)
	{
		dmxtmulv(n,n,&rootX[0],xx,pr);
		xx+=n;
		pr+=n;
	}
	size_t r=eigendecomp(n,&X[0],&sp[0],100);
	if(sp[n-1]<0)
		return dmin(1.0,(-1./sp[n-1]));
	else
		return 1.;
}
double getStepsize(size_t ncone,int* cone,int* typecone,size_t nx,vector x,vector s,vector ds,vector dx,vector dtau,vector dkappa,
				   double tau,double kappa,double mu,double gamma,double beta,bool homog=true)
{
	double XX=ddotvec(nx,x,x);
	double XdX=ddotvec(nx,x,dx);
	double dXdX=ddotvec(nx,dx,dx);
	double SS=ddotvec(nx,s,s);
	double SdS=ddotvec(nx,s,ds);
	double dSdS=ddotvec(nx,ds,ds);
	double XS=ddotvec(nx,x,s);
	double XdS=ddotvec(nx,x,ds);
	double dXS=ddotvec(nx,dx,s);
	double dXdS=ddotvec(nx,dx,ds);
	double alpha=1,desc;
	double lowest=.1,lowest1=1-lowest;

	if(dXdX<=lm_eps)
	{
		if(XdX<-lm_eps)
			alpha=dmin(alpha,lowest1*(-XX/(XdX+XdX)));
	}
	else
	{
		if(fabs(XdX)>lm_eps)desc=1.-XX*dXdX/XdX/XdX;
		else desc=-XX*dXdX;
		if(desc>lm_eps8)
		{
			if(fabs(XdX)>lm_eps)desc=sqrt(desc)*fabs(XdX);
			else desc=sqrt(desc);
			if(XdX+desc<0)
				alpha=dmin(alpha,lowest1*((-XdX-desc)/dXdX));
		}
		else if(desc>=-lm_eps&&XdX<0)
			alpha=dmin(alpha,lowest1*((-XdX)/dXdX));
	}

	if(dSdS<=lm_eps)
	{
		if(SdS<-lm_eps)
			alpha=dmin(alpha,lowest1*(-SS/(SdS+SdS)));
	}
	else
	{
		if(fabs(SdS)>lm_eps)desc=1.-SS*dSdS/SdS/SdS;
		else desc=-SS*dSdS;
		if(desc>lm_eps8)
		{
			if(fabs(SdS)>lm_eps)desc=sqrt(desc)*fabs(SdS);
			else desc=sqrt(desc);
			if(SdS+desc<0)
				alpha=dmin(alpha,lowest1*((-SdS-desc)/dSdS));
		}
		else if(desc>=-lm_eps8&&SdS<0)
			alpha=dmin(alpha,lowest1*((-SdS)/dSdS));
	}

	if(fabs(dXdS)<=lm_eps)
	{
		if(dXS+XdS<-lm_eps)
			alpha=dmin(alpha,lowest1*(-XS/(XdS+dXS)));
	}
	else
	{
		if(fabs(XdS+dXS)>lm_eps)desc=1.-4*XS*dXdS/(XdS+dXS)/(XdS+dXS);
		else desc=-4*XS*dXdS;
		if(desc>lm_eps8)
		{
			if(fabs(XdS+dXS)>lm_eps)desc=sqrt(desc)*fabs(XdS+dXS);
			else desc=sqrt(desc);
			if((XdS+dXS+desc)>0&&dXdS<0)
				alpha=dmin(alpha,lowest1*((-XdS-dXS-desc)/2./dXdS));
			else if((XdS+dXS+desc)/dXdS<0)
				alpha=dmin(alpha,lowest1*((-XdS-dXS-desc)/2./dXdS));
		}
		else if(desc>=-lm_eps8&&(XdS+dXS)/dXdS<0)
			alpha=dmin(alpha,lowest1*((-XdS-dXS)/2./dXdS));
	}

	std::valarray<double> vx1(ncone),vx2(ncone),vx3(ncone);
	std::valarray<double> vs1(ncone),vs2(ncone),vs3(ncone);
	std::valarray<double> cc1(nx),cc2(nx),cc3(nx),cc4(nx);
	int* nncone=cone;
	size_t i,ix,j;
	vector px,pdx,pQdx,pQx;
	vector ps,pds,pQds,pQs;

	vx1=0;
	vx2=0;
	vx3=0;
	vs1=0;
	vs2=0;
	vs3=0;

	dcopyvec(nx,s,&cc1[0]);
	for(i=0,ix=0;i<ncone;ix+=cone[i],i++)
	{
		if(typecone[i]==1||typecone[i]==3)
			Qmulvec(cone[i],&cc1[ix],typecone[i]==3);
	}
	dcopyvec(nx,ds,&cc2[0]);
	for(i=0,ix=0;i<ncone;ix+=cone[i],i++)
	{
		if(typecone[i]==1||typecone[i]==3)
			Qmulvec(cone[i],&cc2[ix],typecone[i]==3);
	}


	for(i=0,nncone=cone,ps=s,pQs=&cc1[0],pQds=&cc2[0],pds=ds;i<ncone;
	ps+=*nncone,pQs+=*nncone,pds+=*nncone,pQds+=*nncone,i++,nncone++)
	{
		if(typecone[i]==0)
		{
			vs1[i]=0;
			vs2[i]=0;
			vs3[i]=0;
			for(j=0;j<*nncone;++j)
			{
				vs1[i]+=ddotvec(1,ps+j,pQs+j);
				vs2[i]+=2*ddotvec(1,pds+j,pQs+j);
				vs3[i]+=ddotvec(1,pds+j,pQds+j);
			}
		}
		else if(typecone[i]==1||typecone[i]==3||typecone[i]==2)
		{
			vs1[i]=ddotvec(*nncone,ps,pQs);
			vs2[i]=2*ddotvec(*nncone,pds,pQs);
			vs3[i]=ddotvec(*nncone,pds,pQds);
		}
	}
	
	dcopyvec(nx,x,&cc3[0]);
	for(i=0,ix=0;i<ncone;ix+=cone[i],i++)
	{
		if(typecone[i]==1||typecone[i]==3)
			Qmulvec(cone[i],&cc3[ix],typecone[i]==3);
	}
	dcopyvec(nx,dx,&cc4[0]);
	for(i=0,ix=0;i<ncone;ix+=cone[i],i++)
	{
		if(typecone[i]==1||typecone[i]==3)
			Qmulvec(cone[i],&cc4[ix],typecone[i]==3);
	}
	for(i=0,nncone=cone,px=x,pQx=&cc3[0],pQdx=&cc4[0],pdx=dx;i<ncone;
	px+=*nncone,pQx+=*nncone,pdx+=*nncone,pQdx+=*nncone,i++,nncone++)
	{
		if(typecone[i]==0)
		{
			vx1[i]=0;
			vx2[i]=0;
			vx3[i]=0;
			for(j=0;j<*nncone;++j)
			{
				vx1[i]+=ddotvec(1,px+j,pQx+j);
				vx2[i]+=2*ddotvec(1,pdx+j,pQx+j);
				vx3[i]+=ddotvec(1,pdx+j,pQdx+j);
			}
		}
		else if(typecone[i]==1||typecone[i]==3||typecone[i]==2)
		{
			vx1[i]=ddotvec(*nncone,px,pQx);
			vx2[i]=2*ddotvec(*nncone,pdx,pQx);
			vx3[i]=ddotvec(*nncone,pdx,pQdx);
		}
	}
	for(i=0,nncone=cone,pQs=&cc1[0],pQds=&cc2[0],pQx=&cc3[0],pQdx=&cc4[0];i<ncone;
	pQs+=*nncone,pQds+=*nncone,pQx+=*nncone,pQdx+=*nncone,i++,nncone++)
	{
		if(typecone[i]==0)
		{
			for(j=0;j<*nncone;++j)
			{
				if(pQdx[j]<0) alpha=dmin(lowest1*(-pQx[j]) / pQdx[j],alpha);
				if(pQds[j]<0) alpha=dmin(lowest1*(-pQs[j]) / pQds[j],alpha);
			}
		}
		else if(typecone[i]==1||typecone[i]==3)
		{
			if(pQdx[*nncone-1]<0) alpha=dmin(lowest1*(-pQx[*nncone-1]) / pQdx[*nncone-1],alpha);
			if(pQds[*nncone-1]<0) alpha=dmin(lowest1*(-pQs[*nncone-1]) / pQds[*nncone-1],alpha);
		}
	}
	if(disnan_BITA(&alpha))return alpha;
	for(i=0,nncone=cone,ps=s,pds=ds,px=x,pdx=dx;i<ncone;
	ps+=*nncone,pds+=*nncone,px+=*nncone,pdx+=*nncone,i++,nncone++)
	{
		if(typecone[i]==0)
		{
			for(j=0;j<*nncone;++j)
			{
				if(pdx[j]<0) alpha=dmin(lowest1*(-px[j]) / pdx[j],alpha);
				if(pds[j]<0) alpha=dmin(lowest1*(-ps[j]) / pds[j],alpha);
			}
		}
		else if(typecone[i]==1||typecone[i]==3)
		{
			if(pdx[*nncone-1]<0) alpha=dmin(lowest1*(-px[*nncone-1]) / pdx[*nncone-1],alpha);
			if(pds[*nncone-1]<0) alpha=dmin(lowest1*(-ps[*nncone-1]) / pds[*nncone-1],alpha);
		}
		else if(typecone[i]==2)
		{
			size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0* *nncone));
			std::valarray<double>xt(*nncone),XS(n*n),eig(n);
			std::valarray<short_scl>AA_P(n);
			alpha=dmin(alpha,lowest1*maxstepSDP(n,px,pdx));

			dcopyvec(*nncone,px,&xt[0]);
			daxpyvec(*nncone,alpha,pdx,&xt[0]);
			
			SDPsMat(n,&xt[0],&XS[0]);
			size_t r=eigendecomp(n,&XS[0],&eig[0],100);
			while(eig[n-1]<=lm_eps8&&alpha>lm_eps)
			{
				alpha*=.99;
				dcopyvec(*nncone,px,&xt[0]);
				daxpyvec(*nncone,alpha,pdx,&xt[0]);
				
				SDPsMat(n,&xt[0],&XS[0]);
				r=eigendecomp(n,&XS[0],&eig[0],100);
			}

			alpha=dmin(alpha,lowest1*maxstepSDP(n,ps,pds));
			
			dcopyvec(*nncone,ps,&xt[0]);
			daxpyvec(*nncone,alpha,pds,&xt[0]);
			
			SDPsMat(n,&xt[0],&XS[0]);
			r=eigendecomp(n,&XS[0],&eig[0],100);
			while(eig[n-1]<=lm_eps8&&alpha>lm_eps)
			{
				alpha*=.99;
				dcopyvec(*nncone,ps,&xt[0]);
				daxpyvec(*nncone,alpha,pds,&xt[0]);
				
				SDPsMat(n,&xt[0],&XS[0]);
				r=eigendecomp(n,&XS[0],&eig[0],100);
			}
		}
	}
	if(disnan_BITA(&alpha))return alpha;
	
	if(homog&&*dtau<0) alpha=dmin(lowest1*-tau/ *dtau,alpha);
	if(disnan_BITA(&alpha))return alpha;
	if(homog&&*dkappa<0) alpha=dmin(lowest1*-kappa/ *dkappa,alpha);
	if(disnan_BITA(&alpha))return alpha;
	double inner,testxs,r1,r2;
	for(i=0,nncone=cone,pdx=dx,pds=ds;i<ncone;pdx+=*nncone,pds+=*nncone,nncone++,++i)
	{
		if(typecone[i]==1||typecone[i]==0||typecone[i]==3||typecone[i]==2)
		{
			if((testxs=vs1[i]+alpha*(vs2[i]+alpha*vs3[i]))<-lm_eps8)
			{
				if(fabs(vs3[i])<=lm_eps)
				{
					if(vs2[i]<-lm_eps)
						alpha=dmin(lowest1*-vs1[i]/vs2[i],alpha);
				}
				else if(fabs(vs2[i])>lm_eps&&(inner=1.-4*vs3[i]*vs1[i]/vs2[i]/vs2[i])>-lm_eps)
				{
					inner=(inner>lm_eps8?sqrt(inner)*fabs(vs2[i]):0);
					r1=(-vs2[i]-inner)/2./vs3[i];r2=(-vs2[i]+inner)/2./vs3[i];
					if(vs3[i]<-lm_eps)
					{
						alpha = dmin(lowest1*(-vs2[i]-inner)/2./vs3[i],alpha);
					}
					else if(vs3[i]>lm_eps)
					{
						alpha = dmin(lowest1*(-vs2[i]-inner)/2./vs3[i],alpha);
					}
				}
				else if(fabs(vs2[i])<=lm_eps&&(inner=-4*vs3[i]*vs1[i])>-lm_eps)
				{
					inner=(inner>lm_eps8?sqrt(inner):0);
					r1=(-vs2[i]-inner)/2./vs3[i];r2=(-vs2[i]+inner)/2./vs3[i];
					if(vs3[i]<-lm_eps)
					{
						alpha = dmin(lowest1*(-vs2[i]-inner)/2./vs3[i],alpha);
					}
					else if(vs3[i]>lm_eps)
					{
						alpha = dmin(lowest1*(-vs2[i]-inner)/2./vs3[i],alpha);
					}
				}
				else
					printf((char*)"still negative\n");
			}
			/*		else if(testxs<1e-16 && testxs<vs1[i])
			{
			for(j=0;j<*nncone;++j)
			pds[j]=0;
		}*/
			if((testxs=vx1[i]+alpha*(vx2[i]+alpha*vx3[i]))<-lm_eps8)
			{
				if(fabs(vx3[i])<=lm_eps8)
				{
					if(vx2[i]<-lm_eps8)
						alpha=dmin(lowest1*-vx1[i]/vx2[i],alpha);
				}
				else if(fabs(vx2[i])>lm_eps&&(inner=1.-4*vx3[i]*vx1[i]/vx2[i]/vx2[i])>-lm_eps)
				{
					inner=(inner>lm_eps8?sqrt(inner)*fabs(vx2[i]):0);
					r1=(-vx2[i]-inner)/2./vx3[i];r2=(-vx2[i]+inner)/2./vx3[i];
					if(vx3[i]<-lm_eps)
					{
						alpha = dmin(lowest1*(-vx2[i]-inner)/2./vx3[i],alpha);
					}
					else if(vx3[i]>lm_eps)
					{
						alpha = dmin(lowest1*(-vx2[i]-inner)/2./vx3[i],alpha);
					}
				}
				else if(fabs(vx2[i])<=lm_eps&&(inner=-4*vx3[i]*vx1[i])>-lm_eps)
				{
					inner=(inner>lm_eps8?sqrt(inner):0);
					r1=(-vx2[i]-inner)/2./vx3[i];r2=(-vx2[i]+inner)/2./vx3[i];
					if(vx3[i]<-lm_eps)
					{
						alpha = dmin(lowest1*(-vx2[i]-inner)/2./vx3[i],alpha);
					}
					else if(vx3[i]>lm_eps)
					{
						alpha = dmin(lowest1*(-vx2[i]-inner)/2./vx3[i],alpha);
					}
				}
				else
					printf((char*)"still negative\n");
			}
		}
		/*		else if(testxs<1e-16 && testxs<vx1[i])
		{
		for(j=0;j<*nncone;++j)
		pdx[j]=0;
	}*/
	}
	if(disnan_BITA(&alpha))return alpha;
	size_t l;
	double rhs,gamma1=1-gamma,test1,test2=1;
	for(l=0;l<1000;++l)
	{
		rhs=beta*(1-alpha*gamma1)*mu;
		if(homog)test2=(tau+alpha* *dtau)*(kappa+alpha* *dkappa);
		test1=0;
		for(i=0;i<ncone;++i)
		{
			if(typecone[i]==1||typecone[i]==0||typecone[i]==3||typecone[i]==2)
			{
				test1+=(vx1[i]+alpha*(vx2[i]+alpha*vx3[i]))*(vs1[i]+alpha*(vs2[i]+alpha*vs3[i]));
			}
		}
		test1=sqrt(test1);
		if(test1>=rhs&&test2>=rhs)break;
		alpha*=lowest1;
	}
	return alpha;
}
void makeResid(size_t m,size_t ncone,size_t nx,int* cone,int* typecone,vector c,vector A,vector b,vector x,vector s,vector y,
			   vector xbar,vector sbar,vector r1,vector r2,vector r3,vector r4,vector r5,vector ds,vector dx,vector dtau,vector dkappa,
			   double tau,double kappa,
			   vector w,vector theta,double mu,double gamma,double alpha,bool homog=true)
{
	size_t i,ix,j;
	double gamma1=gamma-1;
	for(i=0,ix=0;i<ncone;ix+=cone[i],i++)
	{
		if(typecone[i]==0)
		{
			for(j=0;j<cone[i];++j)
				applyXSDP(1,xbar+ix+j,sbar+ix+j,r4+ix+j);
		}
		else if(typecone[i]==1||typecone[i]==3)
		{
			Tmulvec(cone[i],xbar+ix,typecone[i]==3);
			Tmulvec(cone[i],sbar+ix,typecone[i]==3);
			applyX(cone[i],xbar+ix,sbar+ix,r4+ix);
			Tmulvec(cone[i],xbar+ix,typecone[i]==3);
			Tmulvec(cone[i],sbar+ix,typecone[i]==3);
			Tmulvec(cone[i],r4+ix,typecone[i]==3);
		}
		else if(typecone[i]==2)
		{
			size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[i]));
			applyXSDPold(n,xbar+ix,sbar+ix,r4+ix);
		}
	}
	dnegvec(nx,r4);
	vector rr4,xxbar;
	if(gamma!=0)
	{
		double gammam=gamma*mu,gmult=100;
		for(i=0,rr4=r4,xxbar=xbar;i<ncone;rr4+=cone[i],xxbar+=cone[i],i++)
		{
			if(typecone[i]==0)
			{
				for(j=0;j<cone[i];++j)
				{
					rr4[j]+= gammam;// - (mu<1e-3?gamma1*mu*mu*gmult:0);
				}
			}
			else if(typecone[i]==1)
			{
				rr4[cone[i]-1]+= gammam;//- (mu<1e-3?gamma1*mu*mu*gmult:0);
			}
			else if(typecone[i]==3)
			{
				rr4[cone[i]-2]+= (gammam/* - (mu<1e-3?gamma1*mu*mu*gmult:0)*/)*lm_rroot2;
				rr4[cone[i]-1]+= (gammam/* - (mu<1e-3?gamma1*mu*mu*gmult:0)*/)*lm_rroot2;
			}
			else if(typecone[i]==2)
			{
				size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[i]));
				for(j=0;j<n;++j)
					rr4[cone[i]+j-n]+=gammam;// - (mu<1e-3?gamma1*mu*mu*gmult:0);
			}
		}
	}
	if(homog)*r5=-tau*kappa + gamma*mu;//keep
	if(alpha!=0)//The correction dsbardxbar
	{
		std::valarray<double> cor(3*nx);
		dcopyvec(nx,ds,&cor[nx+nx]);//(theta.w)**-1 ds = w**-1 theta**-1 ds
		for(i=0,ix=0;i<ncone;ix+=cone[i],i++)
		{
			if(typecone[i]==0)
			{
				for(j=0;j<cone[i];++j)
				{
					WtransSDP(1,&cor[nx+nx+ix+j],&w[ix+j],&cor[ix+j],true);//Transformed ds
					WtransSDP(1,dx+ix+j,&w[ix+j],&cor[nx+ix+j]);//Transformed dx
					applyXSDP(1,&cor[nx+ix+j],&cor[ix+j],&cor[nx+nx+ix+j]);
				}
			}
			else if(typecone[i]==3)
			{
				thetaScale(cone[i],&cor[nx+nx+ix],theta[i],true);
				Qmulvec(cone[i],&cor[nx+nx+ix],typecone[i]==3);
				WtransR(cone[i],&cor[nx+nx+ix],&w[ix],&cor[ix]);
				Qmulvec(cone[i],&cor[ix],typecone[i]==3);
				
				WtransR(cone[i],dx+ix,&w[ix],&cor[nx+ix]);//theta.w.dx
				thetaScale(cone[i],&cor[nx+ix],theta[i]);
				Tmulvec(cone[i],&cor[ix],true);
				Tmulvec(cone[i],&cor[nx+ix],true);
				applyX(cone[i],&cor[nx+ix],&cor[ix],&cor[nx+nx+ix]);

				Tmulvec(cone[i],&cor[ix],true);
				Tmulvec(cone[i],&cor[nx+ix],true);
				Tmulvec(cone[i],&cor[nx+nx+ix],true);
			}
			else if(typecone[i]==1)
			{
				thetaScale(cone[i],&cor[nx+nx+ix],theta[i],true);
				Qmulvec(cone[i],&cor[nx+nx+ix]);
				Wtrans(cone[i],&cor[nx+nx+ix],&w[ix],&cor[ix]);
				Qmulvec(cone[i],&cor[ix]);
				
				Wtrans(cone[i],dx+ix,&w[ix],&cor[nx+ix]);//theta.w.dx
				thetaScale(cone[i],&cor[nx+ix],theta[i]);
				applyX(cone[i],&cor[nx+ix],&cor[ix],&cor[nx+nx+ix]);
			}
			else if(typecone[i]==2)
			{
				size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[i]));
				WtransSDP(n,&cor[nx+nx+ix],&w[ix],&cor[ix],true);//Transformed ds
				WtransSDP(n,dx+ix,&w[ix],&cor[nx+ix]);//Transformed dx
				applyXSDPold(n,&cor[nx+ix],&cor[ix],&cor[nx+nx+ix]);
			}
		}
		dsubvec(nx,r4,&cor[nx+nx],r4);
		if(homog)*r5-=*dtau* *dkappa;
	}
	for(i=0;i<m;++i)
	{
		r1[i]=gamma1*(ddotvec(nx,A+i*nx,x)-b[i]*(homog?tau:1));//keep
	}
	for(i=0;i<nx;++i)
	{
		r2[i]=gamma1*(BITA_ddot(m,A+i,nx,y,1)+s[i]-c[i]*(homog?tau:1));//keep
	}
	if(homog)*r3=gamma1*(-ddotvec(nx,c,x)+ddotvec(m,b,y)-kappa);//keep
}
long conecheck(size_t ncone,int*cone,int*typecone,vector x,double eps=0,double tau=1.)
{
	long back=-1;
	vector xc;
	size_t i,j,nn;
	double check,epsc=eps;
	if(tau!=1.&&eps)epsc*=(tau*tau);
	for(i=0,xc=x;i<ncone;++i)
	{
		if(typecone[i]==1)
		{
			nn=cone[i] -1;
			if(!nn)
			{
				if(*xc<eps)
				{
					back=i;
					xc++;
					continue;
				}
			}
			check=0;
			for(j=0;j<nn;++j)
				check-=*xc* *xc++;
			check+=*xc* *xc;
			if(check<epsc)
			{
				back= i;
			}
			xc++;
		}
		else if(typecone[i]==3)
		{
			nn=cone[i] -2;
			check=0;
			for(j=0;j<nn;++j)
				check-=*xc* *xc++;
			check+=2.* *xc* *(xc+1);
			if(check<epsc)
			{
				back= i;
			}
			xc++;
			xc++;
		}
		else if(typecone[i]==0)
		{
			for(j=0;j<cone[i];++j)
			{
				if(*xc<eps)
				{
					back=i;
				}
				xc++;
			}
		}
		else if(typecone[i]==2)
		{
			size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[i]));
			std::valarray<double>XS(n*n),eig(n);

			SDPsMat(n,xc,&XS[0]);
			size_t r=eigendecomp(n,&XS[0],&eig[0],100);
			if(eig[n-1]<eps)
				back=i;
			xc+=cone[i];
		}
	}
	return back;
}

/*For passing integer arrays to c# it's convenient to use int* as int is 4 bytes on 32 and 64 bit systems*/
short Conic_General(size_t ncone,int*cone,int*typecone,size_t m,vector x,vector s,vector y,vector A,vector b,
										 vector c,vector tau,vector kappa,double comptoll,double gaptoll,double stepmax,int straight,int fastbreak,
										 int log,char*outfile,int method)
{
#ifdef __SYSNT__
	_ASSERT(0);
#endif
#ifdef PAS
//	UnlockBita((char*)"colincolin");
	if(!Optimise::bitago)
	{
		fprintf(stderr,(char*)"Bad PAS key\n");
		return -1;
	}
	return -1;
#endif
	Optimise O;
	if(!O.licenced)return -1;
	comptoll=small_round(comptoll);
	gaptoll=small_round(gaptoll);
	stepmax=small_round(stepmax);
	/*	
	Primal:	Minimise c.x subject to A.x=b				and x is a stack of cones

	Dual:	Maximise b.y subject to A*.y + s =c			and s is a stack of cones

	if typecone[i] = 1 the subcone is a second order cone dimension cone[i]
	if typecone[i] = 3 the subcone is a rotated second order cone dimension cone[i] (>=2)
	if typecone[i] = 0 the subcone is the set x>0 dimension cone[i]
	if typecone[i] = 2 the subcone is the of semi-definite matrices dimension n where cone[i]=n*(n+1)/2
	A is the A of GAUSS NEWT transposed
	*/

	std::stringstream logprint;
	std::ofstream outFile;
	size_t nx=0,Rl=0;
	size_t differentsigns;
	bool usedouble=true,regularise=false;//Still testing whether regularising is worth the fuss
	short changetodouble=0;
	vector X=x,S=s;
	Integer i,j;
	bool rot=false;
	for(i=0;i<ncone;++i)
	{
		nx+=cone[i];
	}
	if(outfile&&!strlen(outfile))//In case someone sends outfile=(char*)""
	{
		outfile=0;
	}
	if(outfile)
	{
		outFile.open(outfile,std::ios_base::out|std::ios_base::app);
		if(outFile.fail())
		{
			std::cout<<"Cannot open "<<outfile<<std::endl;
		}
		if(log==2)
		{
			dumpvector(1,(char*)"ncone",&ncone,outFile);
			dumpvector(1,(char*)"m",&m,outFile);
			dumpvector(ncone,(char*)"cone",cone,outFile);
			dumpvector(ncone,(char*)"typecone",typecone,outFile);
			dumpvector(nx*m,(char*)"A",A,outFile,100000);
			dumpvector(m,(char*)"b",b,outFile);
			dumpvector(nx,(char*)"c",c,outFile);
			dumpvector(1,(char*)"comptoll",&comptoll,outFile);
			dumpvector(1,(char*)"gaptoll",&gaptoll,outFile);
			dumpvector(1,(char*)"stepmax",&stepmax,outFile);
			dumpvector(1,(char*)"straight",&straight,outFile);
			dumpvector(1,(char*)"fastbreak",&fastbreak,outFile);
			outFile<<"-------------------------------------------------------------------------------------------";
			outFile<<std::endl;
			outFile.flush();
		}
	}
	for(i=0;i<ncone;++i)
	{
		if(typecone[i]==2)
		{
			size_t n=static_cast<size_t>(-0.25+.5*sqrt(1.0+8.0*cone[i]));
			Rl+=n;
		}
		else
		{
			if(typecone[i]==0)
				Rl+=cone[i];
			else if(typecone[i]==1)
				Rl+=min(cone[i],1);				//The implicit barrier function is -ln sqrt(xn*xn-x.x) i.e. nu=1 but if we divide by 2 SOCP converges quicker
			else if(typecone[i]==3)
			{
				rot=true;
				Rl+=min(cone[i],2);
			}
		}
	}
	if(straight)	rot=false;
	if(rot)
	{
		//This way is more efficient and more accurate
		std::valarray<int> ntypecone(ncone);
		vector AA=A,cc=c,xx=x,ss=s;
		vector am1,am2;
		short back;
		double a1,a2;
		for(j=0;j<m;++j)
		{
			for(i=0;i<ncone;AA+=cone[i],cc+=cone[i],++i)
			{
				if(typecone[i]==3)
				{
					am2=AA+cone[i]-2;
					am1=AA+cone[i]-1;
					a2=(*am1-*am2)*lm_rroot2;
					a1=(*am1+*am2)*lm_rroot2;
					*am2=a2;
					*am1=a1;
					ntypecone[i]=1;
					if(j==0)
					{
						am2=cc+cone[i]-2;
						am1=cc+cone[i]-1;
						a2=(*am1-*am2)*lm_rroot2;
						a1=(*am1+*am2)*lm_rroot2;
						*am2=a2;
						*am1=a1;
					}
				}
				else
					ntypecone[i]=typecone[i];
			}
		}
		back=Conic_General(ncone,cone,&ntypecone[0],m,x,s,y,A,b,c,tau,kappa,comptoll,gaptoll,stepmax,true,fastbreak,log,outfile,method);
		for(j=0,AA=A,cc=c,ss=s,xx=x;j<m;++j)
		{
			for(i=0;i<ncone;AA+=cone[i],ss+=cone[i],cc+=cone[i],xx+=cone[i],++i)
			{
				if(typecone[i]==3)
				{
					am2=AA+cone[i]-2;
					am1=AA+cone[i]-1;
					a2=(*am1-*am2)*lm_rroot2;
					a1=(*am1+*am2)*lm_rroot2;
					*am2=a2;
					*am1=a1;
					if(j==0)
					{
						am2=xx+cone[i]-2;
						am1=xx+cone[i]-1;
						a2=(*am1-*am2)*lm_rroot2;
						a1=(*am1+*am2)*lm_rroot2;
						*am2=a2;
						*am1=a1;
						am2=ss+cone[i]-2;
						am1=ss+cone[i]-1;
						a2=(*am1-*am2)*lm_rroot2;
						a1=(*am1+*am2)*lm_rroot2;
						*am2=a2;
						*am1=a1;
						am2=cc+cone[i]-2;
						am1=cc+cone[i]-1;
						a2=(*am1-*am2)*lm_rroot2;
						a1=(*am1+*am2)*lm_rroot2;
						*am2=a2;
						*am1=a1;
					}
				}
			}
		}
		return back;
	}
	std::valarray<double>AA(m*m);
	std::valarray<float>AAAA;
#ifdef USE_SINGLE
	AAAA.resize(m*(m+1)>>1);usedouble=false;
#endif
	std::valarray<short_scl>AA_P(m);
	double gap;
	if((ddotvec(nx,x,x)+ddotvec(nx,s,s))<0.5)
	{
		dzerovec(nx,x);
		dzerovec(nx,s);
		dzerovec(m,y);
		*tau=*kappa=1.;
		for(i=0,X=x,S=s;i<ncone;i++)
		{
			if(typecone[i]==1)
			{
				X+=cone[i]-1;
				S+=cone[i]-1;
				*S++=*X++=1;
			}
			else if(typecone[i]==3)
			{
				X+=cone[i]-2;
				S+=cone[i]-2;
				*S++=*X++=lm_rroot2;
				*S++=*X++=lm_rroot2;
			}
			else if(typecone[i]==0)
			{
				for(j=0;j<cone[i];++j)
				{
					*S++=*X++=1;
				}
			}
			else if(typecone[i]==2)
			{
				size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[i]));
				X+=cone[i]-n;
				S+=cone[i]-n;
				for(j=0;j<n;++j)
				{
					*X++=1.;
					*S++=1.;
				}
			}
		}
	}
	gap=ddotvec(nx,c,x)-ddotvec(m,b,y);
	if(gap < 0)
	{
		dsetvec(m,1,y);
		double dgap=ddotvec(m,b,y);
		double step=gap/dgap;
		dsetvec(m,(1+lm_rooteps)*step,y);
	}
	else if(gap==0)
	{
		dsetvec(m,-1,y);
	}
	gap=ddotvec(nx,c,x)-ddotvec(m,b,y);
	double mu,mu0;
	int badcount=0,badtop=200;
	double alphamax=stepmax;
	std::valarray<bool>ysign(2*m);
	size_t worsecount=0;
	bool restart=false,highcondition=false;
	void* work=0;
	void* workQ=0;
//	if(method==1)
//		InitialiseGen(m,&work);
	double resid=lm_max,residmin=lm_max,compmin=lm_max;
	double rhoP0,rhoD0,rhoG0;

	std::valarray<double>w(nx),xbar(nx),sbar(nx),rD(2+m+2*nx),theta(ncone);
	std::valarray<double>dx(nx),dy(m),ds(nx);
	std::valarray<double>ex(nx),ey(m),es(nx);
	std::valarray<double>xkeep(nx),ykeep(m),skeep(nx);
	double taukeep,kappakeep;
	vector r1,r2,r3,r4,r5;
	double dtau,dkappa,etau,ekappa;

	double beta=1e-6,delta=.5;
	long badcone;
	double gamma=0,alpha=1,alphat=0,comp=10,rhoconv=lm_eps8;//,gapcheck,gapcheckt;
	double rhoDlim=rhoconv,rhoGlim=rhoconv,rhoAlim=rhoconv,rhoPlim=rhoconv;
	size_t maxit=100;
	double rhoD=lm_max,rhoP=lm_max,rhoG=lm_max,rhoA=lm_max;
	short changed=changetodouble;
	while(badcount++<badtop)
	{
		if(log) AddLog(&logprint,(char*)"                                Outer Loop %d\n",badcount);
		double inner;
		rhoP0=0;
		for(i=0;i<m;++i)
		{
			inner=ddotvec(nx,A+i*nx,x)-*tau*b[i];
			rhoP0+=inner*inner;
		}
		rhoP=rhoP0=sqrt(rhoP0);
		rhoG=rhoG0=fabs(-ddotvec(nx,c,x)+ddotvec(m,b,y)-*kappa);
		if(rhoG==0)
			rhoG0=1;
		rhoD0=0;
		for(i=0;i<nx;++i)
		{
			inner=BITA_ddot(m,A+i,nx,y,1)+s[i]-*tau*c[i];
			rhoD0+=inner*inner;
		}
		rhoD=rhoD0=sqrt(rhoD0);

		mu=mu0=(ddotvec(nx,x,s)+*tau* *kappa)/(Rl+1);
		r1=&rD[0];
		r2=&rD[m];
		r3=&rD[m+nx];
		r4=&rD[m+nx+1];
		r5=&rD[m+nx*2+1];

		if(!getw_and_theta(nx,ncone,cone,typecone,x,s,&theta[0],&w[0],&xbar[0],&sbar[0]))break;
		makeResid(m,ncone,nx,cone,typecone,c,A,b,x,s,y,&xbar[0],&sbar[0],r1,r2,r3,r4,r5,&ds[0],&dx[0],&dtau,&dkappa,*tau,*kappa,&w[0],&theta[0],mu,0,0);
		residmin=resid=ddotvec(2+m+2*nx,&rD[0],&rD[0]);
		for(i=0;i<maxit&&(rhoD>rhoDlim||rhoG>rhoGlim||rhoP>rhoPlim);++i)
		{
			changed=changetodouble;highcondition=false;
			if(log) AddLog(&logprint,(char*)"                                       Inner Loop %d\n",i);
			if(getDirection(true,m,nx,ncone,cone,typecone,c,b,&theta[0],&w[0],A,&AA[0],&AA_P[0],&xbar[0],&sbar[0],r1,r2,r3,r4,r5,&dx[0],&dy[0],&ds[0],&dtau,
				&dkappa,tau,kappa,changetodouble,usedouble,&AAAA[0],highcondition,regularise,&work,&workQ,method))
			{
				if(log) AddLog(&logprint,(char*)"\e[1;34mgetDirection failed\e[0m");
				break;
			}
			if(highcondition&&log)AddLog(&logprint,(char*)"\e[1;34mUnstable normal equations\e[0m\n");
			alpha=getStepsize(ncone,cone,typecone,nx,x,s,&ds[0],&dx[0],&dtau,&dkappa,*tau,*kappa,mu,0,beta);
			if(disnan_BITA(&alpha))
			{
				if(log) AddLog(&logprint,(char*)"\e[1;34mBad step alpha\e[0m\n");
				gamma=dmin(delta,((1-.05)*(1-.05)))*(1-.05);
			}

			dcopyvec(nx,x,&ex[0]);
			dcopyvec(nx,s,&es[0]);etau=*tau,ekappa=*kappa;
			dcopyvec(m,y,&ey[0]);
			while(true)
			{
				bool again=false;
				daxpyvec(m,alpha,&dy[0],&ey[0]);
				daxpyvec(nx,alpha,&dx[0],&ex[0]);
				daxpyvec(nx,alpha,&ds[0],&es[0]);
				etau+=alpha* dtau;ekappa+=alpha* dkappa;
				if((badcone=conecheck(ncone,cone,typecone,&ex[0],0.,etau))>-1)
				{
					again=true;
				}
				if((badcone=conecheck(ncone,cone,typecone,&es[0],0.,etau))>-1)
				{
					again=true;
				}
				/*if(ddotvec(nx,c,&ex[0])-ddotvec(m,b,&ey[0])<-1e-8) STUPID IDEA
				{
					again=true;
				}*/
				if(again)
				{
					daxpyvec(m,-alpha,&dy[0],&ey[0]);
					daxpyvec(nx,-alpha,&dx[0],&ex[0]);
					daxpyvec(nx,-alpha,&ds[0],&es[0]);
					etau-=alpha* dtau;ekappa-=alpha* dkappa;
					alpha*=.95;
				}
				else break;
				if(alpha<alphamax*.1)
				{
					if(log) AddLog(&logprint,(char*)"alpha wants to be too small %e\n",alpha);
					break;
				}
			}
			if(disnan_BITA(&alpha))
			{
				if(log) AddLog(&logprint,(char*)"Bad step alpha\n");
			}
			else
				gamma=dmin(delta,((1-alpha)*(1-alpha)))*(1-alpha);
			
			makeResid(m,ncone,nx,cone,typecone,c,A,b,x,s,y,&xbar[0],&sbar[0],r1,r2,r3,r4,r5,&ds[0],&dx[0],&dtau,&dkappa,*tau,*kappa,&w[0],&theta[0],mu,gamma,alpha);
			getDirection(false,m,nx,ncone,cone,typecone,c,b,&theta[0],&w[0],A,&AA[0],&AA_P[0],&xbar[0],&sbar[0],r1,r2,r3,r4,r5,&dx[0],&dy[0],&ds[0],&dtau,
				&dkappa,tau,kappa,changetodouble,usedouble,&AAAA[0],highcondition,regularise,&work,&workQ,method);
			alphat=getStepsize(ncone,cone,typecone,nx,x,s,&ds[0],&dx[0],&dtau,&dkappa,*tau,*kappa,mu,gamma,beta);
			if(disnan_BITA(&alphat))
			{
				if(log) AddLog(&logprint,(char*)"Bad step alphat\n");
			}

			if(changed==changetodouble||changetodouble==2)
			{
				if((!disnan_BITA(&alpha)&&alphat>alpha)||(!disnan_BITA(&alphat)&&disnan_BITA(&alpha)))
				{		
					while(disnan_BITA(&alpha)||alphat>alpha)
					{
						bool again=false;
						daxpyvec(nx,alphat,&dx[0],x);
						daxpyvec(nx,alphat,&ds[0],s);
						daxpyvec(m,alphat,&dy[0],y);
						if((badcone=conecheck(ncone,cone,typecone,x,0.,*tau+alphat*dtau))>-1)
						{
							again=true;
						}
						if((badcone=conecheck(ncone,cone,typecone,s,0.,*tau+alphat*dtau))>-1)
						{
							again=true;
						}
						/*if(ddotvec(nx,c,x)-ddotvec(m,b,y)<-1e-8) STUPID IDEA
						{
							again=true;
						}*/
						if(again)
						{
							daxpyvec(m,-alphat,&dy[0],y);
							daxpyvec(nx,-alphat,&dx[0],x);
							daxpyvec(nx,-alphat,&ds[0],s);
							alphat*=.95;
						}
						else break;
						if(alpha<alphamax*.1)
						{
							break;
						}
					}
					if(!disnan_BITA(&alphat)&&alphat>alpha)
					{
						*tau+=alphat* dtau;
						*kappa+=alphat* dkappa;
						if(!getw_and_theta(nx,ncone,cone,typecone,x,s,&theta[0],&w[0],&xbar[0],&sbar[0]))
						{
							dcopyvec(nx,&ex[0],x);
							dcopyvec(nx,&es[0],s);
							dcopyvec(m,&ey[0],y);
							*tau=etau;
							*kappa=ekappa;
							if(!getw_and_theta(nx,ncone,cone,typecone,x,s,&theta[0],&w[0],&xbar[0],&sbar[0]))break;
						}
					}
				}
				if(!disnan_BITA(&alpha)&&!disnan_BITA(&alphat)&&alphat<=alpha)
				{
					dcopyvec(nx,&ex[0],x);
					dcopyvec(nx,&es[0],s);
					dcopyvec(m,&ey[0],y);
					*tau=etau;
					*kappa=ekappa;
					if(!getw_and_theta(nx,ncone,cone,typecone,x,s,&theta[0],&w[0],&xbar[0],&sbar[0]))break;
				}
			}
			makeResid(m,ncone,nx,cone,typecone,c,A,b,x,s,y,&xbar[0],&sbar[0],r1,r2,r3,r4,r5,&ds[0],&dx[0],&dtau,&dkappa,*tau,*kappa,&w[0],&theta[0],mu,0,0);
			resid=ddotvec(2+m+2*nx,&rD[0],&rD[0]);
			gap=(ddotvec(nx,c,x)-ddotvec(m,b,y))/ *tau;
			comp=ddotvec(nx,s,x)+*tau* *kappa;
			if(disnan_BITA(&comp)||disnan_BITA(&gap))
			{
				if(log) AddLog(&logprint,(char*)"Bad comp or gap\n");break;
			}
			memmove(&ysign[m],&ysign[0],m*sizeof(bool));
			signset(m,y,&ysign[0]);
			differentsigns=signcheck(m,&ysign[0],&ysign[m]);
			if(resid<residmin&&comp<compmin)
			{
				dcopyvec(nx,x,&xkeep[0]);
				dcopyvec(nx,s,&skeep[0]);
				dcopyvec(m,y,&ykeep[0]);
				taukeep=*tau;
				kappakeep=*kappa;
				worsecount=0;
			}
			residmin=dmin(resid,residmin);
			compmin=dmin(comp,compmin);
			mu=(ddotvec(nx,x,s)+*tau* *kappa)/(Rl+1);
			for(j=0,rhoP=0;j<m;++j)
			{
				inner=ddotvec(nx,A+j*nx,x)-*tau*b[j];
				rhoP+=inner*inner;
			}
			rhoP=sqrt(rhoP);
			if(restart)rhoP0=rhoP;
			rhoP/=rhoP0;
			for(j=0,rhoD=0;j<nx;++j)
			{
				inner=BITA_ddot(m,A+j,nx,y,1)+s[j]-*tau*c[j];
				rhoD+=inner*inner;
			}
			rhoD=sqrt(rhoD);
			if(restart)rhoD0=rhoD;
			rhoD/=rhoD0;
			rhoG=fabs(-ddotvec(nx,c,x)+ddotvec(m,b,y)-*kappa);
			if(restart)rhoG0=rhoG;
			if(restart)mu0=mu;
			rhoG/=rhoG0;
			restart=false;
			rhoA=fabs(ddotvec(nx,c,x)-ddotvec(m,b,y))/
				(*tau+fabs(ddotvec(m,b,y)));
			if(log)
			{
				AddLog(&logprint,(char*)"Complementarity         \t\t\t%20.12f\n",comp);
				AddLog(&logprint,(char*)"Primal dual gap         \t\t\t%20.12f\n",gap);
				AddLog(&logprint,(char*)"relative primal residual\t\t\t%20.12f(%20.12f)\n",rhoP,rhoP*rhoP0/m);
				AddLog(&logprint,(char*)"relative dual residual\t\t\t\t%20.12f(%20.12f)\n",rhoD,rhoD*rhoD0/nx);
				AddLog(&logprint,(char*)"relative gap residual\t\t\t\t%20.12f(%20.12f)\n",rhoG,rhoG*rhoG0);
				AddLog(&logprint,(char*)"relative complementarity residual\t\t%20.12f\n",rhoA);
				AddLog(&logprint,(char*)"mu/(first mu)\t\t\t\t\t%20.12f(%20.12f)\n",mu/mu0,mu);
				AddLog(&logprint,(char*)"tau/kappa\t\t\t\t\t%20.12e\n",*tau/ *kappa);
				AddLog(&logprint,(char*)"\t\t\t\t\t\t(steps %f %f)\n",alpha,alphat);
			}
			if(fastbreak&&ratiotest(rhoP,rhoD,rhoG,mu/mu0,log,logprint)&&(*tau/ *kappa>1e6))break;
			if(comp<=comptoll&&fabs(gap)<=gaptoll/*&&resid<lm_rooteps*/)break;
			if(!fastbreak&&dmax(alphat,alpha)<alphamax)break;//Not sure if we want to do this if fastbreak is true
			if(comp<=comptoll&&(*tau/ *kappa<100))break;

			if(changetodouble&&!usedouble)
			{
				if(log) AddLog(&logprint,(char*)"Use double precision solver in next iteration\n");
			}
			if(!(rhoD>rhoDlim||rhoG>rhoGlim||rhoP>rhoPlim||rhoA>rhoAlim))
			{
				if(log) AddLog(&logprint,(char*)"gap cgap %20.8e\n",gap);
				if(log) AddLog(&logprint,(char*)"comp ccomp %20.8e \n",comp);
				if(log) AddLog(&logprint,(char*)"rhoD rhoDlim %20.8e %20.8e\n",rhoD,rhoDlim);
				if(log) AddLog(&logprint,(char*)"rhoG rhoGlim %20.8e %20.8e\n",rhoG,rhoGlim);
				if(log) AddLog(&logprint,(char*)"rhoP rhoPlim %20.8e %20.8e\n",rhoP,rhoPlim);
				if(log) AddLog(&logprint,(char*)"rhoA rhoAlim %20.8e %20.8e\n",rhoA,rhoAlim);
				if(log) AddLog(&logprint,(char*)"rmu  mu0     %20.8e %20.8e\n",mu/mu0,mu0);
			}
		}
		gap=(ddotvec(nx,c,x)-ddotvec(m,b,y))/ *tau;
		comp=ddotvec(nx,s,x)+*tau* *kappa;
		if(log) AddLog(&logprint,(char*)"(Gap %20.12e Complementarity %20.12e)\n",gap ,comp);
		if(disnan_BITA(&comp)||disnan_BITA(&gap))
		{
			if(log) AddLog(&logprint,(char*)"Fix up for nan in comp or gap\n");
			dcopyvec(nx,&xkeep[0],x);
			dcopyvec(nx,&skeep[0],s);
			dcopyvec(m,&ykeep[0],y);
			*tau=taukeep;
			*kappa=kappakeep;
			gap=(ddotvec(nx,c,x)-ddotvec(m,b,y))/ *tau;
			comp=ddotvec(nx,s,x)+*tau* *kappa;
			alpha=1;
		}
		if((dmax(alphat,alpha)<alphamax&&(/*rhoD>rhoDlim*rhoD0||rhoG>rhoGlim*rhoG0||rhoP>rhoPlim*rhoP0||*/fabs(gap)>gaptoll||comp>comptoll))&&(*tau/ *kappa>1e-4)&&(fabs(1-fabs(gap)/fabs(gaptoll))>1e-1||fabs(1-fabs(comp)/fabs(comptoll))>1e-1))
		{
			if(fabs(1-fabs(gap)/fabs(gaptoll))>1e-1){gaptoll*=1.1;gaptoll=small_round(gaptoll);}
			if(fabs(1-fabs(comp)/fabs(comptoll))>1e-1){comptoll*=1.1;comptoll=small_round(comptoll);}
			if(log)AddLog(&logprint,(char*)"SOCP optimisation steps %20.12e\n",dmax(alphat,alpha));
			dscalvec(nx,1./ *tau,s);
			dscalvec(nx,1./ *tau,x);
			dscalvec(m,1./ *tau,y);
			*tau=1;
			double gap=ddotvec(nx,c,x)-ddotvec(m,b,y),oldmu=mu,ext=sqrt((1-dmax(alphat,alpha))*lmod(nx,x)*lmod(nx,s))/nx;
			vector pxx,pss;
			if(ext<=0)ext=1e-6;
			if(i==0)
			{
				size_t i;
				if(log) AddLog(&logprint,(char*)"ext for restart %f\n",ext);
				for(i=0,pxx=x,pss=s;i<ncone;pxx+=cone[i],pss+=cone[i],i++)
				{
					if(typecone[i]==0)
					{
						for(j=0;j<cone[i];++j)
						{
							pxx[j]+=ext;
							pss[j]+=ext;
						}
					}
					else if(typecone[i]==1)
					{
						pxx[cone[i]-1]+=ext;
						pss[cone[i]-1]+=ext;
					}
					else if(typecone[i]==3)
					{
						pxx[cone[i]-2]+=ext*lm_rroot2;
						pss[cone[i]-2]+=ext*lm_rroot2;
						pxx[cone[i]-1]+=ext*lm_rroot2;
						pss[cone[i]-1]+=ext*lm_rroot2;
					}
					else if(typecone[i]==2)
					{
						size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[i]));
						double exth=ext/n;
						for(j=0;j<n;++j)
						{
							pxx[cone[i]-n+j]+=exth;
							pss[cone[i]-n+j]+=exth;
						}
					}
				}
			}
			*tau=1;
			*kappa=lm_eps8;
			gap=ddotvec(nx,c,x)-ddotvec(m,b,y);
			if(gap < 0)
			{
				dsetvec(m,1,y);
				double dgap=ddotvec(m,b,y);
				double step=gap/dgap;
				if(!disnan_BITA(&step))
					dsetvec(m,(1+lm_rooteps)*step,y);
			}
			mu=ddotvec(nx,x,s)/Rl;*kappa=mu;
/*			if(mu>oldmu&&oldmu>lm_rooteps)
			{
				double pp=sqrt(oldmu/mu);
				dscalvec(nx,pp,x);
				dscalvec(nx,pp,s);
				dscalvec(m,pp,y);
				*tau*=pp;
				*kappa*=pp;
				dscalvec(nx,1./ *tau,s);
				dscalvec(nx,1./ *tau,x);
				dscalvec(m,1./ *tau,y);
				*tau=1;
				gap=(ddotvec(nx,c,x)-ddotvec(m,b,y))/ *tau;
				*kappa=mu=ddotvec(nx,x,s)/Rl;
			}*/
			comp=ddotvec(nx,s,x);
			//if(gap>comp)*kappa=gap-comp;
			restart=true;
#ifdef USE_SINGLE
			usedouble=false;
			changetodouble=0;
#endif
		}
		else
		{
			if(outfile)
			{
				PrintLog(&logprint,&outFile);
				outFile.close();
			}
			else
				PrintLog(&logprint);
			if(method==1)
				DeleteGen(&work);
			else if(method==2)
				DeleteSymm(&work);
			if(workQ)DeleteGen(&workQ);
			if(i==maxit)return 1;
			return 0;
		}
	}
	if(badcount>=badtop||disnan_BITA(&comp)||disnan_BITA(&gap))
	{
		dcopyvec(nx,&xkeep[0],x);
		dcopyvec(nx,&skeep[0],s);
		dcopyvec(m,&ykeep[0],y);
		*tau=taukeep;
		*kappa=kappakeep;
	}
	if(outfile)
	{
		PrintLog(&logprint,&outFile);
		outFile.close();
	}
	else
		PrintLog(&logprint);
	if(method==1)
		DeleteGen(&work);
	else if (method==2)
		DeleteSymm(&work);
	if(workQ)DeleteGen(&workQ);
				
	if(badcount>=badtop)
		return 1;
	return 0;
}
short Conic_VeryGeneral(size_t ncone,int*cone,int*typecone,size_t m,vector x,vector s,vector y,vector A,vector b,
										 vector c,vector tau,vector kappa,double comptoll,double gaptoll,double stepmax,int straight,int fastbreak,
										 int log,char*outfile,int method,int homog,long nf,vector SV,vector FL,vector FC,size_t fcone)
{
#ifdef __SYSNT__
	_ASSERT(0);
#endif

#ifdef PAS
//	UnlockBita((char*)"colincolin");
	if(!Optimise::bitago)
	{
		fprintf(stderr,(char*)"Bad PAS key\n");
		return -1;
	}
	return -1;
#endif
	Optimise O;
	if(!O.licenced)return -1;
	comptoll=small_round(comptoll);
	gaptoll=small_round(gaptoll);
	stepmax=small_round(stepmax);
	/*	
	Primal:	Minimise c.x subject to A.x=b				and x is a stack of cones

	Dual:	Maximise b.y subject to A*.y + s =c			and s is a stack of cones

	if typecone[i] = 1 the subcone is a second order cone dimension cone[i]
	if typecone[i] = 3 the subcone is a rotated second order cone dimension cone[i] (>=2)
	if typecone[i] = 0 the subcone is the set x>0 dimension cone[i]
	if typecone[i] = 2 the subcone is the of semi-definite matrices dimension n where cone[i]=n*(n+1)/2
	A is the A of GAUSS NEWT transposed
	*/

	std::stringstream logprint;
	std::ofstream outFile;
	size_t nx=0,Rl=0;
	size_t differentsigns;
	bool usedouble=true,regularise=true;//Still testing whether regularising is worth the fuss
	short changetodouble=0;
	vector X=x,S=s;
	Integer i,j;
	bool rot=false;
	for(i=0;i<ncone;++i)
	{
		nx+=cone[i];
	}
	if(outfile&&!strlen(outfile))//In case someone sends outfile=(char*)""
	{
		outfile=0;
	}
	if(outfile)
	{
		outFile.open(outfile,std::ios_base::out|std::ios_base::app);
		if(outFile.fail())
		{
			std::cout<<"Cannot open "<<outfile<<std::endl;
		}
		if(log==2)
		{
			dumpvector(1,(char*)"ncone",&ncone,outFile);
			dumpvector(1,(char*)"m",&m,outFile);
			dumpvector(ncone,(char*)"cone",cone,outFile);
			dumpvector(ncone,(char*)"typecone",typecone,outFile);
			dumpvector(nx*m,(char*)"A",A,outFile,100000);
			dumpvector(m,(char*)"b",b,outFile);
			dumpvector(nx,(char*)"c",c,outFile);
			dumpvector(1,(char*)"comptoll",&comptoll,outFile);
			dumpvector(1,(char*)"gaptoll",&gaptoll,outFile);
			dumpvector(1,(char*)"stepmax",&stepmax,outFile);
			dumpvector(1,(char*)"straight",&straight,outFile);
			dumpvector(1,(char*)"fastbreak",&fastbreak,outFile);
			dumpvector(1,(char*)"method",&method,outFile);
			dumpvector(1,(char*)"homog",&homog,outFile);
			dumpvector(1,(char*)"nf",&nf,outFile);
			dumpvector(1,(char*)"fcone",&fcone,outFile);
			size_t ns=0;
			if(nf)
			{
				if(typecone[fcone]==0)ns=cone[fcone];
				else if(typecone[fcone]==1)ns=cone[fcone]-1;
				else if(typecone[fcone]==3)ns=cone[fcone]-2;
			}
			if(nf==-1)
			{
				dumpvector(0,(char*)"SV",SV,outFile);
				dumpvector(ns*(ns+1)/2,(char*)"FC",FC,outFile);
				dumpvector(0,(char*)"FL",FL,outFile);
			}
			else
			{
				dumpvector(ns,(char*)"SV",SV,outFile);
				dumpvector(nf*(nf+1)/2,(char*)"FC",FC,outFile);
				dumpvector(ns*nf,(char*)"FL",FL,outFile);
			}
			outFile<<"-------------------------------------------------------------------------------------------";
			outFile<<std::endl;
			outFile.flush();
		}
	}
	for(i=0;i<ncone;++i)
	{
		if(typecone[i]==2)
		{
			size_t n=static_cast<size_t>(-0.25+.5*sqrt(1.0+8.0*cone[i]));
			Rl+=n;
		}
		else
		{
			if(typecone[i]==0)
				Rl+=cone[i];
			else if(typecone[i]==1)
				Rl+=min(cone[i],1);				//The implicit barrier function is -ln sqrt(xn*xn-x.x) i.e. nu=1 but if we divide by 2 SOCP converges quicker
			else if(typecone[i]==3)
			{
				rot=true;
				Rl+=min(cone[i],2);
			}
		}
	}
	if(straight)	rot=false;
	if(rot)
	{
		//This way is more efficient and more accurate
		std::valarray<int> ntypecone(ncone);
		vector AA=A,cc=c,xx=x,ss=s;
		vector am1,am2;
		short back=1;
		double a1,a2;
		for(j=0;j<m;++j)
		{
			for(i=0;i<ncone;AA+=cone[i],cc+=cone[i],++i)
			{
				if(typecone[i]==3)
				{
					am2=AA+cone[i]-2;
					am1=AA+cone[i]-1;
					a2=(*am1-*am2)*lm_rroot2;
					a1=(*am1+*am2)*lm_rroot2;
					*am2=a2;
					*am1=a1;
					ntypecone[i]=1;
					if(j==0)
					{
						am2=cc+cone[i]-2;
						am1=cc+cone[i]-1;
						a2=(*am1-*am2)*lm_rroot2;
						a1=(*am1+*am2)*lm_rroot2;
						*am2=a2;
						*am1=a1;
					}
				}
				else
					ntypecone[i]=typecone[i];
			}
		}
		back=Conic_VeryGeneral(ncone,cone,&ntypecone[0],m,x,s,y,A,b,c,tau,kappa,comptoll,gaptoll,stepmax,true,fastbreak,log,outfile,method,homog,
			nf,SV,FL,FC,fcone);
		for(j=0,AA=A,cc=c,ss=s,xx=x;j<m;++j)
		{
			for(i=0;i<ncone;AA+=cone[i],ss+=cone[i],cc+=cone[i],xx+=cone[i],++i)
			{
				if(typecone[i]==3)
				{
					am2=AA+cone[i]-2;
					am1=AA+cone[i]-1;
					a2=(*am1-*am2)*lm_rroot2;
					a1=(*am1+*am2)*lm_rroot2;
					*am2=a2;
					*am1=a1;
					if(j==0)
					{
						am2=xx+cone[i]-2;
						am1=xx+cone[i]-1;
						a2=(*am1-*am2)*lm_rroot2;
						a1=(*am1+*am2)*lm_rroot2;
						*am2=a2;
						*am1=a1;
						am2=ss+cone[i]-2;
						am1=ss+cone[i]-1;
						a2=(*am1-*am2)*lm_rroot2;
						a1=(*am1+*am2)*lm_rroot2;
						*am2=a2;
						*am1=a1;
						am2=cc+cone[i]-2;
						am1=cc+cone[i]-1;
						a2=(*am1-*am2)*lm_rroot2;
						a1=(*am1+*am2)*lm_rroot2;
						*am2=a2;
						*am1=a1;
					}
				}
			}
		}
		return back;
	}
	size_t ns=0,Qstart=0;
	std::valarray<double>Q,Qx,QQ,LL;
	std::valarray<short_scl>QQpiv;
	double futil=0;
	if(nf>0)//Factor model
	{
		for(i=0;i<fcone;++i)
		{
			Qstart+=cone[i];
		}
		if(typecone[fcone]==0)//LP with quadratic primal
		{
			ns=cone[fcone];
			LL.resize(ns);//Just holds the modified diagonal
			QQ.resize((nf+1)*ns);
		}
		else if(typecone[fcone]==1)//SOCP with quadratic primal
		{
			ns=cone[fcone]-1;
			LL.resize(2*cone[fcone]*nf);
			QQ.resize(cone[fcone]*(cone[fcone]+1)/2);
			QQpiv.resize(cone[fcone]);
		}
		else if(typecone[fcone]==3)//rotated SOCP with quadratic primal
		{
			ns=cone[fcone]-2;
			LL.resize(2*cone[fcone]*nf);
			QQ.resize(cone[fcone]*(cone[fcone]+1)/2);
			QQpiv.resize(cone[fcone]);
		}
		Q.resize((nf+1)*ns);
		Qx.resize(ns);
		factor_model_process(ns,nf,FL,FC,SV,&Q[0]);
	}
	else if(nf==-1)//Full covariance
	{
		for(i=0;i<fcone;++i)
		{
			Qstart+=cone[i];
		}
		if(typecone[fcone]==0)//LP with quadratic primal
		{
			ns=cone[fcone];
		}
		else if(typecone[fcone]==1)//SOCP with quadratic primal
		{
			ns=cone[fcone]-1;
		}
		else if(typecone[fcone]==3)//rotated SOCP with quadratic primal
		{
			ns=cone[fcone]-2;
		}
		QQ.resize(cone[fcone]*(cone[fcone]+1)/2);
		QQpiv.resize(cone[fcone]);
		Qx.resize(ns);
		LL.resize(2*cone[fcone]);//work space
	}
	vector pQx=&Qx[0];
	std::valarray<double>AA(m*m);
	std::valarray<float>AAAA;
#ifdef USE_SINGLE
	AAAA.resize(m*(m+1)>>1);usedouble=false;
#endif
	std::valarray<short_scl>AA_P(m);
	double gap;
	if((ddotvec(nx,x,x)+ddotvec(nx,s,s))<0.5)
	{
		dzerovec(nx,x);
		dzerovec(nx,s);
		dzerovec(m,y);
		*tau=*kappa=1.;
		for(i=0,X=x,S=s;i<ncone;i++)
		{
			if(typecone[i]==1)
			{
				X+=cone[i]-1;
				S+=cone[i]-1;
				*S++=*X++=1;
			}
			else if(typecone[i]==3)
			{
				X+=cone[i]-2;
				S+=cone[i]-2;
				*S++=*X++=lm_rroot2;
				*S++=*X++=lm_rroot2;
			}
			else if(typecone[i]==0)
			{
				for(j=0;j<cone[i];++j)
				{
					*S++=*X++=1;
				}
			}
			else if(typecone[i]==2)
			{
				size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[i]));
				X+=cone[i]-n;
				S+=cone[i]-n;
				for(j=0;j<n;++j)
				{
					*X++=1.;
					*S++=1.;
				}
			}
		}
	}

	if(nf>0)
	{
		facmul_and_inv(ns,nf,&Q[0],x+Qstart,&Qx[0]);
		if(homog)dscalvec(ns,1./ *tau,&Qx[0]);
		futil=.5*ddotvec(ns,x+Qstart,&Qx[0]);
	}
	else if(nf==-1)
	{
		dsmxmulv(ns,FC,x+Qstart,&Qx[0]);
		if(homog)dscalvec(ns,1./ *tau,&Qx[0]);
		futil=.5*ddotvec(ns,x+Qstart,&Qx[0]);
	}
	gap=ddotvec(nx,c,x)-ddotvec(m,b,y)+2*futil;
	double mu,mu0;
	int badcount=0,badtop=200;
	double alphamax=stepmax;
	std::valarray<bool>ysign(2*m);
	size_t worsecount=0;
	bool restart=false,highcondition=false,badtheta=false;
	void* work=0;
	void* workQ=0;
//	if(method==1)
//		InitialiseGen(m,&work);
	double resid=lm_max,residmin=lm_max,compmin=lm_max;
	double rhoP0,rhoD0,rhoG0;

	std::valarray<double>w(nx),xbar(nx),sbar(nx),rD(2+m+2*nx),theta(ncone);
	std::valarray<double>dx(nx),dy(m),ds(nx);
	std::valarray<double>ex(nx),ey(m),es(nx);
	std::valarray<double>xkeep(nx),ykeep(m),skeep(nx);
	double taukeep,kappakeep;
	vector r1,r2,r3,r4,r5;
	double dtau,dkappa,etau,ekappa;

	double beta=1e-8,delta=.5;
	long badcone;
	double gamma=0,alpha=1,alphat=0,comp=10,rhoconv=lm_eps8;//,gapcheck,gapcheckt;
	double rhoDlim=rhoconv,rhoGlim=rhoconv,rhoAlim=rhoconv,rhoPlim=rhoconv;
	size_t maxit=100;
	double rhoD=lm_max,rhoP=lm_max,rhoG=lm_max,rhoA=lm_max;
	short changed=changetodouble;
	while(badcount++<badtop)
	{
		if(log) AddLog(&logprint,(char*)"                                Outer Loop %d\n",badcount);
		double inner;
		rhoP0=0;
		for(i=0;i<m;++i)
		{
			inner=fabs(ddotvec(nx,A+i*nx,x)-(homog?*tau:1)*b[i]);
			//rhoP0+=inner*inner;
			rhoP0=dmax(rhoP0,inner);
		}
		rhoP=rhoP0;//=sqrt(rhoP0);
		rhoG=rhoG0=fabs(-ddotvec(nx,c,x)-futil*2+ddotvec(m,b,y)-(homog?*kappa:0));
		rhoD0=0;
		for(i=0;i<nx;++i)
		{
			inner=BITA_ddot(m,A+i,nx,y,1)+s[i]-(homog?*tau:1)*c[i];
			if(i>=Qstart&&i<Qstart+ns)
				inner-=(homog?*tau:1)*Qx[i-Qstart];
			inner=fabs(inner);
			//rhoD0+=inner*inner;
			rhoD0=dmax(inner,rhoD0);
		}
		rhoD=rhoD0;//=sqrt(rhoD0);

		mu=mu0=(ddotvec(nx,x,s)+(homog?(*tau* *kappa):0))/((double)(Rl+(homog?1:0)));

		r1=&rD[0];
		r2=&rD[m];
		r3=&rD[m+nx];
		r4=&rD[m+nx+1];
		r5=&rD[m+nx*2+1];
		if(!homog)
		{
			*tau=*kappa=*r3=*r5=dtau=dkappa=0;
		}
		double wwcheck;
		wwcheck=ddotvec(nx,x,s);
		if(disnan_BITA(&wwcheck))
			printf((char*)"bad s x initially\n");
		if(!getw_and_theta(nx,ncone,cone,typecone,x,s,&theta[0],&w[0],&xbar[0],&sbar[0])){badtheta=true;break;};
		wwcheck=ddotvec(nx,&w[0],&w[0]);
		if(disnan_BITA(&wwcheck))
			printf((char*)"bad w initially\n");
		if(ns)daddvec(ns,c+Qstart,&Qx[0],c+Qstart);
		makeResid(m,ncone,nx,cone,typecone,c,A,b,x,s,y,&xbar[0],&sbar[0],r1,r2,r3,r4,r5,&ds[0],&dx[0],&dtau,&dkappa,*tau,*kappa,&w[0],&theta[0],mu,0,0,homog);
		if(ns)dsubvec(ns,c+Qstart,&Qx[0],c+Qstart);
		residmin=resid=ddotvec(2+m+2*nx,&rD[0],&rD[0]);
		for(i=0;i<maxit&&((rhoD>rhoDlim||rhoG>rhoGlim||rhoP>rhoPlim)/*&&resid>=lm_eps*/);++i)
		{
			changed=changetodouble;highcondition=false;
			if(log) AddLog(&logprint,(char*)"                                       Inner Loop %d\n",i);
			if(ns)daddvec(ns,c+Qstart,&Qx[0],c+Qstart);
			wwcheck=ddotvec(nx,&w[0],&w[0]);
			if(disnan_BITA(&wwcheck))
				printf((char*)"%d bad w\n",i);
			if(getDirection(true,m,nx,ncone,cone,typecone,c,b,&theta[0],&w[0],A,&AA[0],&AA_P[0],&xbar[0],&sbar[0],r1,r2,r3,r4,r5,&dx[0],&dy[0],&ds[0],&dtau,
				&dkappa,tau,kappa,changetodouble,usedouble,&AAAA[0],highcondition,regularise,&work,&workQ,method,homog,nf,ns,Qstart,(nf>=0?&Q[0]:FC),
				&QQ[0],&LL[0],&QQpiv[0]))
			{
				if(ns)dsubvec(ns,c+Qstart,&Qx[0],c+Qstart);
				if(log) AddLog(&logprint,(char*)"\e[1;34mgetDirection failed\e[0m");
				break;
			}
			if(ns)dsubvec(ns,c+Qstart,&Qx[0],c+Qstart);
			if(highcondition&&log)AddLog(&logprint,(char*)"\e[1;34mUnstable normal equations\e[0m\n");
			alpha=getStepsize(ncone,cone,typecone,nx,x,s,&ds[0],&dx[0],&dtau,&dkappa,*tau,*kappa,mu,0,beta,homog);
			if(disnan_BITA(&alpha))
			{
				if(log) AddLog(&logprint,(char*)"\e[1;34mBad step alpha\e[0m\n");
				gamma=dmin(delta,((1-.05)*(1-.05)))*(1-.05);
			//	break;
			}

			/*printf((char*)"alpha %20.8e\n",alpha);
			printx(nx,x);
			printx(nx,s);
			printx(m,y);
			printx(1,tau);
			printx(1,kappa);*/
			dcopyvec(nx,x,&ex[0]);
			dcopyvec(nx,s,&es[0]);etau=*tau,ekappa=*kappa;
			dcopyvec(m,y,&ey[0]);
			while(!disnan_BITA(&alpha))
			{
				bool again=false;
				daxpyvec(m,alpha,&dy[0],&ey[0]);
				daxpyvec(nx,alpha,&dx[0],&ex[0]);
				daxpyvec(nx,alpha,&ds[0],&es[0]);
				if(homog)
				{
					etau+=alpha* dtau;ekappa+=alpha* dkappa;
				}
				if((badcone=conecheck(ncone,cone,typecone,&ex[0],(futil>0?lm_eps8:0),(homog?etau:1.)))>-1)
				{
					again=true;
				}
				if((badcone=conecheck(ncone,cone,typecone,&es[0],(futil>0?lm_eps8:0),(homog?etau:1.)))>-1)
				{
					again=true;
				}
				/*if(ddotvec(nx,c,&ex[0])-ddotvec(m,b,&ey[0])<-1e-8) STUPID IDEA
				{
					again=true;
				}*/
				if(again)
				{
					daxpyvec(m,-alpha,&dy[0],&ey[0]);
					daxpyvec(nx,-alpha,&dx[0],&ex[0]);
					daxpyvec(nx,-alpha,&ds[0],&es[0]);
					if(homog)
					{
						etau-=alpha* dtau;ekappa-=alpha* dkappa;
					}
					alpha*=.95;
				}
				else break;
				if(alpha<(alphamax*.001))
				{
					gamma=dmin(delta,((1-alpha)*(1-alpha)))*(1-alpha);
					if(log) AddLog(&logprint,(char*)"alpha wants to be too small %e (less than %e?)\n",alpha,alphamax*.001);
					break;
				}
			}
			if(disnan_BITA(&alpha))
			{
				if(log) AddLog(&logprint,(char*)"Bad step alpha\n");
			}
			else
				gamma=dmin(delta,((1-alpha)*(1-alpha)))*(1-alpha);
			
			/*printx(nx,&ex[0]);
			printx(nx,&es[0]);
			printx(m,&ey[0]);
			printx(1,&etau);
			printx(1,&ekappa);*/
			if(ns)daddvec(ns,c+Qstart,&Qx[0],c+Qstart);
			makeResid(m,ncone,nx,cone,typecone,c,A,b,x,s,y,&xbar[0],&sbar[0],r1,r2,r3,r4,r5,&ds[0],&dx[0],&dtau,&dkappa,*tau,*kappa,&w[0],&theta[0],mu,gamma,alpha,homog);
			getDirection(false,m,nx,ncone,cone,typecone,c,b,&theta[0],&w[0],A,&AA[0],&AA_P[0],&xbar[0],&sbar[0],r1,r2,r3,r4,r5,&dx[0],&dy[0],&ds[0],&dtau,
				&dkappa,tau,kappa,changetodouble,usedouble,&AAAA[0],highcondition,regularise,&work,&workQ,method,homog,nf,ns,Qstart,(nf>=0?&Q[0]:FC),
				&QQ[0],&LL[0],&QQpiv[0]);
			if(ns)dsubvec(ns,c+Qstart,&Qx[0],c+Qstart);
			alphat=getStepsize(ncone,cone,typecone,nx,x,s,&ds[0],&dx[0],&dtau,&dkappa,*tau,*kappa,mu,gamma,beta,homog);
			//printf((char*)"alphat %20.8e\n",alphat);
			if(disnan_BITA(&alphat))
			{
				if(log) AddLog(&logprint,(char*)"Bad step alphat\n");
			}

			if(changed==changetodouble||changetodouble==2)
			{
				if((!disnan_BITA(&alpha)&&alphat>alpha)||(!disnan_BITA(&alphat)&&disnan_BITA(&alpha)))
				{		
					while(disnan_BITA(&alpha)||alphat>alpha)
					{
						bool again=false;
						daxpyvec(nx,alphat,&dx[0],x);
						daxpyvec(nx,alphat,&ds[0],s);
						daxpyvec(m,alphat,&dy[0],y);
						if((badcone=conecheck(ncone,cone,typecone,x,(futil>0?lm_eps8:0),(homog?*tau+alphat*dtau:1.)))>-1)
						{
							again=true;
						}
						if((badcone=conecheck(ncone,cone,typecone,s,(futil>0?lm_eps8:0),(homog?*tau+alphat*dtau:1.)))>-1)
						{
							again=true;
						}
						/*if(ddotvec(nx,c,x)-ddotvec(m,b,y)<-1e-8) STUPID IDEA
						{
							again=true;
						}*/
						if(again)
						{
							daxpyvec(m,-alphat,&dy[0],y);
							daxpyvec(nx,-alphat,&dx[0],x);
							daxpyvec(nx,-alphat,&ds[0],s);
							alphat*=.95;
						}
						else break;
						if(alphat<alphamax*.1)
						{
							break;
						}
					}
					if(!disnan_BITA(&alphat)&&alphat>alpha)
					{
						if(homog)
						{
							*tau+=alphat* dtau;
							*kappa+=alphat* dkappa;
						}
		wwcheck=ddotvec(nx,x,s);
		if(disnan_BITA(&wwcheck))
			printf((char*)"bad s x at middle\n");
						if(!getw_and_theta(nx,ncone,cone,typecone,x,s,&theta[0],&w[0],&xbar[0],&sbar[0]))
						{
							dcopyvec(nx,&ex[0],x);
							dcopyvec(nx,&es[0],s);
							dcopyvec(m,&ey[0],y);
							if(homog)
							{
								*tau=etau;
								*kappa=ekappa;
							}
		wwcheck=ddotvec(nx,x,s);
		if(disnan_BITA(&wwcheck))
			printf((char*)"bad s x middle 2\n");
							if(!getw_and_theta(nx,ncone,cone,typecone,x,s,&theta[0],&w[0],&xbar[0],&sbar[0])){badtheta=true;break;};
						}
					}
				}
				if(!disnan_BITA(&alpha)&&!disnan_BITA(&alphat)&&alphat<=alpha)
				{
					dcopyvec(nx,&ex[0],x);
					dcopyvec(nx,&es[0],s);
					dcopyvec(m,&ey[0],y);
					if(homog)
					{
						*tau=etau;
						*kappa=ekappa;
					}
		wwcheck=ddotvec(nx,x,s);
		if(disnan_BITA(&wwcheck))
			printf((char*)"bad s x middle 3\n");
					if(!getw_and_theta(nx,ncone,cone,typecone,x,s,&theta[0],&w[0],&xbar[0],&sbar[0])){badtheta=true;break;};
					//printx(ncone,&theta[0]);
				}
			}
			if(nf>0)
			{
				facmul_and_inv(ns,nf,&Q[0],x+Qstart,&Qx[0]);
				if(homog)dscalvec(ns,1./ *tau,&Qx[0]);
				futil=.5*ddotvec(ns,&Qx[0],x+Qstart);
			}
			else if(nf==-1)
			{
				dsmxmulv(ns,FC,x+Qstart,&Qx[0]);
				if(homog)dscalvec(ns,1./ *tau,&Qx[0]);
				futil=.5*ddotvec(ns,x+Qstart,&Qx[0]);
			}
			/*printx(nx,x);
			printx(nx,s);
			printx(m,y);
			printx(1,tau);
			printx(1,kappa);
			printx(ncone,&theta[0]);
			printx(nx,&w[0]);*/
			if(ns)daddvec(ns,c+Qstart,&Qx[0],c+Qstart);
			makeResid(m,ncone,nx,cone,typecone,c,A,b,x,s,y,&xbar[0],&sbar[0],r1,r2,r3,r4,r5,&ds[0],&dx[0],&dtau,&dkappa,*tau,*kappa,&w[0],&theta[0],mu,0,0,homog);
			if(ns)dsubvec(ns,c+Qstart,&Qx[0],c+Qstart);
			resid=ddotvec(2+m+2*nx,&rD[0],&rD[0]);
			if(disnan_BITA(&resid))
				exit(23);
			if(homog)gap=(ddotvec(nx,c,x)-ddotvec(m,b,y)+2*futil) /* / *tau*/ ;
			else gap=(ddotvec(nx,c,x)-ddotvec(m,b,y)+2*futil);
			comp=ddotvec(nx,s,x)+*tau* *kappa;
			if(disnan_BITA(&comp)||disnan_BITA(&gap))
			{
				if(log) AddLog(&logprint,(char*)"Bad comp or gap\n");break;
			}
			memmove(&ysign[m],&ysign[0],m*sizeof(bool));
			signset(m,y,&ysign[0]);
			differentsigns=signcheck(m,&ysign[0],&ysign[m]);
			if(/*resid<residmin&&*/comp<compmin)
			{
				dcopyvec(nx,x,&xkeep[0]);
				dcopyvec(nx,s,&skeep[0]);
				dcopyvec(m,y,&ykeep[0]);
				if(homog)
				{
					taukeep=*tau;
					kappakeep=*kappa;
				}
				worsecount=0;
			}
			else
				residmin=dmin(resid,residmin);
			compmin=dmin(comp,compmin);
			if(homog)mu=(ddotvec(nx,x,s)+*tau* *kappa)/(Rl+1);
			else mu=ddotvec(nx,x,s)/Rl;
			for(j=0,rhoP=0;j<m;++j)
			{
				inner=fabs(ddotvec(nx,A+j*nx,x)-(homog?*tau:1)*b[j]);
				//rhoP+=inner*inner;
				rhoP=dmax(inner,rhoP);
			}
			//rhoP=sqrt(rhoP);
			if(restart)rhoP0=rhoP;
			rhoP/=rhoP0;
			for(j=0,rhoD=0;j<nx;++j)
			{
				inner=BITA_ddot(m,A+j,nx,y,1)+s[j]-(homog?*tau:1)*c[j];
				if(j>=Qstart&&j<Qstart+ns)
					inner-=(homog?*tau:1)*Qx[j-Qstart];
				inner=fabs(inner);
				//rhoD+=inner*inner;
				rhoD=dmax(inner,rhoD);
			}
			//rhoD=sqrt(rhoD);
			if(restart)rhoD0=rhoD;
			rhoD/=rhoD0;
			rhoG=fabs(-ddotvec(nx,c,x)-futil*2+ddotvec(m,b,y)-(homog?*kappa:0));
			if(restart)rhoG0=rhoG;
			if(restart)mu0=mu;
			rhoG/=rhoG0;
			restart=false;
			rhoA=fabs(ddotvec(nx,c,x)-ddotvec(m,b,y)+futil*2)/
				(homog?*tau:0+fabs(ddotvec(m,b,y)));
			if(log)
			{
				AddLog(&logprint,(char*)"Complementarity         \t\t\t%20.12f\n",comp);
				AddLog(&logprint,(char*)"Primal dual gap         \t\t\t%20.12f\n",gap);
				AddLog(&logprint,(char*)"relative primal residual\t\t\t%20.12f(%20.12f)\n",rhoP,rhoP*rhoP0/m);
				AddLog(&logprint,(char*)"relative dual residual\t\t\t\t%20.12f(%20.12f)\n",rhoD,rhoD*rhoD0/nx);
				if(homog)AddLog(&logprint,(char*)"relative gap residual\t\t\t\t%20.12f(%20.12f)\n",rhoG,rhoG*rhoG0);
				if(homog)AddLog(&logprint,(char*)"relative complementarity residual\t\t%20.12f\n",rhoA);
				AddLog(&logprint,(char*)"mu/(first mu)\t\t\t\t\t%20.12f(%20.12f)\n",mu/mu0,mu);
				if(homog)AddLog(&logprint,(char*)"tau/kappa\t\t\t\t\t%20.12e\n",*tau/ *kappa);
				AddLog(&logprint,(char*)"\t\t\t\t\t\t(steps %f %f)\n",alpha,alphat);
			}
			if(fastbreak&&ratiotest(rhoP,rhoD,rhoG,mu/mu0,log,logprint)&&((homog&&*tau/ *kappa>1e6)||!homog))break;
			if(comp <=comptoll&&fabs(gap)<=gaptoll/*&&resid<lm_rooteps*/)break;
			if(!fastbreak&&dmax(alphat,alpha)<alphamax)break;//Not sure if we want to do this if fastbreak is true
			if(comp<=comptoll&&homog&&(*tau/ *kappa)<100)break;
			if(nf&&homog&&((*tau/ *kappa>1e6)/*&&fabs(gap)<1e-3*/&&comp<1e-3&&resid<1e-3||i>50))
			{//It looks like the homogenous method will be slow, but the problem seems feasible!
				dscalvec(nx,1./ *tau,x);
				dscalvec(nx,1./ *tau,s);
				dscalvec(m,1./ *tau,y);
				*tau=1;
				if(*kappa>1e-12)homog=0;
				*kappa=lm_eps8;
			}

			if(changetodouble&&!usedouble)
			{
				if(log) AddLog(&logprint,(char*)"Use double precision solver in next iteration\n");
			}
			if(!(rhoD>rhoDlim||rhoG>rhoGlim||rhoP>rhoPlim||rhoA>rhoAlim))
			{
				if(log) AddLog(&logprint,(char*)"gap cgap %20.8e\n",gap);
				if(log) AddLog(&logprint,(char*)"comp ccomp %20.8e \n",comp);
				if(log) AddLog(&logprint,(char*)"rhoD rhoDlim %20.8e %20.8e\n",rhoD,rhoDlim);
				if(log&&homog) AddLog(&logprint,(char*)"rhoG rhoGlim %20.8e %20.8e\n",rhoG,rhoGlim);
				if(log) AddLog(&logprint,(char*)"rhoP rhoPlim %20.8e %20.8e\n",rhoP,rhoPlim);
				if(log&&homog) AddLog(&logprint,(char*)"rhoA rhoAlim %20.8e %20.8e\n",rhoA,rhoAlim);
				if(log) AddLog(&logprint,(char*)"rmu  mu0     %20.8e %20.8e\n",mu/mu0,mu0);
			}
		}
		if(nf>0)
		{
			facmul_and_inv(ns,nf,&Q[0],x+Qstart,&Qx[0]);
			if(homog)dscalvec(ns,1./ *tau,&Qx[0]);
			futil=.5*ddotvec(ns,x+Qstart,&Qx[0]);
		}
		else if(nf==-1)
		{
			dsmxmulv(ns,FC,x+Qstart,&Qx[0]);
			if(homog)dscalvec(ns,1./ *tau,&Qx[0]);
			futil=.5*ddotvec(ns,x+Qstart,&Qx[0]);
		}
		gap=(ddotvec(nx,c,x)-ddotvec(m,b,y)+2*futil)/*/(homog? *tau:1)*/;
		comp=ddotvec(nx,s,x)+(homog?*tau* *kappa:0);
		if(log) AddLog(&logprint,(char*)"(Gap %20.12e Complementarity %20.12e)\n",gap ,comp);
		if(disnan_BITA(&comp)||disnan_BITA(&gap)||badtheta)
		{
			if(log) AddLog(&logprint,(char*)"Fix up for nan in comp or gap or bad theta\n");
			dcopyvec(nx,&xkeep[0],x);
			dcopyvec(nx,&skeep[0],s);
			dcopyvec(m,&ykeep[0],y);
			*tau=taukeep;
			*kappa=kappakeep;
			if(nf>0)
			{
				facmul_and_inv(ns,nf,&Q[0],x+Qstart,&Qx[0]);
				if(homog)dscalvec(ns,1./ *tau,&Qx[0]);
				futil=.5*ddotvec(ns,x+Qstart,&Qx[0]);
			}
			else if(nf==-1)
			{
				dsmxmulv(ns,FC,x+Qstart,&Qx[0]);
				if(homog)dscalvec(ns,1./ *tau,&Qx[0]);
				futil=.5*ddotvec(ns,x+Qstart,&Qx[0]);
			}
			gap=(ddotvec(nx,c,x)-ddotvec(m,b,y)+2*futil)/*/(homog? *tau:1)*/;
			comp=ddotvec(nx,s,x)+(homog?*tau* *kappa:0);
			alpha=1;
		}
		if((dmax(alphat,alpha)<alphamax&&(/*rhoD>rhoDlim*rhoD0||(homog&&(rhoG>rhoGlim*rhoG0))||rhoP>rhoPlim*rhoP0||*/comp>comptoll||fabs(gap)>gaptoll))&&(homog?*tau/ *kappa>1e-4:true)&&(fabs(1-fabs(gap)/fabs(gaptoll))>1e-1||fabs(1-fabs(comp)/fabs(comptoll))>1e-1))
		{
			/*If comp and gap are large when alpha has become small maybe the tolerances are too small*/
		//	if(fabs(1-fabs(gap)/fabs(gaptoll))>1e-1){gaptoll*=1.1;gaptoll=small_round(gaptoll);}
		//	if(fabs(1-fabs(comp)/fabs(comptoll))>1e-1){comptoll*=1.1;comptoll=small_round(comptoll);}
			if(log)AddLog(&logprint,(char*)"SOCP optimisation steps %20.12e\n",dmax(alphat,alpha));
//			conecheck(ncone,cone,typecone,x);
//			conecheck(ncone,cone,typecone,s);
			if(homog)
			{
				dscalvec(nx,1./ *tau,s);//Rescale to make tau 1
				dscalvec(nx,1./ *tau,x);
				dscalvec(m,1./ *tau,y);
				*kappa/=*tau;
				*tau=1;
			}
			else
			{
				*tau=0;
			}
//			conecheck(ncone,cone,typecone,x);
//			conecheck(ncone,cone,typecone,s);
			if(nf>0)
			{
				facmul_and_inv(ns,nf,&Q[0],x+Qstart,&Qx[0]);
				if(homog)dscalvec(ns,1./ *tau,&Qx[0]);
				futil=.5*ddotvec(ns,x+Qstart,&Qx[0]);
			}
			else if(nf==-1)
			{
				dsmxmulv(ns,FC,x+Qstart,&Qx[0]);
				if(homog)dscalvec(ns,1./ *tau,&Qx[0]);
				futil=.5*ddotvec(ns,x+Qstart,&Qx[0]);
			}
			gap=ddotvec(nx,c,x)-ddotvec(m,b,y)+2*futil;
			double oldmu=mu,ext=sqrt((1-dmax(alphat,alpha))*lmod(nx,x)*lmod(nx,s))/nx;
			vector pxx,pss;
			size_t i;
			if(!homog||(fabs(gap)>1e-3&&comp>1e-3)||dmax(alphat,alpha)<1e-4)
			{
				if(futil>0)ext=0;
				if(ext<=0)ext=1e-1;
				if(log) AddLog(&logprint,(char*)"ext for restart %f\n",ext);
				double extP=ext,extD=ext;
				//if(rhoP<=rhoD)extD=0;
				//else extP=0;
				for(i=0,pxx=x,pss=s;i<ncone;pxx+=cone[i],pss+=cone[i],i++)
				{
					if(typecone[i]==0)
					{
						for(j=0;j<cone[i];++j)
						{
							pxx[j]+=extP;
							pss[j]+=extD;
						}
					}
					else if(typecone[i]==1)
					{
						pxx[cone[i]-1]+=extP;
						pss[cone[i]-1]+=extD;
					}
					else if(typecone[i]==3)
					{
						pxx[cone[i]-2]+=extP*lm_rroot2;
						pss[cone[i]-2]+=extD*lm_rroot2;
						pxx[cone[i]-1]+=extP*lm_rroot2;
						pss[cone[i]-1]+=extD*lm_rroot2;
					}
					else if(typecone[i]==2)
					{
						size_t n=(size_t)(-0.25+.5*sqrt(1.0+8.0*cone[i]));
						double exthP=extP/n;
						double exthD=extD/n;
						for(j=0;j<n;++j)
						{
							pxx[cone[i]-n+j]+=exthP;
							pss[cone[i]-n+j]+=exthD;
						}
					}
				}
			}
			mu=ddotvec(nx,x,s)/Rl;
			if(homog)
			{
				*tau=1;
				*kappa=mu;//lm_eps8;
			}
			if(nf>0)
			{
				facmul_and_inv(ns,nf,&Q[0],x+Qstart,&Qx[0]);
				if(homog)dscalvec(ns,1./ *tau,&Qx[0]);
				futil=.5*ddotvec(ns,x+Qstart,&Qx[0]);
			}
			else if(nf==-1)
			{
				dsmxmulv(ns,FC,x+Qstart,&Qx[0]);
				if(homog)dscalvec(ns,1./ *tau,&Qx[0]);
				futil=.5*ddotvec(ns,x+Qstart,&Qx[0]);
			}
			gap=ddotvec(nx,c,x)-ddotvec(m,b,y)+2*futil;
			if(gap < 0)
			{
				double dl=ddotvec(m,b,y);
				dsetvec(m,1,y);
				double dgap=-ddotvec(m,b,y)+dl;
				double step=-gap/dgap;
				if(!disnan_BITA(&step))
					dsetvec(m,(1+lm_rooteps)*step,y);
				gap=(ddotvec(nx,c,x)-ddotvec(m,b,y)+2*futil);
			}
			/*mu=(ddotvec(nx,x,s)+*tau* *kappa)/(Rl+1);
			dscalvec(nx,gap/mu,s);
			*kappa *= (gap/mu);*/
/*			if(mu>oldmu&&oldmu>lm_rooteps)
			{
				double pp=sqrt(oldmu/mu);
				dscalvec(nx,pp,x);
				dscalvec(nx,pp,s);
				dscalvec(m,pp,y);
				if(homog)
				{
					*tau*=pp;
					*kappa*=pp;
					dscalvec(nx,1./ *tau,s);
					dscalvec(nx,1./ *tau,x);
					dscalvec(m,1./ *tau,y);
					*tau=1;
				}
				if(nf>0)
				{
					facmul_and_inv(ns,nf,&Q[0],x+Qstart,&Qx[0]);
					if(homog)dscalvec(ns,1./ *tau,&Qx[0]);
					futil=.5*ddotvec(ns,x+Qstart,&Qx[0]);
				}
				else if(nf==-1)
				{
					dsmxmulv(ns,FC,x+Qstart,&Qx[0]);
					if(homog)dscalvec(ns,1./ *tau,&Qx[0]);
					futil=.5*ddotvec(ns,x+Qstart,&Qx[0]);
				}
				gap=(ddotvec(nx,c,x)-ddotvec(m,b,y)+2*futil)/ (homog?*tau:1);
				mu=(ddotvec(nx,x,s)+(homog?*tau* *kappa:0))/(Rl+homog?1:0);
			}*/
			comp=ddotvec(nx,s,x);
			//if(gap>comp)*kappa=gap-comp;
			restart=true;
#ifdef USE_SINGLE
			usedouble=false;
			changetodouble=0;
#endif
		}
		else
		{
			if(outfile)
			{
				PrintLog(&logprint,&outFile);
				outFile.close();
			}
			else
				PrintLog(&logprint);
			if(method==1)
				DeleteGen(&work);
			else if(method==2)
				DeleteSymm(&work);
			if(workQ)DeleteGen(&workQ);
			if(!homog||(*tau==0&&*kappa==0))
			{
				*tau=1,*kappa=lm_eps8;
			}
			if(i==maxit||(*tau>*kappa&&comp>comptoll))return 1;
			return 0;
		}
	}
	if(badcount>=badtop||disnan_BITA(&comp)||disnan_BITA(&gap)||badtheta)
	{
		dcopyvec(nx,&xkeep[0],x);
		dcopyvec(nx,&skeep[0],s);
		dcopyvec(m,&ykeep[0],y);
		*tau=taukeep;
		*kappa=kappakeep;
	}
	if(outfile)
	{
		PrintLog(&logprint,&outFile);
		outFile.close();
	}
	else
		PrintLog(&logprint);
	if(method==1)
		DeleteGen(&work);
	else if(method==2)
		DeleteSymm(&work);
	
	if(workQ)DeleteGen(&workQ);
				
	if(!homog||(*tau==0&&*kappa==0))
	{
		*tau=1,*kappa=lm_eps8;
	}
	if(badcount>=badtop||badtheta)
		return 1;
	return 0;
}

extern "C" DLLEXPORT void Qwi2M(size_t n,size_t i,vector Qw,vector M)
{
	//Add the vector Qw at the i'th position in symmetric packed matrix M. (lead up to SDPsymm2MCAR etc.)
	size_t j,ii=(i*(i+1)>>1),jj;
	M[ii+i]+=Qw[i];
	daxpyvec(i,1,Qw,M+ii);
	for(j=i+1,jj=ii+i+1;j<n;j++,jj+=j)
		M[jj + i]+=Qw[j];
}

extern "C" DLLEXPORT void SDPsymm2MCAR(size_t n,size_t nc,vector Q,vector A)
{
	/* Q is a covariance matrix in packed form
	   A is an SDP constraint to contrain w[nC]*MCAR[nC] off-diags, need root2 factor for svec and .5 to get trace correct hence lm_rroot2
	   Q should have dimension n*(n+1)/2
	   A should have dimension (n+1)*(n+2)/2
	   assumes A is initialised.
	   */
	size_t i,nn=n*(n+1)>>1,nd=nc*(nc+3)>>1;
	vector Qs,As;

	A[nn+nc]+=Q[nd];
	for(i=0,Qs=Q+(nc*(nc+1)>>1),As=A+(nc-1)*nc/2;i<nc;++i,As++,Qs++)
	{
		*As+=*Qs * lm_rroot2;
	}
	As=A+nd;
	for(i=nc+1,Qs=Q+nd+nc+1;i<n;As+=i,++i,Qs+=i)
	{
		*As+=*Qs * lm_rroot2;
	}
}
extern "C" DLLEXPORT void SDPwsymm2MCAR(size_t n,size_t nc,double wc,vector Q,vector A)
{
	/*Weight the input covariances by wc,then do SDPsymm2MCAR. This would allow easy setting up of factor risk budgetting, for
	sector risk budgetting the value of wc would be 1
	*/
	size_t i,nn=n*(n+1)>>1,nd=nc*(nc+3)>>1;
	vector Qs,As;

	A[nn+nc]+=wc*Q[nd];
	wc*=lm_rroot2;
	for(i=0,Qs=Q+(nc*(nc+1)>>1),As=A+(nc-1)*nc/2;i<nc;++i,As++,Qs++)
	{
		*As+=wc* *Qs;
	}
	As=A+nd;
	for(i=nc+1,Qs=Q+nd+nc+1;i<n;As+=i,++i,Qs+=i)
	{
		*As+=wc* *Qs;
	}
}

extern "C" DLLEXPORT void SDPvec2MCAR(size_t n,size_t nc,vector Qnci,vector A)
{
	/*Another way to get the constraint matrix for the w[nC]*MCAR[nC] off-diags is to just pass in the relevent row of Q in Qnci. This
	can be found from Q*unit vector i.e. don't need to have the whole of Q stored.
	*/
	size_t i,nn=n*(n+1)>>1,nd=nc*(nc+3)/2;
	vector As;
	A[nn+nc]+=Qnci[nc];
	for(i=0,As=A+(nc-1)*nc/2;i<nc;As++,i++,Qnci++)
		*As+=*Qnci * lm_rroot2;
	As=A+nd;
	Qnci++;
	for(i=nc+1;i<n;As+=i,++i,Qnci++)
		*As+=*Qnci * lm_rroot2;
}


extern "C" DLLEXPORT short RiskParityOpt(dimen n,dimen nsect,long nf,vector w,vector alpha,
										 vector sectors,vector SV,vector FC,vector FL,double*conc,double*lambda,int longonly=0,
										 int*rank=0,int do_parity=1,int fastbreak=0,int link_extra=0,int alpha_extra=0,double*sos_check=0,double budget=1)
{
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	size_t nn=(n+1)*(n+2)/2,i,j,riskno=-1,concno=-1,alpha_checkno=-1;
	vector H;
	std::valarray<double>pH,Qw(n),space((n+1)*(n+1));
	double RiskConc=-1;

	bool parity2=(do_parity==2?true:false);
	bool parity3=(do_parity==3?true:false);
	if(parity3)do_parity=0;

	if(*lambda<0)
	{
		RiskConc=-*lambda;
		*lambda=0;
	}

	if(nf==-1)
	{
		H=FC;
	}
	else
	{
		pH.resize(n*(nf+1));
		H=&pH[0];
		factor_model_process(n,nf,FL,FC,SV,H);
	}

	/* 
	1 semi-def cone,nsect  SO cones (do_parity=1) OR nsect LP cones (do_parity=2), 1 lp cone
	Constraints

    SDP on n+1 order semi-def matrices (want rank 1 so as to link order 2 and order 1 variables)
	1 to make last entry 1 (for rank 1)
	2 for budget
	1 for concentration equality extra 1 for <=

    second order cone (do_parity=1) OR LP cone (do_parity=2) (SO cones allow |risk budget| constraint LP cones allow (risk budget) constraint)
	nsect risk budget constraints

	extra linking constraints to try to enforce the rank one condition makes the problem huge and slow
	need a further n in LP cone for long only variables

	alpha_extra, use a rotated second order cone to impose
	(alpha.w)**2   < 2 * 0.5 * w.(alpha alpha).w
	hopefully to make the semi-def cone have rank 1

	if budget is 0, then we must have that sum abs(xi) = 1. Do this with n SOCs of dimension 2, linking with the inside variables and making the sum of the top variables 2
	*/

	size_t n_link=0;
	switch(link_extra)//-1<=xi<=1 so (1+xi)(1+xj)>=0 and xi*xi<=1 So xi+xj+Xij>=-1 (n*(n-1)/2 constraints) and Xii<=1 (n constraints)
	{
	case 1://for Xii<=1
		n_link+=n;
		break;
	case 2://for xi+xj+Xij >= -1
		n_link+=n*(n-1)/2;
		break;
	case 3://for xi+xj+Xij >= -1 and Xii<=1
		n_link+=n*(n+1)/2;
		break;
	default:
		break;
	}

	size_t ncone=1+(do_parity?nsect:0)+(longonly?1:0)+(*conc<3?1:0)+(RiskConc>0?1:0)+n_link+(alpha_extra?1:0)+(budget==0?n:0),nx=nn,m=3;

	std::valarray<int>cone(ncone),typecone(ncone);
	cone[0]=nn;
	typecone[0]=2;
	if(parity3)
		m+=nsect-1;
	if(do_parity)
	{
		for(i=0;i<nsect;++i)
		{
			if(do_parity==1)
			{
				cone[i+1]=2;
				typecone[i+1]=1;
				nx+=2;
			}
			else if(do_parity==2)
			{
				cone[i+1]=1;
				typecone[i+1]=0;
				nx++;
			}
		}
		if(RiskConc>0&&do_parity==2)
			m+=nsect;
		else
			m+=nsect*2;
	}
	if(*conc<3)//Make the concentration constraint <= rather than ==, needs extra LP cone of length 1 to give the slack variable
	{
		cone[(do_parity?nsect:0)+1]=1;
		typecone[(do_parity?nsect:0)+1]=0;
		m++;
		nx++;
	}

	if(RiskConc>0)//Make the risk constraint <= rather than ==, needs extra LP cone of length 1 to give the slack variable
	{
		cone[(do_parity?nsect:0)+(*conc<3?1:0)+1]=1;
		typecone[(do_parity?nsect:0)+(*conc<3?1:0)+1]=0;
		m++;
		nx++;
	}

	if(link_extra)
	{
		for(i=0;i<n_link;++i)
		{
			cone[1+(do_parity?nsect:0)+(*conc<3?1:0)+(RiskConc>0?1:0)+i]=1;
			typecone[1+(do_parity?nsect:0)+(*conc<3?1:0)+(RiskConc>0?1:0)+i]=0;
			m++;
			nx++;
		}
	}


	if(longonly)
	{
		m+=n*(n+1)/2;
		cone[1+(do_parity?nsect:0)+(*conc<3?1:0)+(RiskConc>0?1:0)+n_link]=n*(n+1)/2;
		typecone[1+(do_parity?nsect:0)+(*conc<3?1:0)+(RiskConc>0?1:0)+n_link]=0;
		nx+=n*(n+1)/2;
	}

	if(alpha_extra)
	{
		m+=3;
		cone[1+(do_parity?nsect:0)+(*conc<3?1:0)+(RiskConc>0?1:0)+n_link+(longonly?1:0)]=3;
		typecone[1+(do_parity?nsect:0)+(*conc<3?1:0)+(RiskConc>0?1:0)+n_link+(longonly?1:0)]=3;
		nx+=3;
	}

	if(budget==0)
	{
		m+=1;
		for(i=0;i<n;++i)
		{
			cone[1+(do_parity?nsect:0)+(*conc<3?1:0)+(RiskConc>0?1:0)+n_link+(longonly?1:0)+(alpha_extra?1:0)+i]=2;
			typecone[1+(do_parity?nsect:0)+(*conc<3?1:0)+(RiskConc>0?1:0)+n_link+(longonly?1:0)+(alpha_extra?1:0)+i]=1;
			m+=1;
			nx+=2;
		}
	}
	std::valarray<double>c(nx),A(nx*m),b(m),x(nx),y(m),s(nx);
	vector Anow=&A[0];
	double wc;
	size_t cnow=0;

	//Constraints
	//Rank 1 
	dzerovec(nx,Anow);
	Anow[nn-1]=1;
	b[cnow]=1;
	cnow++;
	Anow+=nx;

	//Budget 1 sum(x)=1
	dzerovec(nx,Anow);
	space=0;
	dsetvec(n,1,&space[nn-n-1]);
	packed2symm(n+1,&space[0]);
	SDPsvec(n+1,&space[0],Anow);
	b[cnow]=budget*2;
	cnow++;
	Anow+=nx;

	//Budget 2 sum(x)*sum(x)=1
	dzerovec(nx,Anow);
	space=0;
	dsetvec(n*(n+1)/2,1,&space[0]);
	packed2symm(n+1,&space[0]);
	SDPsvec(n+1,&space[0],Anow);
	b[cnow]=budget;
	cnow++;
	Anow+=nx;
	
	if(*conc<3)//Concentration constraint
	{
		dzerovec(nx,Anow);
		dsetvec(n,1,Anow+nn-n-1);
		Anow[nn+(do_parity?(parity2?nsect:2*nsect):0)]=1;//slack part to make concentration a <= constraint
		b[cnow]=*conc;
		concno=cnow;
		cnow++;
		Anow+=nx;
	}

	if(RiskConc>0)//Risk Constraint
	{
		space=0;
		if(nf==-1)
		{
			dcopyvec(n*(n+1)/2,FC,&space[0]);
		}
		else
		{
			Factor2Cov(n,nf,FC,FL,SV,&space[0]);
		}

		packed2symm(n+1,&space[0]);
		dzerovec(nx,Anow);
		SDPsvec(n+1,&space[0],Anow);
		Anow[nn+(do_parity?(parity2?nsect:2*nsect):0)+(*conc<3?1:0)]=(budget==0?0:1);//slack part to make risk a <= constraint. If hedging we want the risk at the top end so no slack
		b[cnow]=RiskConc*RiskConc;
		riskno=cnow;
		cnow++;
		Anow+=nx;
	}
	if(link_extra)//For -1<=xi<=1 (1+xi)*(1+xj)>=0 i.e. 1+xi+xj+Xij>=0 this provides more linking constraints, also Xii<=1
	{
		size_t ij=0;
		if(link_extra==1||link_extra==3)
		{
			for(i=0;i<n;++i)//Xii<=1
			{
				space=0;
				space[i*(i+3)/2]=1;//Xii
				packed2symm(n+1,&space[0]);
				dzerovec(nx,Anow);
				SDPsvec(n+1,&space[0],Anow);
				Anow[nn+(do_parity?(parity2?nsect:2*nsect):0)+(*conc<3?1:0)+(RiskConc>0?1:0)+ij]=1;//slack part to make a <= constraint
				b[cnow]=1;
				cnow++;
				Anow+=nx;
				ij++;
			}
		}
		if(link_extra==2||link_extra==3)
		{
			for(i=1;i<n;++i)//xi+xj+Xij>=-1
			{
				for(j=0;j<i;++j)
				{
					space=0;
					space[n*(n+1)/2+i]=1;//2xi
					space[n*(n+1)/2+j]=1;//2xj
					space[i*(i+1)/2+j]=1;//2Xij
					packed2symm(n+1,&space[0]);
					dzerovec(nx,Anow);
					SDPsvec(n+1,&space[0],Anow);
					Anow[nn+(do_parity?(parity2?nsect:2*nsect):0)+(*conc<3?1:0)+(RiskConc>0?1:0)+ij]=-1;//slack part to make a >= constraint
					b[cnow]=-2;
					cnow++;
					Anow+=nx;
					ij++;
				}
			}
		}
	}
	if(parity3)
	{
		space=0;
		if(nf==-1)
		{
			dcopyvec(n*(n+1)/2,FC,&space[0]);
		}
		else
		{
			Factor2Cov(n,nf,FC,FL,SV,&space[0]);
		}

		packed2symm(n+1,&space[0]);
		for(i=0;i<nsect-1;++i)//risk budget costraint wants all MCTR*w to be the same (total risk over nsect)
		{
			dzerovec(nx,Anow);
			SDPsvec(n+1,&space[0],Anow);
			dscalvec(nn,-1.0/((double) nsect),Anow);//Anow holds -covariance matrix/nsect
			if(sectors)
			{
				for(j=0;j<n;++j)
				{
					dzerovec(n,w);
					if((wc=sectors[i*n+j]))
					{
						w[j]=wc;
						if(nf==-1)
							dsmxmulv(n,H,w,&Qw[0]);
						else
							facmulold(n,nf,H,w,&Qw[0]);
						w[j]=0;
						SDPvec2MCAR(n,j,&Qw[0],Anow);
					}
				}
			}
			else
			{
				dzerovec(n,w);w[i]=1;
				if(nf==-1)
					dsmxmulv(n,H,w,&Qw[0]);
				else
					facmulold(n,nf,H,w,&Qw[0]);
				SDPvec2MCAR(n,i,&Qw[0],Anow);
			}
			b[cnow]=0;
			cnow++;
			Anow+=nx;
		}
	}
	if(do_parity)
	{
		space=0;
		if(nf==-1)
		{
			dcopyvec(n*(n+1)/2,FC,&space[0]);
		}
		else
		{
			Factor2Cov(n,nf,FC,FL,SV,&space[0]);
		}

		packed2symm(n+1,&space[0]);

		for(i=0;i<nsect;++i)//risk budget costraint wants all MCTR*w to be the same (total risk over nsect)
		{
			dzerovec(nx,Anow);
			if(sectors)
			{
				for(j=0;j<n;++j)
				{
					dzerovec(n,w);
					if((wc=sectors[i*n+j]))
					{
						w[j]=wc;
						if(nf==-1)
							dsmxmulv(n,H,w,&Qw[0]);
						else
							facmulold(n,nf,H,w,&Qw[0]);
						w[j]=0;
						SDPvec2MCAR(n,j,&Qw[0],Anow);
					}
				}
			}
			else
			{
				dzerovec(n,w);w[i]=1;
				if(nf==-1)
					dsmxmulv(n,H,w,&Qw[0]);
				else
					facmulold(n,nf,H,w,&Qw[0]);
				SDPvec2MCAR(n,i,&Qw[0],Anow);
			}
			if(!parity2 || !(RiskConc>0))
			{
				Anow[nn+(parity2?i:(i*2))]=(parity2?-1./nsect:1./nsect);
				b[cnow]=0;
				cnow++;
				Anow+=nx;
				dzerovec(nx,Anow);
				SDPsvec(n+1,&space[0],Anow);
				Anow[nn+(parity2?i:(i*2+1))]=-1;
				b[cnow]=0;
				cnow++;
				Anow+=nx;
			}
			else//Since we know know what the risk should be we can just set up a less than constraint for the risk in each sector
			{
				Anow[nn+i]=1;
				b[cnow]=RiskConc*RiskConc/nsect;
				cnow++;
				Anow+=nx;
			}
		}
	}
	if(longonly)
	{
		size_t ij;
		for(i=0,ij=0;i<n;++i)
		{
			for(j=0;j<=i;++j)
			{
				dzerovec(nx,Anow);
				space=0;
				if(i==j)
					space[nn-n-1+i]=1;
				else
					space[ij]=1;
				packed2symm(n+1,&space[0]);
				SDPsvec(n+1,&space[0],Anow);
				Anow[nn+(do_parity?(parity2?nsect:2*nsect):0)+(*conc<3?1:0)+(RiskConc>0?1:0)+n_link+ij]=-1;
				b[cnow]=0;
				cnow++;
				Anow+=nx;
				ij++;
			}
		}
	}
	if(alpha_extra)
	{
		dzerovec(nx,Anow);
		space=0;
		dcopyvec(n,alpha,&space[nn-n-1]);
		packed2symm(n+1,&space[0]);
		SDPsvec(n+1,&space[0],Anow);
		Anow[nn+(do_parity?(parity2?nsect:2*nsect):0)+(*conc<3?1:0)+(RiskConc>0?1:0)+n_link+(longonly?n*(n+1)/2:0)]=-2;
		b[cnow]=0;
		alpha_checkno=cnow;
		cnow++;
		Anow+=nx;

		dzerovec(nx,Anow);
		Anow[nn+(do_parity?(parity2?nsect:2*nsect):0)+(*conc<3?1:0)+(RiskConc>0?1:0)+n_link+(longonly?n*(n+1)/2:0)+1]=1;
		b[cnow]=.5;
		cnow++;
		Anow+=nx;

		dzerovec(nx,Anow);
		space=0;
		for(i=0,j=0;i<n;++i)//alpha'*alpha
		{
			daxpyvec(i+1,alpha[i],alpha,&space[j]);
			j+=(i+1);
		}
		packed2symm(n+1,&space[0]);
		SDPsvec(n+1,&space[0],Anow);
		Anow[nn+(do_parity?(parity2?nsect:2*nsect):0)+(*conc<3?1:0)+(RiskConc>0?1:0)+n_link+(longonly?n*(n+1)/2:0)+2]=-1;
		b[cnow]=0;
		cnow++;
		Anow+=nx;
	}
	if(budget==0)
	{
		for(i=0;i<n;++i)
		{
			dzerovec(nx,Anow);
			space=0;
			space[nn-n-1+i]=1;
			packed2symm(n+1,&space[0]);
			SDPsvec(n+1,&space[0],Anow);
			Anow[nn+(do_parity?(parity2?nsect:2*nsect):0)+(*conc<3?1:0)+(RiskConc>0?1:0)+n_link+(longonly?n*(n+1)/2:0)+(alpha_extra?3:0)+2*i]=-2;
			b[cnow]=0;
			cnow++;
			Anow+=nx;
		}
		dzerovec(nx,Anow);
		dset(n,1,Anow+nn+(do_parity?(parity2?nsect:2*nsect):0)+(*conc<3?1:0)+(RiskConc>0?1:0)+n_link+(longonly?n*(n+1)/2:0)+(alpha_extra?3:0)+1,2);
		b[cnow]=2;
		cnow++;
		Anow+=nx;
	}
	if(*lambda)
	{
		space=0;
		if(nf==-1)
		{
			dcopyvec(n*(n+1)/2,FC,&space[0]);
		}
		else
		{
			Factor2Cov(n,nf,FC,FL,SV,&space[0]);
		}
		packed2symm(n+1,&space[0]);
		symm2packed(n+1,&space[0]);
		dzerovec(n*(n-3)/2+1,&space[n*(n+1)/2]);
		daxpyvec(n,-1./ *lambda,alpha,&space[n*(n+1)/2]);//This means we minimise U=-2*return+lambda*variance
	}
	else
	{
		dzerovec(nn,&space[0]);
		daxpyvec(n,-1,alpha,&space[n*(n+1)/2]);//This means we minimise U=-2*return+lambda*variance
	}
	packed2symm(n+1,&space[0]);
	c=0;
	SDPsvec(n+1,&space[0],&c[0]);

	x=0;y=0;s=0;
	double tau=0,kappa=0;

	int straight=1,log=1,method=1,homog=1;
	double comptoll=(fastbreak?lm_rooteps:lm_rooteps*2),gaptoll=1,stepmax=(fastbreak?2e-5:2e-3);//OK for a small step of 2e-5 if we use fastbreak
	char* outfile=(char*)"";

	double norm=1;//sqrt(ddotvec(nx,&c[0],&c[0])+ddotvec(m,&b[0],&b[0])+ddotvec(m*nx,&A[0],&A[0]));

	//norm=lmod(nx,&c[0])+lmod(m,&b[0])+lmod(nx*m,&A[0]);
	dscalvec(nx,1./norm,&c[0]);
	dscalvec(m,1./norm,&b[0]);
	dscalvec(nx*m,1./norm,&A[0]);
	short back=Conic_VeryGeneral(ncone,&cone[0],&typecone[0],m,&x[0],&s[0],&y[0],&A[0],&b[0],&c[0],&tau,&kappa,
		comptoll,gaptoll,stepmax,straight,fastbreak,log,outfile,method,homog,0,0,0,0,0);

	dscalvec(nx,norm,&c[0]);
	dscalvec(m,norm,&b[0]);
	dscalvec(nx*m,norm,&A[0]);
	if(back==0)
	{
		if(tau/kappa>1e2)
		{
			dscalvec(nx,1./tau,&x[0]);
			dscalvec(nx,1./tau,&s[0]);
			dscalvec(m,1./tau,&y[0]);
			double sos1,sos2;
			sos1=dsumvec(n,&x[nn-n-1]);
			SDPsMat(n+1,&x[0],&space[0]);
			dcopyvec(n,&space[n*(n+1)],w);//(n+1)(n+1) - n - 1 = n(n+1)
			sos2=ddotvec(n,&space[n*(n+1)],&space[n*(n+1)]);
			if(sos_check)*sos_check=sos1-sos2;
			printf((char*)"sos1 %20.8e\n",sos1);
			printf((char*)"sos2 %20.8e\n",sos2);
			if(alpha_extra)
			{
				vector ww=&x[nn+(do_parity?(parity2?nsect:2*nsect):0)+(*conc<3?1:0)+(RiskConc>0?1:0)+n_link+(longonly?n*(n+1)/2:0)];
				vector ss=&s[nn+(do_parity?(parity2?nsect:2*nsect):0)+(*conc<3?1:0)+(RiskConc>0?1:0)+n_link+(longonly?n*(n+1)/2:0)];
				printf((char*)"x alpha check   %20.8e %20.8e\n",ww[2]*ww[1]*2-ww[0]*ww[0],ww[1]);
				printf((char*)"s alpha check   %20.8e %20.8e\n",ss[2]*ss[1]*2-ss[0]*ss[0],ss[1]);
				printf((char*)"x.s alpha check %20.8e\n",ddotvec(3,ww,ss));
				printf((char*)"s alpha vec     %20.8e %20.8e %20.8e\n",ss[0],ss[1],ss[2]);
				printf((char*)"alpha check lambdas (.5*%20.8e) %20.8e %20.8e\n",-2*y[alpha_checkno],-y[alpha_checkno+1],-y[alpha_checkno+2]);
			}
			if(budget==0)
			{
				vector ww=&x[nn+(do_parity?(parity2?nsect:2*nsect):0)+(*conc<3?1:0)+(RiskConc>0?1:0)+n_link+(longonly?n*(n+1)/2:0)+(alpha_extra?3:0)];
				for(i=0;i<n;++i)
				{
					printf((char*)"%3ld  %20.5f %20.5f %20.5f\n",i+1,w[i],ww[2*i],ww[2*i+1]);
				}
				printf((char*)"%3s  %20.5f %20s %20.5f\n",(char*)" ",dsumvec(n,w),(char*)" ",dsum(n,ww+1,2));
			}
			if(*conc<3)
			{
				*conc = -y[concno];
			}
			if(RiskConc>0)
			{
				*lambda = -y[riskno];
			}
			std::valarray<double>eigv(n+1);
			eigendecomp(n+1,&space[0],&eigv[0],3000);
			size_t eigsig=0;
			for(i=0;i<n+1;++i)
			{
				if(fabs(eigv[i])>1e-6*eigv[0])
					eigsig++;
			}
			*rank=eigsig;
		}
		else
			back=1;
	}
	else
		back=1;
	return back;
}


class DLLEXPORT ParityInfo:public ForUpdates
{
public:
	vector Q;//Covariance matrix
	vector Qw;//Covariance matrix times weights
	vector alpha;
	vector sectors;
	size_t nsect,nsame;
	vector RiskRat;//vector of required sector risks divided by total risk (use a vector in case we want them different in the future)
	size_t nstocks;
	long nf;
	vector Qf;
	double mu;
	vector lambda;
	double fac;
	ParityUtype Utype;
	double resid(vector w,vector resid);
	bool DOUBLE;
	double gamma;
	double lower;
};
double ParityInfo::resid(vector w,vector resid)
{
	size_t i,k;
	vector ss,sk;
	if(nf==-1)
		dsmxmulv(nstocks,Q,w,Qw);
	else
		facmulold(nstocks,nf,Qf,w,Qw);
	double var=ddotvec(nstocks,w,Qw);
	if(sectors)
	{
		for(i=0,ss=sectors;i<nsect;i++,ss+=nstocks)
		{
			resid[i]=-var * RiskRat[i];
			for(k=0,sk=ss;k<nstocks;++k,sk++)
			{
				if(*sk==1)
				{
					resid[i]+=w[k]*Qw[k];
				}
			}
		}
	}
	else
	{
		for(k=0;k<nsect;++k)
		{
			resid[k]=w[k]*Qw[k] - var * RiskRat[k];
		}
	}
	return linfinity(nsect,resid);
}
extern "C" double ParityUV(dimen n,vector w,void* info)
{
	ParityInfo *INFO=(ParityInfo*)info;
	size_t k,l;
	if(INFO->nf==-1)
		dsmxmulv(INFO->nstocks,INFO->Q,w,INFO->Qw);
	else
		facmulold(INFO->nstocks,INFO->nf,INFO->Qf,w,INFO->Qw);

	double back=0,var=ddotvec(INFO->nstocks,w,INFO->Qw),part,spart,lpart;
	double conc=ddotvec(INFO->nstocks,w,w);
	vector ss,sl;

	if(INFO->sectors)
	{
		for(k=0,spart=0,lpart=0,ss=INFO->sectors;k<INFO->nsect;++k,ss+=n)
		{
			part=-var*INFO->RiskRat[k];
			for(l=0,sl=ss;l<n;++l,sl++)
			{
				if(*sl==1)
				{
					part+=w[l]*INFO->Qw[l];
				}
			}
			spart+=part*part;
			lpart+=INFO->lambda[k]*part;
		}
	}
	else
	{
		for(k=0,spart=0,lpart=0;k<INFO->nsect;++k)
		{
			part = w[k] * INFO->Qw[k] - var * INFO->RiskRat[k];
			spart+=part*part;
			lpart+=INFO->lambda[k]*part;
		}
	}
	if(INFO->Utype==ConcentrationType)
	{
		return (conc*INFO->fac+spart/INFO->mu)*0.5 - lpart;
	}
	else if(INFO->Utype==VarianceType)
	{
		return (var*INFO->fac+spart/INFO->mu)*0.5 - lpart;
	}
	else if(INFO->Utype==EntropyType)
	{
		double entropy=0;
		for(k=0;k<n;++k)
		{
			if(w[k]>lm_eps)
				entropy+=w[k]*log(w[k]);
		}
		return (2.0*entropy*INFO->fac+spart/INFO->mu)*0.5 - lpart;
	}
}

//#define CONC_NOT_VAR


extern "C" DLLEXPORT double ParityVarianceF(dimen nvab,vector xx,void*info)
{
	ParityInfo *INFO=(ParityInfo*)info;
	std::valarray<double>xxx;
	vector x=xx;
	if(INFO->lower!=0)
	{
		xxx.resize(nvab);
		x=&xxx[0];
		dcopyvec(nvab,xx,x);
		for(size_t i=0;i<nvab;++i)
			x[i] += INFO->lower;
	}
	dimen n=INFO->nstocks;
	vector w=x,v=x+n,Qw=INFO->Qw,Qv=Qw+n;
	if(INFO->nf==-1)
	{
		dsmxmulv(n,INFO->Q,w,Qw);
	}
	else
	{
		facmulold(n,INFO->nf,INFO->Qf,w,Qw);
	}
	double var=ddotvec(n,w,Qw);
	double conc=ddotvec(n,w,w);
	double ret=0;
	if(INFO->alpha) ret=ddotvec(n,w,INFO->alpha);
	double scale=INFO->gamma/(1-INFO->gamma);
	double back=var*0.5 - scale*ret;
	if(INFO->DOUBLE)
	{
		dsubvec(n,w,v,Qv);
		double diff=ddotvec(n,Qv,Qv);
		return 0.5*(var+INFO->fac*diff);
	}
#ifdef CONC_NOT_VAR
	else//concentration primal
	{
		back= 0.5*conc;
	}
#endif
	return back;
}
extern "C" DLLEXPORT void ParityVarianceG(dimen nvab,vector xx,vector g,void*info)
{
	ParityInfo *INFO=(ParityInfo*)info;
	std::valarray<double>xxx;
	vector x=xx;
	if(INFO->lower!=0)
	{
		xxx.resize(nvab);
		x=&xxx[0];
		dcopyvec(nvab,xx,x);
		for(size_t i=0;i<nvab;++i)
			x[i] += INFO->lower;
	}
	dimen n=INFO->nstocks;
	vector w=x,v=x+n,Qw=INFO->Qw,Qv=Qw+n,gv=g+n;
	dimen i;
	if(INFO->nf==-1)
	{
		dsmxmulv(n,INFO->Q,w,g);
	}
	else
	{
		facmulold(n,INFO->nf,INFO->Qf,w,g);
	}
	double scale=INFO->gamma/(1-INFO->gamma);
	if(INFO->DOUBLE)
	{
		for(i=0;i<n;++i)
		{
			gv[i]=-INFO->fac*(w[i]-v[i]);
			g[i]-=gv[i];
		}
	}
	else if(INFO->alpha)
	{
		daxpyvec(n,-scale,INFO->alpha,g);
	}
#ifdef CONC_NOT_VAR
	else//concentration primal
		dcopyvec(n,x,g);
#endif
}
extern "C" DLLEXPORT void ParityVarianceH(dimen nvab,vector xx,vector H,void*info)
{
	ParityInfo *INFO=(ParityInfo*)info;
	std::valarray<double>xxx;
	vector x=xx;
	if(INFO->lower!=0)
	{
		xxx.resize(nvab);
		x=&xxx[0];
		dcopyvec(nvab,xx,x);
		for(size_t i=0;i<nvab;++i)
			x[i] += INFO->lower;
	}
	dimen n=INFO->nstocks,nn=n*(n+1)>>1,i,ii;
	vector w=x,v=x+n;
	dcopyvec(nn,INFO->Q,H);
	if(INFO->DOUBLE)
	{
		for(i=0,ii=0;i<n;++i,ii+=i)
		{
			H[ii+i]+=INFO->fac;
		}
		dzerovec(nn+n*n,H+nn);
		for(;i<nvab;++i,ii+=i)
		{
			H[ii+i]+=INFO->fac;
			H[ii+i-n]=-INFO->fac;
		}
	}
#ifdef CONC_NOT_VAR
	else //concentration primal
	{
		dzerovec(nn,H);
		for(i=0,ii=0;i<n;i++,ii+=i)
			H[ii+i]=1;
	}
#endif
}
extern "C" DLLEXPORT void ParityGenC(dimen nvab,dimen m,vector xx,vector y,vector A,vector H,vector G,void*info)
{
	ParityInfo *INFO=(ParityInfo*)info;
	std::valarray<double>xxx;
	vector x=xx;
	if(INFO->lower!=0)
	{
		xxx.resize(nvab);
		x=&xxx[0];
		dcopyvec(nvab,xx,x);
		for(size_t i=0;i<nvab;++i)
			x[i] += INFO->lower;
	}
	dimen n=INFO->nstocks;
	vector w=x,v=x+n,Qw=INFO->Qw,Qv=Qw+n,Gv=G+n;
	size_t k,kk,i,ii,j,jj;

	if(INFO->nf==-1)
	{
		dsmxmulv(n,INFO->Q,w,Qw);
		if(INFO->DOUBLE)
			dsmxmulv(n,INFO->Q,v,Qv);
	}
	else
	{
		facmulold(n,INFO->nf,INFO->Qf,w,Qw);
		if(INFO->DOUBLE)
			facmulold(n,INFO->nf,INFO->Qf,v,Qv);
	}

	double var=ddotvec(n,w,INFO->Qw);

	for(k=0;k<n;++k)
	{
		if(INFO->DOUBLE)
		{
			G[k] = -(w[k] * Qv[k]/var -  INFO->RiskRat[k]);
			Gv[k] = w[k] - v[k];
		}
		else
			G[k] = -(w[k] * Qw[k]/var -  INFO->RiskRat[k]);
	}

	if(A)
	{
		dzerovec(nvab*m,A);
		if(INFO->DOUBLE)
		{
			for(k=0,kk=0;k<n;++k,kk+=k)
			{
				daxpyvec(n,2.0*w[k]*Qv[k]/var/var,Qw,A+nvab*k);
				A[k*nvab + k] -= Qv[k]/var;
				for(i=0,ii=0;i<k;++i,ii+=i)
					A[k*nvab + n + i] += -w[k]*INFO->Q[kk+i]/var;
				for(;i<n;++i,ii+=i)
					A[k*nvab + n + i] += -w[k]*INFO->Q[ii+k]/var;

				A[(k+INFO->nsect)*nvab + k] += 1.0;
				A[(k+INFO->nsect)*nvab + n + k] += -1.0;
			}
		}
		else
		{
			for(k=0,kk=0;k<n;k++,kk+=k)
			{
				daxpyvec(n,2.0*w[k]*Qw[k]/var/var,Qw,A+nvab*k);
				A[k*nvab + k] -= Qw[k]/var;
				for(i=0,ii=0;i<k;i++,ii+=i)
					A[k*nvab + i] -= w[k]*INFO->Q[kk+i]/var;
				for(;i<n;i++,ii+=i)
					A[k*nvab + i] -= w[k]*INFO->Q[ii+k]/var;
			}
		}
	}

	if(H)
	{
		size_t nn=n*(n+1)>>1;
		dzerovec(nvab*(nvab+1)>>1,H);
		if(INFO->DOUBLE)
		{
			for(k=0,kk=0;k<n;++k,kk+=k)
			{
				daxpyvec(nn,2.0*y[k]*w[k]*Qv[k]/var/var,INFO->Q,H);
				for(i=0,ii=0;i<n;++i,ii+=i)
				{
					for(j=0;j<n;++j)
					{
						if(j<=i)
							H[ii+j]-=y[k]*8.0*w[k]*Qw[i]*Qw[j]*Qv[k]/var/var/var;
						if(i<k)
						{
							H[((i+n)*(i+n+1)>>1) +j]+=y[k]*w[k]*2.0*Qw[j]*INFO->Q[kk+i]/var/var;
							if(j==k)
								H[((i+n)*(i+n+1)>>1) +j]+= - y[k]*INFO->Q[kk+i]/var;
						}
						else if(k<i)
						{
							H[((i+n)*(i+n+1)>>1) +j]+=y[k]*w[k]*2.0*Qw[j]*INFO->Q[ii+k]/var/var;
							if(j==k)
								H[((i+n)*(i+n+1)>>1) +j]+= - y[k]*INFO->Q[ii+k]/var;
						}
						else
						{
							H[((i+n)*(i+n+1)>>1) +i]+=y[k]*w[k]*2.0*Qw[j]*INFO->Q[ii+k]/var/var; 
							if(j==k)
								H[((i+n)*(i+n+1)>>1) +j]+= - y[k]*INFO->Q[ii+k]/var;
						}
					}
				}
				for(j=0,jj=0;j<k;++j,jj+=j)
				{
					H[kk+j]+=y[k]*4.0*Qw[j]*Qv[k]/var/var;
				}
				for(;j<n;++j,jj+=j)
				{
					H[jj+k]+=y[k]*4.0*Qw[j]*Qv[k]/var/var;
				}
			}
		}
		else
		{
			double Qwij,Qwi,Qwj;
			for(k=0,kk=0;k<n;++k,kk+=k)
			{
				daxpyvec(nn,2.0*y[k]*w[k]*Qw[k]/var/var,INFO->Q,H);
			}
			for(i=0,ii=0;i<n;++i,ii+=i)
			{
				Qwi=Qw[i]/var/var;
				for(j=0,jj=0;j<=i;++j,jj+=j)
				{
					Qwij=Qw[j]*Qwi/var;
					Qwj=Qw[j]/var/var;
					for(k=0,kk=0;k<n;++k,kk+=k)
					{
						H[ii+j] -= 8.0 * y[k]*w[k]*Qw[k]*Qwij;
						if(j<k)
						{
							H[ii+j] += 2.0*y[k]*w[k]*INFO->Q[kk+j]*Qwi;
						}
						else
						{
							H[ii+j] += 2.0*y[k]*w[k]*INFO->Q[jj+k]*Qwi;
						}
						if(j==k && i<k)
							H[ii+j] += -y[k]*INFO->Q[kk+i]/var;
						else if(j==k)
							H[ii+j] += -y[k]*INFO->Q[ii+k]/var;
						if(i==k && j<k)
							H[ii+j] += -y[k]*INFO->Q[kk+j]/var;
						else if(i==k)
							H[ii+j] += -y[k]*INFO->Q[jj+k]/var;
						if(i<k)
						{
							H[ii+j] += y[k]*2.0*w[k]*INFO->Q[kk+i]*Qwj;
						}
						else
						{
							H[ii+j] += y[k]*2.0*w[k]*INFO->Q[ii+k]*Qwj;
						}
						if(i==k)
							H[ii+j] += y[k]*2.0*Qw[k]*Qwi;
						if(j==k)
							H[ii+j] += y[k]*2.0*Qw[k]*Qwj;
					}
				}
			}
		}
		if(INFO->DOUBLE)
		{
			for(j=n,jj=nn;j<2*n;++j,jj+=j)
				H[jj+j]+=lm_rooteps;//Regularise to try to make the Hessian +ve definite.
		}
	}

	if(INFO->DOUBLE && (m == (2*n + 1)))//Budget if present
	{
		G[m-1] = 1 - dsumvec(n,w);
		if(A)
		{
			dsetvec(n,-1.0,A+(m-1)*nvab);
			dzerovec(n,A+(m-1)*nvab+n);
		}
		//Nothing extra to set for H
	}
	if(!INFO->DOUBLE && (m == (n + 1)))//Budget if present
	{
		G[m-1] = 1 - dsumvec(n,w);
		if(A)
		{
			dsetvec(n,-1.0,A+(m-1)*nvab);
		}
		//Nothing extra to set for H
	}
}
extern "C" DLLEXPORT void ParityGenC2(dimen nvab,dimen m,vector xx,vector y,vector A,vector H,vector G,void*info)
{
	H=0;//decide never to modify Hessian
	ParityInfo *INFO=(ParityInfo*)info;
	std::valarray<double>xxx;
	vector x=xx;
	if(INFO->lower!=0)
	{
		xxx.resize(nvab);
		x=&xxx[0];
		dcopyvec(nvab,xx,x);
		for(size_t i=0;i<nvab;++i)
			x[i] += INFO->lower;
	}
	double cscale=1e3;
	dimen n=INFO->nstocks;
	vector w=x,v=x+n,Qw=INFO->Qw,Qv=Qw+n,Gv=G+n;
	vector ss=INFO->sectors,si;
	size_t k,kk,i,ii,j,jj;

	if(INFO->nf==-1)
	{
		dsmxmulv(n,INFO->Q,w,Qw);
		if(INFO->DOUBLE)
			dsmxmulv(n,INFO->Q,v,Qv);
	}
	else
	{
		facmulold(n,INFO->nf,INFO->Qf,w,Qw);
		if(INFO->DOUBLE)
			facmulold(n,INFO->nf,INFO->Qf,v,Qv);
	}

	double var=ddotvec(n,w,INFO->Qw);

	if(INFO->sectors)
	{
		for(k=0,ss=INFO->sectors;k<m-1;++k,ss+=n)
		{
			G[k] = var*INFO->RiskRat[k];
			for(i=0,si=ss;i<n;++i,si++)
			{
				if(*si == 1)
				{
					G[k] -= w[i]*Qw[i];
				}
			}
		}
	}
	else
	{
		for(k=0;k<m-1;++k)
		{
			if(INFO->DOUBLE)
			{
				G[k] = -(w[k] * Qv[k] -  var*INFO->RiskRat[k]);
				Gv[k] = w[k] - v[k];
			}
			else
				G[k] = -(w[k] * Qw[k] -  var*INFO->RiskRat[k]);
		}
	}
	dscalvec(m-1,cscale,G);
	if(A)
	{
		dzerovec(nvab*m,A);
		if(INFO->sectors)
		{
			size_t j,jj;
			for(k=0,ss=INFO->sectors;k<m-1;++k,ss+=n)
			{
				daxpyvec(n,2.0*INFO->RiskRat[k],Qw,A+nvab*k);
				for(i=0,si=ss,ii=0;i<n;++i,ii+=i,si++)
				{
					if(*si == 1)
					{
						A[k*nvab + i] -= Qw[i];
						for(j=0,jj=0;j<i;++j,jj+=j)
						{
							A[k*nvab + j] -= w[i]*INFO->Q[ii+j];
						}
						for(;j<n;++j,jj+=j)
						{
							A[k*nvab + j] -= w[i]*INFO->Q[jj+i];
						}
					}
				}
			}
		}
		else
		{
			if(INFO->DOUBLE)
			{
				for(k=0,kk=0;k<m-1;++k,kk+=k)
				{
					daxpyvec(n,2.0*INFO->RiskRat[k],Qw,A+nvab*k);
					A[k*nvab + k] -= Qv[k];
					for(i=0,ii=0;i<k;++i,ii+=i)
						A[k*nvab + n + i] += -w[k]*INFO->Q[kk+i];
					for(;i<n;++i,ii+=i)
						A[k*nvab + n + i] += -w[k]*INFO->Q[ii+k];

					A[(k+INFO->nsect)*nvab + k] += 1.0;
					A[(k+INFO->nsect)*nvab + n + k] += -1.0;
				}
			}
			else
			{
				for(k=0,kk=0;k<m-1;k++,kk+=k)
				{
					daxpyvec(n,2.0*INFO->RiskRat[k],Qw,A+nvab*k);
					A[k*nvab + k] -= Qw[k];
					for(i=0,ii=0;i<k;i++,ii+=i)
						A[k*nvab + i] -= w[k]*INFO->Q[kk+i];
					for(;i<n;i++,ii+=i)
						A[k*nvab + i] -= w[k]*INFO->Q[ii+k];
				}
			}
		}
		dscalvec(nvab*m,cscale,A);
	}

	if(H)
	{
		size_t nn=n*(n+1)>>1;
		dzerovec(nvab*(nvab+1)>>1,H);
		if(INFO->sectors)
		{
			size_t j,jj,l,ll;
			for(k=0,ss=INFO->sectors;k<m-1;++k,ss+=n)
			{
				daxpyvec(nn,2.0*y[k]*INFO->RiskRat[k],INFO->Q,H);
				for(i=0,si=ss,ii=0;i<n;++i,ii+=i,si++)
				{
					if(*si == 1)
					{
						for(j=0,jj=0;j<i;++j,jj+=j)
						{
							H[ii+j] -= 2.0*y[k]*INFO->Q[ii+j];
						}
						for(;j<n;++j,jj+=j)
						{
							H[jj+i] -= 2.0*y[k]*INFO->Q[jj+i];
						}
					}
				}
			}
		}
		else
		{
			if(INFO->DOUBLE)
			{
				for(k=0,kk=0;k<m-1;++k,kk+=k)
				{
					daxpyvec(nn,2.0*y[k]*INFO->RiskRat[k],INFO->Q,H);
					for(i=0,ii=0;i<n;++i,ii+=i)
					{
						for(j=0;j<n;++j)
						{
							if(i<k)
							{
								if(j==k)
									H[((i+n)*(i+n+1)>>1) +j]+= - y[k]*INFO->Q[kk+i];
							}
							else if(k<i)
							{
								if(j==k)
									H[((i+n)*(i+n+1)>>1) +j]+= - y[k]*INFO->Q[ii+k];
							}
							else
							{
								if(j==k)
									H[((i+n)*(i+n+1)>>1) +j]+= - y[k]*INFO->Q[ii+k];
							}
						}
					}
				}
			}
			else
			{
				for(k=0,kk=0;k<m-1;++k,kk+=k)
				{
					daxpyvec(nn,2.0*y[k]*INFO->RiskRat[k],INFO->Q,H);
				}
				for(i=0,ii=0;i<n;++i,ii+=i)
				{
					for(j=0,jj=0;j<=i;++j,jj+=j)
					{
						for(k=0,kk=0;k<m-1;++k,kk+=k)
						{
							if(j==k && i<k)
								H[ii+j] += -y[k]*INFO->Q[kk+i];
							else if(j==k)
								H[ii+j] += -y[k]*INFO->Q[ii+k];
							if(i==k && j<k)
								H[ii+j] += -y[k]*INFO->Q[kk+j];
							else if(i==k)
								H[ii+j] += -y[k]*INFO->Q[jj+k];
						}
					}
				}
			}
		}
		if(INFO->DOUBLE)
		{
			for(j=n,jj=nn;j<2*n;++j,jj+=j)
				H[jj+j]+=lm_rooteps;//Regularise to try to make the Hessian +ve definite.
		}
	}

	if(INFO->DOUBLE)// && (m == (2*n + 1)))//Budget if present Nowe always do budget but only need nsect-1 independent risk parity constraints (including the extra nsect'th redundant one doesn't make much difference)
	{
		G[m-1] = 1 - dsumvec(n,w);
		if(A)
		{
			dsetvec(n,-1.0,A+(m-1)*nvab);
			dzerovec(n,A+(m-1)*nvab+n);
		}
		//Nothing extra to set for H
	}
	if(!INFO->DOUBLE)// && (m == (INFO->nsect + 1)))//Budget if present
	{
		G[m-1] = 1 - dsumvec(n,w);
		if(A)
		{
			dsetvec(n,-1.0,A+(m-1)*nvab);
		}
		//Nothing extra to set for H
	}
}

extern "C" void ParityGradUV(dimen n,vector w,vector g,void* info)
{
	ParityInfo *INFO=(ParityInfo*)info;
	size_t i,ii,k,kk,j,jj,l,ll;
	if(INFO->nf==-1)
		dsmxmulv(INFO->nstocks,INFO->Q,w,INFO->Qw);
	else
		facmulold(INFO->nstocks,INFO->nf,INFO->Qf,w,INFO->Qw);

	double back=0,var=ddotvec(INFO->nstocks,w,INFO->Qw),spart,part,parti,lpart;
	dzerovec(n,g);
	vector ss,ssj,sss,ssl;
	if(INFO->sectors)
	{
		for(i=0;i<n;i++)
		{
			if(INFO->Utype==ConcentrationType)
			{
				g[i]=w[i]*INFO->fac;//gradient of conc/2
			}
			else if(INFO->Utype==VarianceType)
			{
				g[i]=INFO->fac*INFO->Qw[i];
			}
			else if(INFO->Utype==EntropyType)
			{
				if(w[i]>lm_eps)g[i]=-INFO->fac*(1-log(w[i]));
			}
		}
		for(k=0,ss=INFO->sectors;k<INFO->nsect;++k,ss+=n)
		{
			part =  - var * INFO->RiskRat[k];
			for(j=0,jj=0,ssj=ss;j<n;++j,jj+=j,ssj++)
			{
				if(*ssj==1)
				{
					part += w[j] * INFO->Qw[j];
				}
			}
			part/=INFO->mu;
			part-=INFO->lambda[k];
			for(j=0,jj=0,ssj=ss;j<n;++j,jj+=j,ssj++)
			{
				parti=0;
				if(*ssj==1)
				{
					parti += -2.0*INFO->RiskRat[k] * INFO->Qw[j];
					for(l=0,ll=0;l<n;++l,ll+=l)
					{
						if(j<l)
							parti+=w[j] * INFO->Q[ll+j];
						else if(l<j)
							parti+=w[j] * INFO->Q[jj+l];
						else
							parti+=w[j] * INFO->Q[jj+j] + INFO->Qw[j];
					}
				}
				g[j]+=part*parti;
			}
		}
	}
	else
	{
		for(i=0,ii=0;i<n;i++,ii+=i)
		{
			if(INFO->Utype==ConcentrationType)
			{
				g[i]=w[i]*INFO->fac;//gradient of conc/2
			}
			else if(INFO->Utype==VarianceType)
			{
				g[i]=INFO->fac*INFO->Qw[i];
			}
			else if(INFO->Utype==EntropyType)
			{
				if(w[i]>lm_eps)g[i]=-INFO->fac*(1-log(w[i]));
			}
		}
		for(k=0,kk=0;k<INFO->nsect;++k,kk+=k)
		{
			part = w[k] * INFO->Qw[k] - var * INFO->RiskRat[k];
			part/=INFO->mu;
			part-=INFO->lambda[k];
			for(i=0,ii=0;i<n;i++,ii+=i)
			{
				parti = -2.0*INFO->RiskRat[k] * INFO->Qw[i];
				if(k<i)
					parti+=w[k] * INFO->Q[ii+k];
				else if(i<k)
					parti+=w[k] * INFO->Q[kk+i];
				else
					parti+=w[i] * INFO->Q[ii+i] + INFO->Qw[k];
				g[i]+=part*parti;
			}
		}
	}
}
extern "C" void ParityHessUV(dimen n,vector w,vector h,void* info)
{
	ParityInfo *INFO=(ParityInfo*)info;
	size_t k,l,i,ii,kk,ll,nn=n*(n+1)>>1,j,jj,m,mm,o,oo;
	if(INFO->nf==-1)
		dsmxmulv(INFO->nstocks,INFO->Q,w,INFO->Qw);
	else
		facmulold(INFO->nstocks,INFO->nf,INFO->Qf,w,INFO->Qw);

	double back=0,var=ddotvec(INFO->nstocks,w,INFO->Qw),spart,part,parti,lpart,partj,partij;
	vector ssi,ssj,sli,slj,ss,ssk,sss;
	dzerovec(nn,h);

	if(INFO->sectors)
	{
		bool neg=false;
		for(i=0,ii=0;i<n;i++,ii+=i)
		{
			for(j=0,jj=0;j<=i;j++,jj+=j)
			{
				if(INFO->Utype==ConcentrationType)
				{
					if(i==j)h[ii+j]=INFO->fac;
				}
				else if(INFO->Utype==VarianceType)
				{
					h[ii+j]=INFO->fac * INFO->Q[ii+j];
				}
				else if(INFO->Utype==EntropyType)
				{
					if(i==j && w[i]>lm_eps)h[ii+j]=INFO->fac/w[i];
				}
			}
		}
		for(k=0,kk=0,ss=INFO->sectors;k<INFO->nsect;++k,kk+=k,ss+=n)
		{
			part=-var*INFO->RiskRat[k];
			for(l=0,ssk=ss;l<n;++l,ssk++)
			{
				if(*ssk==1)
				{
					part += w[l] * INFO->Qw[l];
				}
			}
			part/=INFO->mu;
			part-=INFO->lambda[k];
			//part=fabs(part);
			neg=part<0;

			for(l=0,ll=0,ssk=ss;l<n;++l,ssk++,ll+=l)
			{
				parti=0;
				if(*ssk==1)
				{
					parti += -2.0*INFO->RiskRat[k] * INFO->Qw[l];
					partij = -2.0*INFO->RiskRat[k]*INFO->Q[ll+l];
					for(m=0,mm=0;m<n;++m,mm+=m)
					{
						if(m<l)
							parti+=w[l] * INFO->Q[ll+m];
						else if(l<m)
							parti+=w[l] * INFO->Q[mm+l];
						else
						{
							parti+=w[l] * INFO->Q[ll+l] + INFO->Qw[l];
							partij+=2*INFO->Q[ll+l];
						}
					}
					h[ll+l]+=(neg?(-part*partij + parti*parti/INFO->mu):(part*partij + parti*parti/INFO->mu));
					for(j=0,jj=0,ssj=ss;j<l;j++,jj+=j,ssj++)
					{
						partj=0;
						if(*ssj==1)
						{
							partj += -2.0*INFO->RiskRat[k] * INFO->Qw[j];
							partij = -2.0*INFO->RiskRat[k]*INFO->Q[ll+j];
							for(m=0,mm=0;m<n;++m,mm+=m)
							{
								if(m>j)
									partij = -2.0*INFO->RiskRat[k]*INFO->Q[mm+j];
								else
									partij = -2.0*INFO->RiskRat[k]*INFO->Q[jj+m];
								if(j<m)
								{
									partj+=w[j] * INFO->Q[mm+j];
									if(j==l)
										partij+=INFO->Q[mm+j];
								}
								else if(m<j)
								{
									partj+=w[j] * INFO->Q[jj+m];
									if(j==l)
										partij+=INFO->Q[jj+m];
								}
								else
								{
									partj+=w[j] * INFO->Q[mm+m] + INFO->Qw[m];
									if(l>m)
										partij+=INFO->Q[ll+m];
									else
										partij+=INFO->Q[mm+l];
								}
							}
						}
						h[ll+j]+=(neg?(-part*partij + parti*partj/INFO->mu):(part*partij + parti*partj/INFO->mu));
					}
				}
			}
		}
	}
	else
	{
		bool neg=false;
		for(i=0,ii=0;i<n;i++,ii+=i)
		{
			for(j=0,jj=0;j<=i;j++,jj+=j)
			{
				if(INFO->Utype==ConcentrationType)
				{
					if(i==j)h[ii+j]=INFO->fac;
				}
				else if(INFO->Utype==VarianceType)
				{
					h[ii+j]=INFO->fac * INFO->Q[ii+j];
				}
				else if(INFO->Utype==EntropyType)
				{
					if(i==j && w[i]>lm_eps)h[ii+j]=INFO->fac/w[i];
				}
			}
		}
		for(k=0,kk=0;k<INFO->nsect;++k,kk+=k)
		{
			part = w[k] * INFO->Qw[k] - var * INFO->RiskRat[k];
			part/=INFO->mu;
			part-=INFO->lambda[k];
			//part=fabs(part);
			neg=part<0;
			for(i=0,ii=0;i<n;i++,ii+=i)
			{
				parti = -2.0*INFO->RiskRat[k] * INFO->Qw[i];
				partij = -2.0*INFO->RiskRat[k]*INFO->Q[ii+i];
				if(k<i)
					parti+=w[k] * INFO->Q[ii+k];
				else if(i<k)
					parti+=w[k] * INFO->Q[kk+i];
				else
				{
					parti+=w[i] * INFO->Q[ii+i] + INFO->Qw[i];
					partij+=2*INFO->Q[ii+i];
				}
				h[ii+i]+=(neg?(-part*partij + parti*parti/INFO->mu):(part*partij + parti*parti/INFO->mu));
				for(j=0,jj=0;j<i;j++,jj+=j)
				{
					partj = -2.0*INFO->RiskRat[k] * INFO->Qw[j];
					partij = -2.0*INFO->RiskRat[k]*INFO->Q[ii+j];
					if(i==k)
						partij+=INFO->Q[ii+j];
					if(k<j)
						partj+=w[k] * INFO->Q[jj+k];
					else if(j<k)
						partj+=w[k] * INFO->Q[kk+j];
					else
					{
						partj+=w[j] * INFO->Q[jj+j] + INFO->Qw[j];
						partij+=INFO->Q[ii+j];
					}
					h[ii+j]+=(neg?(-part*partij + parti*partj/INFO->mu):(part*partij + parti*partj/INFO->mu));
				}
			}
		}
	}
}
extern "C" double ParityU(dimen n,vector w,void* info)
{
	ParityInfo *INFO=(ParityInfo*)info;

	size_t nn=n*(n+1)>>1;
	size_t i,j;
	if(INFO->nf==-1)
		dsmxmulv(n,INFO->Q,w,INFO->Qw);
	else
		facmulold(n,INFO->nf,INFO->Qf,w,INFO->Qw);
	double back=0,var=ddotvec(n,w,INFO->Qw),part;
	if(INFO->nsame)
		var=ddotvec(INFO->nsame,w+n-INFO->nsame,INFO->Qw+n-INFO->nsame);
	vector ss,sj;

	if(INFO->sectors)
	{
		for(i=0,ss=INFO->sectors;i<INFO->nsect;++i,ss+=n)
		{
			part=-var*INFO->RiskRat[i];
			for(j=0,sj=ss;j<n;++j,sj++)
			{
				if(*sj==1)
				{
					part+=w[j]*INFO->Qw[j];
				}
			}
			back+=part*part;
		}
	}
	else
	{
		size_t i1=0;
		if(INFO->nsame)i1=n-INFO->nsame;
		for(i=i1;i<INFO->nsect;++i)
		{
			part=w[i]*INFO->Qw[i]-var*INFO->RiskRat[i];
			back+=part*part;
		}
	}
	return back+1;
}

extern "C" void ParityGradU(dimen n,vector w,vector grad,void*info)
{
	ParityInfo *INFO=(ParityInfo*)info;
	if(INFO->nf==-1)
		dsmxmulv(n,INFO->Q,w,INFO->Qw);
	else
		facmulold(n,INFO->nf,INFO->Qf,w,INFO->Qw);
	double back=0,var=ddotvec(n,w,INFO->Qw),part,parti,CI;
	if(INFO->nsame)
		var=ddotvec(INFO->nsame,w+n-INFO->nsame,INFO->Qw+n-INFO->nsame);
	size_t i,j,v,vv,jj,ii,u,uu;
	vector ss,sj,sv,su;

	dzerovec(n,grad);
	if(INFO->sectors)
	{
		for(i=0,ss=INFO->sectors;i<INFO->nsect;++i,ss+=n)
		{
			for(j=0,jj=j*(j+1)>>1,sj=ss;j<n;++j,sj++,jj+=j)
			{
				if(*sj==1)
				{
					for(v=0,vv=0,sv=INFO->sectors;v<INFO->nsect;++v,vv+=v,sv+=n)
					{
						CI=2.0*INFO->RiskRat[v];
						part=-var*INFO->RiskRat[v];
						parti=0;
						for(u=0,uu=0,su=sv;u<n;++u,uu+=u,su++)
						{
							if(*su==1)
							{
								part+=w[u]*INFO->Qw[u];
								if(j<u)
									parti+=w[u]*INFO->Q[uu+j]-CI*INFO->Qw[j];
								else if(u<j)
									parti+=w[u]*INFO->Q[jj+u]-CI*INFO->Qw[j];
								else if(j==u)
									parti+=w[u]*INFO->Q[uu+u]+(1.0-CI)*INFO->Qw[u];
							}
						}
						grad[i]+=2.0*part*parti;
					}
				}
			}
		}
	}
	else
	{
		size_t i1=0;
		if(INFO->nsame)i1=n-INFO->nsame;
		for(i=i1,ii=i1*(i1+1)>>1;i<INFO->nsect;++i,ii+=i)
		{
			for(v=i1,vv=i1*(i1+1)>>1;v<INFO->nsect;++v,vv+=v)
			{
				CI=2.0*INFO->RiskRat[v];
				part=w[v]*INFO->Qw[v]-var*INFO->RiskRat[v];
				if(i<v)
					parti=w[v]*INFO->Q[vv+i]-CI*INFO->Qw[i];
				else if(v<i)
					parti=w[v]*INFO->Q[ii+v]-CI*INFO->Qw[i];
				else if(i==v)
				{
					parti=w[v]*INFO->Q[vv+v]+(1.0-CI)*INFO->Qw[v];
				}
				grad[i]+=2*part*parti;
			}
		}
	}
}
extern "C" void ParityHessU(dimen n,vector w,vector H,void*info)
{
	ParityInfo *INFO=(ParityInfo*)info;
	if(INFO->nf==-1)
		dsmxmulv(n,INFO->Q,w,INFO->Qw);
	else
		facmulold(n,INFO->nf,INFO->Qf,w,INFO->Qw);
	double back=0,var=ddotvec(n,w,INFO->Qw),part,parti,partj,partij,CI,CJ;
	if(INFO->nsame)
		var=ddotvec(INFO->nsame,w+n-INFO->nsame,INFO->Qw+n-INFO->nsame);
	long i,j,k,l,kl,nn=n*(n+1)>>1,ii,jj,kk,ll,v,vv,u,pi,pii,pj,pjj;
	vector si,sj,sii,sjj,sv,su;
//	double pen=0;

	dzerovec(nn,H);

	if(INFO->sectors)
	{
		for(i=0,ii=0,si=INFO->sectors;i<INFO->nsect;++i,ii+=i,si+=n)
		{
			for(j=0,jj=0,sj=INFO->sectors;j<=i;++j,jj+=j,sj+=n)
			{
				for(pi=0,sii=si,pii=0;pi<n;++pi,sii++,pii+=pi)
				{
					for(pj=0,pjj=0,sjj=sj;pj<n;++pj,sjj++,pjj+=pj)
					{
						if(*sii==1 && *sjj==1)
						{
							for(u=0,su=INFO->sectors;u<INFO->nsect;++u,su+=n)
							{
								part=-var*INFO->RiskRat[u];
								CI=2.0*INFO->RiskRat[u];
								partj=0;
								parti=0;
								partij=0;
								for(v=0,sv=su,vv=0;v<n;++v,sv++,vv+=v)
								{
									if(*sv==1)
									{
										part+=w[v]*INFO->Qw[v];
										if(pi<v)
											parti+=w[v]*INFO->Q[vv+pi]-CI*INFO->Qw[pi];
										else if(v<pi)
											parti+=w[v]*INFO->Q[pii+v]-CI*INFO->Qw[pi];
										else if(pi==v)
											parti+=w[v]*INFO->Q[vv+v]+(1.0-CI)*INFO->Qw[v];
										if(pj<v)
											partj+=w[v]*INFO->Q[vv+pj]-CI*INFO->Qw[pj];
										else if(v<pj)
											partj+=w[v]*INFO->Q[pjj+v]-CI*INFO->Qw[pj];
										else if(pj==v)
											partj+=w[v]*INFO->Q[vv+v]+(1.0-CI)*INFO->Qw[v];
										if(pi==v&&pi==pj)
											partij+=(2-CI)*INFO->Q[pii+pj];
										else if(pi==v&&pi>pj)
											partij+=(1-CI)*INFO->Q[pii+pj];
										else if(pi==v&&pi<pj)
											partij+=(1-CI)*INFO->Q[pjj+pi];
										else if(pj==v&&pi>pj)
											partij+=(1-CI)*INFO->Q[pii+pj];
										else if(pj==v&&pi<pj)
											partij+=(1-CI)*INFO->Q[pjj+pi];
										else if(pi>pj)
											partij+=-CI*INFO->Q[pii+pj];
										else if(pi<pj)
											partij+=-CI*INFO->Q[pjj+pi];
									}
								}
								H[ii+j]+=2.0*(parti*partj + part*partij);
							}
						}
					}
				}
			}
		}
	}
	else
	{
		size_t i1=0;
		if(INFO->nsame)i1=n-INFO->nsame;
		for(i=i1,ii=i1*(i1+1)>>1;i<INFO->nsect;++i,ii+=i)
		{
			for(j=i1,jj=i1*(i1+1)>>1;j<=i;++j,jj+=j)
			{
				for(v=0,vv=0;v<INFO->nsect;++v,vv+=v)
				{
					part=w[v]*INFO->Qw[v]-var*INFO->RiskRat[v];
					CI=2.0*INFO->RiskRat[v];
					if(i<v)
						parti=w[v]*INFO->Q[vv+i]-CI*INFO->Qw[i];
					else if(v<i)
						parti=w[v]*INFO->Q[ii+v]-CI*INFO->Qw[i];
					else if(i==v)
						parti=w[v]*INFO->Q[vv+v]+(1.0-CI)*INFO->Qw[v];
					if(j<v)
						partj=w[v]*INFO->Q[vv+j]-CI*INFO->Qw[j];
					else if(v<j)
						partj=w[v]*INFO->Q[jj+v]-CI*INFO->Qw[j];
					else if(j==v)
						partj=w[v]*INFO->Q[vv+v]+(1.0-CI)*INFO->Qw[v];
					if(i==v&&i==j)
						partij=(2-CI)*INFO->Q[ii+j];
					else if(i==v&&i!=j)
						partij=(1-CI)*INFO->Q[ii+j];
					else if(j==v&&i!=j)
						partij=(1-CI)*INFO->Q[ii+j];
					else
						partij=-CI*INFO->Q[ii+j];
					H[ii+j]+=2.0*(parti*partj + part*partij);
				}
			}
		}
	}
}

extern "C" double ParityUOld(dimen n,vector w,void* info)
{
	ParityInfo *INFO=(ParityInfo*)info;

	size_t nn=n*(n+1)>>1;
	size_t i,j;
	if(INFO->nf==-1)
		dsmxmulv(n,INFO->Q,w,INFO->Qw);
	else
		facmulold(n,INFO->nf,INFO->Qf,w,INFO->Qw);
	double back=0,var=ddotvec(n,w,INFO->Qw),part;
	if(INFO->nsame)
		var=ddotvec(INFO->nsame,w+n-INFO->nsame,INFO->Qw+n-INFO->nsame);
	vector ss,sj;

	if(INFO->sectors)
	{
		for(i=0,ss=INFO->sectors;i<INFO->nsect;++i,ss+=n)
		{
			part=-var*INFO->RiskRat[i];
			for(j=0,sj=ss;j<n;++j,sj++)
			{
				if(*sj==1)
				{
					part+=w[j]*INFO->Qw[j];
				}
			}
			back+=part*part;
		}
	}
	else
	{
		size_t i1=0;
		if(INFO->nsame)i1=n-INFO->nsame;
		for(i=i1;i<INFO->nsect;++i)
		{
			part=w[i]*INFO->Qw[i]-var*INFO->RiskRat[i];
			back+=part*part;
		}
	}
	return back+1;
}

extern "C" void ParityGradUOld(dimen n,vector w,vector grad,void*info)
{
	ParityInfo *INFO=(ParityInfo*)info;
	if(INFO->nf==-1)
		dsmxmulv(n,INFO->Q,w,INFO->Qw);
	else
		facmulold(n,INFO->nf,INFO->Qf,w,INFO->Qw);
	double back=0,var=ddotvec(n,w,INFO->Qw),part,partk,CI;
	if(INFO->nsame)
		var=ddotvec(INFO->nsame,w+n-INFO->nsame,INFO->Qw+n-INFO->nsame);
	size_t i,j,k,kk,jj,ii;
	vector ss,sj;

	dzerovec(n,grad);
	if(INFO->sectors)
	{
		for(i=0,ss=INFO->sectors,ii=0;i<INFO->nsect;++i,ii+=i,ss+=n)
		{
			CI=2.0*INFO->RiskRat[i];
			for(k=0,kk=0;k<n;++k,kk+=k)
			{
				part=-var*INFO->RiskRat[i];
				partk=-CI*INFO->Qw[k];
				for(j=0,sj=ss,jj=0;j<n;++j,jj+=j,sj++)
				{
					if(*sj==1)
					{
						part+=w[j]*INFO->Qw[j];
						partk+=w[j]*INFO->Q[(k>j?kk+j:jj+k)];
						if(j==k)partk+=INFO->Qw[k];
					}
				}
				grad[k]+=2.0*part*partk;
			}
		}
	}
	else
	{
		size_t i1=0;
		if(INFO->nsame)i1=n-INFO->nsame;
		for(i=i1,ii=i1*(i1+1)>>1;i<INFO->nsect;++i,ii+=i)
		{
			CI=2.0*INFO->RiskRat[i];
			part=w[i]*INFO->Qw[i]-var*INFO->RiskRat[i];
			for(k=0,kk=0;k<n;++k,kk+=k)
			{
				partk=w[i]*INFO->Q[(k>i?kk+i:ii+k)]-CI*INFO->Qw[k];
				if(i==k)partk+=INFO->Qw[k];
				grad[k]+=2.0*part*partk;
			}
		}
	}
}
void FiniteDiffGrad(dimen n,vector x,vector g,void*info)
{//Generate numerical first derivatives one-sided if necessary
	ForUpdates *Passer=(ForUpdates*)info;
	if(Passer->ModDeriv&&Passer->gradinfo)
	{
		Passer->ModDeriv(n,x,g,Passer->gradinfo);
	}
	else
	{
		size_t i;
		double eps=1e-8,gbase=Passer->Util(n,x,Passer->Uinfo);
		std::valarray<double>xe(n);
		dcopyvec(n,x,&xe[0]);
		for(i=0;i<n;++i)
		{
			xe[i]+=eps;
			g[i]=(Passer->Util(n,&xe[0],Passer->Uinfo)-gbase)/eps;
			xe[i]-=eps;
		}
	}
	if(Passer->BFGS)
	{
		Passer->count++;
		dcopyvec(n,Passer->xnow,Passer->xpast);
		dcopyvec(n,Passer->gnow,Passer->gpast);
		dcopyvec(n,x,Passer->xnow);
		dcopyvec(n,g,Passer->gnow);
	}
}
void BFGSHess(dimen n,vector x,vector h,void*info)
{//Generate a psuedo Hessian using BFGS updates
	ForUpdates *Passer=(ForUpdates*)info;
    size_t i,j,ij,nn=n*(n+1)>>1;
    std::valarray<double>dx(n),dg(n),implied;
    dsubvec(n,x,Passer->xpast,&dx[0]);
    dsubvec(n,Passer->gnow,Passer->gpast,&dg[0]);
    double bot1=ddotvec(n,&dx[0],&dg[0]),bot2,botmod;
    if(Passer->count>1&&ddotvec(n,&dx[0],&dx[0]) > 1e-15)
    {
        implied.resize(n);
        dsmxmulv(n,Passer->hnow,&dx[0],&implied[0]);
        bot2=ddotvec(n,&dx[0],&implied[0]);
        for(i=0,ij=0;i<n;++i)
        {
            if(implied[i])
            {
                botmod=implied[i]/bot2;
                for(j=0,ij=i*(i+1)>>1;j<=i;++j,ij++)
                    Passer->hnow[ij]-=botmod*implied[j];
            }
            if(dg[i]&&bot1)//Must never divide by bot1 if it is zero, so can't update in this case
            {
                botmod=dg[i]/bot1;
                for(j=0,ij=i*(i+1)>>1;j<=i;++j,ij++)
                    Passer->hnow[ij]+=botmod*dg[j];
            }
        }
    }
    else if(Passer->count==1&&Passer->hnow[0]==0)
    {//Start with unit matrix unless there is something better.
        for(i=0,ij=0;i<n;++i)
        {
            for(j=0;j<=i;++j,++ij)
            {
                if(i==j)Passer->hnow[ij]=1;
                else Passer->hnow[ij]=0;
            }
        }
    }
    dcopyvec(nn,Passer->hnow,h);
}
#ifdef _OPENMP
#include<omp.h>
#endif

extern "C" void ParityHessUOld(dimen n,vector w,vector H,void*info)
{
	ParityInfo *INFO=(ParityInfo*)info;
	if(INFO->nf==-1)
		dsmxmulv(n,INFO->Q,w,INFO->Qw);
	else
		facmulold(n,INFO->nf,INFO->Qf,w,INFO->Qw);
	double back=0,var=ddotvec(n,w,INFO->Qw),part,partk,partl,partkl,CI;
	if(INFO->nsame)
		var=ddotvec(INFO->nsame,w+n-INFO->nsame,INFO->Qw+n-INFO->nsame);
	long i,j,k,l,kl,nn=n*(n+1)>>1,ii,jj,kk,ll;
	vector ss,sj;
//	double pen=0;

	dzerovec(nn,H);

	if(INFO->sectors)
	{
		for(i=0,ss=INFO->sectors,ii=0;i<INFO->nsect;++i,ii+=i,ss+=n)
		{
			CI=2.0*INFO->RiskRat[i];
			for(k=0,kk=0,kl=0;k<n;++k,kk+=k)
			{
				for(l=0,ll=0;l<=k;++l,kl++,ll+=l)
				{
					part=-var*INFO->RiskRat[i];
					partk=-CI*INFO->Qw[k];
					partl=-CI*INFO->Qw[l];
					partkl=-CI*INFO->Q[kl];
					for(j=0,sj=ss,jj=0;j<n;++j,jj+=j,sj++)
					{
						if(*sj==1)
						{
							part+=w[j]*INFO->Qw[j];
							partk+=w[j]*INFO->Q[(k>j?kk+j:jj+k)];
							partl+=w[j]*INFO->Q[(l>j?ll+j:jj+l)];
							partkl+=INFO->Q[kl];

							if(j==k)
							{
								partk+=INFO->Qw[k];partkl+=INFO->Q[kl];
							}
							if(j==l)
								partl+=INFO->Qw[l];
						}
					}

					H[kl]+=2*(partk*partl + part*partkl);
//					if(i==0&&l==k)H[kl]+=pen;
				}
			}
		}
	}
	else
	{
#ifdef _OPENMP
		if(n>500)
		{
			for(i=0,ii=0;i<INFO->nsect;++i,ii+=i)
			{
				CI=2.0*INFO->RiskRat[i];
				part=w[i]*INFO->Qw[i]-var*INFO->RiskRat[i];
#pragma omp parallel
				{
#pragma omp for private(k,kk,kl,l,ll,partk,partl,partkl) schedule(dynamic) nowait
					for(k=0;k<n;++k)
					{
						kk=k*(k+1)>>1;
						for(l=0,ll=0;l<=k;++l,ll+=l)
						{
							kl=kk+l;
							partk=w[i]*INFO->Q[(k>i?kk+i:ii+k)];
							partl=w[i]*INFO->Q[(l>i?ll+i:ii+l)];
							partkl=INFO->Q[kl];

							if(i==k)
							{
								partk+=INFO->Qw[k];partkl+=INFO->Q[kl];
							}
							if(i==l)
								partl+=INFO->Qw[l];
							partk-=CI*INFO->Qw[k];
							partl-=CI*INFO->Qw[l];
							partkl-=CI*INFO->Q[kl];

							H[kl]+=2.0*(partk*partl + part*partkl);
						}
					}
				}
			}
		}
		else//Don't bother about omp for a small number of assets
		{
			for(i=0,ii=0;i<INFO->nsect;++i,ii+=i)
			{
				CI=2.0*INFO->RiskRat[i];
				part=w[i]*INFO->Qw[i]-var*INFO->RiskRat[i];
				for(k=0,kk=0,kl=0;k<n;++k,kk+=k)
				{
					for(l=0,ll=0;l<=k;++l,kl++,ll+=l)
					{
						partk=w[i]*INFO->Q[(k>i?kk+i:ii+k)];
						partl=w[i]*INFO->Q[(l>i?ll+i:ii+l)];
						partkl=INFO->Q[kl];

						if(i==k)
						{
							partk+=INFO->Qw[k];partkl+=INFO->Q[kl];
						}
						if(i==l)
							partl+=INFO->Qw[l];
						partk-=CI*INFO->Qw[k];
						partl-=CI*INFO->Qw[l];
						partkl-=CI*INFO->Q[kl];

						H[kl]+=2.0*(partk*partl + part*partkl);
					}
				}
			}
		}
#else
		size_t i1=0;
		if(INFO->nsame)i1=n-INFO->nsame;
		for(i=i1,ii=i1*(i1+1)>>1;i<INFO->nsect;++i,ii+=i)
		{
			CI=2.0*INFO->RiskRat[i];
			part=w[i]*INFO->Qw[i]-var*INFO->RiskRat[i];
			for(k=0,kk=0,kl=0;k<n;++k,kk+=k)
			{
				for(l=0,ll=0;l<=k;++l,kl++,ll+=l)
				{
					partk=w[i]*INFO->Q[(k>i?kk+i:ii+k)];
					partl=w[i]*INFO->Q[(l>i?ll+i:ii+l)];
					partkl=INFO->Q[kl];

					if(i==k)
					{
						partk+=INFO->Qw[k];partkl+=INFO->Q[kl];
					}
					if(i==l)
						partl+=INFO->Qw[l];
					partk-=CI*INFO->Qw[k];
					partl-=CI*INFO->Qw[l];
					partkl-=CI*INFO->Q[kl];

					H[kl]+=2.0*(partk*partl + part*partkl);
//					if(i==0&&l==k)H[kl]+=pen;
				}
			}
		}
#endif
	}
}

extern "C" DLLEXPORT short OptimiseNLC_Seq(dimen n,vector x,vector y,vector z,dimen m,pConstraintFunc GenAb,void* Abinfo,pUtility F,pModC gradF,pModQ hessF,
	void *Uinfo,void *Minfo,void *Qinfo,double tol=1e-12,int*iter=0,int log=0,double nu=0.075,vector lower=0,vector upper=0);

extern "C"  void OnlyBudgetConstraint(dimen n,dimen m,vector x,vector y,vector j,vector h,vector g,void*info)
{
#ifdef __SYSNT__
	_ASSERT(m==1);
#endif
	g[0]=1.0 - dsumvec(n,x);
	if(j)
	{
		dsetvec(n,-1.0,j);
	}
}

extern "C" DLLEXPORT size_t findzero(size_t n,vector w)
{
	size_t i,back=n;
	for(i=0;i<n;++i)
	{
		if(w[i]<lm_rooteps)
		{
			back=i;std::cout<<"\e[1;1;34mLowest zero w index is "<<back<<" "<<w[i]<<"\e[0;m"<<std::endl;
			break;
		}
	}
	return back;
}
extern "C" DLLEXPORT bool parity_check(size_t n,long nfac,vector w,vector alpha,vector Q,vector FL,vector FC,vector SV,size_t nsect=0,vector sectors=0)
{
	std::vector<double> MCTR;
	MCTR.resize(n);
	double areturn,arisk,ratio;
	vector pMCTR=&MCTR.front(),pw=w;
	bool back=false;
	PropertiesCA(n,nfac,0,w,0,alpha,0,&areturn,0,0,Q,0,&arisk,0,0,0,0,0,&MCTR.front(),0,0,0,0,0,0,0,0,0,0,0,0,0,FL,FC,SV,0,0);
	if(!nsect)
	{
		for(size_t i=0;i<n&&!back;++i,pMCTR++,pw++)
		{
			ratio=(*pMCTR * *pw)/arisk;std::cout<<"\e[1;1;33m"<<i+1<<" of "<<n<<" "<<ratio<<" "<<1.0/n<<" "<<ratio-1.0/n<<"\e[0;m"<<std::endl;
			if(fabs(ratio - 1.0/n) > lm_rooteps)
				back=true;
		}
	}
	else
	{
		for(size_t i=0,j=0;i<nsect&&!back;++i)
		{
			ratio=0;
			for(j=0,pMCTR=&MCTR.front(),pw=w;j<n;++j,pMCTR++,pw++)
			{
				if(sectors[i*n+j])
					ratio+=(*pMCTR * *pw);
			}
			if(fabs(ratio/arisk - 1.0/nsect) > lm_rooteps)
				back=true;
		}
	}
	return back;
}


extern "C" DLLEXPORT short RiskParitySolve(dimen n,dimen nsect,long nf,vector w,vector alpha,
										 vector sectors,vector SV,vector FC,vector FL,double*conc,int BFGS=0,int DiffGrad=0)
{
	std::ofstream outFile;
	char*outfile=(char*)"riskparity.log";
	time_t	timenow;
	time(&timenow);
	
	if(outfile&&!strlen(outfile))//In case someone sends outfile=(char*)""
	{
		std::cout<<"No output file was given"<<std::endl;
		outfile=0;
	}
	if(outfile)
	{
		//parity log outFile.open(outfile,std::ios_base::in);
		if(true||outFile.fail())
		{
			outFile.open(outfile,std::ios_base::out);
		}
		else
		{
			outFile.close();
			outFile.clear();
			char aa[50];
			char*aaaa=aa;
			sprintf(aaaa,(char*)"parity%ld.log",timenow);
			outFile.open(aaaa,std::ios_base::out);
		}
		if(outFile.fail())
		{
			std::cout<<"Cannot open "<<outfile<<std::endl;
		}
		else
		{
			dumpvector(1,(char*)"n",&n,outFile);
			dumpvector(1,(char*)"nsect",&nsect,outFile);
			dumpvector(1,(char*)"nfac",&nf,outFile);
			dumpvector(n,(char*)"alpha",alpha,outFile);
			if(sectors)dumpvector(n*nsect,(char*)"sectors",sectors,outFile);
			else dumpvector(0,(char*)"sectors",sectors,outFile);
			if(nf>-1)
			{
				if(SV&&FC&&FL)
				{
					dumpvector(n,(char*)"SV",SV,outFile);
					dumpvector(n*nf,(char*)"FL",FL,outFile);
					dumpvector(nf*(nf+1)/2,(char*)"FC",FC,outFile,nf);
				}
				else if(FC)
				{
					dumpvector(n,(char*)"SV",SV,outFile);
					dumpvector(n*nf,(char*)"FL",FL,outFile);
					dumpvector(n*(nf+1),(char*)"FC",FC,outFile,nf);
				}
			}
			else if(nf==-1)
			{
				dumpvector(0,(char*)"SV",SV,outFile);
				dumpvector(0,(char*)"FL",FL,outFile);
				dumpvector(n*(n+1)/2,(char*)"FC",FC,outFile,n);
			}
			dumpvector(1,(char*)"BFGS",&BFGS,outFile,100000);
			dumpvector(1,(char*)"DiffGrad",&DiffGrad,outFile);
			outFile<<"-------------------------------------------------------------------------------------------";
			outFile.close();
			outFile.clear();
		}
	}

#ifdef PAS
//	UnlockBita((char*)"colincolin");
	if(!Optimise::bitago)
	{
		fprintf(stderr,(char*)"Bad PAS key\n");
		return -1;
	}
	return -1;
#endif
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	//Solve the risk parity conditions by optimising their sum of squares
	short back=-1;
	//Allow Hessian update and finite difference gradients as options for testing. Risk parity works best with exact 1st and 2nd derivatives
	size_t nn=n*(n+1)>>1;
	double covscale,rcovscale,var;
	ParityInfo MainInfo;

	pUtility	PU	=	ParityUV;
	pModC		PGU	=	ParityGradUV;
	pModQ		PHU	=	ParityHessUV;


	size_t nvab=n,nvabnvab=nvab*(nvab+1)>>1;
	std::valarray<double> ww;
	vector wkeep=w;

#if 0
	PU	=	ParityU;
	PGU	=	ParityGradU;
	PHU	=	ParityHessU;
#else
	ww.resize(nvab);
	w=&ww[0];
#endif


	MainInfo.ModDeriv=(DiffGrad==1)?0:PGU;
	MainInfo.gradinfo=&MainInfo;
	MainInfo.BFGS=BFGS==1;
	MainInfo.lower=0;
	std::valarray<double>Qw(n),H(nn),Q;
	Qw=0;
	H=0;
	MainInfo.Qw=&Qw[0];
	MainInfo.sectors=sectors;
	MainInfo.nsect=nsect;
	MainInfo.nsame=0;
	MainInfo.Q=&H[0];
	MainInfo.nf=nf;
	MainInfo.nstocks=n;

	std::valarray<double>keepers;
	
	if(MainInfo.BFGS)
	{
		keepers.resize(4*n+nn);
		keepers=0;
		MainInfo.count=0;
		MainInfo.xnow=&keepers[0];
		MainInfo.xpast=&keepers[nvab];
		MainInfo.gnow=&keepers[nvab+nvab];
		MainInfo.gpast=&keepers[nvab+nvab+nvab];
		MainInfo.hnow=&keepers[nvab+nvab+nvab+nvab];
	}

	if(nf==-1)
	{
		dcopyvec(n*(n+1)/2,FC,&H[0]);
	}
	else
	{
		Q.resize(n*(nf+1));
		MainInfo.Qf=&Q[0];
		if(FL&&SV&&FC)factor_model_process(n,nf,FL,FC,SV,&Q[0]);
		else if(FC) MainInfo.Qf=FC;
		Factor2Cov(n,nf,FC,FL,SV,&H[0]);
	}

	//Scale the covariance constraint when largest covariance is less than 1
	double mm1,mm2;
	dxminmax(nn,&H[0],1,&mm1,&mm2);
	if((covscale=dmax(mm1,mm2))<1)
		covscale=1000./covscale;
	else
		covscale=1./covscale;
//parity log printf((char*)"covscale is %20.8f\n",covscale);

	std::valarray<double>RiskRat(nsect);
	MainInfo.RiskRat=&RiskRat[0];
	dsetvec(nsect,1./nsect,&RiskRat[0]);

	size_t m=1;
	std::valarray<double> A(m*nvab),L(nvab+m),U(nvab+m),initial(nvab);
	initial=0;
	std::valarray<int>shake(nvab);
	double gamma,ogamma;
	gamma=ogamma=0;
	dsetvec(nvab,0,&L[0]);
	dsetvec(nvab,1,&U[0]);
	dset(nvab,1,&A[0],m);

	L[nvab]=U[nvab]=1;
	if(m>1)
	{
		L[nvab+1]=.48924;U[nvab+1]=1;
		dcopy(nvab,alpha,1,&A[1],m);
	}

	std::valarray<double>HH(nvabnvab),aalpha(nvab);
	HH=0;
	aalpha=0;

	dscalvec(nn,covscale,MainInfo.Q);
	if(nf!=-1)
	{
		rcovscale=sqrt(covscale);
		dscalvec(n,covscale,MainInfo.Qf);
		dscalvec(n*nf,rcovscale,MainInfo.Qf+n);
	}

	pModQ Hesser=BFGS?BFGSHess:PHU;
	pUtility Util=PU;
	double AugLambda=0;
	std::valarray<double>Lambda;

	dsetvec(nvab,1.0/nvab,w);
	dsmxmulv(MainInfo.nstocks,MainInfo.Q,w,MainInfo.Qw);
	if(w!=wkeep)
	{
		var=ddotvec(MainInfo.nstocks,w,MainInfo.Qw);
		MainInfo.mu=1;
		MainInfo.Utype=EntropyType;
		//			MainInfo.Utype=ConcentrationType;
		//			MainInfo.Utype=VarianceType;
		Lambda.resize(nsect);
		MainInfo.mu=MainInfo.resid(w,&Lambda[0]);
		Lambda=(-1.0/MainInfo.mu)*Lambda;
		MainInfo.lambda=&Lambda[0];
	//parity log 	printx(nsect,MainInfo.lambda);
		MainInfo.fac=1;
		MainInfo.mu=dmin(MainInfo.mu,.9);
	}
	if(BFGS)
	{
		if(PHU)
			PHU(nvab,w,MainInfo.hnow,&MainInfo);
		else
			ParityHessU(nvab,w,MainInfo.hnow,&MainInfo);
	}
	if(DiffGrad)
	{
		MainInfo.Util=Util;
		MainInfo.Uinfo=&MainInfo;
	}

	/*	back=Optimise_internalCVPAextcostslSaMSoft(n,-1,0,w,m,&A[0],&L[0],&U[0],&aalpha[0],0,&HH[0],gamma,&initial[0],-1,.5,-1,-1,0,0,0,0,1,-1,-1,0,0,0,&shake[0],0,0,1,0,0,0,0,0,0,0,0,
	Util,FiniteDiffGrad,Hesser,-1,-1,&ogamma,&MainInfo,&MainInfo,&MainInfo,0,0,1,(char*)"");*/
	double delt=0;
	back=OptimiseGeneral(nvab,w,m,&A[0],&L[0],&U[0],&aalpha[0],&HH[0],Util,FiniteDiffGrad,Hesser,&MainInfo,&MainInfo,&MainInfo);
	if(w!=wkeep)
	{
		std::valarray<double>resid(nsect),wlowest(nvab);
		double reduce=1e3,tau=1,deltold,deltmin;
		delt=0;
		size_t j=0;
		deltmin=delt=MainInfo.resid(w,&resid[0]);
		dcopyvec(nvab,w,&wlowest[0]);
	//parity log 	printf((char*)"\e[1;1;32m%d \e[1;1;35mmu %20.15e delt %20.15e\e[0m\n",back,MainInfo.mu,delt);
		while(delt > lm_eps8 /*&& reduce>lm_eps*lm_eps*/&&back!=6)
		{
			if(MainInfo.BFGS)MainInfo.count=0;
			j++;
			if(delt < reduce)// && j < 10)
			{
				daxpyvec(nsect,-1.0/MainInfo.mu,&resid[0],MainInfo.lambda);
//parity log 				printx(nsect,MainInfo.lambda);
			}
			else if(MainInfo.mu > lm_eps)
			{
				MainInfo.mu *= tau;
				if(MainInfo.mu < lm_eps)
					MainInfo.mu=lm_eps;
				j=0;
			}
			else
			{
				if(j>20)
				{
					dzerovec(nsect,MainInfo.lambda);j=0;
				}
				else if(fabs(reduce-delt)<=lm_eps){/*parity log printf((char*)"\e[1;1;36m %25.15e\e[0m\n",reduce-delt);*/break;}

				daxpyvec(nsect,-1.0/MainInfo.mu,&resid[0],MainInfo.lambda);
//parity log 				printx(nsect,MainInfo.lambda);
			}
			if(delt<deltmin)
			{
				deltmin=delt;dcopyvec(nvab,w,&wlowest[0]);
			}
			back=OptimiseGeneral(nvab,w,m,&A[0],&L[0],&U[0],&aalpha[0],&HH[0],Util,FiniteDiffGrad,Hesser,&MainInfo,&MainInfo,&MainInfo);
			deltold=delt;
			reduce=delt;
			delt=MainInfo.resid(w,&resid[0]);
			if(MainInfo.mu>lm_rooteps)
				reduce=10*exp(log(MainInfo.mu)*(0.05+0.95*j));
			if(MainInfo.mu<lm_rooteps)
				tau=0.2;
			else
				tau = dmin(0.2, (sqrt(MainInfo.mu)) );
	//parity log 		printf((char*)"\e[1;1;32m%d Fac %f \e[1;1;35mmu %20.15e delt %20.15e reduce %20.15e\e[0m\n",back,MainInfo.fac,MainInfo.mu,delt,reduce);
			if(delt<2e-6)
				MainInfo.Utype=VarianceType;
		}
		dcopyvec(nvab,&wlowest[0],w);
	}

	/*	int iter=1000;//This doesn't work as well as OptimiseGeneral

	std::valarray<double>y(1),z(nvab);
	y=0;
	z=1;
	dsetvec(nvab,1,w);
	back=OptimiseNLC_Seq(nvab,w,&y[0],&z[0],1,OnlyBudgetConstraint,0,Util,FiniteDiffGrad,Hesser,&MainInfo,&MainInfo,&MainInfo,0,&iter,1,1,0,0);
*/

	dscalvec(nn,1./covscale,MainInfo.Q);
	if(nf!=-1)
	{	
		dscalvec(n,1./covscale,MainInfo.Qf);
		dscalvec(n*nf,1./rcovscale,MainInfo.Qf+n);
	}

	*conc=ddotvec(n,w,w);
	if(!(w!=wkeep&&nvab==nsect))
	{
		double checkval=PU(nvab,w,&MainInfo)-1;
	//parity log 	printf((char*)"U = %20.8e\n",checkval);
		if(fabs(checkval)>lm_eps8)back=18;
	}
	else
	{
		double checkval=PU(nvab,w,&MainInfo);
	//parity log 	printf((char*)"\e[1;1;34mPU = %20.8e\e[0m\n",checkval);
		if(delt>lm_rooteps*2)
			back=18;
	}
	if(PGU)
	{
		PGU(nvab,w,&aalpha[0],&MainInfo);
	//parity log 	printf((char*)"Gradients of variables\n");
	//parity log 	printx(nvab,&aalpha[0]);
	}
	if(PHU)
	{
		PHU(nvab,w,&HH[0],&MainInfo);
		std::valarray<double>st(nvab*nvab),eig(nvab);
		dcopyvec(nvabnvab,&HH[0],&st[0]);
		packed2symm(nvab,&st[0]);
		short ee=eigendecomp(nvab,&st[0],&eig[0],100);

//parity log		printf((char*)"%d (0 is ok) Hessian eigenvalues at end\n",ee);
//parity log		printf((char*)"back %d\n",back);
	/*	if(eig[n-2]<0.0)
		{
			//printf((char*)"eig[n-2] is %20.8f\n",eig[n-2]);
			if(back==0)back=18;
		}*/
//parity log		printx(nvab,&eig[0]);
	}
//parity log	printf((char*)"Expected return %20.8f\n",ddotvec(n,alpha,w));
	if(w!=wkeep)
		dcopyvec(MainInfo.nstocks,w,wkeep);

	return back;
}
extern "C" DLLEXPORT short RiskParitySolveF(dimen n,dimen nsect,long nf,vector w,vector alpha,
										 vector sectors,vector SV,vector FC,vector FL,vector first=0,size_t nsame=0,double*conc=0,int BFGS=0,int DiffGrad=0)
{
#ifdef PAS
//	UnlockBita((char*)"colincolin");
	if(!Optimise::bitago)
	{
		fprintf(stderr,(char*)"Bad PAS key\n");
		return -1;
	}
	return -1;
#endif
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	if(!first && !nsame)
	{
		return RiskParitySolve(n,nsect,nf,w,alpha,sectors,SV,FC,FL,conc,BFGS,DiffGrad);
	}

	double psuml,Rmin=-1,Rmax=-1;

	pUtility PU=ParityU;
	pModC PGU=ParityGradU;
	pModQ PHU=ParityHessU;


	//Solve the risk parity conditions by optimising their sum of squares
	short back=-1;
	//Allow Hessian update and finite difference gradients as options for testing. Risk parity works best with exact 1st and 2nd derivatives
	size_t nn=n*(n+1)>>1,i;


	double covscale,rcovscale;
	ParityInfo MainInfo;
	MainInfo.ModDeriv=(DiffGrad==1)?0:PGU;
	MainInfo.gradinfo=&MainInfo;
	MainInfo.BFGS=BFGS==1;
	MainInfo.nsame=nsame;
	std::valarray<double>Qw(n),H(nn),Q;
	MainInfo.Qw=&Qw[0];
	MainInfo.sectors=sectors;
	MainInfo.nsect=nsect;
	MainInfo.Q=&H[0];
	MainInfo.nf=nf;
	MainInfo.lower=0;
	Qw=0;
	H=0;

	std::valarray<double>keepers;
	
	if(MainInfo.BFGS)
	{
		keepers.resize(4*n+nn);
		keepers=0;
		MainInfo.count=0;
		MainInfo.xnow=&keepers[0];
		MainInfo.xpast=&keepers[n];
		MainInfo.gnow=&keepers[n+n];
		MainInfo.gpast=&keepers[n+n+n];
		MainInfo.hnow=&keepers[n+n+n+n];
	}

	if(nf==-1)
	{
		dcopyvec(n*(n+1)/2,FC,&H[0]);
	}
	else
	{
		Q.resize(n*(nf+1));
		MainInfo.Qf=&Q[0];
		factor_model_process(n,nf,FL,FC,SV,&Q[0]);
		Factor2Cov(n,nf,FC,FL,SV,&H[0]);
	}

	std::valarray<size_t>order(n*2);
	std::valarray<double>mags(n);
	bool change_order=false,have_RS=false;
	for(i=0;i<n;++i)//Reorder to make riskfree (if present) not to appear at the end
	{
		mags[i]=n-i;
		if(H[i*(i+3)/2]==0)
		{
			mags[i]=2*n-i;
			change_order=true;
		}
	}
	getorder(n,&mags[0],&order[0],0,0);
	for(i=0;i<n;++i)
		order[n+order[i]]=i;

	if(change_order)
	{
		Reorder_gen(n,&order[0],first,1);
		ReorderS(n,&order[0],&H[0]);
	}
	//Scale the covariance constraint when largest covariance is less than 1
	double mm1,mm2;
	dxminmax(nn,&H[0],1,&mm1,&mm2);
	if((covscale=dmax(mm1,mm2))<1)
		covscale=100./covscale;
	else
		covscale=1;
	printf((char*)"covscale is %20.8f\n",covscale);

	std::valarray<double>RiskRat(n);
	MainInfo.RiskRat=&RiskRat[0];
	if(nsame)dsetvec(n,1./nsame,&RiskRat[0]);
	else dsetvec(n,1./n,&RiskRat[0]);

	double gamma,ogamma,psum=0,nsum=0;
	for(i=0;i<n;++i)
	{
		if(first[i]<-lm_eps)nsum-=first[i];
		if(first[i]>lm_eps)psum+=first[i];
	}

	psuml=psum;
	size_t m=1;
	if(nsum)m++;
	std::valarray<double> A(m*n),L(n+m),U(n+m),initial(n);
	A=0;
	initial=0;
	std::valarray<int>shake(n);
	gamma=ogamma=0;


	for(i=n-nsame;i<n;++i)
	{
		if(first[i]<0){L[i]=-1;U[i]=0;}
		if(first[i]>=0){L[i]=0;U[i]=1;}
	}

	dcopyvec(n-nsame,first,&L[0]);
	dcopyvec(n-nsame,first,&U[0]);
	for(i=0;i<n;++i)
	{
		if(change_order&&H[i*(i+3)/2]==0)
		{
			U[i]=2;L[i]=0;have_RS=true;
		}
	}
	if(have_RS)m--;
	L[n]=U[n]=dsumvec(n,first);
	if(!have_RS)
	{
		L[n]=-2;U[n]=2;
		psuml=0;
		if(nsum)
		{
			for(i=0;i<n;++i)
			{
				if(first[i]<0)A[i*m+1]=1;
			}
			L[n+1]=-nsum;
			U[n+1]=-nsum;
		}
	}
	dset(n,1,&A[0],m);
	std::valarray<double>HH(nn),aalpha(n);
	HH=0;
	aalpha=0;

	dscalvec(nn,covscale,MainInfo.Q);
	if(nf!=-1)
	{
		rcovscale=sqrt(covscale);
		dscalvec(n,covscale,MainInfo.Qf);
		dscalvec(n*nf,rcovscale,MainInfo.Qf+n);
	}

	pModQ Hesser=BFGS?BFGSHess:PHU;
	pUtility Util=PU;

	if(BFGS)
	{
		dsetvec(n,1./n,w);
		PHU(n,w,MainInfo.hnow,&MainInfo);
	}
	if(DiffGrad)
	{
		MainInfo.Util=Util;
		MainInfo.Uinfo=&MainInfo;
	}

	int ls=0;
	if(nsum&&have_RS)ls=1;
	back=Optimise_internalCVPAextcostslSaMSoft(n,-1,0,w,m,&A[0],&L[0],&U[0],&aalpha[0],0,&HH[0],gamma,&initial[0],-1,.5,-1,-1,0,0,0,ls,0,Rmin,Rmax,0,0,0,&shake[0],0,0,psum,0,0,0,0,0,0,0,0,
		Util,FiniteDiffGrad,Hesser,-1,-1,&ogamma,&MainInfo,&MainInfo,&MainInfo,0,0,1,(char*)"",1,0,3,-1,-1,-1,-1,1,1,1,psuml);

	//back=OptimiseGeneral(n,w,m,&A[0],&L[0],&U[0],&aalpha[0],&HH[0],Util,FiniteDiffGrad,Hesser,&MainInfo,&MainInfo,&MainInfo);

	dscalvec(nn,1./covscale,MainInfo.Q);
	if(nf!=-1)
	{	
		dscalvec(n,1./covscale,MainInfo.Qf);
		dscalvec(n*nf,1./rcovscale,MainInfo.Qf+n);
	}

	if(conc)*conc=ddotvec(n,w,w);
	double checkval=PU(n,w,&MainInfo)-1;
	printf((char*)"U = %20.8e\n",checkval);
	if(fabs(checkval)>1e-15)back=18;
	PGU(n,w,&aalpha[0],&MainInfo);
	printf((char*)"Gradients of variables\n");
	printx(n,&aalpha[0]);
	PHU(n,w,&HH[0],&MainInfo);
	std::valarray<double>st(n*n),eig(n);
	dcopyvec(nn,&HH[0],&st[0]);
	packed2symm(n,&st[0]);
	short ee=eigendecomp(n,&st[0],&eig[0],100);
	if(back==0&&eig[n-2]<0)back=18;
	printf((char*)"%d Hessian eigenvalues at end\n",ee);
	printx(n,&eig[0]);
	printf((char*)"Expected return %20.8f\n",ddotvec(n,alpha,w));
	if(change_order)
	{
		Reorder_gen(n,&order[n],first,1);
		Reorder_gen(n,&order[n],w,1);
		ReorderS(n,&order[n],&H[0]);
	}
	return back;
}

class Sharpinfo:public ForUpdates
{
public:
	long nf;		//Numbe of factors -1 for full covariance
	vector Q;		//historic covariance or compressed factor model 
	vector alpha;	//expected returns
	vector implied;	//space for Q.w
	vector COV;		//covarinaces from factor model 
	vector benchmark;
};

extern "C" double SharpRatio(dimen n,vector w,void *info)
{
	Sharpinfo *SI=(Sharpinfo*)info;
	if(SI->benchmark)dsubvec(n,w,SI->benchmark,w);
	double ret=ddotvec(n,w,SI->alpha);
	if(SI->nf>-1)
		facmulold(n,SI->nf,SI->Q,w,SI->implied);
	else
		dsmxmulv(n,SI->Q,w,SI->implied);
	double risk=sqrt(ddotvec(n,w,SI->implied));
	if(SI->benchmark)daddvec(n,w,SI->benchmark,w);
	return -ret/risk;//minus as we really want to maximise
}
extern "C" double SharpRatioI(dimen n,vector w,void *info)
{
	Sharpinfo *SI=(Sharpinfo*)info;
	if(SI->benchmark)dsubvec(n,w,SI->benchmark,w);
	double ret=ddotvec(n,w,SI->alpha);
	if(SI->nf>-1)
		facmulold(n,SI->nf,SI->Q,w,SI->implied);
	else
		dsmxmulv(n,SI->Q,w,SI->implied);
	double risk=sqrt(ddotvec(n,w,SI->implied));
	if(SI->benchmark)daddvec(n,w,SI->benchmark,w);
	return risk/ret;//reciprical as we really want to maximise
}

extern "C" void SharpGrad(dimen n,vector w,vector grad,void *info)
{
	Sharpinfo *SI=(Sharpinfo*)info;
	if(SI->benchmark)dsubvec(n,w,SI->benchmark,w);
	double ret=ddotvec(n,w,SI->alpha);
	if(SI->nf>-1)
		facmulold(n,SI->nf,SI->Q,w,SI->implied);
	else
		dsmxmulv(n,SI->Q,w,SI->implied);
	double var,risk=sqrt((var=ddotvec(n,w,SI->implied)));
	if(SI->benchmark)daddvec(n,w,SI->benchmark,w);
	dcopyvec(n,SI->alpha,grad);
	daxpyvec(n,-ret/var,SI->implied,grad);
	dscalvec(n,-1./risk,grad);//minus as we really want to maximise
}
extern "C" void SharpGradI(dimen n,vector w,vector grad,void *info)
{
	Sharpinfo *SI=(Sharpinfo*)info;
	if(SI->benchmark)dsubvec(n,w,SI->benchmark,w);
	double ret=ddotvec(n,w,SI->alpha);
	if(SI->nf>-1)
		facmulold(n,SI->nf,SI->Q,w,SI->implied);
	else
		dsmxmulv(n,SI->Q,w,SI->implied);
	double var,risk=sqrt((var=ddotvec(n,w,SI->implied)));
	if(SI->benchmark)daddvec(n,w,SI->benchmark,w);
	dcopyvec(n,SI->alpha,grad);
	dscalvec(n,-risk/ret,grad);
	daxpyvec(n,1./risk,SI->implied,grad);
	dscalvec(n,1./ret,grad);
}


extern "C" void SharpHess(dimen n,vector w,vector hess,void *info)
{
	Sharpinfo *SI=(Sharpinfo*)info;
	if(SI->benchmark)dsubvec(n,w,SI->benchmark,w);
	double ret=ddotvec(n,w,SI->alpha);
	if(SI->nf>-1)
		facmulold(n,SI->nf,SI->Q,w,SI->implied);
	else
		dsmxmulv(n,SI->Q,w,SI->implied);
	double var,risk=sqrt((var=ddotvec(n,w,SI->implied)));
	if(SI->benchmark)daddvec(n,w,SI->benchmark,w);
	size_t i,j,ij;
	if(SI->nf==-1)
	{
		for(i=0,ij=0;i<n;++i)
		{
			for(j=0;j<=i;++j,ij++)
			{
				hess[ij]=-((3.0*SI->implied[i]*SI->implied[j]/var-SI->Q[ij])*ret - SI->alpha[i]*SI->implied[j] - SI->alpha[j]*SI->implied[i])/var/risk;//minus as we really want to maximise
			}
		}
	}
	else
	{
		for(i=0,ij=0;i<n;++i)
		{
			for(j=0;j<=i;++j,ij++)
			{
				hess[ij]=-((3.0*SI->implied[i]*SI->implied[j]/var-SI->COV[ij])*ret - SI->alpha[i]*SI->implied[j] - SI->alpha[j]*SI->implied[i])/var/risk;//minus as we really want to maximise
			}
		}
	}
}
extern "C" void SharpHessI(dimen n,vector w,vector hess,void *info)
{
	Sharpinfo *SI=(Sharpinfo*)info;
	if(SI->benchmark)dsubvec(n,w,SI->benchmark,w);
	double ret=ddotvec(n,w,SI->alpha);
	if(SI->nf>-1)
		facmulold(n,SI->nf,SI->Q,w,SI->implied);
	else
		dsmxmulv(n,SI->Q,w,SI->implied);
	double var,risk=sqrt((var=ddotvec(n,w,SI->implied)));
	if(SI->benchmark)daddvec(n,w,SI->benchmark,w);
	size_t i,j,ij;
	if(SI->nf==-1)
	{
		for(i=0,ij=0;i<n;++i)
		{
			for(j=0;j<=i;++j,ij++)
			{
				hess[ij]=SI->Q[ij]/risk/ret - SI->implied[i]*SI->implied[j]/risk/var/ret - SI->implied[i]*SI->alpha[j]/risk/ret/ret - SI->implied[j]*SI->alpha[i]/risk/ret/ret 
					+ 2*SI->alpha[i]*SI->alpha[j]*risk/ret/ret/ret;
			}
		}
	}
	else
	{
		for(i=0,ij=0;i<n;++i)
		{
			for(j=0;j<=i;++j,ij++)
			{
				hess[ij]=SI->COV[ij]/risk/ret - SI->implied[i]*SI->implied[j]/risk/var/ret - SI->implied[i]*SI->alpha[j]/risk/ret/ret - SI->implied[j]*SI->alpha[i]/risk/ret/ret 
					+ 2*SI->alpha[i]*SI->alpha[j]*risk/ret/ret/ret;
			}
		}
	}
}


extern "C" DLLEXPORT short SharpOpt(dimen n,dimen m,long nfac,vector w,vector benchmark,vector alpha,vector L,vector U,vector A,vector FC,vector SV,vector FL,int no_opt=0,int BFGS=0,int DiffGrad=0,int log=0)
{
#ifdef PAS
//	UnlockBita((char*)"colincolin");
	if(!Optimise::bitago)
	{
		fprintf(stderr,(char*)"Bad PAS key\n");
		return -1;
	}
	return -1;
#endif
	/*	This shows how to maximise Sharpe ratio using analytic first and second derivatives OR just function variables	*/
	/*	seems better to minimise risk/ret rather than -ret/risk */
	pModC useGrad=SharpGradI;
	pModQ useHess=SharpHessI;
	pUtility useU=SharpRatioI;
	int invert=0;
	size_t i;
	for(i=0;i<n;++i)
	{
		if(invert*alpha[i]<0)
		{
			invert=2;break;
		}
		if(alpha[i]<0)invert=-1;
		else invert=1;
	}
	if(benchmark||invert==2)
	{	//No good minimising risk/return as for active return we can easily get return=0 for risk/=0 for non minimal risk/return
		useGrad=SharpGrad;
		useHess=SharpHess;
		useU=SharpRatio;
	}
	size_t nn=n*(n+1)>>1;
	Sharpinfo SI;
	SI.BFGS=BFGS==1;
	SI.ModDeriv=DiffGrad?0:useGrad;
	SI.gradinfo=&SI;
	SI.nf=nfac;
	SI.Util=useU;
	SI.Uinfo=&SI;
	SI.benchmark=benchmark;
	std::valarray<double>implied(2*n),COV,Q,HH(nn),c(n);
	implied=0;
	SI.implied=&implied[0];
	SI.alpha=alpha;
	if(nfac==-1)
	{
		SI.Q=FC;
		SI.COV=0;
	}
	else
	{
		Q.resize(n*(nfac+1));
		SI.Q=&Q[0];
		COV.resize(nn);
		SI.COV=&COV[0];
		if(FL&&SV)factor_model_process(n,nfac,FL,FC,SV,&Q[0]);
		else dcopyvec(Q.size(),FC,&Q[0]);//In case FC is passed in as compressed matrix
		Factor2Cov(n,nfac,FC,FL,SV,&COV[0]);
	}
	HH=0;
	c=0;
	double gamma=.5,ogamma,kappa=.5;
	vector initial=&implied[n];
	std::valarray<int>shake(n);

	short back=-1;

	if(!no_opt)		//Bypass this optimisation so as to report first and second derivatives
	{
		std::valarray<double>xnow,xpast,gnow,gpast,hnow;
		if(SI.BFGS)
		{
			hnow.resize(nn);
			xnow.resize(n);
			xpast.resize(n);
			gnow.resize(n);
			gpast.resize(n);
			SI.xnow=&xnow[0];
			SI.xpast=&xpast[0];
			SI.gnow=&gnow[0];
			SI.gpast=&gpast[0];
			SI.hnow=&hnow[0];
			SI.count=0;
		}
		back=Optimise_internalCVPAextcostslSaMSoft(n,-1,0,w,m,A,L,U,&c[0],0,&HH[0],gamma,initial,-1,kappa,-1,-1,0,0,0,0,1,-1,-1,0,0,0,&shake[0],0,0,1,0,0,0,0,0,0,0,0,
			SI.Util,FiniteDiffGrad,BFGS?BFGSHess:useHess,-1,-1,&ogamma,&SI,&SI,&SI,0,0,log,(char*)"");
	}

	if(log)
	{
		std::valarray<double>active(n);
		dcopyvec(n,w,&active[0]);
		if(benchmark)dsubvec(n,&active[0],benchmark,&active[0]);
		double checkval=useU(n,w,&SI);
		if(useU==SharpRatioI)printf((char*)"Max. Sharp = %20.15e\n",1./checkval);
		else if(useU==SharpRatio)printf((char*)"Max. Sharp = %20.15e\n",-checkval);
		useGrad(n,w,&c[0],&SI);
		if(useU==SharpRatio)dnegvec(n,&c[0]);
		printf((char*)"grad.active %20.8f\n",ddotvec(n,&c[0],&active[0]));
		printf((char*)"Gradients of variables\n");
		printx(n,&c[0]);
		useHess(n,w,&HH[0],&SI);
		dsmxmulv(n,&HH[0],&active[0],initial);
		printf((char*)"0.5active.hess.active %20.8f\n",.5*ddotvec(n,initial,&active[0]));
		std::valarray<double>st(n*n),eig(n);
		dcopyvec(nn,&HH[0],&st[0]);
		packed2symm(n,&st[0]);
		short ee=eigendecomp(n,&st[0],&eig[0],100);
		printf((char*)"%d Hessian eigenvalues at end\n",ee);
		printx(n,&eig[0]);
		printf((char*)"Expected active return %20.8f\n",ddotvec(n,alpha,&active[0]));
		printf((char*)"Expected active risk %20.8f\n",sqrt(ddotvec(n,SI.implied,&active[0])));
	}
	return back;
}
class meritinfo
{
public:
	pUtility F;
	pConstraintFunc g;
	void*info;
	void*Cinfo;
	vector x,y,z,dx,dy,dz;
	vector lambda;
	vector A,b;
	double mu,nu,cexp,sigma;
	bool conc;
	dimen n,m;
	bool noz;
};

double MERIT(dimen n,dimen m,vector x,vector y,pUtility F,pConstraintFunc GenAb,void*Cinfo,double mu,double nu,double sigma,vector lambda,void*info)
{
	double back = F(n,x,info),barr;
	std::valarray<double>g(m);
	GenAb(n,m,x,y,0,0,&g[0],Cinfo);
	size_t i;

	if(sigma)
	{
		for(i=0,barr=0;i<m;++i)
			barr += square(g[i]);
		back+=barr*.5/sigma;
	}
	
	back+=ddotvec(m,&g[0],lambda);
	back-=ddotvec(m,&g[0],y);

	for(i=0,barr=0;i<m;++i)
		barr += square(g[i]-(lambda[i]-y[i])*sigma);
	back+=barr*.5*nu/sigma;
	
	return back;
}

double MERIT(dimen n,dimen m,vector x,vector y,vector z,pUtility F,pConstraintFunc GenAb,void*Cinfo,double mu,double nu,double sigma,vector lambda,void*info)
{
	if(!z)
	{
		return MERIT(n,m,x,y,F,GenAb,Cinfo,mu,nu,sigma,lambda,info);
	}
	double back = F(n,x,info),barr,b1;
	std::valarray<double>g(m);
	GenAb(n,m,x,y,0,0,&g[0],Cinfo);
	size_t i;
	if(sigma)
	{
		for(i=0,barr=0;i<m;++i)
			barr += square(g[i]);
		back+=barr*.5/sigma;
	}
	if(mu)
	{
		for(i=0,barr=0;i<n;++i)
			barr+=log(x[i]);
		back-=barr*mu;
	}

	back+=ddotvec(m,&g[0],lambda);
	back-=ddotvec(m,&g[0],y);
	for(i=0,barr=0;i<m;++i)
		barr += square(g[i]-(lambda[i]-y[i])*sigma);
	back+=barr*.5*nu/sigma;
	b1=0;
	if(true)
	{
		for(i=0,barr=0;i<n;++i)
			barr+=square(x[i]*z[i]-mu);
		b1=log((ddotvec(n,x,z)+barr)/n);
		for(i=0,barr=0;i<n;++i)
			barr+=log(x[i]*z[i]);
		b1-=(barr)/n;
	}
	return back+b1;
}
double MERIT_SEQ(dimen n,dimen m,vector x,vector y,vector z,pUtility F,pConstraintFunc GenAb,void*Cinfo,double mu,double nu,double cexp,void*info)
{
	double back = F(n,x,info);
	std::valarray<double>g(m);
	GenAb(n,m,x,y,0,0,&g[0],Cinfo);
//	back+=nu*linfinity(m,&g[0])/mu;
	if(mu)back+=linfinity(m,&g[0])*linfinity(m,y)/mu;
	return back;
}
double MERIT(dimen n,dimen m,vector x,vector y,vector z,pUtility F,vector A,vector b,double mu,double nu,bool conc,void*info)
{
	double back = F(n,x,info),barr;
	if(conc)m--;
	size_t i;
	for(i=0,barr=0;i<m;++i)
		barr += square(ddotvec(n,A+i*n,x)-b[i]);
	if(mu)back+=barr*.5/mu;
	
	for(i=0,barr=0;i<n;++i)
		barr+=log(x[i]);
	back-=barr*mu;
	for(i=0,barr=0;i<m;++i)
		barr += square(ddotvec(n,A+i*n,x)-b[i]+y[i]*mu);
	back+=barr*.5*nu;
	
	for(i=0,barr=0;i<n;++i)
		barr+=square(x[i]*z[i]-mu);
	back+=nu*log(ddotvec(n,x,z)/n+barr);
	for(i=0,barr=0;i<n;++i)
		barr+=log(x[i]*z[i]);
	back-=nu/n*(barr);
	if(conc)
	{
		barr=square(ddotvec(n,x,x)-b[m]);
		if(mu)back+=barr*.5/mu;
		barr=square(ddotvec(n,x,x)-b[m]+y[m]*mu);
		back+=barr*.5*nu;
	}
	return back;
}
double Path_merit(double step,void*info)//Minimise the merit function along a fixed path using PathMin
{
	meritinfo *Info=(meritinfo*)info;
	daxpyvec(Info->n,step,Info->dx,Info->x);
	daxpyvec(Info->m,step,Info->dy,Info->y);
	daxpyvec(Info->n,step,Info->dz,Info->z);
	double back=MERIT(Info->n,Info->m,Info->x,Info->y,Info->z,Info->F,Info->A,Info->b,Info->mu,Info->nu,Info->conc,Info->info);
	daxpyvec(Info->n,-step,Info->dx,Info->x);
	daxpyvec(Info->m,-step,Info->dy,Info->y);
	daxpyvec(Info->n,-step,Info->dz,Info->z);
	return back;
}
double Path_meritC(double step,void*info)//Minimise the merit function along a fixed path using PathMin
{
	meritinfo *Info=(meritinfo*)info;
	daxpyvec(Info->n,step,Info->dx,Info->x);
	//daxpyvec(Info->m,step,Info->dy,Info->y);
	if(!Info->noz)daxpyvec(Info->n,step,Info->dz,Info->z);
	double back;
	if(!Info->noz)back=MERIT(Info->n,Info->m,Info->x,Info->y,Info->z,Info->F,Info->g,Info->Cinfo,Info->mu,Info->nu,Info->sigma,Info->lambda,Info->info);
	else back=MERIT(Info->n,Info->m,Info->x,Info->y,Info->F,Info->g,Info->Cinfo,Info->mu,Info->nu,Info->sigma,Info->lambda,Info->info);
	daxpyvec(Info->n,-step,Info->dx,Info->x);
	//daxpyvec(Info->m,-step,Info->dy,Info->y);
	if(!Info->noz)daxpyvec(Info->n,-step,Info->dz,Info->z);
	return back;
}
double Path_merit_Seq(double step,void*info)//Minimise the merit function along a fixed path using PathMin
{
	meritinfo *Info=(meritinfo*)info;
	daxpyvec(Info->n,step,Info->dx,Info->x);
	double back;
	back=MERIT_SEQ(Info->n,Info->m,Info->x,Info->y,Info->z,Info->F,Info->g,Info->Cinfo,Info->mu,Info->nu,Info->cexp,Info->info);
	daxpyvec(Info->n,-step,Info->dx,Info->x);
	return back;
}
extern "C" DLLEXPORT short OptimiseGeneralBarrier(dimen n,vector x,vector y,vector z,dimen m,vector A,vector b,pUtility F,pModC gradF,pModQ hessF,
	void *Uinfo,void *Minfo,void *Qinfo,double nu=.6,double mudec=.5,double beta=.9,double e0=.001,int* iter=0)
{
	/*	min a general function F(w)
		such that A.w = b (m constraints)
		and w[i]>=0 i=0....n-1

		using a primal-dual method
	*/

	//Decide whether to use true or approximate derivatives
#ifdef __SYSNT__
	_ASSERT(0);
#endif

	bool iprint=false;
	ForUpdates Passer;
	Passer.Util=F;
	Passer.Uinfo=Uinfo;
	Passer.BFGS=hessF?false:true;
	Passer.ModDeriv=gradF?gradF:0;
	if(Passer.ModDeriv)
		Passer.gradinfo=Minfo;
	std::valarray<double>xnow,xpast,gnow,gpast,hnow;
	if(Passer.BFGS)
	{
		hnow.resize(n*(n+1)>>1);Passer.hnow=&hnow[0];
		xnow.resize(n);Passer.xnow=&xnow[0];
		xpast.resize(n);Passer.xpast=&xpast[0];
		gnow.resize(n);Passer.gnow=&gnow[0];
		gpast.resize(n);Passer.gpast=&gpast[0];
		Passer.count=0;
	}

	//We proceed like this
	pModC gradFhere=FiniteDiffGrad;
	pModQ hessFhere=hessF?hessF:BFGSHess;
	void* gradInfo=&Passer;
	void* hessInfo=hessF?Qinfo:&Passer;
	bool conc=true;

	size_t M=m;

	if(conc)m+=1;//For concentration

	std::valarray<double> dxy(n+m),dz(n);
	std::valarray<double> H((n+m)*(n+m+1)/2),r(n+m);
	std::valarray<Integer> piv(n+m);
	double stepx,stepz,xdz=1e8,step,Mc=.95;
	size_t i,j;

	for(i=0;i<n;++i)
	{
		z[i]=(double)n;
		x[i]=1./n;
	}
	for(i=0;i<m;i++)
	{
		y[i]=0;
	}
	double Primal=F(n,&x[0],Uinfo),M1,M2,DM=0;
	double Dual,mu,r_p=1,r_d=1,r_C=1,mu0=1,r_p0=1,r_d0=1,r_C0=1,beta1=1,stephere,gg;
	meritinfo MERIT_info; 

	hessFhere(n,&x[0],&H[0],hessInfo);

	size_t ik=0;

	mu0=mu=1;
	while(ik<1000&&(r_d>1e-10*r_d0||r_p>1e-10*r_p0||r_C>1e-10*r_C0))
	{
		if(ik&&iprint)printf((char*)"Iteration %3ld (%10.5f): Primal %20.10e, Dual %20.10e, Gap %20.10e, Complementarity %20.10e, r_d %20.10e r_p %20.10e mu %20.10e\n",ik,stephere,Primal,Dual,Primal-Dual,r_C/r_C0,r_d/r_d0,r_p/r_p0,mu/mu0);
		xdz=ddotvec(n,&x[0],&z[0]);
		if((ik)&&fabs(Primal-Dual)<lm_eps && r_C < lm_eps)break;
		for(i=0,gg=0;i<M;++i)
		{
			if(y[i]!=0)gg+=fabs((ddotvec(n,A+i*n,&x[0])-b[i])/y[i]);
		}
		if(conc)
		{
			if(y[M]!=0)gg+=fabs((ddotvec(n,&x[0],&x[0])-b[M])/y[M]);
		}
		if(!gg)gg=lm_max;
		if(beta1<1e-10)
			mu*=mudec;
		else //if(!ik || (r_d < Mc*mu*r_d0 && r_p < Mc*mu*r_p0))
			mu=mudec*dmin(xdz/n , gg/m);
		if(mu<lm_eps8)mu=0;
		for(i=0;i<n;++i)
		{
			H[i*(i+3)/2]+=z[i]/x[i];
		}
		for(i=0;i<m;++i)
		{
			if(i<M)
			{
				dsubvec(n,&H[(n+i)*(n+i+1)/2],&A[i*n],&H[(n+i)*(n+i+1)/2]);
				H[(n+i)*(n+i+1)/2+n+i]=-mu;
			}
			else//for concentration constraint
			{
				for(j=0;j<n;++j)
				{
					H[(n+i)*(n+i+1)/2+j] -= 2*x[j];
				}
				H[(n+i)*(n+i+1)/2+n+i]=-mu;
			}
		}
		gradFhere(n,&x[0],&r[0],gradInfo);dnegvec(n,&r[0]);
		// Residuals start
		//_________________________________________________________________________________
		for(i=0,r_d=0,r_C=0;i<n;++i)
		{
			r_d+=square(r[i]+BITA_ddot(M,&y[0],1,A+i,n)+((conc)?y[M]*2*x[i]:0)+z[i]);
			r_C+=square(x[i]*z[i]-mu);
			r[i]+=BITA_ddot(M,&y[0],1,A+i,n)+((conc)?y[M]*2*x[i]:0)+mu/x[i];
		}
		r_d=sqrt(r_d);
		r_C=sqrt(r_C);
		for(i=0;i<M;++i)
		{
			r[i+n]=mu*y[i]+ddotvec(n,A+i*n,&x[0])-b[i];
		}
		if(conc)r[M+n]=mu*y[M]+ddotvec(n,&x[0],&x[0])-b[M];
		r_p=sqrt(ddotvec(m,&r[n],&r[n]));
		// Residuals end
		//_________________________________________________________________________________
		if(!ik)
		{
			mu0=mu;
			r_d0=r_d;
			r_p0=r_p;
			r_C0=r_C;
		}

		bunchf(n+m,&H[0],&piv[0]);dxy=r;

		//Get new x,y,z start
		//_________________________________________________________________________________
		dsptrs((char*)"U",n+m,1,&H[0],&piv[0],&dxy[0],n+m);
		for(i=0;i<n;++i)
		{
			dz[i]=(mu - z[i]*dxy[i])/x[i]-z[i];
		}
		stepx=1;stepz=1;
		for(i=0;i<n;++i)
		{
			if(dxy[i]<0)
			{
				stepx=dmin(stepx,(-x[i]/dxy[i]));
			}
			if(dz[i]<0)
			{
				stepz=dmin(stepz,(-z[i]/dz[i]));
			}
		}
		stephere=step=.95*dmin(stepx,stepz);
		/*	daxpyvec(n,stephere,&dxy[0],&x[0]);
			daxpyvec(n,stephere,&dz[0],&z[0]);
			daxpyvec(m,stephere,&dxy[n],&y[0]);*/

		if(false)
		{//Use PathMin
			MERIT_info.A=A;
			MERIT_info.b=b;
			MERIT_info.conc=conc;
			MERIT_info.dx=&dxy[0];
			MERIT_info.dy=&dxy[n];
			MERIT_info.dz=&dz[0];
			MERIT_info.F=F;
			MERIT_info.info=Uinfo;
			MERIT_info.m=m;
			MERIT_info.mu=mu;
			MERIT_info.n=n;
			MERIT_info.nu=nu;
			MERIT_info.x=&x[0];
			MERIT_info.y=&y[0];
			MERIT_info.z=&z[0];

			stephere=PathMin(Path_merit,0,.99*dmin(stepx,stepz),1e-4,&MERIT_info,0);
			daxpyvec(n,stephere,&dxy[0],&x[0]);
			daxpyvec(n,stephere,&dz[0],&z[0]);
			daxpyvec(m,stephere,&dxy[n],&y[0]);
		}
		else
		{//Avoid PathMin and minimise along the path approximately
			M1=MERIT(n,m,&x[0],&y[0],&z[0],F,A,b,mu,nu,conc,Uinfo);
			daxpyvec(n,1e-8,&dxy[0],&x[0]);
			daxpyvec(n,1e-8,&dz[0],&z[0]);
			daxpyvec(m,1e-8,&dxy[n],&y[0]);
			DM=MERIT(n,m,&x[0],&y[0],&z[0],F,A,b,mu,nu,conc,Uinfo);
			daxpyvec(n,-1e-8,&dxy[0],&x[0]);
			daxpyvec(n,-1e-8,&dz[0],&z[0]);
			daxpyvec(m,-1e-8,&dxy[n],&y[0]);
			DM=(DM-M1)/1e-8;
			beta1=beta;
			stephere=step*beta1;
			daxpyvec(n,stephere,&dxy[0],&x[0]);
			daxpyvec(n,stephere,&dz[0],&z[0]);
			daxpyvec(m,stephere,&dxy[n],&y[0]);
			M2=MERIT(n,m,&x[0],&y[0],&z[0],F,A,b,mu,nu,conc,Uinfo);
			while(M2>M1+e0*beta1*step*DM&&beta1>lm_eps)
			{
				beta1*=beta;
				daxpyvec(n,-stephere,&dxy[0],&x[0]);
				daxpyvec(n,-stephere,&dz[0],&z[0]);
				daxpyvec(m,-stephere,&dxy[n],&y[0]);
				stephere=step*beta1;
				daxpyvec(n,stephere,&dxy[0],&x[0]);
				daxpyvec(n,stephere,&dz[0],&z[0]);
				daxpyvec(m,stephere,&dxy[n],&y[0]);
				M2=MERIT(n,m,&x[0],&y[0],&z[0],F,A,b,mu,nu,conc,Uinfo);
			}
		}
		//Get new x,y,z end
		//_________________________________________________________________________________
		Primal=F(n,&x[0],Uinfo);H=0;
		hessFhere(n,&x[0],&H[0],hessInfo);dsmxmulv(n,&H[0],&x[0],&dxy[0]);
		Dual=ddotvec(m,&y[0],&b[0]) + ((conc)?ddotvec(n,&x[0],&x[0])*y[M]:0) - 0.5* ddotvec(n,&dxy[0],&x[0]);
		ik++;
	}
	short back=0;
	if(ik>=1000)back=1;
	if(iter)*iter=ik;
	return back;
}

class DLLEXPORT NLC_Info: public ForUpdates
{
public:
	double scaleF;
	vector scaleG;
	pConstraintFunc G;
	pModQ H;
	void*Abinfo;
	void*hessInfo;
	void*AbHinfo;
};

extern "C" double NLC_F(dimen n,vector x,void*info)
{
	NLC_Info*Ninfo=(NLC_Info*)info;
	return Ninfo->Util(n,x,Ninfo->Uinfo)/Ninfo->scaleF;
}
extern "C" void NLC_Grad(dimen n,vector x,vector g,void*info)
{
	NLC_Info*Ninfo=(NLC_Info*)info;
	FiniteDiffGrad(n,x,g,info);
	//Ninfo->ModDeriv(n,x,g,Ninfo->gradinfo);
	dscalvec(n,1./Ninfo->scaleF,g);
}
extern "C" void NLC_Hess(dimen n,vector x,vector H,void*info)
{
	NLC_Info*Ninfo=(NLC_Info*)info;
	Ninfo->H(n,x,H,Ninfo->hessInfo);
	dscalvec(n*(n+1)/2,1./Ninfo->scaleF,H);
}

extern "C" void NLC_G(dimen n,dimen m,vector x,vector y,vector J,vector H,vector g,void*info)
{
	NLC_Info*Ninfo=(NLC_Info*)info;
	size_t i;
	if(H&&y)
	{
		for(i=0;i<m;++i)
			y[i]/=Ninfo->scaleG[i];
	}
	if(J&&Ninfo->BFGS)
	{
		Ninfo->G(n,m,x,y,J,0,g,Ninfo->Abinfo);
		for(i=0;i<n;++i)
			Ninfo->gnow[i]-=BITA_ddot(m,J+i,n,y,1);
	}
	else
		Ninfo->G(n,m,x,y,J,H,g,Ninfo->Abinfo);
	if(H&&y)
	{
		for(i=0;i<m;++i)
			y[i]*=Ninfo->scaleG[i];
	}
	for(i=0;i<m;++i)
	{
		if(J)dscalvec(n,1./Ninfo->scaleG[i],&J[i*n]);
		g[i]/=Ninfo->scaleG[i];
	}
}


extern "C" Integer SolveQAAM(dimen n,dimen m,vector Q,vector d,bool diag=false,bool chol=false)
{
	/*Solve  Q    AT        x           r
	         A    M         y           p

	where d=[r;p]  and Q is really Q;
	                               A;M

    Use either Bunch-Kaufman LDL solver or Pulling Sparse Choleski (must have +ve definite sub Q for this)
	If sub Q is diagonal then we can save a lot of time
	*/
	Integer prob=0;
	size_t nn=n*(n+1)>>1,i;
	size_t mm=m*(m+1)>>1,j;
	void *work=0;
	vector A=Q+nn;
	std::valarray<double>Qfac;
	std::valarray<Integer> piv,piv2(m);
	if(!diag)
	{
		Qfac.resize(nn);piv.resize(n);
		dcopyvec(nn,Q,&Qfac[0]);
		if(!chol)
			prob=bunchf(n,&Qfac[0],&piv[0]);
			//prob=FactorSymm(n,&Qfac[0],&work);
		else
			prob=FactorGen(n,&Qfac[0],&work);
	}
	std::valarray<double>QA(n*(m+1));
	vector Qr=&QA[n*m];
	for(i=0;i<m;++i)
	{
		dcopyvec(n,A+(n*i+i*(i+1)/2),&QA[i*n]);
		if(diag)
		{
			for(j=0;j<n;++j)QA[i*n+j]/=Q[j*(j+3)/2];
		}
		else
		{
			if(!chol)
				dsptrs((char*)"U",n,1,&Qfac[0],&piv[0],&QA[i*n],n);
				//SolveSymm(&QA[i*n],&work);
			else
				SolveGen(&QA[i*n],&work);
		}
	}
	dcopyvec(n,d,Qr);
	if(diag)
	{
		for(j=0;j<n;++j)Qr[j]/=Q[j*(j+3)/2];
	}
	else
	{
		if(!chol)
			dsptrs((char*)"U",n,1,&Qfac[0],&piv[0],Qr,n);
			//SolveSymm(Qr,&work);
		else
			SolveGen(Qr,&work);
	}
	if(chol)
		DeleteGen(&work);
	/*else
		DeleteSymm(&work);*/

	std::valarray<double>AQA(mm),y(m),x(n);

	AQA=0;
	for(i=0;i<m;++i)
	{
		for(j=0;j<n;++j)
		{
/*			for(k=0;k<i+1;++k)
			{
				AQA[i*(i+1)/2+k]+=A[n*i+i*(i+1)/2+j]*QA[k*n+j];
			}*/
			BITA_daxpy(i+1,A[n*i+i*(i+1)/2+j],&QA[j],n,&AQA[i*(i+1)/2],1);
		}
		dsubvec(i+1,&AQA[i*(i+1)/2],&A[n*i+i*(i+1)/2 + n],&AQA[i*(i+1)/2]);//This makes the routine more general; any splitting of n and m will work
		//AQA[i*(i+3)/2]-=A[n*i+i*(i+1)/2 + n + i];//Only correct if M is diagonal as it is with the interior point method
		y[i]=ddotvec(n,d,&QA[i*n]) - d[n+i];
	}

	if(m==1) y[0]/=AQA[0];
	else if(m>0)
	{
		Integer p1;
		if(!chol)
			p1=bunchf(m,&AQA[0],&piv2[0]);
		else
		{
			p1=FactorGen(m,&AQA[0],&work);
		}
		prob=max(prob,p1);
		if(!chol)
			dsptrs((char*)"U",m,1,&AQA[0],&piv2[0],&y[0],m);
		/*
		{
			SolveSymm(&y[0],&work);
			DeleteSymm(&work);
		}
		*/
		else
		{
			SolveGen(&y[0],&work);
			DeleteGen(&work);
		}
	}
	for(i=0;i<n;++i)
	{
		x[i]=Qr[i]-BITA_ddot(m,&QA[i],n,&y[0],1);
	}
	dcopyvec(n,&x[0],d);
	dcopyvec(m,&y[0],d+n);
	return prob;
}
extern "C" DLLEXPORT double getsigma(size_t n,vector g,vector lambda,vector y)
{
	double back=0,close=lm_eps8;
	size_t i;
	dsubvec(n,lambda,y,lambda);
	back=linfinity(n,lambda);
	if(back>close)
	{
		back=linfinity(n,g)/back;
		daddvec(n,lambda,y,lambda);

		//for(i=0;i<n;i++)
		//	y[i]=  lambda[i]-g[i]/back;
	}
	else
	{
		back=lm_eps;
		daddvec(n,lambda,y,lambda);
	}
	return back;
}

class AL_info: public ForUpdates
{
public:
	dimen m;
	pConstraintFunc Ab;
	pModQ H;
	void *Abinfo;
	void *Qinfo;
	double mu,fac;
	vector lambda,localg,localh,localA,localspace;
};
extern "C" double AL_Util(dimen n,vector w,void*info)
{
	AL_info *V=(AL_info*)info;
	dimen m=V->m;
	double back=V->Util(n,w,V->Uinfo)*V->fac;
	V->Ab(n,m,w,V->lambda,0,0,V->localg,V->Abinfo);
	back+=ddotvec(m,V->localg,V->localg)*0.5/V->mu-ddotvec(m,V->lambda,V->localg);
	return back;
}
extern "C" void AL_Grad(dimen n,vector w,vector g,void*info)
{
	AL_info *V=(AL_info*)info;
	dimen m=V->m;
	V->ModDeriv(n,w,g,V->gradinfo);dscalvec(n,V->fac,g);
	V->Ab(n,m,w,V->lambda,V->localA,0,V->localg,V->Abinfo);
	dscalvec(m,1.0/V->mu,V->localg);
	dsubvec(m,V->localg,V->lambda,V->localg);
	for(size_t i=0;i<n;++i)
		g[i]+=BITA_ddot(m,V->localg,1,V->localA+i,n);
	if(V->BFGS)
	{
		V->count++;
		dcopyvec(n,V->xnow,V->xpast);
		dcopyvec(n,V->gnow,V->gpast);
		dcopyvec(n,w,V->xnow);
		dcopyvec(n,g,V->gnow);
	}
}
extern "C" void AL_Hess(dimen n,vector w,vector h,void*info)
{
	AL_info *V=(AL_info*)info;
//	bool neg=false;
	dimen m=V->m;
	V->H(n,w,h,V->Qinfo);dscalvec(n*(n+1)>>1,V->fac,h);
	V->Ab(n,m,w,V->lambda,V->localA,0,V->localg,V->Abinfo);
	dscalvec(m,1.0/V->mu,V->localg);
	dsubvec(m,V->localg,V->lambda,V->localspace);
	dzerovec(n*(n+1)>>1,V->localh);
	V->Ab(n,m,w,V->localspace,0,V->localh,V->localg,V->Abinfo);
	for(size_t i=0,ij,ii=0;i<n;i++,ii+=i)
	{
		ij=ii+i;
		h[ij]+=BITA_ddot(m,V->localA+i,n,V->localA+i,n)/V->mu;
//		neg=V->localh[ij]<0;
//		h[ij]+=(neg?-V->localh[ij]:V->localh[ij]);
		h[ij]+=fabs(V->localh[ij]);//ensure that the Hessian is positive definite
		for(size_t j=0;j<i;++j)
		{
			ij=ii+j;
			h[ij]+=BITA_ddot(m,V->localA+j,n,V->localA+i,n)/V->mu;
//			h[ij]+=(neg?-V->localh[ij]:V->localh[ij]);
			h[ij]+=V->localh[ij];
		}
	}
}

extern "C" DLLEXPORT short OptimiseNLCAL(dimen n,vector w,dimen m,vector A,dimen mAL,pConstraintFunc GenAb,void* Abinfo,pUtility F,pModC gradF,pModQ hessF,
	void *Uinfo,void *Minfo,void *Qinfo,vector L,vector U)
{
	/*	
		min a general function F(w)
		such that GenAb(x)=0 (mAL constraints)
		and U[i]>=w[i]>=L[i] i=0....n-1
		and m linear constraints in A
		U[i+n]>=(Aw)[i]>=L[i+n] i=0....m-1

		using Augmented Lagrangian Method for the constraints in GenAb.
	*/

	//Decide whether to use true 2nd derivatives or updates.

#ifdef __SYSNT__
	_ASSERT(0);
#endif
	std::valarray<double> wkeep(n);
	AL_info Passer;
	Passer.fac=1;
	Passer.Qinfo=0;
	Passer.gradinfo=0;
	Passer.m=mAL;
	Passer.H=hessF;
	if(Passer.H)
		Passer.Qinfo=Qinfo;

	Passer.Ab=GenAb;
	Passer.Abinfo=Abinfo;
	Passer.Util=F;
	Passer.Uinfo=Uinfo;
	Passer.ModDeriv=gradF?gradF:0;
	if(Passer.ModDeriv)
		Passer.gradinfo=Minfo;
	std::valarray<double>xnow,xpast,gnow,gpast,hnow;

	
	Passer.BFGS=hessF?false:true;
	if(Passer.BFGS)
	{
		hnow.resize(n*(n+1)>>1);		
		Passer.hnow=&hnow[0];
		xnow.resize(n);Passer.xnow=&xnow[0];
		xpast.resize(n);Passer.xpast=&xpast[0];
		gnow.resize(n);Passer.gnow=&gnow[0];
		gpast.resize(n);Passer.gpast=&gpast[0];
		Passer.count=0;
	}

	pUtility UtilFhere = AL_Util;
	pModQ hessFhere=hessF?AL_Hess:BFGSHess;
	pModC gradFhere=gradF?AL_Grad:FiniteDiffGrad;//(Using approximate first derivatives works very badly)

	size_t nn=n*(n+1)>>1;
	std::valarray<double>HH(nn),aalpha(n);

	std::valarray<double> Lambda(mAL),gcon(mAL),hcon(nn),LocalA(n*mAL),localspace(mAL);
	Lambda=0;

	if(ddotvec(n,w,w) < lm_eps8)
		dsetvec(n,1.01/n,w);

	Passer.lambda=&Lambda[0];
	Passer.localA=&LocalA[0];
	Passer.localg=&gcon[0];
	Passer.localh=&hcon[0];  
	Passer.localspace=&localspace[0];

	Passer.mu=1;
	Passer.Ab(n,mAL,w,&Lambda[0],0,0,&gcon[0],Passer.Abinfo);
	Passer.ModDeriv(n,w,&aalpha[0],Passer.gradinfo);

	Passer.mu=linfinity(mAL,&gcon[0]);
	//Passer.fac=Passer.mu/linfinity(n,&aalpha[0]);//Try to get a good scaling between nonlinear constraint error and function gradient.
	Passer.fac=1e-4;
	aalpha=0;

	daxpyvec(mAL,-Passer.fac/Passer.mu,&gcon[0],&Lambda[0]);
	Passer.mu=dmin( (Passer.mu) , 0.1);

	double delt,deltkeep=lm_max;
	double reduce=1e3,tau=1;

	short back=OptimiseGeneral(n,w,m,&A[0],&L[0],&U[0],&aalpha[0],&HH[0],UtilFhere,gradFhere,hessFhere,&Passer,&Passer,&Passer);

	Passer.Ab(n,mAL,w,&Lambda[0],0,0,&gcon[0],Passer.Abinfo);
	delt=linfinity(mAL,&gcon[0]);

	size_t j=0;
	printf((char*)"\e[1;1;32m%d fac %f \e[1;1;35mmu %20.15e delt %20.15e\e[0m\n",back,Passer.fac,Passer.mu,delt);
	tau=0.3;
	while(delt > lm_eps8 /*&& reduce>lm_eps*lm_eps*/&&back!=6)
	{
		if(Passer.BFGS)Passer.count=0;
		j++;
		if(delt < reduce)
		{
			daxpyvec(mAL,-1.0/Passer.mu,&gcon[0],&Lambda[0]);
		//parity log 	printx(mAL,Passer.lambda);
		}
		else if(Passer.mu > lm_eps)
		{
			Passer.mu *= tau;
			if(Passer.mu < lm_eps)
				Passer.mu=lm_eps;
			j=0;
		}
		else
		{
			if(j>20)
			{
				dzerovec(mAL,&Lambda[0]);j=0;
			}
			//else if(reduce==delt && delt <= lm_rooteps) break;
			else if(fabs(reduce-delt)<=lm_eps){printf((char*)"\e[1;1;36m %25.15e\e[0m\n",reduce-delt);break;}
			daxpyvec(mAL,-1.0/Passer.mu,&gcon[0],&Lambda[0]);
		//parity log 	printx(mAL,Passer.lambda);
		}
		if(delt < deltkeep)
		{
			dcopyvec(n,w,&wkeep[0]);deltkeep=delt;
		}

		back=OptimiseGeneral(n,w,m,&A[0],&L[0],&U[0],&aalpha[0],&HH[0],UtilFhere,gradFhere,hessFhere,&Passer,&Passer,&Passer);
		Passer.Ab(n,mAL,w,&Lambda[0],0,0,&gcon[0],Passer.Abinfo);
		reduce=delt;
		delt=linfinity(mAL,&gcon[0]);
		if(Passer.mu >1e-12)
			reduce=10.0*exp(log(Passer.mu)*(0.1+0.9*j));
		/*		if(Passer.mu<lm_rooteps)
		tau=0.1;
		else
		tau = dmin(0.1, (sqrt(Passer.mu)) );*/
		printf((char*)"\e[1;1;32m%d fac %f\e[1;1;35mmu %20.15e delt %20.15e reduce %20.15e\e[0m\n",back,Passer.fac,Passer.mu,delt,reduce);
		if(false)
		{
			if(Passer.BFGS)
			{
				std::valarray<double>st(n*n),eig(n);
				dcopyvec(nn,&hnow[0],&st[0]);
				packed2symm(n,&st[0]);
				short ee=eigendecomp(n,&st[0],&eig[0],100);

			//parity log 	printf((char*)"%d (0 is ok) Hessian eigenvalues at end\n",ee);
			//parity log 	printf((char*)"back %d\n",back);
			//parity log 	printx(n,&eig[0]);
			}
			else
			{
				hessFhere(n,w,&HH[0],&Passer);
				std::valarray<double>st(n*n),eig(n);
				dcopyvec(nn,&HH[0],&st[0]);
				packed2symm(n,&st[0]);
				short ee=eigendecomp(n,&st[0],&eig[0],100);

			//parity log 	printf((char*)"%d (0 is ok) Hessian eigenvalues at end\n",ee);
			//parity log 	printf((char*)"back %d\n",back);
			//parity log 	printx(n,&eig[0]);
				HH=0;
			}
		}
	}
	if(deltkeep<delt)dcopyvec(n,&wkeep[0],w);
	return back;
}

extern "C" DLLEXPORT short OptimiseNLC(dimen n,vector x,vector y,vector z,dimen m,pConstraintFunc GenAb,void* Abinfo,pUtility F,pModC gradF,pModQ hessF,
	void *Uinfo,void *Minfo,void *Qinfo,double tol=1e-11,double nu=1.4,double mudec=2.7,double Mc=std::exp(4.0*std::log(10.0)),double mexp=4,double shape=0.0,int* iter=0,int iprint=0,int conventional=0)
{
	/*	min a general function F(w)
		such that GenAb(x)=0 (m constraints)
		and w[i]>=0 i=0....n-1

		using a primal-dual method
	*/

	//Decide whether to use true or approximate derivatives
	//Best to keep shape=0, hard to understand how it helps (although it can make a difference and help a lot.)
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	bool only_strict_primal=!conventional;
	short method=1;
	size_t smallstepcount=0,smallstepcount_top=10;
	double curve=0;
	Optimise O;
	if(!O.licenced)return -1;

	tol=max(lm_eps,tol);
	tol=small_round(tol);

	NLC_Info Passer;
	Passer.Util=F;
	Passer.Uinfo=Uinfo;
	Passer.BFGS=hessF?false:true;
	Passer.ModDeriv=gradF?gradF:0;
	if(Passer.ModDeriv)
		Passer.gradinfo=Minfo;
	std::valarray<double>xnow,xpast,gnow,gpast,hnow;
	bool noz=!z;
	if(Passer.BFGS)
	{
		hnow.resize(n*(n+1)>>1);Passer.hnow=&hnow[0];
		xnow.resize(n);Passer.xnow=&xnow[0];
		xpast.resize(n);Passer.xpast=&xpast[0];
		gnow.resize(n);Passer.gnow=&gnow[0];
		gpast.resize(n);Passer.gpast=&gpast[0];
		Passer.count=0;
	}

	//We proceed like this
	pModC gradFhere=NLC_Grad;
	pModQ hessFhere=hessF?hessF:BFGSHess;
	void* gradInfo=&Passer;
	void* hessInfo=hessF?Qinfo:&Passer;
	Passer.H=hessFhere;
	hessFhere=NLC_Hess;
	Passer.hessInfo=hessInfo;

	Passer.G=GenAb;
	Passer.Abinfo=Abinfo;

	GenAb=NLC_G;

	size_t nn=n*(n+1)>>1;
	std::valarray<double> dxy(n+m),dz(n),lambda(m);
	std::valarray<double> H((n+m)*(n+m+1)/2),r(n+m),r0(n);
	std::valarray<Integer> piv(n+m);
	double stepx,stepz,xdz=1e8,step,yinfinity=0,zinfinity=0;
	bool setx=false,setz=false,sety=false;
	size_t i,ii;
	int maxiter=1000;
	if(iter&&iter[0]) maxiter=iter[0];

	std::valarray<double> A(n*m),g(m);

	if(ddotvec(n,x,x)<=lm_eps)setx=true;
	if(z&&ddotvec(n,z,z)<=lm_eps)setz=true;
	if(ddotvec(m,y,y)<=lm_eps)sety=true;
	if(setx)
	{
		dsetvec(n,1.,x);
	}
	if(z&&setz)
	{
		dsetvec(n,1.,z);
	}
	if(sety)
	{
		dsetvec(m,.1,y);
	}


	double Primal=F(n,&x[0],Uinfo),DM=0,beta=.9,e0=.001,oldmu=1,Gap;
	double Dual=Primal,mu,r_p=1,r_d=1,r_C=1,mu0=1,r_p0=1,r_d0=1,beta1=1,stephere=1,Ay,Fmax,Gmax,Fmin,Gmin;
	double sigma;
	void *WORKSYMM=0;
	std::valarray<double>GG(m);
	bool phase2=false;
	meritinfo MERIT_info; 
	MERIT_info.noz=noz;
	FiniteDiffGrad(n,&x[0],&r[0],gradInfo);dxminmax(n,&r[0],1,&Fmax,&Fmin);Fmax=dmax(1,Fmax);
	Passer.scaleF=Fmax;

	Passer.G(n,m,&x[0],&y[0],&A[0],0,&g[0],Abinfo);
	
	for(i=0;i<m;i++)
	{
		dxminmax(n,&A[i*n],1,&Gmax,&Gmin);
		GG[i]=dmax(fabs(g[i]),dmax(1,Gmax));
	}
	Passer.scaleG=&GG[0];

	H=0;hessFhere(n,&x[0],&H[0],&Passer);
	GenAb(n,m,&x[0],&y[0],&A[0],0,&g[0],&Passer);
	gradFhere(n,&x[0],&r[0],gradInfo);//dnegvec(n,&r[0]);
	dimen ik=0;

	mu0=mu=1.;
	sigma=mu;

	if(noz)mu=0;
	while(ik<maxiter&&(/*mu>lm_eps*mu0||*/r_d>tol*r_d0||r_p>tol*r_p0||(!noz&&r_C>tol)))
	{
		if(!conventional)
			dcopyvec(m,y,&lambda[0]);
		if(ik)Gap=Primal-Dual;
		if(ik&&iprint)printf((char*)"Iteration %3ld (%10.5f): Primal %20.10e, Dual %20.10e, Gap %20.10e, Complementarity %20.10e, r_d %20.10e r_p %20.10e mu %20.10e\n",ik,stephere,Primal,Dual,Gap,r_C,r_d/r_d0,r_p/r_p0,mu/mu0);
		//if((ik)&&fabs(Gap)<tol && (!noz&&r_C < tol) && r_p<tol*r_p0 && mu<lm_eps*mu0)break;
		xdz=noz?1:ddotvec(n,&x[0],&z[0]);

		oldmu=mu;

		if(conventional)
		{
			if(!noz&&mu !=1)
				mu=0.5*ddotvec(n,x,z)/n;
			if(stephere<1e-4 && mu<1)
			{
				mu*=1.05;
				mu=max(mu,1e-12);
			}
		}
		else
		{
			if(ik && ((r_d < Mc*mu*r_d0/mu0 && r_p < Mc*mu*r_p0/mu0 && r_C < n*Mc*mu) /* || (stephere>.9)*/))
			{
				//mu=mudec*std::pow(dmin(xdz/n,gg/m),mexp);
				//mu=min(1.0/ik,mudec*std::pow(dmin(mu,dmin(xdz/n,gg/m)),mexp));
				if(stephere>1e-2)mu=dmin(1.0/ik,(mudec+shape*curve)*std::pow(mu,mexp));
			}
			if(stephere<1e-4 && mu<1)
			{
				mu*=1.05;
				mu=max(mu,2e-11);
			}
		}
		if(!noz&&mu==0)mu=0.5*ddotvec(n,x,z)/n;
		//if(mu<lm_eps8)mu=0;
		if(!noz)
		{
			for(i=0,ii=0;i<n;++i,ii+=i)
			{
				H[ii+i]+=z[i]/x[i];
			}
		}
		for(i=0;i<m;++i) 
		{
			dsubvec(n,&H[(n+i)*(n+i+1)/2],&A[i*n],&H[(n+i)*(n+i+1)/2]);
			if(!conventional)H[(n+i)*(n+i+1)/2+n+i]=-sigma;
		}
		/*gradFhere(n,&x[0],&r[0],gradInfo);*/dnegvec(n,&r[0]);
		// Residuals start
		//_________________________________________________________________________________
		for(i=0;i<n;++i)
		{
			Ay=BITA_ddot(m,&y[0],1,&A[i],n);
			r[i]+=Ay;
			if(r[i]<=-lm_eps && x[i]<lm_eps)//if As long as r[i] is negative and x[i] is zero then r0[i] is degenerately 0 since z[i] is really free
			{
			//	z[i]=-r[i];//DON'T  not necessary and sometimes messes things up. It should optimise to this result.
				r0[i]=0;
			}
			else
				r0[i]=r[i]+(noz?0:z[i]);
			r[i]+=((conventional||noz)?0:(mu/x[i]));
			//r[i] = r0[i] + ((conventional||noz)?0:(mu/x[i])) - z[i];
		}
		r_d = linfinity(n,&r0[0]);
		if(z)r_C=ddotvec(n,x,z);
		for(i=0;i<m;++i)
		{
			r[i+n]=(conventional?0:(-sigma*(lambda[i]-y[i])))+g[i];
		}
		r_p=linfinity(m,&r[n]);
		// Residuals end
		//_________________________________________________________________________________
		if(only_strict_primal)
		{
			if(!(ik<maxiter&&(/*mu>lm_eps*mu0||*//*r_d>tol*r_d0||*/r_p>tol*r_p0||(!noz&&r_C>tol))))
			{
				ik++;break;
			}
		}
		else
		{
			if(!(ik<maxiter&&(/*mu>lm_eps*mu0||*/r_d>tol*r_d0||r_p>tol*r_p0||(!noz&&r_C>tol))))
			{
				ik++;break;
			}
		}
		//Get new x,y,z start
		//_________________________________________________________________________________

		dxy=r;
		if(conventional)
		{
			if(method==1)
			{
				bunchf(n+m,&H[0],&piv[0]);

				dsptrs((char*)"U",n+m,1,&H[0],&piv[0],&dxy[0],n+m);
			}
			else if(method==2)
			{
				FactorSymm(n+m,&H[0],&WORKSYMM);
				SolveSymm(&dxy[0],&WORKSYMM);
			}
		}
		else
			SolveQAAM(n,m,&H[0],&dxy[0],zerocount(nn,&H[0]) == (nn-n));

		if(!noz)
		{
			for(i=0;i<n;++i)
			{
				dz[i]=(((conventional?0:mu) - z[i]*dxy[i])/x[i]-z[i]);
			}
		}
		stepx=1;stepz=1;
		if(!noz)
		{
			for(i=0;i<n;++i)
			{
				if(dxy[i]<0)
				{
					stepx=dmin(stepx,(-x[i]/dxy[i]));
				}
				if(dz[i]<0)
				{
					stepz=dmin(stepz,(-z[i]/dz[i]));
				}
			}
		}
		stephere=step=.95*(!noz?dmin(stepx,stepz):stepx);
		if(false&&conventional)
		{//Use PathMin
			MERIT_info.dx=&dxy[0];
			MERIT_info.dy=&dxy[n];
			MERIT_info.dz=&dz[0];
			MERIT_info.F=NLC_F;
			MERIT_info.info=&Passer;
			MERIT_info.m=m;
			MERIT_info.mu=0;
			MERIT_info.n=n;
			MERIT_info.nu=0;
			MERIT_info.x=&x[0];
			MERIT_info.y=&y[0];
			MERIT_info.z=&z[0];
			MERIT_info.Cinfo=&Passer;
			MERIT_info.g=GenAb;

			stephere=PathMin(Path_meritC,0,.95*dmin(stepx,stepz),1e-4,&MERIT_info,0);
		}
		else if(true&&!conventional)
		{//Use PathMin
			MERIT_info.dx=&dxy[0];
			MERIT_info.dy=&dxy[n];
			MERIT_info.dz=&dz[0];
			MERIT_info.F=NLC_F;
			MERIT_info.info=&Passer;
			MERIT_info.m=m;
			MERIT_info.mu=mu;
			MERIT_info.sigma=sigma;
			MERIT_info.lambda=&lambda[0];
			MERIT_info.n=n;
			MERIT_info.nu=nu;
			MERIT_info.x=&x[0];
			MERIT_info.y=&y[0];
			MERIT_info.z=&z[0];
			MERIT_info.Cinfo=&Passer;
			MERIT_info.g=GenAb;

			double curve1=Path_meritC(0.0,&MERIT_info);
			//if(stephere>=1e-3)
				stephere=PathMin(Path_meritC,0,.95*dmin(stepx,stepz),1e-8,&MERIT_info,0);

			curve=(curve1-Path_meritC(stephere,&MERIT_info))/stephere;
			//printf((char*)"curve:: %20.8e %20.8e %20.8e\n",curve1,stephere,curve);

			daxpyvec(n,stephere,&dxy[0],&x[0]);
			if(!noz)daxpyvec(n,stephere,&dz[0],&z[0]);
			daxpyvec(m,stephere,&dxy[n],&y[0]);
			GenAb(n,m,&x[0],&y[0],&A[0],0,&g[0],&Passer);
			//sigma=getsigma(m,&g[0],&lambda[0],y)*1e-2;Still need a way to get a better decreasing sequence for sigma, here we just use sigma=mu
			//if(sigma>1e-7)
				sigma=mu;//0.5*getsigma(m,&g[0],&lambda[0],y);
		}
		//stephere=small_round(stephere);
		if(conventional)
		{
			double gamma=dmin(.5,((1-stephere)*(1-stephere)))*(1-stephere);
			std::valarray<double>r1(n+m),dz1(n);
			double stepx1,stepz1,stephere1;
			daxpyvec(n,stephere,&dxy[0],&x[0]);
			if(!noz)daxpyvec(n,stephere,&dz[0],&z[0]);
			//daxpyvec(m,stephere,&dxy[n],&y[0]);
			if(!noz)mu=ddotvec(n,&x[0],&z[0])/n;
			daxpyvec(n,-stephere,&dxy[0],&x[0]);
			if(!noz)daxpyvec(n,-stephere,&dz[0],&z[0]);
			//daxpyvec(m,-stephere,&dxy[n],&y[0]);
			gradFhere(n,&x[0],&r1[0],gradInfo);dnegvec(n,&r1[0]);
			GenAb(n,m,&x[0],&y[0],&A[0],0,&g[0],&Passer);
			for(i=0;i<n;++i)
			{
				Ay=BITA_ddot(m,&y[0],1,&A[i],n);
				r1[i]+=Ay+mu/x[i];
				/*			//Not worth the effort
				r1[i]+=Ay+((x[i]>lm_eps)?mu/x[i]:0);
				if(x[i]<=lm_eps)z[i]=-r1[i];
				*/
			}
			for(i=0;i<m;++i)
			{
				r1[i+n]=g[i];
			}
			dscalvec(n+m,(1.0-gamma),&r1[0]);
			if(method==1)
				dsptrs((char*)"U",n+m,1,&H[0],&piv[0],&r1[0],n+m);
			else
				SolveSymm(&r1[0],&WORKSYMM);
			for(i=0;!noz&&i<n;++i)
			{
				dz1[i]=((gamma*mu - z[i]*r1[i])/x[i]-z[i]);
			}
			stepx1=1;stepz1=1;
			for(i=0;i<n;++i)
			{
				if(r1[i]<0)
				{
					stepx1=dmin(stepx1,(-x[i]/r1[i]));
				}
				if(!noz&&dz1[i]<0)
				{
					stepz1=dmin(stepz1,(-z[i]/dz1[i]));
				}
			}
			if(false)
			{
				MERIT_info.dx=&r1[0];
				MERIT_info.dy=&r1[n];
				MERIT_info.dz=&dz1[0];
				MERIT_info.F=NLC_F;
				MERIT_info.info=&Passer;
				MERIT_info.m=m;
				MERIT_info.mu=mu;
				MERIT_info.n=n;
				MERIT_info.nu=0;
				MERIT_info.x=&x[0];
				MERIT_info.y=&y[0];
				MERIT_info.z=&z[0];
				MERIT_info.Cinfo=&Passer;
				MERIT_info.g=GenAb;

				stephere1=PathMin(Path_meritC,0,.95*dmin(stepx1,stepz1),1e-4,&MERIT_info,0);
			}
			else stephere1=.95*dmin(stepx1,stepz1);
			//stephere1=small_round(stephere1);
			if(stephere1>=stephere/*&&mu!=0*/)
			{
				daxpyvec(n,stephere1,&r1[0],&x[0]);
				if(!noz)daxpyvec(n,stephere1,&dz1[0],&z[0]);
				daxpyvec(m,stephere1,&r1[n],&y[0]);
				stephere=stephere1;
				//if(stephere<1e-4)mu*=10;
			}
			/*else if(stephere1>=stephere&&r_d>1e-3&&mu!=0)
			{
				daxpyvec(n,stephere1,&r1[0],&x[0]);
				daxpyvec(n,stephere1,&dz1[0],&z[0]);
				daxpyvec(m,stephere1,&r1[n],&y[0]);
				stephere=stephere1;
				//if(stephere<1e-4)mu*=10;
			}*/
			else//Affine direction
			{
				daxpyvec(n,stephere,&dxy[0],&x[0]);
				if(!noz)daxpyvec(n,stephere,&dz[0],&z[0]);
				daxpyvec(m,stephere,&dxy[n],&y[0]);
				mu=0;
			}
			if(stephere<1e-6)//Reset the optimisation near the current x if the step is too small too many times
			{
				if(smallstepcount==10)
				{
					double linf=linfinity(m,y);
					if(iprint)printf((char*)"----- step size too small %e reset -----\n",stephere);
					if(!noz)dsetvec(n,1e-3,z);
					daxpyvec(n,1e0,z,x);
					//dscalvec(n,.5,x);
					mu=0;//0.5*ddotvec(n,z,x)/n;
					/*if(linf<lm_eps)
					dscalvec(m,1./linf,y);
					else*/
					dsetvec(m,1e-1,y);
					smallstepcount=0;
				}
				else smallstepcount++;
			}
			else if(true)//Fix ups here seemed to help sometimes but can mess things up in general
			{
				smallstepcount=0;
				if(true&&r_p<lm_eps&&r_C<lm_eps&&r_d>1e-2&&linfinity(m,y)>yinfinity)
				{
					yinfinity=linfinity(m,y);
					dzerovec(m,y);if(iprint)printf((char*)"\e[1;1;35my set to zero in %s %d\e[0m\n", __FILE__ ,__LINE__);
					if(!noz)dsetvec(n,1,z);
					if(!noz)daxpyvec(n,lm_rooteps,z,x);
					mu=0;
					if(iprint)printf((char*)"---------------------- Reset yinfinity to %20.8e -----------------------\n",yinfinity);
				}
				else if(true&&r_C<1e-16&&r_d<1e-16&&r_p>1e-6)
				{
					if(iprint)printf((char*)"----- zero complementarity (%e), dual residual (%e) but primal residual (%e), have to reset x,y and z -----\n",r_C,r_d,r_p);
					double ss1=linfinity(n,z),linf=linfinity(n,x),xx1=ss1*linf,xlow=linf-xx1;
					if(iprint)printf((char*)"linf %e, xx1 %e, ss1 %e, xlow %e",linf,xx1,ss1,xlow);
					dzerovec(m,y);if(iprint)printf((char*)"\e[1;1;35my set to zero in %s %d\e[0m\n", __FILE__ ,__LINE__);
					dsetvec(n,1,z);
					for(i=0;i<n;++i)
					{
						if(x[i]>xx1)
						{
							x[i]=xlow;
						}
						else if(-x[i]>xx1)
						{
							x[i]=-xlow;
						}
					}
					mu=0;
				}
				else if(true&&r_C<1e-25&&r_d>1e-6&&r_p>1e-6)//1e-16 might not be small enough
				{
					if(iprint)printf((char*)"----- zero complementarity (%e) but primal and dual residuals are large (%e,%e), have to reset x,y and z -----\n",r_C,r_p,r_d);
					double ss1=linfinity(n,z),linf=linfinity(n,x),xx1=ss1*linf,xlow=linf-xx1;
					if(iprint)printf((char*)"linf %e, xx1 %e, ss1 %e, xlow %e",linf,xx1,ss1,xlow);
					dzerovec(m,y);if(iprint)printf((char*)"\e[1;1;35my set to zero in %s %d\e[0m\n", __FILE__ ,__LINE__);
					dsetvec(n,1,z);
					for(i=0;i<n;++i)
					{
						if(x[i]>xx1)
						{
							x[i]=xlow;
						}
						else if(-x[i]>xx1)
						{
							x[i]=-xlow;
						}
					}
					mu=0;
				}
				else if(true&&r_C<1e-13&&r_d>1e-4&&r_p>1e-4)//1e-16 might not be small enough
				{
					if(iprint)printf((char*)"----- zero complementarity (%e) but primal and dual residuals are large (%e,%e), have to reset x,y and z -----\n",r_C,r_p,r_d);
					double ss1=linfinity(n,z),linf=linfinity(n,x),xx1=ss1*linf,xlow=linf-xx1;
					if(iprint)printf((char*)"linf %e, xx1 %e, ss1 %e, xlow %e",linf,xx1,ss1,xlow);
					dzerovec(m,y);if(iprint)printf((char*)"\e[1;1;35my set to zero in %s %d\e[0m\n", __FILE__ ,__LINE__);
					dsetvec(n,1,z);
					for(i=0;i<n;++i)
					{
						if(x[i]>xx1)
						{
							x[i]=xlow;
						}
						else if(-x[i]>xx1)
						{
							x[i]=-xlow;
						}
					}
					mu=ddotvec(n,z,x)/n;
				}
				else if(r_C<1e-25&&r_d>1e-11&&r_p>lm_eps*16)
				{
					dzerovec(m,y);if(iprint)printf((char*)"\e[1;1;35my set to zero in %s %d\e[0m\n", __FILE__ ,__LINE__);
					dsetvec(n,1,z);
					daxpyvec(n,1e-4,z,x);
					mu=ddotvec(n,z,x)/n;
				}
				else if(true&&r_C<lm_eps&&(r_p>1e-1/*||r_d>1e-4*/)&&linfinity(n,z)>zinfinity)
				{
					if(iprint)printf((char*)"----- zero complementarity (%e) but primal  residual is large (%e), have to reset x,y and z -----\n",r_C,r_p);
					zinfinity=linfinity(n,z);
					dzerovec(m,y);if(iprint)printf((char*)"\e[1;1;35my set to zero in %s %d\e[0m\n", __FILE__ ,__LINE__);
					dsetvec(n,1,z);
					//daxpyvec(n,1e-6,z,x);
					mu=0;
				}
				else if(true&&r_p>1e-7)//Try out 4-7-2016
				{
					double yM,ym;
					dxminmax(m,y,1,&yM,&ym);
					if(/*ym<=0||*/yM>1e7)
					{
						if(iprint)printf((char*)"----- y is getting huge (%e,%e) ----- r_p=%e\n",ym,yM,r_p);
						dscalvec(m,1.0/yM,y);if(iprint)printf((char*)"\e[1;1;35my scaled by 1/maxy in %s %d\e[0m\n", __FILE__ ,__LINE__);
						//dsetvec(n,1,z);
						//mu=0;
					}
				}
				if(r_C<1e-30&&r_d>1e-10)
				{
					dzerovec(m,y);if(iprint)printf((char*)"\e[1;1;35my set to zero in %s %d\e[0m\n", __FILE__ ,__LINE__);
					dsetvec(n,1,z);
					daxpyvec(n,1e-5,z,x);
					mu=ddotvec(n,z,x)/n;
				}
			}
		}
		else
		{
			if(stephere<1e-5)
			{
				//printf((char*)"----- small step %e-----\n",stephere);
				if(smallstepcount==smallstepcount_top)
				{
					//double cc1;
					if(iprint)
						printf((char*)"----- step size too small %e reset -----\n",stephere);
					dsetvec(n,1e0,z);
					daxpyvec(n,1e-4,z,x);
					dsetvec(m,1e-2,y);
					//cc1=ddotvec(n,x,z)/n;
					//mu=dmax(mu*1e4,cc1);
					smallstepcount=0;
				}
				else smallstepcount++;
			}
			else
			{
				smallstepcount=0;//smallstepcount_top++;
				if(r_C<1e-25&&r_d>1e-11)
				{
					dzerovec(m,y);if(iprint)printf((char*)"\e[1;1;35my set to zero in %s %d\e[0m\n", __FILE__ ,__LINE__);
					dsetvec(n,1,z);
					daxpyvec(n,1e-4,z,x);
					mu=ddotvec(n,z,x)/n;
				}
			}
		}
		if(!ik)
		{
			//mu0=(mu?mu:1);
			//r_d0=r_d;
			//r_p0=r_p;
			if(!noz&&!mu)mu=ddotvec(n,x,z)/n;
		}
//		if(ik<3&&ddotvec(m,y,y)>1e16)
		if(linfinity(m,y)>1e16)
		{
			dzerovec(m,y);if(iprint)printf((char*)"\e[1;1;35my set to zero in %s %d\n\e[0m", __FILE__ ,__LINE__);
		}
		//Get new x,y,z end
		//_________________________________________________________________________________
		Primal=NLC_F(n,&x[0],&Passer);H=0;
		hessFhere(n,&x[0],&H[0],&Passer);
		gradFhere(n,&x[0],&dxy[0],gradInfo);r=dxy;
		if(conventional&&(r_d>5e-3*r_d0||r_p>5e-3*r_p0||/*mu>lm_eps*mu0||*/(!noz&&r_C>5e-3)))
			;
		else if(!conventional&&(r_d>5e-1*r_d0||r_p>5e-1*r_p0||/*mu>lm_eps*mu0||*/(!noz&&r_C>5e-1)))
			;
		else if(mu>lm_eps*mu0||r_d>tol*r_d0||r_p>tol*r_p0||(!noz&&r_C>tol))
		{
			if(!phase2&&r_d>1.5e-9)
			{
				dzerovec(m,y);if(iprint)printf((char*)"\e[1;1;35my set to zero (r_d %20.8e) in %s %d\e[0m\n",r_d, __FILE__ ,__LINE__);//Try to avoid a local minimum
			}
			phase2=true;
		}

		//phase2=true;
		if(stephere<1e-5)// && conventional)
			phase2=false;
		if(r_C<lm_rooteps && r_p>1e-3*r_p0)
			phase2 = false;
		//phase2=true;
		if(phase2&&iprint)printf((char*)"\e[1;4;35mPHASE2\e[0m\n");
		if(!phase2)
			GenAb(n,m,&x[0],&y[0],&A[0],0,&g[0],&Passer);
		else
			GenAb(n,m,&x[0],&y[0],&A[0],&H[0],&g[0],&Passer);//Only use constraint 2nd derivatives at final stage? Not sure.
		for(i=0;i<m;++i)
			dxy[n+i]=ddotvec(n,&A[n*i],&x[0]);
		Dual= ddotvec(m,&dxy[n],&y[0]) - ddotvec(m,&y[0],&g[0])  +Primal - ddotvec(n,x,&dxy[0]);
		ik++;
	}
	if(conventional&&method==2)
	{
		DeleteSymm(&WORKSYMM);
		WORKSYMM=0;//Already done actually in DeleteSymm
	}
	if(ik&&iprint)printf((char*)"Iteration %3ld (%10.5f): Primal %20.10e, Dual %20.10e, Gap %20.10e, Complementarity %20.10e, r_d %20.10e r_p %20.10e mu %20.10e\n",ik,stephere,Primal,Dual,Primal-Dual,r_C,r_d/r_d0,r_p/r_p0,mu/mu0);

	//Get y and z correct________________________________________________________
	for(i=0;i<m;++i)
		y[i]*=Passer.scaleF/Passer.scaleG[i];
	if(z)dscalvec(n,Passer.scaleF,z);
	//___________________________________________________________________________

	short back=0;
	if(ik>=maxiter)back=1;
	if(iter)*iter=ik;
	return back;
}




extern "C" DLLEXPORT short OptimiseNLC1(dimen n,vector x,vector y,vector z,dimen m,pConstraintFunc GenAb,void* Abinfo,pUtility F,pModC gradF,pModQ hessF,
	void *Uinfo,void *Minfo,void *Qinfo,double tol=1e-12,int*iter=0,int iprint=0,double rho=0.9,double theta=10.0,double nu=1.0,double stepmin=0.2)
{
	/*	min a general function F(w)
		such that GenAb(x)=0 (m constraints)
		and w[i]>=0 i=0....n-1

		using a primal-dual method
	*/
	//Decide whether to use true or approximate derivatives
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	NLC_Info Passer;
	Passer.Util=F;
	Passer.Uinfo=Uinfo;
	Passer.BFGS=hessF?false:true;
	Passer.ModDeriv=gradF?gradF:0;
	if(Passer.ModDeriv)
		Passer.gradinfo=Minfo;
	std::valarray<double>xnow,xpast,gnow,gpast,hnow;
	bool noz=!z;
	if(Passer.BFGS)
	{
		hnow.resize(n*(n+1)>>1);Passer.hnow=&hnow[0];
		xnow.resize(n);Passer.xnow=&xnow[0];
		xpast.resize(n);Passer.xpast=&xpast[0];
		gnow.resize(n);Passer.gnow=&gnow[0];
		gpast.resize(n);Passer.gpast=&gpast[0];
		Passer.count=0;
	}

	//We proceed like this
	pModC gradFhere=NLC_Grad;
	pModQ hessFhere=hessF?hessF:BFGSHess;
	void* gradInfo=&Passer;
	void* hessInfo=hessF?Qinfo:&Passer;
	Passer.H=hessFhere;
	hessFhere=NLC_Hess;
	Passer.hessInfo=hessInfo;

	Passer.G=GenAb;
	Passer.Abinfo=Abinfo;

	GenAb=NLC_G;


	size_t nn=n*(n+1)>>1;
	std::valarray<double> dxy(n+m),dz(n);
	std::valarray<double> H((n+m)*(n+m+1)/2),r(n+m),r0(n+m);
	std::valarray<Integer> piv(n+m);
	double stepx,stepz,xdz=1e8,step;
	bool setx=false,setz=false,sety=false;
	size_t i;
	int maxiter=1000;

	if(iter&&iter[0]) maxiter=iter[0];

	std::valarray<double> A(n*m),g(m);

	if(ddotvec(n,x,x)<=lm_eps)setx=true;
	if(z&&ddotvec(n,z,z)<=lm_eps)setz=true;
	if(ddotvec(m,y,y)<=lm_eps)sety=true;
	if(setx)
	{
		dsetvec(n,1.,x);
	}
	if(z&&setz)
	{
		dsetvec(n,1.,z);
	}
	if(sety)
	{
		dsetvec(m,0,y);
	}
	double Primal=F(n,&x[0],Uinfo),DM=0,beta=.9,e0=.001,oldmu=1,Gap,LastAx;
	double Dual,mu,r_p=1,r_d=1,r_C=1,beta1=1,stephere=1,gg,Ay,Fmax,Gmax,Fmin,Gmin;
	bool diagOK=false;
	std::valarray<double>GG(m);
	meritinfo MERIT_info; 
	MERIT_info.noz=noz;
	FiniteDiffGrad(n,&x[0],&r[0],gradInfo);dxminmax(n,&r[0],1,&Fmax,&Fmin);Fmax=dmax(1.0,Fmax);
	Passer.scaleF=Fmax;

	Passer.G(n,m,&x[0],&y[0],&A[0],0,&g[0],Abinfo);
	
	for(i=0;i<m;i++)
	{
		dxminmax(n,&A[i*n],1,&Gmax,&Gmin);
		GG[i]=dmax(fabs(g[i]),dmax(1.0,Gmax));
	}
	Passer.scaleG=&GG[0];

	H=0;hessFhere(n,&x[0],&H[0],&Passer);
	GenAb(n,m,&x[0],&y[0],&A[0],&H[0],&g[0],&Passer);
	gradFhere(n,&x[0],&dxy[0],gradInfo);r=dxy;
	long ik=0;

	// Residuals for initial guess at x for y=0, z=0 and mu=0
	//_________________________________________________________________________________
	dnegvec(n,&r[0]);

	for(i=0;i<m;++i)
	{
		r[i+n]=g[i];
	}
	// Residuals end
	//_________________________________________________________________________________


	mu=linfinity(n+m,&r[0])*.01;
	double mubar,mumin,mumink,norm,r_Cm;
	std::valarray<double>currentlinfinity(maxiter);
	long l=5,lk,small_stepc=0;
	r0=r;
	r_C=0;
	while(ik<maxiter&&stephere>lm_eps8&&(/*mu>lm_eps||*/(norm=dmax(r_C,linfinity(n+m,&r0[0])))>tol))
	{
		r_Cm=0;
		if(!noz)
		{
			for(i=0;i<n;++i)
				r_Cm=dmax(r_Cm,(fabs(x[i]*z[i]-mu)));
		}
		currentlinfinity[ik]=dmax(r_Cm,(linfinity(n+m,&r[0])));
		r=dxy;
		if(ik)Gap=Primal-Dual;
		if(ik)
		{
			mubar=1./ik;
			if(ik==1)mumink=.5*lm_eps/(linfinity(m,y)+theta/(1-rho));
			else
			{
				mumin=.5*lm_eps/(linfinity(m,y)+theta/(1-rho));
				if(mumink>mumin)
				{
					mumink=dmin((.5*mumink),mumin);
				}
			}
		}
		if(ik&&iprint)printf((char*)"%3ld (dr=%10.5f, er=%10.5e): Primal %20.10e, Dual %20.10e, Gap %20.10e, Complementarity %20.10e, r_d %20.10e r_p %20.10e mu %20.10e\n",ik,stephere,norm,Primal,Dual,Gap,r_C,r_d,r_p,mu);
		xdz=noz?1:ddotvec(n,&x[0],&z[0]);
		for(i=0,gg=0;i<m;++i)
		{
			if(y[i]!=0)gg+=fabs(g[i]/y[i]);
		}
		if(!gg)gg=lm_eps;
		oldmu=mu;

		lk=(ik>l?ik-l:0);
		if(ik)
		{
			if(currentlinfinity[ik]<rho*linfinity(ik-lk,&currentlinfinity[lk])+theta*mu)
				mu=dmax(dmin(mu*.2,std::pow(mu,1.5)),mumink);
			else
			{
				if(stephere<stepmin)
				{
					if(small_stepc>2)
					{
						mu=dmin((mu*2.0),dmin((mubar-mu)*.1 + mu,mubar));
						mu=dmax(mu,0.25*(gg+(noz?gg:(xdz/n))));
					}
					small_stepc++;
				}
				else
					small_stepc=0;
			}

		}

		if(!noz)
		{
			for(i=0;i<n;++i)
			{
				H[i*(i+3)/2]+=z[i]/x[i];
			}
		}
		for(i=0;i<m;++i) 
		{
			dsubvec(n,&H[(n+i)*(n+i+1)/2],&A[i*n],&H[(n+i)*(n+i+1)/2]);
			H[(n+i)*(n+i+1)/2+n+i]=-mu;
		}
		// Residuals start
		//_________________________________________________________________________________
		dnegvec(n,&r[0]);
		for(i=0;i<n;++i)
		{
			Ay=BITA_ddot(m,&y[0],1,&A[i],n);
			r0[i]=r[i]+Ay+(noz?0:z[i]);
			r[i]+=Ay+((noz)?0:(mu/x[i]));
		}
		r_d=linfinity(n,&r0[0]);
		r_C=0;
		if(!noz)
		{
			for(i=0;i<n;++i)
				r_C=dmax(r_C,(fabs(x[i]*z[i])));
		}


		for(i=0;i<m;++i)
		{
			r[i+n]=mu*y[i]+g[i];
			r0[i+n]=g[i];
		}
		r_p=linfinity(m,&r0[n]);
		// Residuals end
		//_________________________________________________________________________________

		//Get new x,y,z start
		//_________________________________________________________________________________

		dxy=r;
		if(ik<4)diagOK=(zerocount(nn,&H[0]) == (nn-n));//If the first 2 iterations had diagonal H they all will 
		if(SolveQAAM(n,m,&H[0],&dxy[0],diagOK,true))  //For n and m partitioned H choleski is ok
			printf((char*)"Solver problem\n");

		if(!noz)
		{
			for(i=0;i<n;++i)
			{
				dz[i]=((mu - z[i]*dxy[i])/x[i]-z[i]);
			}
		}
		stepx=1;stepz=1;
		if(!noz)
		{
			for(i=0;i<n;++i)
			{
				if(dxy[i]<0)
				{
					stepx=dmin(stepx,(-x[i]/dxy[i]));
				}
				if(dz[i]<0)
				{
					stepz=dmin(stepz,(-z[i]/dz[i]));
				}
			}
		}
		stephere=step=.95*(!noz?dmin(stepx,stepz):stepx);
		MERIT_info.dx=&dxy[0];
		MERIT_info.dy=&dxy[n];
		MERIT_info.dz=&dz[0];
		MERIT_info.F=NLC_F;
		MERIT_info.info=&Passer;
		MERIT_info.m=m;
		MERIT_info.mu=mu;
		MERIT_info.n=n;
		MERIT_info.nu=nu;//nu scales the constraint part of the merit function
		MERIT_info.x=&x[0];
		MERIT_info.y=&y[0];
		MERIT_info.z=&z[0];
		MERIT_info.Cinfo=&Passer;
		MERIT_info.g=GenAb;

		stephere=PathMin(Path_meritC,0,.95*(!noz?dmin(stepx,stepz):stepx),lm_rooteps,&MERIT_info,0);
		if(stephere<lm_rooteps)
		{
			stephere=step=.95*(!noz?dmin(stepx,stepz):stepx);mu=gg*.5/n;
		}
		daxpyvec(n,stephere,&dxy[0],&x[0]);
		if(!noz)daxpyvec(n,stephere,&dz[0],&z[0]);
		daxpyvec(m,stephere,&dxy[n],&y[0]);
		if(ik<3&&ddotvec(m,y,y)>1e16)
			dzerovec(m,y);
		//Get new x,y,z end
		//_________________________________________________________________________________
		Primal=NLC_F(n,&x[0],&Passer);H=0;
		hessFhere(n,&x[0],&H[0],&Passer);//;dsmxmulv(n,&H[0],&x[0],&dxy[0]);
		gradFhere(n,&x[0],&dxy[0],gradInfo);
		GenAb(n,m,&x[0],&y[0],&A[0],&H[0],&g[0],&Passer);
		for(i=0;i<m;++i)
			dxy[n+i]=ddotvec(n,&A[n*i],&x[0]);
		LastAx=linfinity(m,&dxy[n]);
		Dual= ddotvec(m,&dxy[n],&y[0]) - ddotvec(m,&y[0],&g[0])  +Primal - ddotvec(n,x,&dxy[0]);
		ik++;
	}
	if(ik&&iprint)printf((char*)"%3ld (dr=%10.5f, er=%10.5e): Primal %20.10e, Dual %20.10e, Gap %20.10e, Complementarity %20.10e, r_d %20.10e r_p %20.10e mu %20.10e\n",ik,stephere,norm,Primal,Dual,Gap,r_C,r_d,r_p,mu);
	//printx(ik,&currentlinfinity[0]);
	//Get y and z correct________________________________________________________
	for(i=0;i<m;++i)
		y[i]*=Passer.scaleF/Passer.scaleG[i];
	if(z)dscalvec(n,Passer.scaleF,z);
	if(LastAx<lm_eps8)printf((char*)"LastAx %20.10e and Primal %20.10e, is it infeasible?",LastAx,Primal);
	//___________________________________________________________________________

	short back=0;
	if(ik>=maxiter||stephere<=lm_eps8)back=1;
	if(iter)*iter=ik;
	return back;
}

extern "C" DLLEXPORT short RiskParitySolve2(dimen n,dimen nsect,long nf,vector w,vector alpha,
										 vector sectors,vector SV,vector FC,vector FL,double*conc,int BFGS=0,int DiffGrad=0,int seq=0,double lower=0,double gamma=0)
{
	std::ofstream outFile;
	char*outfile=(char*)"riskparity2.log";
	time_t	timenow;
	time(&timenow);
	
	if(outfile&&!strlen(outfile))//In case someone sends outfile=(char*)""
	{
		std::cout<<"No output file was given"<<std::endl;
		outfile=0;
	}
	if(outfile)
	{
		//parity log outFile.open(outfile,std::ios_base::in);
		if(true||outFile.fail())
		{
			outFile.open(outfile,std::ios_base::out);
		}
		else
		{
			outFile.close();
			outFile.clear();
			char aa[50];
			char*aaaa=aa;
			sprintf(aaaa,(char*)"parity%ld.log",timenow);
			outFile.open(aaaa,std::ios_base::out);
		}
		if(outFile.fail())
		{
			std::cout<<"Cannot open "<<outfile<<std::endl;
		}
		else
		{
			dumpvector(1,(char*)"n",&n,outFile);
			dumpvector(1,(char*)"nsect",&nsect,outFile);
			dumpvector(1,(char*)"nfac",&nf,outFile);
			dumpvector(n,(char*)"alpha",alpha,outFile);
			if(sectors)dumpvector(n*nsect,(char*)"sectors",sectors,outFile,n);
			else dumpvector(0,(char*)"sectors",sectors,outFile);
			if(nf>-1)
			{
				if(SV&&FC&&FL)
				{
					dumpvector(n,(char*)"SV",SV,outFile);
					dumpvector(n*nf,(char*)"FL",FL,outFile);
					dumpvector(nf*(nf+1)/2,(char*)"FC",FC,outFile,nf);
				}
				else if(FC)
				{
					dumpvector(n,(char*)"SV",SV,outFile);
					dumpvector(n*nf,(char*)"FL",FL,outFile);
					dumpvector(n*(nf+1),(char*)"FC",FC,outFile,nf);
				}
			}
			else if(nf==-1)
			{
				dumpvector(0,(char*)"SV",SV,outFile);
				dumpvector(0,(char*)"FL",FL,outFile);
				dumpvector(n*(n+1)/2,(char*)"FC",FC,outFile,n);
			}
			dumpvector(1,(char*)"BFGS",&BFGS,outFile,100000);
			dumpvector(1,(char*)"DiffGrad",&DiffGrad,outFile);
			dumpvector(1,(char*)"seq",&seq,outFile);
			dumpvector(1,(char*)"lower",&lower,outFile);
			dumpvector(1,(char*)"gamma",&gamma,outFile);
			outFile<<"-------------------------------------------------------------------------------------------";
			outFile.close();
			outFile.clear();
		}
	}

#ifdef PAS
//	UnlockBita((char*)"colincolin");
	if(!Optimise::bitago)
	{
		fprintf(stderr,(char*)"Bad PAS key\n");
		return -1;
	}
	return -1;
#endif
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	ParityInfo Passer;

	Passer.DOUBLE=false;
	if(sectors)Passer.DOUBLE=false;

	Passer.BFGS=BFGS;

	size_t nvab;

	if(Passer.DOUBLE)
		nvab = 2*n;
	else
		nvab = n;

	size_t nvabnvab=nvab*(nvab+1)>>1,nn=n*(n+1)>>1;


	Passer.ModDeriv=0;
	Passer.lower=lower;
	Passer.nf=nf;
	Passer.Util=0;
	Passer.gradinfo=0;
	Passer.nsect=nsect;
	Passer.nstocks=n;
	std::valarray<double> Q(nn),Qf,Qw(nvab),RiskRat(nsect),H(nvabnvab);
	dsetvec(nsect,1.0/nsect,&RiskRat[0]);
	Passer.Q=&Q[0];
	Passer.Qw=&Qw[0];
	Passer.Qf=&Qf[0];
	Passer.RiskRat=&RiskRat[0];
	Passer.sectors=sectors;
	Passer.Uinfo=0;
	Passer.fac=1e7;//This is the multiplier for w-v penalty term in DOUBLE option
	Passer.alpha=alpha;
	Passer.gamma=0;
	if(alpha&&ddotvec(n,alpha,alpha)>lm_rooteps)
		Passer.gamma=gamma;

	if(nf==-1)
	{
		dcopyvec(nn,FC,&Q[0]);
	}
	else
	{
		Qf.resize(n*(nf+1));
		Passer.Qf=&Qf[0];
		if(FL&&SV&&FC)factor_model_process(n,nf,FL,FC,SV,&Qf[0]);
		else if(FC) Passer.Qf=FC;
		Factor2Cov(n,nf,FC,FL,SV,&Q[0]);
	}

#if 1
	std::valarray<double> eigv(n*n),eig(n);
	dcopyvec(nn,&Q[0],&eigv[0]);
	packed2symm(n,&eigv[0]);
	short ee=eigendecomp(n,&eigv[0],&eig[0],100);
	//parity log printf((char*)"\e[1;1;33mHighest eigenvalue %20.15e, lowest %20.15e;\e[1;1;35m\nCondition %20.15e\e[0;m\n",eig[0],eig[n-1],eig[n-1]/eig[0]);
	eigv.resize(0);
	eig.resize(0);
#endif

	size_t m,iprint=0,conventional=0;
	int iter = 100;
	if (seq == 3)
	{
		conventional = 1;
		seq = 0;
	}
	if (!seq)
		iter = 100;
	if(Passer.DOUBLE)
		m=n+nsect+1;
	else
		m=nsect+1;
	std::valarray<double> x(nvab),y(m),z(nvab);
	size_t i;

/*	******************************************************************** */
	//The starting guess for x can make a big difference to the convergence of the optimisation to a proper risk parity solution!!!!!!!!!!!!!
	if ((*conc = ddotvec(n, w, w)) > lm_rooteps)
	{
		dcopyvec(n, w, &x[0]);
		if (Passer.DOUBLE)
			dcopyvec(n, w, &x[n]);
	}
	else
	{
		if (seq == 0 || seq == 1)
			x = 1.01 / n;
		else
		{
			for (i = 0; i < n; ++i)
			{
				x[i] = (i + 1);
			}
			dscalvec(n, 1.0 / dsumvec(n, &x[0]), &x[0]);
		}
	}
/*	******************************************************************** */
	z=1;
	y=0;

	short back;
	pModQ Hesser=ParityVarianceH;
	void* Hinfo=&Passer;
//	Hesser=0;Hinfo=0;


	double nu=0.05,mudec=4,Mu=3e4,mexp=4,shape=0;
	bool neg=false;
	for(i=0;i<n;++i)
	{
		if(fabs(x[i])<lm_rooteps)
		{
		//parity log 	printf((char*)"\e[1;1;32mChange\t%4d\t\t%e\e[0;m\n",i+1,x[i]);
			if(x[i]<0)
				x[i]=-1e-6;
			else
				x[i]=1e-6;
		}
	}

	if(true)//!Passer.sectors)
	{
		if(seq)
		{
			std::valarray<double> LL(nvab),UU(nvab);
			if(seq==2)
			{
				LL=Passer.lower;
				Passer.lower=0;
			}
			else
				LL=0;
			UU=1-Passer.lower;
			nu =0.5;
			back=OptimiseNLC_Seq(nvab,&x[0],&y[0],&z[0],m-1,ParityGenC2,&Passer,ParityVarianceF,ParityVarianceG,Hesser,
				&Passer,&Passer,Hinfo,lm_eps,&iter,iprint,nu,&LL[0],&UU[0]);
		}
		else
			back=OptimiseNLC(nvab,&x[0],&y[0],&z[0],m-1,ParityGenC2,&Passer,ParityVarianceF,ParityVarianceG,Hesser,
			&Passer,&Passer,Hinfo,lm_eps65392,nu,mudec,Mu,mexp,shape,&iter,iprint,conventional);
		if(Passer.lower!=0)
		{
			for(i=0;i<nvab;++i)
				x[i] += Passer.lower;
		}

	}
	else
	{
		std::valarray<double> LL(nvab),UU(nvab);
		LL=0;
		UU=1;
		back=OptimiseNLC_Seq(nvab,&x[0],&y[0],&z[0],m-1,ParityGenC2,&Passer,ParityVarianceF,ParityVarianceG,Hesser,
			&Passer,&Passer,Hinfo,lm_eps16348,&iter,iprint,0.75,&LL[0],&UU[0]);
	}
	/*	for(i=0;i<n;++i)
	{
		if(x[i]<0)
		{
			neg=true;x[i]=-x[i];
		}
	}

	if(neg)
	{
		iter=200;
		back=OptimiseNLC(nvab,&x[0],&y[0],&z[0],m,ParityGenC2,&Passer,ParityVarianceF,ParityVarianceG,Hesser,&Passer,&Passer,Hinfo,lm_rooteps*.1,nu,mudec,Mu,mexp,shape,&iter,iprint,conventional);
	}*/
	//parity log printx(m-1,&y[0]);


	dcopyvec(n,&x[0],w);
	*conc=ddotvec(n,w,w);
	return back;
}

class minCvarinfo
{
public:
	dimen n,tlen,number_included;
	vector DATA,w;
};
extern "C" double MinCVar(double x,void*info)
{
	//This gives VaR as the optimal x
	minCvarinfo*MC=(minCvarinfo*)info;
	MC->w[MC->n]=x;
	return CVarValueO(MC->n+1,MC->tlen,MC->DATA,MC->number_included,MC->w);
}

extern "C" short LPhelper(size_t n,size_t m,vector w,vector A,vector c,vector L,vector U,int log=1,char*logfile=0);

extern "C" DLLEXPORT short OptCVar(dimen nstocks,dimen m,dimen t,double beta,vector w,vector DATA,vector lower,vector upper,vector A,int log=0,double*CVaR=0,double*VaR=0)
{
	/*

	DATA is for a loss function so in the context of portfolio optimisation using return data it is -returns.

	DATA[i*t +j] is minus the return of stock i in period j

	*/
	auto cvarmax=false;
#ifdef __SYSNT__
	_ASSERT(0);
#endif
#ifdef PAS
	//	UnlockBita((char*)"colincolin");
	if (!Optimise::bitago)
	{
		fprintf(stderr, "Bad PAS key\n");
		return -1;
	}
	return -1;
#endif
	char* outfile=0;
	if(log==2)
		outfile=(char*)"CVarf1.log";
	std::ofstream outFile;

	if(outfile&&!strlen(outfile))//In case someone sends outfile=(char*)""
	{
		std::cout<<"No output file was given"<<std::endl;
		//return;
	}
	if(outfile)
	{
		outFile.open(outfile,std::ios_base::out);
		if(outFile.fail())
		{
			std::cout<<"Cannot open "<<outfile<<std::endl;
			//return;
		}
		if(log==2)
		{
			dumpvector(1,(char*)"nstocks",&nstocks,outFile);
			dumpvector(1,(char*)"m",&m,outFile);
			dumpvector(1,(char*)"t",&t,outFile);
			dumpvector(1,(char*)"beta",&beta,outFile);
			dumpvector(nstocks*t,(char*)"DATA",DATA,outFile);
			dumpvector(nstocks+m,(char*)"lower",lower,outFile);
			dumpvector(nstocks+m,(char*)"upper",upper,outFile);
			dumpvector(nstocks*m,(char*)"A",A,outFile);
			outFile<<"-------------------------------------------------------------------------------------------";
			outFile<<std::endl;
			outFile.flush();
		}
	}
	short back;
	dimen M=m+t+(dimen)cvarmax,n=nstocks+1+t,number_included=(dimen)(beta*t),i,j;
	Optimise OO;
	if(log)OO.SetLog();
	std::valarray<double>x(n),AA(n*M),L(n+M),U(n+M),lambda(n+M),cvarc(n),c(n);

	double maxret;

	MVCvar Opt(nstocks,t,DATA,number_included);

	Opt.getMeans();
	c=0;
	dcopyvec(n,Opt.mean,&c[0]);
	dnegvec(n,&c[0]);

	maxret=linfinity(nstocks*t,DATA);
	dcopyvec(nstocks,lower,&L[0]);
	dcopyvec(nstocks,upper,&U[0]);
	L[nstocks]=-maxret;
	U[nstocks]=maxret;
	dsetvec(t,0,&L[nstocks+1]);
	dsetvec(t,maxret,&U[nstocks+1]);
	dcopyvec(m,lower+nstocks,&L[n]);
	dcopyvec(m,upper+nstocks,&U[n]);
	dsetvec(t,-maxret,&L[n+m]);
	dsetvec(t,0,&U[n+m]);

	AA=0;
	for(j=0;j<m;++j)
		dcopy(nstocks,A+j,m,&AA[j],M);
	for(j=m;j<M-1;j++)
	{
		dcopy(nstocks,DATA+j-m,t,&AA[j],M);
		AA[nstocks*M+j]=-1;
		AA[(nstocks+1+j-m)*M+j]=-1;
	}

	cvarc=0;
	cvarc[nstocks]=1;
	dsetvec(t,1.0/(t-number_included),&cvarc[nstocks+1]);

	if(!cvarmax)
	{
		c = cvarc;//Utility is CVAR
	}
	else
	{
		dcopy(n,&cvarc[0],1,&AA[M-1],M);
		L[n+M-1]=-1;
		U[n+M-1]=-.0001;
	}

	OO.lp=true;
	x=1.0/n;
	lambda=1;
	back=OO.OptAdvanced(n,M,&x[0],&AA[0],&L[0],&U[0],&c[0],&lambda[0]);
	//back=LPhelper(n,M,&x[0],&AA[0],&c[0],&L[0],&U[0],1);
	double ret,tot,CV1,CV2,CVarn,Varn=x[nstocks],dX=0;
	CV1=CVarValue(nstocks,t,DATA,number_included,&x[0]);
	CV2=CVarValueO(nstocks+1,t,DATA,number_included,&x[0]);
	CVarn=CV1;
	if(log)OO.AddLog((char*)"old VaR %20.8e CVaR %20.8e CVaR %20.8e\n",Varn,CV1,CV2);
	if(back<2 && fabs(CV1-CV2)>lm_rooteps)
	{
		//If these values for CVaR are different find what the VaR should be? This should never happen! If it does, the CVaR constraints are wrong!
		std::valarray<double>xx(nstocks+1);
		dcopyvec(nstocks,&x[0],&xx[0]);
		minCvarinfo MC;
		MC.n=nstocks;
		MC.tlen=t;
		MC.DATA=DATA;
		MC.number_included=number_included;
		MC.w=&xx[0];
		PathMin(MinCVar,-maxret,maxret,lm_rooteps,&MC,0);
		CVarn=MinCVar(xx[nstocks],&MC);
		dX=xx[nstocks]-Varn;
		Varn=xx[nstocks];
		if(log)OO.AddLog((char*)"new VaR %20.8e CVaR %20.8e\n",Varn,CVarn);
	}
	if(log)
	{
		OO.AddLog((char*)"%s\n",Return_Message(back));
		OO.AddLog((char*)"Primal          %20.8e\n",ddotvec(n,&x[0],&c[0]));
		OO.AddLog((char*)"Dual (L)        %20.8e\n",ddotvec(M,&lambda[n],&L[n]));
		OO.AddLog((char*)"Dual (U)        %20.8e\n",ddotvec(M,&lambda[n],&U[n]));
		OO.AddLog((char*)"Complementarity %20.8e\n",ddotvec(n,&x[0],&lambda[0]));
		OO.AddLog((char*)"CVar  %10.5f VaR %10.5f (maxret %10.5f)\n",ddotvec(n,&cvarc[0],&x[0]),x[nstocks],maxret);
		OO.AddLog((char*)"Check %10.5f     %10.5f\n",CV1,CV2);
		OO.AddLog((char*)"%20s %20s %20s %20s\n",(char*)"Lower",(char*)"Constraint",(char*)"lambda",(char*)"Upper");
		for(i=0;i<m;++i)
		{
			OO.AddLog((char*)"%20.8e %20.8e %20.8e %20.8e\n",lower[i+nstocks],BITA_ddot(nstocks,&x[0],1,A+i,m),lambda[n+i],upper[i+nstocks]);
		}
		OO.AddLog((char*)"______________________________________________________________________________________\n");
		OO.AddLog((char*)"%20s %20s %20s %20s\n",(char*)"Lower",(char*)"Weights",(char*)"lambda",(char*)"Upper");
		for(i=0;i<nstocks;++i)
		{
			OO.AddLog((char*)"%20.8e %20.8e %20.8e %20.8e\n",lower[i],x[i],lambda[i],upper[i]);
		}
		OO.AddLog((char*)"______________________________________________________________________________________\n");
		OO.AddLog((char*)"Extra variables that enable CVaR to be a linear optimisation\n");
		OO.AddLog((char*)"%20s %20s %20s %20s\n",(char*)"Lower",(char*)"Weights",(char*)"lambda",(char*)"Upper");
		for(i=nstocks;i<nstocks+1;++i)
		{
			OO.AddLog((char*)"%20.8e %20.8e %20.8e %20.8e\n",L[i],x[i],lambda[i],U[i]);
		}
		OO.AddLog((char*)"%20s %20s %20s %20s %20s %20s %20s\n",(char*)"Lower",(char*)"rti - X",(char*)" ",(char*)"lambda",(char*)"lambda constraint",(char*)"lambda constraint-lambda",(char*)"Upper");
		for(i=nstocks+1,tot=0;i<n;++i)
		{
			ret=BITA_ddot(nstocks,DATA+i-nstocks-1,t,&x[0],1);tot+=ret;
			OO.AddLog((char*)"%20.8e %20.8e (%20.8e) %20.8e %20.8e %20.8e %20.8e\n",L[i],x[i],ret-x[nstocks],lambda[i],lambda[n+i-nstocks-1+m],-lambda[i]+lambda[n+i-nstocks-1+m],U[i]);
		}
		OO.AddLog((char*)"%20s %20.8e (%20s)|%20.8e %20.8e %20.8e\n",(char*)"Total/t +X",tot/t,(char*)"-timeaveraged return",dsumvec(t,&lambda[nstocks+1]),dsumvec(t,&lambda[n+m]),-dsumvec(t,&lambda[nstocks+1])+dsumvec(t,&lambda[n+m]));
		OO.AddLog((char*)"%20s %20s  %20s  %20.8e %20s %20.8e\n",(char*)" ",(char*)" ",(char*)"ni/(t-ni)",(double(number_included)/(t-number_included)),(char*)"t/(t-ni)",(double(t))/(t-number_included));
		OO.AddLog((char*)"CVaR change %20.8e, Change in VaR %20.8e\n",CV1-CV2,dX);
		OO.AddLog((char*)"(-Timeaveraged return - VaR)*t/(t-ni) + VaR %20.8e (CV2=%20.8e)\n",dsumvec(t,&x[nstocks+1])/(t-number_included)+x[nstocks],CV2);

		std::valarray<size_t> oR(t),iR(t);
		getorderneg(t,&x[nstocks+1],&oR[0],0);
		for(i=0;i<t;++i)iR[oR[i]]=i;
		Reorder(t,&oR[0],&x[nstocks+1]);
		OO.AddLog((char*)"CVaR from ordered %20.8e (CV1=%20.8e)\n",x[nstocks]+dsumvec(t-number_included,&x[nstocks+1+number_included])/(t-number_included),CV1);
		OO.AddLog((char*)"VaR from ordered %20.8e (%20.8e)\n",x[nstocks+1+number_included]+x[nstocks],x[nstocks]);
		Reorder(t,&iR[0],&x[nstocks+1]);


		OO.AddLog((char*)"_____________________________________________________________________\n");
	}
	dcopyvec(nstocks,&x[0],w);
	if(CVaR)*CVaR=CVarn;
	if(VaR)*VaR=Varn;
	if(outfile)
	{
		outFile<<OO.logprint->str();
		outFile.clear();
		outFile.close();
	}

	return back;
}



short OptimiseNLC_Seq(dimen n,vector x,vector y,vector z,dimen m,pConstraintFunc GenAb,void* Abinfo,pUtility F,pModC gradF,pModQ hessF,
	void *Uinfo,void *Minfo,void *Qinfo,double tol,int*iter,int log,double nu,vector lower,vector upper)
{
	/*	

		Minimise a general function F(x)
		such that GenAb(x)=0 (m non-linear constraints)
		and x[i]>=0 i=0....n-1

		using sequential quadratic programming.

		Unfortunately this process can converge to false solutions which have primal=dual and non-linear constraints satisfied but primal is not
		globally lowest!

		Needs a good starting point to get the true optimal solution.

		Also nu (<1) depends very much on the problem and getting it right reduces number of iterations needed a lot.

		There is no conclusive way to identify an infeasible set of constraints.

	*/
	//Decide whether to use true or approximate derivatives
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	NLC_Info Passer;
	Passer.Util=F;
	Passer.Uinfo=Uinfo;
	Passer.BFGS=hessF?false:true;
	Passer.ModDeriv=gradF?gradF:0;
	if(Passer.ModDeriv)
		Passer.gradinfo=Minfo;
	std::valarray<double>xnow,xpast,gnow,gpast,hnow;
	bool noz=!z;
	if(Passer.BFGS)
	{
		hnow.resize(n*(n+1)>>1);Passer.hnow=&hnow[0];
		xnow.resize(n);Passer.xnow=&xnow[0];
		xpast.resize(n);Passer.xpast=&xpast[0];
		gnow.resize(n);Passer.gnow=&gnow[0];
		gpast.resize(n);Passer.gpast=&gpast[0];
		Passer.count=0;
	}

	//We proceed like this
	pModC gradFhere=NLC_Grad;
	pModQ hessFhere=hessF?hessF:BFGSHess;
	void* gradInfo=&Passer;
	void* hessInfo=hessF?Qinfo:&Passer;
	Passer.H=hessFhere;
	hessFhere=NLC_Hess;
	Passer.hessInfo=hessInfo;

	Passer.G=GenAb;
	Passer.Abinfo=Abinfo;

	GenAb=NLC_G;


	size_t nn=n*(n+1)>>1,div;
	std::valarray<double> dxy(n+m),dz(n);
	std::valarray<double> H((n+m)*(n+m+1)/2),r0(n);
	bool setx=false,setz=false,sety=false;
	size_t i;
	int maxiter=1000;

	if(iter&&iter[0]) maxiter=iter[0];

	std::valarray<double> A(n*m),g(m);

	if(ddotvec(n,x,x)<=lm_eps)setx=true;
	if(z&&ddotvec(n,z,z)<=lm_eps)setz=true;
	if(ddotvec(m,y,y)<=lm_eps)sety=true;
	if(setx)
	{
		dsetvec(n,1.,x);
	}
	if(z&&setz)
	{
		dsetvec(n,1.,z);
	}
	if(sety)
	{
		dsetvec(m,0,y);
	}
	double Primal=F(n,&x[0],Uinfo),SubP=1,stepmin,pathlength2=1,ss_p=1,muincrease=1;
	double mu,Fmax,Gmax,Fmin,Gmin,stephere=1;

	std::valarray<double>GG(m);
	meritinfo MERIT_info; 
	MERIT_info.noz=noz;
	FiniteDiffGrad(n,&x[0],&r0[0],gradInfo);dxminmax(n,&r0[0],1,&Fmax,&Fmin);Fmax=dmax(1.0,Fmax);
	Passer.scaleF=Fmax;

	Passer.G(n,m,&x[0],&y[0],&A[0],0,&g[0],Abinfo);
	
	for(i=0;i<m;i++)
	{
		dxminmax(n,&A[i*n],1,&Gmax,&Gmin);
		GG[i]=dmax(fabs(g[i]),dmax(1.0,Gmax));
	}
	Passer.scaleG=&GG[0];

	H=0;hessFhere(n,&x[0],&H[0],&Passer);
	gradFhere(n,&x[0],&dxy[0],gradInfo);
	GenAb(n,m,&x[0],&y[0],&A[0],&H[0],&g[0],&Passer);

	Optimise OO;
	if(log)OO.SetLog();

	std::valarray<double> L(n+m),U(n+m),dX(2*n+m);

	if(!lower )
		dsetvec(n,0,&L[0]);
	else
		dcopyvec(n,lower,&L[0]);
	if(!upper)
		dsetvec(n,1e10,&U[0]);
	else
		dcopyvec(n,upper,&U[0]);

	dsubvec(n,&L[0],x,&L[0]);
	dsubvec(n,&U[0],x,&U[0]);
	dcopyvec(m,&g[0],&L[n]);dnegvec(m,&L[n]);
	dcopyvec(m,&g[0],&U[n]);dnegvec(m,&U[n]);
	dmx_transpose(n,m,&A[0],&A[0]);
	OO.H=&H[0];
	if(z)dcopyvec(n,z,&dX[n]);
	dcopyvec(m,y,&dX[n*2]);
	dsetvec(n+m,0,&dX[n]);
	size_t loop=0,badback=0,badback_lim=5;
	short back;
	short stephere_count=0;
	
	OO.lp=false;
	OO.hmul=(pHmul)HMUL;
	double cexp_reset = 1e-3;
	double cexp=1e-8,cexptest;
	std::valarray<double>cexpm(m);
	double lcexpm;
	bool was6 = false,was8=false,was5=false,pathchange=false;
	size_t pathchange_start = 0;

	cexpm = 1;

	for(i=0;i<m;++i)
	{
		cexpm[i] = fabs(g[i]);

		L[n+i]=-g[i]-cexp*cexpm[i];
		U[n+i]=-g[i]+cexp*cexpm[i];
	}
	while((!loop||(loop<maxiter && ((lcexpm=linfinity(m,&g[0]))>tol /*|| (pathlength2>tol*tol&&ss_p>tol*(n+m))*/)))&&(stephere_count < 10))
	{
		if(badback>badback_lim)break;
		if (back == 0 && (lcexpm = linfinity(m, &g[0])) < 1e-14)
		{
			size_t small_num = 0;
			for (i = 0; i < m; ++i)
			{
				if (fabs(g[i]) <= lm_eps) small_num++;
			}
			OO.AddLog((char*)"\e[1;4;35msmall_num %d\n", small_num);
			if (small_num)break;
		}
		was5 = back == 5;
		was8 = back == 8;
		back=OO.OptAdvanced(n,m,&dX[0],&A[0],&L[0],&U[0],&dxy[0],&dX[n]);
		was6 = back == 6;
		if(z)dcopyvec(n,&dX[n],z);
		dcopyvec(m,&dX[n*2],y);
		if(linfinity(m,&y[0])>1e16)
			dzerovec(m,&y[0]);
		cexptest=linfinity(m,&g[0])*nu;

		if(log&&back<=2)
		{
			for(i=0;i<m;i++)
			{
				OO.AddLog((char*)"y=%20.8e C%d %20.8e (%20.8e,%20.8e) -g=%20.8e\n",y[i],i,BITA_ddot(n,&A[i],m,&dX[0],1),L[n+i],U[n+i],-g[i]);
			}
			OO.AddLog((char*)"\n");
		}

		while(back==6)// || back==8)//||back==5)
		{
			if (cexp)
			{
				cexp /= (nu);
				cexp /= (nu*1.5);
			}
			else cexp=1e-8;
			for(i=0;i<m;++i)
			{
				L[n+i]=-g[i]-cexp*cexpm[i];
				U[n+i]=-g[i]+cexp*cexpm[i];
			}
			back=OO.OptAdvanced(n,m,&dX[0],&A[0],&L[0],&U[0],&dxy[0],&dX[n]);
			if(z)dcopyvec(n,&dX[n],z);
			dcopyvec(m,&dX[n*2],y);
			if(log&&back<=2)
			{
				for(i=0;i<m;i++)
				{
					OO.AddLog((char*)"Cy%d %20.8e %20.8e (%20.8e,%20.8e) -g=%20.8e\n",i,y[i],BITA_ddot(n,&A[i],m,&dX[0],1),L[n+i],U[n+i],-g[i]);
				}
				OO.AddLog((char*)"\n");
			}
		}

		if(cexp== cexp_reset)badback++;
		else badback=0;

		SubP=ddotvec(n,&dX[0],&dxy[0]);
		pathlength2=ddotvec(n,&dX[0],&dX[0]);
		ss_p=(SubP*SubP/pathlength2);

		for(i=0,div=m,mu=0;i<m;++i)
		{
			if(fabs(y[i])>lm_eps8)mu+=fabs(g[i]/y[i]);
			else div--;
			cexpm[i] = fabs(g[i]);
		}

		lcexpm = linfinity(m, &cexpm[0]);

/*		if (lcexpm > cexp && cexp > lm_eps)
		{
			dscalvec(m, cexp / lcexpm, &cexpm[0]);
			lcexpm = cexp;
		}*/

		if(div)
			mu/=((double)div);
		if(mu==0)
			mu=1;

		pathchange = false;
		if (back == 0 && pathlength2<1e-4&&cexp>1e-1)
		{
			pathchange_start++;
			OO.AddLog((char*)"\e[1;4;35m pathchange_start %d\e[0m\n", pathchange_start);
			if(pathchange_start > 4)
			{
				pathchange_start = 0;
				double oldp2 = pathlength2;
				size_t nzero = 0;
				stephere = 2;
				for (i = 0; i < n; ++i)
				{
					if (x[i] < 1e-12)
					{
						dX[i] = 1e-1; pathchange = true; nzero++;
					}
					pathlength2 = ddotvec(n, &dX[0], &dX[0]);
				}
				if (!pathchange||nzero==1)
				{
									dscalvec(n, 1e-1 / sqrt(pathlength2), &dX[0]);
				/*	std::valarray<double> dir2(n);
					dir2 = 1;
					daxpyvec(n, 1e-2, &dir2[0], &dX[0]);*/
					pathchange = true;
					if(nzero)OO.AddLog((char*)"\e[1;4;33m Path had one small variable ");
				}
				else
					OO.AddLog((char*)"\e[1;4;33m Path had small variables ");
				SubP = ddotvec(n, &dX[0], &dxy[0]);
				pathlength2 = ddotvec(n, &dX[0], &dX[0]);
				ss_p = (SubP*SubP / pathlength2);
				OO.AddLog((char*)"\e[1;4;36m Path changed to discourage near 'local' solution %e (%was %e)\e[0m\n", pathlength2, oldp2);
			}
		}
		else
		{
			pathchange_start = 0;
		}


		MERIT_info.dx=&dX[0];
		MERIT_info.dy=&dX[n+n];
		MERIT_info.dz=&dX[n];
		MERIT_info.F=NLC_F;
		MERIT_info.info=&Passer;
		MERIT_info.m=m;
		MERIT_info.mu=mu;
		MERIT_info.cexp=cexp;
		MERIT_info.n=n;
		MERIT_info.nu=nu;
		MERIT_info.x=x;
		MERIT_info.y=y;
		MERIT_info.z=y;
		MERIT_info.Cinfo=&Passer;
		MERIT_info.g=GenAb;
		double FF=NLC_F(n,x,&Passer),GG=linfinity(m,&g[0]);
		if (log)OO.AddLog((char*)"F before path minimisation %20.8e\n\e[1;36m||G||oo %20.8e\e[0;m\n\e[1;35mFF/||G||oo %20.8e\n", FF, GG, FF / GG);

		if (cexp > lm_eps)
		{
			MERIT_info.mu = mu;
			stepmin = (back == 0 ? (pathlength2 < 5e-5 ? 0.4 : 0.3) : 8e-1);
			if (pathchange)
				stepmin = 0.2;
			stephere = PathMin(Path_merit_Seq, stepmin, 1.0, lm_rooteps, &MERIT_info, 0);
			MERIT_info.mu = mu;
		}
		else
		{
			if(fabs(GG/FF)>lm_rooteps||ss_p<lm_rooteps)
			{
				stepmin = back==0 ? 1e-1 : 9e-1;
				stephere=PathMin(Path_merit_Seq,stepmin,1.0,lm_rooteps,&MERIT_info,0);
				if(false)//stephere<1.5e-1)
				{
					if(mu<=1e-2)MERIT_info.mu*=1e3*muincrease;
					else MERIT_info.mu=muincrease*ddotvec(n,x,z)/n;
					if(MERIT_info.mu < lm_eps) MERIT_info.mu=lm_rooteps;
					if(log)OO.AddLog((char*)"\e[1;1;35mTry mu=%e since step is \e[1;4;34m%f\n",MERIT_info.mu,stephere);
					stephere=PathMin(Path_merit_Seq,stephere,1.0,lm_rooteps,&MERIT_info,0);
					if(log)OO.AddLog((char*)"\e[1;1;35mNew step \e[1;4;34m%f\n",stephere);
					MERIT_info.mu=mu;
					muincrease*=10.0;
				}
				else
					muincrease=1;
			}
			else
				stephere=1;
		}

		daxpyvec(n, stephere, &dX[0], x);
		lcexpm = linfinity(m, &cexpm[0]);
		if(log)
		{
			OO.AddLog((char*)"step %20.8e cexp %20.8e cexpm %20.8e mu %20.8e F %20.8e SubP %20.8e pathlength2 %20.8e\n",stephere,cexp, lcexpm,MERIT_info.mu,NLC_F(n,x,&Passer),SubP,pathlength2);
			OO.AddLog((char*)"SubP*SubP/pathlength2 %20.8e\n",ss_p);
		}

		H=0;hessFhere(n,&x[0],&H[0],&Passer);
		gradFhere(n,&x[0],&dxy[0],gradInfo);
		GenAb(n,m,&x[0],&y[0],&A[0],&H[0],&g[0],&Passer);
		dmx_transpose(n,m,&A[0],&A[0]);
		daxpyvec(n,-stephere,&dX[0],&L[0]);
		daxpyvec(n,-stephere,&dX[0],&U[0]);

		if (pathlength2 > 5e-4 || cexp<1e-2)
			cexp *= nu;
		else if (back == 0 && pathlength2>5e-6)
			cexp *= (0.8);
		else if (back == 0)
			cexp *= (0.9);
		else
			cexp *= nu;

		if(was6)
		{
			if (cexp < 5e-7)cexp = 0;
		}
		else if(back==0)
		{
			if (cexp*lcexpm < lm_rooteps && lcexpm>1e-6 && !was8&&!was5)cexp = 0;
			else if (linfinity(m, &g[0]) < 5e-7 && !was8 && !was5)cexp = 0;
		}
		if ((!was6&&back == 0) && pathlength2 < 1e-4)
		{
			double mm, MM;
			dxminmax(n, &x[0], 1, &mm, &MM);
			//if (MM < 5e-5)
			{
				if(cexp<0.1)cexp = 0;
				OO.AddLog((char*)"\e[1;1;34mSmall path set cexp to %e \e[1;4;35m(%e,%e)\e[0m\n",cexp, mm, MM);
			}
		}

		if (cexp / nu > 10 || (cexp<1e-6 &&(back==8||back==5)))
		{
			cexp = cexp_reset;
			if (back == 8 || back == 5)
				cexp /= 10;
			cexpm = lcexpm;
		}

		if(cexp == 0 && stephere <= lm_eps8)
		{
			stephere_count++;//OO.AddLog((char*)"cexp %f stephere %f stephere_count %d\n",cexp,stephere,stephere_count);
		}
		else
			stephere_count=0;

		for(i=0;i<m;++i)
		{
			L[n+i]=-g[i]-cexp*cexpm[i];
			U[n+i]=-g[i]+cexp*cexpm[i];
		}

		loop++;
		if(log)
		{
			Primal=NLC_F(n,&x[0],&Passer);
			for(i=0;i<m;++i)
				dxy[n+i]=BITA_ddot(n,&A[i],m,&x[0],1);
			double Dual= ddotvec(m,&dxy[n],&y[0]) - ddotvec(m,&y[0],&g[0])  +Primal - ddotvec(n,x,&dxy[0]);
			if(z)
				Dual+= ddotvec(n,x,z);
			OO.AddLog((char*)"%4d Primal %20.8e Dual %20.8e\n",loop,Primal,Dual);
		}
	}
	if(log)
	{
		Primal=NLC_F(n,&x[0],&Passer);H=0;
		hessFhere(n,&x[0],&H[0],&Passer);
		gradFhere(n,&x[0],&dxy[0],gradInfo);
		GenAb(n,m,&x[0],&y[0],&A[0],&H[0],&g[0],&Passer);dmx_transpose(n,m,&A[0],&A[0]);
		for(i=0;i<m;++i)
			dxy[n+i]=BITA_ddot(n,&A[i],m,&x[0],1);
		double Dual= ddotvec(m,&dxy[n],&y[0]) - ddotvec(m,&y[0],&g[0])  +Primal - ddotvec(n,x,&dxy[0]);
		if(z)
			Dual+= ddotvec(n,x,z);
		OO.AddLog((char*)"%4s Primal %20.8e Dual %20.8e\n",(char*)" ",Primal,Dual);
	}

	//Get y and z correct________________________________________________________
	for(i=0;i<m;++i)
		y[i]*=Passer.scaleF/Passer.scaleG[i];
	if(z)dscalvec(n,Passer.scaleF,z);
	if(iter)*iter=loop;
	if(badback>badback_lim)back=6;
	if(stephere_count>=10)back=11;
	if(loop==maxiter||cexp>0)back=11;
	Passer.G(n,m,&x[0],&y[0],&A[0],&H[0],&g[0],Abinfo);
	return back;
}


extern "C" DLLEXPORT short OptGL(dimen nstocks,dimen m,dimen t,vector R,vector w,vector DATA,vector lower,vector upper,vector A,double C,int log=0,double*Gain=0,double *Loss=0)
{
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	char* outfile=0;
	if(log==2)
		outfile=(char*)"GLf.log";
	std::ofstream outFile;

	if(outfile&&!strlen(outfile))//In case someone sends outfile=(char*)""
	{
		std::cout<<"No output file was given"<<std::endl;
		//return;
	}
	if(outfile)
	{
		outFile.open(outfile,std::ios_base::out);
		if(outFile.fail())
		{
			std::cout<<"Cannot open "<<outfile<<std::endl;
			//return;
		}
		if(log==2)
		{
			dumpvector(1,(char*)"nstocks",&nstocks,outFile);
			dumpvector(1,(char*)"m",&m,outFile);
			dumpvector(1,(char*)"t",&t,outFile);
			dumpvector(t,(char*)"R",R,outFile);
			dumpvector(nstocks*t,(char*)"DATA",DATA,outFile);
			dumpvector(nstocks+m,(char*)"lower",lower,outFile);
			dumpvector(nstocks+m,(char*)"upper",upper,outFile);
			dumpvector(nstocks*m,(char*)"A",A,outFile);
			dumpvector(1,(char*)"C",&C,outFile);
			outFile<<"-------------------------------------------------------------------------------------------";
			outFile<<std::endl;
			outFile.flush();
		}
	}
	short back=0;
	Optimise OO;
	if(log)OO.SetLog();
	std::valarray<size_t>ls;
	dimen M=m+t,n=nstocks+t,i,j,nneg,fixed;
	for(i=0,nneg=0;i<nstocks;++i)
	{
		if(lower[i]<-lm_eps)
		{
			nneg++;
		}
	}
	if(nneg)
	{
		ls.resize(nneg);
		size_t*lsp=&ls[0];
		for(i=0;i<nstocks;++i)
		{
			if(lower[i]<-lm_eps)
			{
				*lsp=i;
				lsp++;
			}
		}
		M+=2*nneg+1;
		n+=2*nneg;
	}



	std::valarray<double>x(n),AA(n*M),L(n+M),U(n+M),lambda(n+M),c(n);
	std::valarray<size_t>order;
	dimen nstart=nstocks,tstart=nstocks;

	double maxret;

	maxret=max(linfinity(nstocks*t,DATA),linfinity(t,R));
	dcopyvec(nstocks,lower,&L[0]);
	dcopyvec(nstocks,upper,&U[0]);

	nstart=nstocks;//+t;
	tstart=nstocks+2*nneg;
	dsetvec(t,0,&L[tstart]);
	dsetvec(t,maxret,&U[tstart]);
	if(nneg)
	{
		dsetvec(nneg,0,&L[nstart]);
		for(i=0;i<nneg;++i)
		{
			U[nstart+i]=upper[ls[i]];
			L[nstart+i+nneg]=lower[ls[i]];
		}
		dsetvec(nneg,0,&U[nstart+nneg]);
	}
	dcopyvec(m,lower+nstocks,&L[n]);
	dcopyvec(m,upper+nstocks,&U[n]);



	dcopyvec(t,R,&L[n+m]);
	dsetvec(t,maxret,&U[n+m]);

	AA=0;
	for(j=0;j<m;++j)
		dcopy(nstocks,A+j,m,&AA[j],M);
	for(j=m;j<m+t;j++)
	{
		AA[j+M*(tstart+j-m)]=1;
		dcopy(nstocks,DATA+j-m,t,&AA[j],M);
	}

	if(nneg)
	{
		for(j=0;j<nneg;++j)
		{
			L[n+j+m+t]=-1;
			U[n+j+m+t]=0;
			U[n+j+m+t+nneg]=1;
			L[n+j+m+t+nneg]=0;
			AA[j+m+t+M*(nstart+j)]=-1;
			AA[j+m+t+M*(ls[j])]=1;
			AA[j+m+t+nneg+M*(nstart+j+nneg)]=-1;
			AA[j+m+t+nneg+M*(ls[j])]=1;
		}
		//Last constraint makes the long side total equal 1
		L[n+M-1]=1;
		U[n+M-1]=1;
		for(i=0;i<nstocks;++i)
		{
			if(lower[i]>lm_eps)
				AA[M-1+M*i]=1;
		}
		for(i=0;i<nneg;++i)
			AA[M-1+M*(nstart+i)]=1;
	}
	c=0;

	GainLossVar Opt(t,nstocks,DATA,R,0,-1,0,0,0);

	//Minimise alpha - C* Expected Loss
	dcopyvec(nstocks,Opt.mean,&c[0]);dnegvec(nstocks,&c[0]);
	dsetvec(t,C/t,&c[tstart]);

	OO.lp=true;
	x=1.0/nstocks;
	lambda=1;

	for(i=0,fixed=0;i<n;++i)
	{
		if(fabs(U[i]-L[i]) < OO.equalbounds)
			fixed++;
	}
 	if(fixed)
  	{
		order.resize(2*n);
 		size_t*inverse=&order[n];
 		long sofar;
 		for(i=0;i<n;++i)order[i]=i;
 		sofar = (long)(n-1);
 		for(i = 0;sofar>=(long)i;++i)
 		{
 			while(sofar>=0&&fabs(L[order[sofar]] - U[order[sofar]]) < OO.equalbounds){sofar--;}
 			if(sofar > (long)i && fabs(L[order[i]] - U[order[i]]) < OO.equalbounds)
 			{
 				std::swap(order[i],order[sofar]);
 			}
 		}
 		for(i=0;i<n;++i) {inverse[order[i]]=i;}
 		Reorder_gen(n,&order[0],&L[0],1);
 		Reorder_gen(n,&order[0],&U[0],1);
 		Reorder_gen(n,&order[0],&AA[0],M);
 		Reorder_gen(n,&order[0],&c[0],1);
 		dcopyvec(fixed,&L[n-fixed],&x[n-fixed]);
 		for(i=0;i<m;++i)//We have to check that fixed stocks don't violate linear constraints
  		{
 			if(BITA_ddot(n-fixed,&AA[i],M,&AA[i],M) <lm_eps)//This is zero if only the fixed stocks are in the constraint
 			{
 				double testcon=BITA_ddot(fixed,&AA[i+(n-fixed)*M],m,&x[n-fixed],1);
 				if(testcon<L[n+i] || testcon>U[n+i])
 					back=6;
 			}
 		}
 		bound_reorganise(1,n,n-fixed,M,&L[0]);
 		bound_reorganise(1,n,n-fixed,M,&U[0]);
 		for(i = n-fixed;i < n;++i)
 		{
 			daxpyvec(M,-x[i],&AA[ + i * M],&L[ + n-fixed]);
 			daxpyvec(M,-x[i],&AA[ + i * M],&U[ + n-fixed]);
  		}
  	}


	if(fixed&&back==6)
		back=6;
	else
		back=OO.OptAdvanced(n-fixed,M,&x[0],&AA[0],&L[0],&U[0],&c[0],&lambda[0]);

	if(fixed)
	{
  		for(i = n-fixed;i < n;++i)
 		{
 			daxpyvec(M,x[i],&AA[ + i * M],&L[ + n-fixed]);
 			daxpyvec(M,x[i],&AA[ + i * M],&U[ + n-fixed]);
  		}
  		bound_reorganise(0,n,n-fixed,M,&L[0]);
 		bound_reorganise(0,n,n-fixed,M,&U[0]);
		Reorder_gen(n,&order[n],&L[0],1);
 		Reorder_gen(n,&order[n],&U[0],1);
 		Reorder_gen(n,&order[n],&AA[0],M);
 		Reorder_gen(n,&order[n],&c[0],1);
 		Reorder_gen(n,&order[n],&x[0],1);
	}
	for(i=0;i<nstocks;++i)
	{
		if(fabs(x[i])<lm_eps8)
			x[i]=0;
	}

	double prob,GGG,LLL,RRET;
	Opt.GainCLoss(&x[0],C,0,0);
	GGG=Opt.Gain;
	LLL=Opt.Loss;
	prob=Opt.pGain;

	RRET=ddotvec(nstocks,Opt.mean,&x[0]);

	//Expected Gain - expected Loss + average R = expected Return
	if(log)
	{
		OO.AddLog((char*)"%s\n",Return_Message(back));
		OO.AddLog((char*)"Expected  Loss  %20.8e (%20.8e)\n",dsumvec(t,&x[tstart])/t,LLL);
		OO.AddLog((char*)"%20s %20s %20s\n",(char*)"Lower",(char*)"Constraint",(char*)"Upper");
		for(i=0;i<m;++i)
		{
			OO.AddLog((char*)"%20.8e %20.8e %20.8e\n",lower[i+nstocks],BITA_ddot(nstocks,&x[0],1,A+i,m),upper[i+nstocks]);
		}
		OO.AddLog((char*)"______________________________________________________________________________________\n");
		OO.AddLog((char*)"%20s %20s %20s\n",(char*)"Lower",(char*)"Weights",(char*)"Upper");
		for(i=0;i<nstocks;++i)
		{
			OO.AddLog((char*)"%20.8e %20.8e %20.8e\n",lower[i],x[i],upper[i]);
		}
		OO.AddLog((char*)"______________________________________________________________________________________________________________________________________________________\n");
		OO.AddLog((char*)"Extra variables that enable C*L to be a linear optimisation\n");
		double LL,cval;
		OO.AddLog((char*)"%20s %20s %20s %20s %20s %20s %20s\n",(char*)"Lower",(char*)"R - rti",(char*)" ",(char*)"Upper",(char*)"Link L",(char*)"link",(char*)"Link U");
		for(i=0;i<t;++i)
		{
			LL=R[i]-BITA_ddot(nstocks,DATA+i,t,&x[0],1);
			cval=BITA_ddot(n,&x[0],1,&AA[m+i],M);
			OO.AddLog((char*)"%20.8e %20.8e (%20.8e) %20.8e %20.8e %20.8e %20.8e\n",L[i+tstart],x[i+tstart],LL,U[i+tstart],L[n+m+i],cval,U[n+m+i]);
		}
		if(nneg)
		{
			OO.AddLog((char*)"Extra variables for long/short\n");
			for(i=0;i<nneg;++i)
			{
				OO.AddLog((char*)"%20.8e %20.8e %20.8e %20.8e %20.8e %20.8e\n",L[nstart+i],x[nstart+i],U[nstart+i],L[nstart+i+nneg],x[nstart+i+nneg],U[nstart+i+nneg]);
			}
		}


		OO.AddLog((char*)"_____________________________________________________________________\n");
	}
	dcopyvec(nstocks,&x[0],w);
	if(Gain)*Gain=GGG;
	if(Loss)*Loss=LLL;
	if(outfile)
	{
		outFile<<OO.logprint->str();
		outFile.clear();
		outFile.close();
	}

	return back;
}

extern "C" DLLEXPORT size_t Arnoldi(dimen n,vector A,vector q,vector H=0,int transpose=0)
{
	//A is m by m not symmetric. Find an orthonomal basis q for A
	size_t k,j;
	vector HH;
	double hh=ddotvec(n,q,q);
	if(hh<lm_eps)
		q[0]=1;
	else
		dscalvec(n,1./sqrt(hh),q);
	dzerovec(n*n,q+n);
	dzerovec(n*n,H);
	for(k=1;k<n+1;k++)
	{
		HH=H+(k-1)*n;
		if(transpose)dmxtmulv(n,n,A,q+(k-1)*n,q+k*n);
		else dmxmulv(n,n,A,q+(k-1)*n,q+k*n);
		for(j=0;j<k;++j)
		{
			hh=ddotvec(n,q+j*n,q+k*n);
			daxpyvec(n,-hh,q+j*n,q+k*n);
			*HH++=hh;
			//printf((char*)"%e %d %d\n",hh,j,k-1);
		}
		hh=ddotvec(n,q+k*n,q+k*n);
		if(hh<=lm_eps)
			break;
		hh=sqrt(hh);
		dscalvec(n,1./hh,q+k*n);
		*HH++=hh;
		//printf((char*)"%e %d %d\n",hh,k,k-1);
	}
	return k;
}
