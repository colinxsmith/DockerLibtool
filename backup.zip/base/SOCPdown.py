#!/usr/bin/env python
#Colin 4th. November 2005
#Set up optimisation with budget, risk constraint and "downside" constraint
#for maximising return by solving the SOCP dual problem.
from SOCPsetup import *
n=100                                           #Number of stocks
nfac=2                                          #Set up factor model
SV=[(i+1)*1e-5 for i in range(n)]               
FL=[1]*n+[1]+[0]*(n-1)
FC=[1e-4,1e-5,2e-4]
alpha=[(i+1)*.01 for i in range(n)]             #Stock alphas
bench=[0 for i in range(n)]                     #Benchmark is cash
Opt=SOCPOPT()                                   #Initialise SOCP optimiser
Opt.BITAconvertModel(n,nfac,SV,FC,FL)           #Get covariance matrix from model
Opt.FactoriseQ(n)                               #Get square root of cov matrix and
                                                #the inverse of square root of cov
                                                #matrix
R=.025  #max risk we allow
Rd=.94  #min downside we allow
#       The constraints require;
#       2 dim cone for budget.   |sum(x) - 1| <= 0
#       n+1 dim cone for risk constraint
#       n+1 dim cone for downside constraint
#       n 1 dim cones to make all variables >=0
Opt.nd=[2]+[n+1]*2+[1]*n                        #Define the cones needed
Opt.m=n                                         #Number of dual variables
Opt.n=3+n                                       #Number of cones
nn=sum(Opt.nd)                                  #Number of primal variables
Opt.A=[1]*n                                     #budget constraint
Opt.A+=[0]*n
Opt.c=[-1,0]
for i in range(n):Opt.A+=Opt.rQ[i*n:(i+1)*n]    #risk constraint
Opt.A+=[0]*n
Opt.c+=[0]*n+[R]
for i in range(n):Opt.A+=Opt.rQ[i*n:(i+1)*n]    #downside constraint
Opt.A+=[i*.5 for i in alpha]                    #Transpose of constraints
Opt.c+=[0]*n+[-Rd*.5]
Opt.b=[-i for i in alpha]
for i in range(n):                              #variable >=0 constraints
    pp=[0]*n
    pp[i]=1
    Opt.A+=pp
    Opt.c+=[0]
dmx_transpose(n,nn,Opt.A,Opt.A)                 #Transpose
Opt.Opt()                                       #Optimise
w=[-i for i in Opt.y]                           #Our stock weights come from
                                                #minus the dual variables
print w,sum(w)
implied=[]
Sym_mult(n,Opt.Q,w,implied)
risk=pow(dot(w,implied),.5)
ret=dot(w,alpha)
print 'Risk\t%20.8f'%risk
print 'Return\t%20.8f'%ret
print 'Down\t%20.8f'%(ret-2*risk)