#include"optimise.h"
template <typename T> void swap_sym(size_t n, T* S, size_t p, size_t q);
void byte_reverse(dimen n, void *b)
{
//#if	defined(__NO_CAST_LVALUE__)
	byte	*B=(byte*)b;
//#else
//#	define	B ((byte*)b)
//#endif
	byte*	e = B+n, t;

	n >>= 1;
	while(n--)
	{
		t = *--e;
		*e = *B;
		*B++ = t;
	}
}
void	bound_reorganise(int f,dimen n,dimen nn,dimen m,double* b)
{
//	BEFORE bound_reorganise(1,n,temp_stocks,m,L);
//	AFTER  bound_reorganise(0,n,temp_stocks,m,L);

	if(b && n > nn)
	{
		dimen	ns[2];

/*	Change n - nn + m to PO.N + m - nn and 0 to PO.N - n 
	to cure a major Robin bug 	Colin 25-11-1996		*/

		ns[1-f] = n - nn + m;
		ns[f]   = m;	

		byte_reverse(ns[0]*sizeof(*b),(byte*)(b+=nn));
		byte_reverse(ns[1]*sizeof(*b),(byte*)b);
	}
}
//___________________________________________________________________________________
//Do the sorting and re-ordering in C++ instead of Robin's routines

template <typename T> extern bool stocksort(const objectorder<T> & x, const objectorder<T> & y)
{
	/*	x.pos is always bigger than y.pos. To avoid rounding problems for double precision we need to include lm_eps8. The rules for this
	function require the test to be > not >=.	*/

	if((x.val > y.val+lm_eps8) && (x.dropbad==y.dropbad)) return 1;
	else if (x.dropbad==y.dropbad) return 0;
	else if (x.dropbad) return 1;
	else return 0;
} 

template <typename T> dimen tran(objectorder<T> &x)
{
	return x.pos;
}

dimen trand(objectorder<double> &x)
{
	return tran(x);
}
dimen trani(objectorder<size_t> &x)
{
	return tran(x);
}
template <typename T> void getorder_gen(size_t n,const T* a,size_t* bb1,FF ff,unsigned char* dropbad,const T init,const short sign)
{
//This shows how the STL works to get an order of a general object

	std::vector<objectorder<T> > aa;
	objectorder<T> pp;
	size_t i;

	if(sign==1)
	{
		for(i=0;i < n;++i)
		{
			pp.val = fabs(a[i]-init);
			pp.pos = i;
			pp.dropbad = dropbad?dropbad[i]:0;
			aa.push_back(pp);
		}
	}
	else
	{
		for(i=0;i < n;++i)
		{
			pp.val = -fabs(a[i]-init);
			pp.pos = i;
			pp.dropbad = dropbad?dropbad[i]:0;
			aa.push_back(pp);
		}
	}
	
	std::sort(aa.begin(),aa.end(),ff);

	std::transform(aa.begin(),aa.end(),&bb1[0],tran<T>);//Give the new order
}
template <typename T> void getorder_eig(size_t n,const T* a,size_t* bb1,FF ff,unsigned char* dropbad,const short sign)
{
//This shows how the STL works to get an order of a general object

	std::vector<objectorder<T> > aa;
	objectorder<T> pp;
	size_t i;

	for(i=0;i < n;++i)
	{
		pp.val = a[i]*sign;
		pp.pos = i;
		pp.dropbad = dropbad?dropbad[i]:0;
		aa.push_back(pp);
	}

	std::sort(aa.begin(),aa.end(),ff);

	std::transform(aa.begin(),aa.end(),&bb1[0],tran<T>);//Give the new order
}

void getorder(size_t n,const double* a,size_t* bb1,unsigned char* dropbad,double init)
{
	getorder_gen(n,a,bb1,stocksort,dropbad,init,1);
}
void getorderrev(size_t n,const double* a,size_t* bb1,unsigned char* dropbad,double init)
{
	getorder_gen(n,a,bb1,stocksort,dropbad,init,-1);
}
void getordereig(size_t n,const double* a,size_t* bb1,unsigned char* dropbad)
{
	getorder_eig(n,a,bb1,stocksort,dropbad,1);
}
void getorderneg(size_t n,const double* a,size_t* bb1,unsigned char* dropbad)
{
	getorder_eig(n,a,bb1,stocksort,dropbad,-1);
}

template <typename T> void Reorder_gen(size_t n, size_t* order,T* array,size_t m)
{
	if(!array||!order) return;
	size_t	i;
	std::valarray<unsigned char> marked(n);
	register size_t j, k;
	marked=0;
	for(i=0;i<n;i++)
	{
		if(!marked[i])
		{
			for(j=i,k=order[j];k!=i;k=order[j=k])
			{
				std::swap_ranges(&array[k*m],&array[(k+1)*m],&array[j*m]);
				//for(l=0;l<m;++l){std::swap(array[k+l],array[j+l]);}
				marked[k] = 1;
			}
			marked[i] = 1;
		}
	}
//	for(i=0;i<n;i++)
//		std::cout << "marked " << i << "\t" << (dimen)marked[i] << std::endl;
}

template void Reorder_gen<double>(size_t n, size_t* order,double* array,size_t m);
template void Reorder_gen<unsigned char>(size_t n, size_t* order,unsigned char* array,size_t m);
template void Reorder_gen<size_t>(size_t n, size_t* order,size_t* array,size_t m);
template void Reorder_gen<long>(size_t n, size_t* order,long* array,size_t m);
//Add these routines so that SWIG can get at the general re-ordering routines
void Reorder(size_t n, size_t* order,double* array)
{
	Reorder_gen(n,order,array,1);
}
extern "C" DLLEXPORT void ReorderNames(size_t n, size_t* order,char** array)
{
	Reorder_gen(n,order,array,1);
}
void Reorder_u(size_t n, size_t* order,unsigned char* array)
{
	Reorder_gen(n,order,array,1);
}
void Reorder_st(size_t n, size_t* order,size_t * array)
{
	Reorder_gen(n,order,array,1);
}

void Reorder_mult(size_t n, size_t* order,double* array,size_t m)
{
	Reorder_gen(n,order,array,m);
}
//___________________________________________________________________________________


template <typename T> void Reorder_sym(size_t n, size_t* order,T* array)
{
	if(!array||!order) return;
	size_t	i;
	std::valarray<unsigned char> marked(n);
	register size_t j, k;
	marked=0;
	for(i=0;i<n;i++)
	{
		if(!marked[i])
		{
			for(j=i,k=order[j];k!=i;k=order[j=k])
			{
				swap_sym(n,array,j,k);
				marked[k] = 1;
			}
			marked[i] = 1;
		}
	}
//	for(i=0;i<n;i++)
//		std::cout << "marked " << i << "\t" << (dimen)marked[i] << std::endl;
}

template <typename T> void swap_sym(size_t n, T* S, size_t p, size_t q) //Robin's routine adapted
{
	T* Sp;
	T* Sq;
	size_t	i;
	long	j;
	if(!n || p==q) return;	/*trivial cases*/

	/*ensure p<q*/
	if(++p>++q) std::swap(p,q);

	/*swap rows p and q columns 1..p-1*/
	Sp = S+(p*(i=(p-1)))/2;		/*Sp points to S(p,1)*/
	Sq = S+(q*(j=((long) q-1)))/2;		/*Sq points to S(q,1)*/
	std::swap_ranges(&Sp[0],&Sp[i],&Sq[0]);

	/*swap columns p and q rows q+1 .. n*/
	Sp += i;			/*Sp points to S(p,p)*/
	Sq += j;			/*Sq points to S(q,q)*/
	j = (long)p - (long)q;	/*negative*/
	for(i=q, S=Sq; i<n; i++)
	{
		S += i;			/*S points to S(i+1,q)*/
		std::swap(S[0],S[j]);
	}

	std::swap( *Sp, *Sq);		/*diagonal elements*/

	/*now swap elements (p+i,p) with elements (q,q-i) i=1,..,q-p-1*/
	Sp = Sq-- +j;
	while( --q > p )
	{
		Sp -= q;
		std::swap(*Sp,*Sq);
		Sq--;
	}
}
template void Reorder_sym<double>(size_t n, size_t* order,double* array);
void ReorderS(size_t n, size_t* order,double* array)
{
	Reorder_sym(n,order,array);
}
void ReorderSchar(size_t n, size_t* order,char** array)
{
	Reorder_sym(n,order,array);
}
dimen	s_lookup(const char *name, dimen n, char **u, const char *uname )
{
	dimen i;
	for(i=0;i<n;i++) {if(stricmp(name,u[i])==0) return i;}
	return n;
}


int	pickout(dimen nstocks,char **stocklist,dimen M_nstocks,char** M_stocklist,vector Q,size_t*Order)
{
	dimen i,j,top = 0;
	int fail = 0;
	size_t* neworder = new size_t[M_nstocks * 2];
	size_t* reverse = neworder + M_nstocks;
			
	for(i = 0;i < M_nstocks;++i)
	{
		neworder[i] = (size_t)-1;
		reverse[i] = (size_t)-1;
	}

	for(i = 0;i < nstocks;++i)
	{
		j = s_lookup(stocklist[i], M_nstocks, M_stocklist, "Model UNIVERSE");
		if(j < M_nstocks)
		{
			neworder[i] = j;
			reverse[j] = i;
		}
		else
		{
			fprintf(stderr,(char*)"%s is not in the model\n",stocklist[i]);
			fail = 1;
		}
	}

	top = nstocks;
	for(i = 0;i < M_nstocks;++i)
	{
		if(reverse[i] == (size_t)-1)
		{
			neworder[top++] = i;
		}
	}

	if(!fail){ReorderS(M_nstocks,neworder,Q);}
	if(Order)
		memcpy(Order,neworder,M_nstocks*sizeof(size_t));
	delete[]neworder;
	return(fail);
}
int	pickoutstrings(dimen nstocks,char **stocklist,dimen M_nstocks,char** M_stocklist,char** Q,size_t*Order)
{
	dimen i,j,top = 0;
	int fail = 0;
	size_t* neworder = new size_t[M_nstocks * 2];
	size_t* reverse = neworder + M_nstocks;
			
	for(i = 0;i < M_nstocks;++i)
	{
		neworder[i] = (size_t)-1;
		reverse[i] = (size_t)-1;
	}

	for(i = 0;i < nstocks;++i)
	{
		j = s_lookup(stocklist[i], M_nstocks, M_stocklist, "Model UNIVERSE");
		if(j < M_nstocks)
		{
			neworder[i] = j;
			reverse[j] = i;
		}
		else
		{
			fprintf(stderr,(char*)"%s is not in the model\n",stocklist[i]);
			fail = 1;
		}
	}

	top = nstocks;
	for(i = 0;i < M_nstocks;++i)
	{
		if(reverse[i] == (size_t)-1)
		{
			neworder[top++] = i;
		}
	}

	if(!fail){ReorderSchar(M_nstocks,neworder,Q);}
	if(Order)
		memcpy(Order,neworder,M_nstocks*sizeof(size_t));
	delete[]neworder;
	return(fail);
}

void ReorderSquare(size_t n,size_t* order,vector SquareArray)
{
	Reorder_mult(n,order,SquareArray,n);
	dmx_transpose(n,n,SquareArray,SquareArray);
	Reorder_mult(n,order,SquareArray,n);
	dmx_transpose(n,n,SquareArray,SquareArray);
}
