#! /bin/env python
#The functions here re-order arrays. They use the simple idea that any permutation can be written as
#a combination of swaps. E.g. The permutation (1234) -> (2341) is swap(14) swap(13) swap(12) in that
#order (start from the right; ab means b followed by a)

def swap(a,i,j):
    """Swap elements i and j in list a"""
    print '(%d<->%d)'%(i,j)
    q=a[i]
    a[i]=a[j]
    a[j]=q
    
def transpose(n,m,a):
    """Transpose a two dimensional matrix stored as a list a[i+n*j] to a[i*m+j]"""
    size=n*m-2
    for i in range(1,size):
        current = i
        while 1:
            col=current/m
            row=current%m
            current=n*row+col
            if current>=i:break
        if current>i:
            swap(a,i,current)

def upper2lower(n,a):
    """Change from upper triangular to lower (it would be nice to avoid having to define the order list)"""
    ij=0
    size=n*(n+1)/2
    order=[0]*size
    stop=[0]*size
    
    for j in range(n):
        for i in range(j+1):
            order[ij]=(i*(2*n+1-i)/2+j-i)
            ij+=1

#This double while code maps a[order[i]] to a[i]    (Inverse of reorder in safeqp)         
    now1=0
    while now1<size:
        then=order[now1]
        if then==now1:stop[now1]=1
        if stop[then]:now1+=1;continue
        while 1:
            swap(a,now1,then)
            stop[then]=1
            then=order[then]
            if then==now1:break
        stop[now1]=1
        now1+=1
            

def lower2upper(n,a):
    """Change from lower triangular to upper (it would be nice to avoid having to define the order list)"""
    ij=0
    size=n*(n+1)/2
    order=[0]*size
    stop=[0]*size
    
    for j in range(n):
        for i in range(j+1):
#            order[(i*(2*n+1-i)/2+j-i)]=ij
            order[ij]=(i*(2*n+1-i)/2+j-i)
            ij+=1
            
#This double while code maps a[i] to a[order[i]]      (Same as reorder in safeqp)         
    now1=0
    while now1<size:
        then=order[now1]
        if then==now1:stop[now1]=1
        if stop[then]:now1+=1;continue
        now=now1
        while 1:
            swap(a,now,then)
            stop[then]=1
            now=then
            then=order[then]
            if then==now1:break
        stop[now1]=1
        now1+=1

            

if __name__ == '__main__':
    n=3
    m=2
    mat=[1,2,3,4,5,6]
    print mat
    transpose(3,2,mat)
    print mat
    transpose(2,3,mat)
    print mat
    n=5
    mat=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14]
    print mat
    upper2lower(n,mat)
    print mat
    lower2upper(n,mat)
    print mat
    """
    The output is
    [1, 2, 3, 4, 5, 6]
    [1, 4, 2, 5, 3, 6]
    [1, 2, 3, 4, 5, 6]
    i.e.
    
    123          14
    456  becomes 25
                 36
    and back
                 
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
    [0, 1, 3, 6, 10, 2, 4, 7, 11, 5, 8, 12, 9, 13, 14]
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]

    i.e.
    0 1  2  3  4
      5  6  7  8
         9 10 11
           12 13
              14
    stored as [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
    becomes
    0
    1  2
    3  4  5
    6  7  8  9
    10 11 12 13 14
    stored as [0, 1, 3, 6, 10, 2, 4, 7, 11, 5, 8, 12, 9, 13, 14]

    and back    
    
    """
    