#! /bin/env python
"""
Colin 18-7-2003
Defining cost functions with python and jython. This script works using either python
or jython, although the jython way is different from the python way, That's why the program
looks a bit odd in places!

This shows how to pass a function as an argument to a procedure written in another language,
which then can call back to the function. It means that costs can be passed to the optimiser
via functions which are written in python or jython.

Finally I show how to solve a non-linear equation in one variable which lets us do
a cost constraint. This shows just how powerful this interface is. The non-linear function
which is called to solve the equation itself does a risk-constrained optimisation!
"""
try:
    from java.lang import *
    import CostFunc
    #System.loadLibrary("safejavajy")#Now this is done in safejavajy.java
    from jarray import *
    from safejavajy import Get_RisksC,Solve1D,FrontierCVPA,FrontierCVPAextcosts,FrontierCVPA,FrontierCVPAF,Optimise_internalCVPAextcosts,Optimise_internalCVPA,Optimise_internalCVPAFb,factor_model_process
except:
    from safe import Get_RisksC,Solve1D,FrontierCVPA,FrontierCVPAextcosts,FrontierCVPA,FrontierCVPAF,Optimise_internalCVPAextcosts,Optimise_internalCVPA,Optimise_internalCVPAFb,factor_model_process
    class CostFunc:
        """
        This class always raises an exception.
        It means we're using Python and can't do
        costs the clumsy jython way
        """
        def __init__(self):raise 'Not this way'
from math import sqrt
#__________________________________________________________
#Helper functions
def turnover(a,b):
    n=len(a)
    if len(b)!=n:raise 'length error in turnover'
    s=0
    for i in range(n):s+=abs(a[i]-b[i])
    return s*.5
def lscheck(w):
    sp=0
    sn=0
    g=0
    for i in w:
        if i < 0:sn+=i
        if i > 0:sp+=i
        g+=abs(i)
    return (sp,sn,g,-sn/sp)
def epsget():
    """Return machine accuracy"""
    a=1.3333333333333333333333333333333333333
    b=a-1.
    return 1-(b+b+b)
#__________________________________________________________
class testopt:
    def __init__(self):
        """Here we wrap the optimiser call into a class"""
        self.n=0
        self.nfac=0
        self.names=[]
        self.FC=[]
        self.FL=[]
        self.SV=[]
        self.m=0
        self.bench=[]
        self.alpha=[]
        self.A=[]
        self.L=[]
        self.U=[]
        self.gamma=0
        self.kappa=.5
        self.costs=0
        self.initial=[]
        self.mask=[]
        self.delta=2
        self.buy=[]
        self.sell=[]
        self.basket=-1
        self.tradenum=-1
        self.revise=0
        self.min_holding=-1
        self.min_trade=-1
        self.ls=0
        self.full=1
        self.rmin=1
        self.rmax=1
        self.round=0
        self.min_lot=[]
        self.size_lot=[]
        self.shake=[]
        self.ncomp=0
        self.Composites=[]
        self.value=1
        self.npiece=0
        self.hpiece=[]
        self.pgrad=[]
        self.nabs=0
        self.A_abs=[]
        self.mabs=0
        self.I_A=[]
        self.Abs_U=[]
        self.Q=[]
        self.riskc=0
        self.maxrisk=0
        self.minrisk=0
        self.shake=[]
        self.w=[]
        self.costgrad=None
        self.costfunc=None
        self.costhess=None
        self.SV=[]
        self.FC=[]
        self.FL=[]
        self.npoints=0
        self.risk=[]
        self.arisk=[]
        self.areturn=[]
        self.rreturn=[]
        self.minrisk=-1
        self.maxrisk=-1
        self.take_out_costs=0
        self.log=1
        self.logfile=""
        self.longbasket=-1
        self.shortbasket=-1
        self.tradebuy=-1
        self.tradesell=-1
    def opt(self):
        """The method for doing optimisations"""
        c=0
        for i in self.__dict__.keys():          #Just debug printout
            print '%4d\t%20s'%(c+1,i),self.__dict__[i]
            c+=1
        try:
            w=array([0]*self.n,Double)          #Need java objects for returned variables
            shake=array([-1]*self.n,Integer)
            if getattr(self,'Q') == []:
                if getattr(self,'nfac')>-1:
                    Q=array([0]*(self.n*(self.nfac+1)),Double)
            else:
                Q=array(self.Q,Double)
        except:
            w=[]
            shake=[]
            Q=self.Q
        try:ogamma=array([0],Double)
        except:ogamma=[]
        if (self.costfunc == None or self.costgrad == None):
            if self.FL==[] and self.FC==[] and self.SV==[]:
                ret = Optimise_internalCVPA(self.n,self.nfac,self.names,w,self.m,self.A,
                                        self.L,self.U,self.alpha,self.bench,Q,
                                        self.gamma,self.initial,self.delta,self.buy,
                                        self.sell,self.kappa,self.basket,self.tradenum,
                                        self.revise,self.costs,self.min_holding,
                                        self.min_trade,self.ls,self.full,self.rmin,
                                        self.rmax,self.round,self.min_lot,self.size_lot,
                                        shake,self.ncomp,self.Composites,self.value,
                                        self.npiece,self.hpiece,self.pgrad,self.nabs,self.A_abs,
                                        self.mabs,self.I_A,self.Abs_U,self.mask,self.log,self.logfile)
            else:
                ret = Optimise_internalCVPAFb(self.n,self.nfac,self.names,w,self.m,self.A,
                                        self.L,self.U,self.alpha,self.bench,Q,
                                        self.gamma,self.initial,self.delta,self.buy,
                                        self.sell,self.kappa,self.basket,self.tradenum,
                                        self.revise,self.costs,self.min_holding,
                                        self.min_trade,self.ls,self.full,self.rmin,
                                        self.rmax,self.round,self.min_lot,self.size_lot,
                                        shake,self.ncomp,self.Composites,self.value,
                                        self.npiece,self.hpiece,self.pgrad,self.nabs,self.A_abs,
                                        self.mabs,self.I_A,self.Abs_U,self.FC,self.FL,self.SV,
                                        self.minrisk,self.maxrisk,ogamma,self.mask,self.log,self.logfile,0,0,
                                        self.longbasket,self.shortbasket,1,1,1)
        else:
            ret = Optimise_internalCVPAextcosts(self.n,self.nfac,self.names,w,self.m,self.A,
                                    self.L,self.U,self.alpha,self.bench,Q,
                                    self.gamma,self.initial,self.delta,self.kappa,
                                    self.basket,self.tradenum,
                                    self.revise,self.min_holding,
                                    self.min_trade,self.ls,self.full,self.rmin,
                                    self.rmax,self.round,self.min_lot,self.size_lot,
                                    shake,self.ncomp,self.Composites,self.value,
                                    self.nabs,self.A_abs,
                                    self.mabs,self.I_A,self.Abs_U,self.FC,self.FL,self.SV,
                                    self.costfunc,self.costgrad,self.costhess,self.minrisk,self.maxrisk,ogamma,
                                    self.take_out_costs,self.mask,self.log,self.logfile,1,0,0,
                                    self.longbasket,self.shortbasket,self.tradebuy,self.tradesell,1,1,1)         
        if self.maxrisk>=0 and self.minrisk>=0:print 'Optimal gamma %20.10e'%ogamma[0]
        print '@*'*10,' ',ret,' ','*@'*10
        if getattr(self,'Q')==[]:
            setattr(self,'Q',map(lambda t:t,Q))
        for i in ['w','shake']:setattr(self,i,map(lambda t:t,eval(i)))
    def risks(self):
        try:
            arisk=array([0],Double)
            risk=array([0],Double)
            Rrisk=array([0],Double)
            brisk=array([0],Double)
            pbeta=array([0],Double)
        except:
            arisk=[]
            risk=[]
            Rrisk=[]
            brisk=[]
            pbeta=[]
        Get_RisksC(self.n,self.nfac,self.Q,self.w,self.bench,arisk,risk,Rrisk,brisk,pbeta,self.ncomp,self.Composites)
        for i in ['arisk','risk','Rrisk','brisk','pbeta']:setattr(self,i,map(lambda t:t,eval(i))[0])
    def front(self):
        """The method for getting frontier points"""
        c=0
        for i in self.__dict__.keys():
            print '%4d\t%20s'%(c+1,i),self.__dict__[i]
            c+=1
        try:
            w=array([0]*self.n*self.npoints,Double)          #Need java objects for returned variables
            shake=array([-1]*self.n,Integer)
            risk=array([0]*self.npoints,Double)
            arisk=array([0]*self.npoints,Double)
            rreturn=array([0]*self.npoints,Double)
            areturn=array([0]*self.npoints,Double)
            if getattr(self,'Q') == []:
                if getattr(self,'nfac')>-1:
                    Q=array([0]*(self.n*(self.nfac+1)),Double)
            else:
                Q=array(self.Q,Double)
        except:
            Q=self.Q
            w=[]
            shake=[]
            risk=[]
            arisk=[]
            rreturn=[]
            areturn=[]
        if self.costfunc == None or self.costgrad == None:
            if self.FL==[] and self.FC==[] and self.SV==[]:
                ret = FrontierCVPA(self.npoints,risk,arisk,rreturn,areturn,self.n,self.nfac,self.names,w,self.m,self.A,
                                        self.L,self.U,self.alpha,self.bench,Q,
                                        self.initial,self.delta,self.buy,
                                        self.sell,self.kappa,self.basket,self.tradenum,
                                        self.revise,self.costs,self.min_holding,
                                        self.min_trade,self.ls,self.full,self.rmin,
                                        self.rmax,self.round,self.min_lot,self.size_lot,
                                        shake,self.ncomp,self.Composites,self.value,
                                        self.npiece,self.hpiece,self.pgrad,self.nabs,self.A_abs,
                                        self.mabs,self.I_A,self.Abs_U,self.mask)
            else:
                ret = FrontierCVPAF(self.npoints,risk,arisk,rreturn,areturn,self.n,self.nfac,self.names,w,self.m,self.A,
                                        self.L,self.U,self.alpha,self.bench,Q,
                                        self.initial,self.delta,self.buy,
                                        self.sell,self.kappa,self.basket,self.tradenum,
                                        self.revise,self.costs,self.min_holding,
                                        self.min_trade,self.ls,self.full,self.rmin,
                                        self.rmax,self.round,self.min_lot,self.size_lot,
                                        shake,self.ncomp,self.Composites,self.value,
                                        self.npiece,self.hpiece,self.pgrad,self.nabs,self.A_abs,
                                        self.mabs,self.I_A,self.Abs_U,self.FC,self.FL,self.SV,self.mask)
        else:
            ret = FrontierCVPAextcosts(self.npoints,risk,arisk,rreturn,areturn,self.n,self.nfac,self.names,w,self.m,self.A,
                                    self.L,self.U,self.alpha,self.bench,Q,
                                    self.initial,self.delta,self.kappa,
                                    self.basket,self.tradenum,
                                    self.revise,self.min_holding,
                                    self.min_trade,self.ls,self.full,self.rmin,
                                    self.rmax,self.round,self.min_lot,self.size_lot,
                                    shake,self.ncomp,self.Composites,self.value,
                                    self.nabs,self.A_abs,
                                    self.mabs,self.I_A,self.Abs_U,self.FC,self.FL,self.SV,
                                    self.costfunc,self.costgrad,self.costhess,self.take_out_costs,self.mask)
        print '@*'*10,' ',ret,' ','*@'*10
        if getattr(self,'Q')==[]:
            setattr(self,'Q',map(lambda t:t,Q))
        for i in ['w','shake','risk','arisk','rreturn','areturn']:setattr(self,i,map(lambda t:t,eval(i)))

#Demonstration script
n=10
buy=map(lambda t:2e-3,range(n))
sell=map(lambda t:2e-3,range(n))
opt=testopt()
opt.n=n
opt.m=1
opt.A=[1]*n
opt.alpha=map(lambda t:float(t-n/2)/n,range(n))
opt.bench=map(lambda t:1.0/n,range(n))
opt.initial=initial=map(lambda t:(opt.bench[t]),range(n))
opt.L=[0]*n+[1]
opt.U=[1]*n+[1]
opt.nfac=nfac=2
FC=[1e-3,1e-5,2e-3]
FL=[1]*n+[1,-1]*(n/2)
SV=map(lambda t:(t+1)*1e-4,range(n))
"""
Either we can send FC FL and SV as properties and let the optimiser do
factor_model_process internally or as here we can do it here and
send opt.SL=[] etc and set opt.Q to Q
"""
try:#jython way
    QQ=array([0]*n*(nfac+1),Double)
    factor_model_process(n,nfac,FL,FC,SV,QQ)
    Q=map(lambda i:i,QQ)#we need a python list, not an array of Doubles
except:#python way
    Q=[]
    factor_model_process(n,nfac,FL,FC,SV,Q)
opt.Q=Q
opt.revise=1
opt.gamma=.1
kappa=.5
opt.kappa=.5
"""
Here we define the total cost function and the cost gradients per stock.
These will be called by the optimiser wrapper library
"""
def costfunc(n,w):
    s=0
    for i in range(n):
        if w[i] < initial[i]:s-=(w[i]-initial[i])*sell[i]
        else:s+=(w[i]-initial[i])*buy[i]
    return s

def costgrad(n,w,grad):
    for i in range(n):
        if w[i] < initial[i]:grad[i]=-sell[i]
        else:grad[i]=buy[i]
def optcost(x):
    opt.kappa=x
    opt.opt()
    cost=costfunc(n,opt.w)
    print 'kappa %e cost %e'%(x,cost)
    return cost-3e-3
optcostI=optcost    #This defines the one dimensional function for python
try:
    """
    In jython we can't pass the costfunc and costgrad
    functions easily the way we do in python.
    Here I've defined a java interface called CostFunc in a separate file.
    This interface has to be extended here (class SSS) and its members
    must be overwritten as below. Then we can instantiate
    SSS and pass the object as an argument to the optimiser routine.
    If this stuff is called in python then
    the python CostFunc class defined above raises an
    exception and passes to the pure python part.
    This way we can use the same script in python and jython
    """
    class SSS(CostFunc):
        """
        CostFunc is defined in java.
        public interface        CostFunc
        {
                public void modc(long n,double[] x,double[] c);//for first derivatives
                public void modq(long n,double[] x,double[] c);//for second derivatives
                public double util(long n,double[] x);//for total
                public double f1d(double x);//for a one parameter function
        }
        Here we implement it and overwrite the methods that we want to use.
        java and jni are then able to execute these jython methods. The jni in the wrapper interface
        expects the names modc, modq, util and f1d to be used.
        For each function we want to pass we give the object variable used to instantiate this class
        to the optimisation procedure. The optimisation procedure has arguments for
        value, first derivatives, second derivatives, I've called them self.costfunc, self.costgrad,
        and self.costhess.
        We haven't got second derivatives for this cost function so pass None for self.costhess.
        (In java we would pass null)
        """
        def modc(self,n,w,grad):costgrad(n,w,grad)
        def util(self,n,w):return costfunc(n,w)
        def f1d(self,x):return optcost(x)

        
    StickItIn=SSS()#This raises an exception in python
    """Assign the instance of the SSS class to the optimiser variables costfunc and costgrad"""
    opt.costfunc=StickItIn
    opt.costgrad=StickItIn
    opt.costhess=None
    optcostI=StickItIn  #This defines the one dimensional function for jython
                        #which we use for the cost constraint
except:
    """
    This is the convenient python way
    """
    print 'The python way'
    opt.costfunc=costfunc
    opt.costgrad=costgrad

#Evaluate the optimal portfolio for kappa = .2 and .9 and then find the value of kappa which
#gives a cost of 3e-3 (optcost returns (cost - 3e-3), see above) This lets us do a
#cost constraint. The constraining function is defined here and it involves a risk-constrained
#optimisation!
    
opt.minrisk=0       #Try a risk constraint as well!
opt.maxrisk=4e-2
optcost(.2)
optcost(.9)

conv=sqrt(epsget())
"""
Solve1D is used to solve the equation f(x) = 0 over a range of values for x.
It only works if there is only 1 value of x in the range which satisfies the equation.
Arguments:
        Solve1D(F,x1,x2,tolerance)
        returns optimal x
            In python F is the function f(x)
            In jython F is an object such that F.f1d is f(x)
            (x1,x2) gives the range over which we expect f(x) to be zero
            tolerance is the convergence criterion
"""
print 'Optimal kappa is %-.8e'%Solve1D(optcostI,.2,.9,conv)   #find the value of kappa that gives a cost of 3e-3
print 'The cost is %-.8e'%costfunc(n,opt.w)
print 'The optimal weights ',opt.w
opt.risks()
print 'Risk is %-.8e'%opt.risk