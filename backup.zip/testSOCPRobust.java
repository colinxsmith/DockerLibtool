public class testSOCPRobust
{
	public static void main(String args[])
	{
	        System.out.println(safejava.version());
		int n=3;
		int nf=-1;
		int m=1;
		int mFE=1;
		int rFE=0;
		double[] w=new double[n];
		double[] alpha=new double[n];
		double[] benchmark=new double[n];
		double[] initial=new double[n];
		double[] meanFE=new double[n];
		double[] L=new double[n+m];
		double[] U=new double[n+m];
		double[][] A=new double[m][n];
		A[0][0]=1;
		A[0][1]=1;
		A[0][2]=1;
		double[] SV=null;
		double[][] FL=null;
		double[] FC=new double[n*(n+1)/2];
		double[] covFE=new double[n*(n+1)/2];
		FC[0]=1;
		FC[1]=.02;
		FC[2]=3;
		FC[3]=.04;
		FC[4]=.05;
		FC[5]=6;
		alpha[0]=.02;
		alpha[1]=.01;
		alpha[2]=.03;
		double gamma=0.5;
		L[0]=0;
		L[1]=0;
		L[2]=0;
		L[3]=1;
		U[0]=1;
		U[1]=1;
		U[2]=1;
		U[3]=1;
		benchmark[0]=.5;
		benchmark[1]=.3;
		benchmark[2]=.2;
		initial[0]=.2;
		initial[1]=.5;
		initial[2]=.3;
		meanFE[0]=1e-4;
		meanFE[1]=3e-4;
		meanFE[2]=2e-4;
		covFE[0]=6;
		covFE[1]=.1;
		covFE[2]=5;
		covFE[3]=.2;
		covFE[4]=.3;
		covFE[5]=1;
		double maxmeanFE=6.95e-05;
		double maxstderrorFE=1.444;
		double maxRisk=.0058;
		double[] sectors=null;
		System.out.println(safejava.Return_Message(safejava.SOCPRobust((long)n,(long)m, w, A, L, U,nf, SV, FL, FC, alpha, meanFE, covFE, maxmeanFE, maxstderrorFE, gamma, maxRisk, benchmark, initial, mFE, rFE,sectors)));
		for(int i=0;i<n;++i)
		{
			System.out.println("w["+i+"]="+w[i]);
		}
	}
}
