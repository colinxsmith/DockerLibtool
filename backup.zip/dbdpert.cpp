#include "baseoptimise.h"
/*
	dbdpert  finds steps  palfa1, palfa2  such that
	the point  X + palfa1*P  reaches a linear constraint that is
	currently not in the working set but is satisfied,
	the point  X + palfa2*P  reaches a linear constraint that is
	currently not in the working set but is violated.
	The constraints are perturbed by an amount  featol, so that
	palfa1  is slightly larger than it should be, and
	palfa2  is slightly smaller than it should be.  This gives
	some leeway later when the exact steps are computed by dbndalf.
	Constraints in the working set are ignored  (istate(J) >= 1).
	If  negstp  is true, the search direction will be taken to be -P.

	VALUES OF ISTATE(J)....
	- 2         - 1         0           1          2         3
	A*X < BL   A*X > BU   A*X free   A*X = BL   A*X = BU   BL = BU

	The values -2 and -1 do not occur once dlpcore finds a feasible point.
*/
void Base_Optimise::dbdpert(int firstv, int negstp, real *bigalf, real *bigbnd, real *pnorm, integer *jadd1, integer *jadd2, real *palfa1, real *palfa2, short_vec istate, dimen n, dimen nctotl, real *anorm, real *ap, real *ax, real *bl, real *bu, real *featol, real *p, real *x)
{

	dimen	i, j;
	int	lastv;
	real epspt9;
	integer js;
	real absatp, rownrm, atp, res, atx;
	--x;
	--p;
	--featol;
	--bu;
	--bl;
	--ax;
	--ap;
	--anorm;
	--istate;

	epspt9 = parm[3];
	if (msg == 99) lm_wmsg(
"\n   J  JS         FEATOL         AX             AP\
     JADD1       PALFA1     JADD2       PALFA2\n");
	lastv = !firstv;
	*jadd1 = 0;
	*jadd2 = 0;
	*palfa1 = *bigalf;
	*palfa2 = 0.0;
	if(firstv) *palfa2 = *bigalf;
	for (j = 1; j <= nctotl; ++j) {
		js = istate[j];
		if (js > 0) continue;
		if (j > n) {
			/*GENERAL LINEAR CONSTRAINT. */
			i = j - n;
			atx = ax[i];
			atp = ap[i];
			rownrm = 1.0 + anorm[i];
			}
		else	{
			/*BOUND CONSTRAINT. */
			atx = x[j];
			atp = p[j];
			rownrm = 1.0;
			}
		if (negstp) atp = -atp;
		if (fabs(atp) <= epspt9 * rownrm * *pnorm) res = -1.0;
		else if(atp > lm_eps){
			/*AX IS INCREASING*/
			/*TEST FOR SMALLER PALFA1 IF UPPER BOUND IS SATISFIED. */
			if (js != -1){
				if (bu[j] < *bigbnd){
					res = bu[j] - atx + featol[j];
					if (*bigalf * atp > fabs(res) && *palfa1 * atp > res){
						*palfa1 = res / atp;
						*jadd1 = j;
						}
					}
				/*TEST FOR DIFFERENT PALFA2 IF LOWER BOUND IS VIOLATED. */
				if (js == -2){
					res = bl[j] - atx - featol[j];
					if (*bigalf * atp > fabs(res)
						&& (firstv || *palfa2 * atp < res)
						&& (lastv || *palfa2 * atp > res)){
						*palfa2 = res / atp;
						*jadd2 = j;
						}
					}
				}
			}
		else if(js != -2){
			/*AX IS DECREASING TEST FOR SMALLER PALFA1 IF LOWER BOUND IS SATISFIED*/
			absatp = -atp;
			if (bl[j] > -(*bigbnd)){
				res = atx - bl[j] + featol[j];
				if (*bigalf * absatp > fabs(res) &&  *palfa1 * absatp > res){
					*palfa1 = res / absatp;
					*jadd1 = j;
					}
				}
			/*TEST FOR DIFFERENT PALFA2 IF UPPER BOUND IS VIOLATED*/
			if (js == -1){
				res = atx - bu[j] - featol[j];
				if (*bigalf * absatp > fabs(res)
					&& (firstv || *palfa2 * absatp < res)
					&& (lastv || *palfa2 * absatp > res) ){
					*palfa2 = res / absatp;
					*jadd2 = j;
					}
				}
			}
		if(msg == 99)
	    		lm_wmsg((char*)"%5ld%4ld%15.5lg%15.5lg%15.5lg%6ld%17.7lg%6ld%17.7lg",
				CL(j), CL(js), featol[j], atx, atp,
				CL(*jadd1), *palfa1, CL(*jadd2), *palfa2);
		}
}
