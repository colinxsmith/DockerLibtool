/*
	copy general vector x to general vector y
*/
#include "ldefns.h"
void dcopy(dimen n, vector x, increment incx, vector y, increment incy)
{
/*	lm_mdvwri("x in dcopy",n,x);
	lm_mdvwri("y in dcopy",n,y);*/
	if(n>0){
		if(abs(incx)==1 && abs(incy)==1) dcopyvec(n,x,y);
		else	{
			if(incx<0) x -= ((long)(n - 1))*incx;
			if(incy<0) y -= ((long)(n - 1))*incy;
			while(n--){
				*y = *x;
				x += incx;
				y += incy;
				}
			}
		}
}
void scopy(dimen n, float* x, increment incx, float* y, increment incy)//single precision
{
/*	lm_mdvwri("x in dcopy",n,x);
	lm_mdvwri("y in dcopy",n,y);*/
	if(n>0){
		if(abs(incx)==1 && abs(incy)==1) scopyvec(n,x,y);
		else	{
			if(incx<0) x -= ((long)(n - 1))*incx;
			if(incy<0) y -= ((long)(n - 1))*incy;
			while(n--){
				*y = *x;
				x += incx;
				y += incy;
				}
			}
		}
}
