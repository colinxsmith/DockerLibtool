#!/usr/bin/env python
#Colin 11th. November 2005
#Set up optimisation with budget, risk constraint and robust constraint
#for a long/short portfolio
#for maximising return by solving the SOCP dual problem.
#The robust constraint is
#       alpha.w - 2 sqrt(sum(wi*wi*dalphai*dalphai)) > min required
#i.e. the dalpha array represents an alpha standard deviation
#We try to do this by doubling the number of variables so as to
#linearise the long value constraint. However as SOCP can only address
#convex problems, we cannot add the non-convex penalty that we use
#in QP so this only works for problems near the top of the return-risk frontier.
from SOCPsetup import *
from Opt import eigen,longshortgross,SOCPlstestMessage
def CheckLSSum(a,short=0):
    if short: return sum([i for i in a if i < 0])
    else: return sum([i for i in a if i > 0])
n=100                                           #Number of stocks
nfac=2                                          #Set up factor model
SV=[(i+1)*1e-5 for i in range(n)]               
FL=[1]*n+[1]+[0]*(n-1)
FC=[1e-4,1e-5,2e-4]
alpha=[(i+1)*.01 for i in range(n)]             #Stock alphas
dalpha=[i*i*.1 for i in alpha]                  #Stock alpha standard errors
bench=[0 for i in range(n)]                     #Benchmark is cash
Opt=SOCPOPT()                                   #Initialise SOCP optimiser
Opt.BITAconvertModel(n,nfac,SV,FC,FL)           #Get covariance matrix from model
Qkeep=[i for i in Opt.Q]
QQ=[i for i in Opt.Q]
for i in range(n,2*n):
    for j in range(i+1):
        if (i-n) > j and j<n:QQ.append(Opt.Q[(i-n)*(i-n+1)/2+j])
        elif (i-n) == j:QQ.append(.5167129106*Opt.Q[j*(j+3)/2])    #The long-short penalty goes here
        elif j>(i-n) and j<n:QQ.append(Opt.Q[j*(j+1)/2+i-n])
        elif j>=n:QQ.append(Opt.Q[(i-n)*(i-n+1)/2+j-n])
print eigen(2*n,QQ)[0]
Opt.Q=QQ
Opt.FactoriseQ(2*n)                             #Get square root of cov matrix and
                                                #the inverse of square root of cov
                                                #matrix
R=0.00859           #max risk we allow
Rd=0.867            #min error modified return we allow
#       The constraints require;
#       2 dim cone for budget.   |sum(x)| <= 0
#       2 dim cone for long value
#       2n+1 dim cone for risk constraint
#       2n+1 dim cone for robust constraint
#       n 1 dim cones to make all variables >=0
#       n 1 dim cones to make all variables <=0
N=2*n
er=[0]*(N*(N+1)/2)
for i in range(n):                              #Get the square root of the doubled
    k=dalpha[i]*dalpha[i]                       #matrix of alpha errors
    er[i*(i+3)/2]=k
    er[(n+i)*(n+i+3)/2]=k
    er[(n+i)*(n+i+1)/2+i]=k
eQ=[0]*(N*N)
eQm1=[0]*(N*N)
RootQ(N,er,eQ,eQm1)
    
Opt.nd=[2]*2+[N+1]*2+[1]*N                      #Define the cones needed
Opt.m=N                                         #Number of dual variables
Opt.n=4+N                                       #Number of cones
nn=sum(Opt.nd)                                  #Number of primal variables
Opt.A=[1]*N                                     #budget constraint
Opt.A+=[0]*N
Opt.c=[0,0]
Opt.A+=[1]*n+[0]*n                              #long value constraint
Opt.A+=[0]*N
Opt.c+=[-1,0]
for i in range(N):Opt.A+=Opt.rQ[i*N:(i+1)*N]    #risk constraint
Opt.A+=[0]*N
Opt.c+=[0]*N+[R] 
for i in range(N):Opt.A+=eQ[i*N:(i+1)*N]        #robust constraint
Opt.A+=[i*.5 for i in alpha]+[i*.5 for i in alpha]                    
Opt.c+=[0]*N+[-Rd*.5]
for i in range(n):                              #n variable >=0 constraints
    pp=[0]*N
    pp[i]=1
    Opt.A+=pp
    Opt.c+=[0]
for i in range(n):                              #n variable <=0 constraints
    pp=[0]*N
    pp[n+i]=-1
    Opt.A+=pp
    Opt.c+=[0]
Opt.b=[-i for i in alpha]+[-i for i in alpha]
print 'A check %d %d'%(N*nn,len(Opt.A))
print 'c check %d %d'%(nn,len(Opt.c))
print 'b check %d %d'%(N,len(Opt.b))
dmx_transpose(N,nn,Opt.A,Opt.A)                 #Transpose
try:
    if Opt.Opt():raise 'Failed'                     #Optimise
    w=[-Opt.y[i]-Opt.y[i+n] for i in range(n)]      #Our stock weights come from
                                                    #minus the dual variables
    print '%20s %20s %20s %20s'%('','Alpha','Alpha error','weight')
    for i in range(n):print '%20s %20.8f %20.8f %20.8f'%('Stock %3d'%(i+1),alpha[i],dalpha[i],w[i])
    implied=[]
    Sym_mult(n,Qkeep,w,implied)
    risk=pow(dot(w,implied),.5)
    error=pow(sum([w[i]*w[i]*dalpha[i]*dalpha[i] for i in range(n)]),.5)
    ret=dot(w,alpha)
    print '%20s %20.8f %20.8f %20.8f'%('Totals',ret,error,sum(w))

    print 'Return - 2*error\t%20.8f (min. required %20.8f)'%((ret-2*error),Rd)
    print 'Risk\t\t\t%20.8f (max. required %20.8f)'%(risk,R)

    ry=[dot(Opt.y,Opt.rQ[i*N:(i+1)*N]) for i in range(N)]
    print 'Risk from square root %20.8f'%pow(dot(ry,ry),0.5)
    print 'Long sum %20.8f'%CheckLSSum(w)
    print 'Short sum %20.8f'%CheckLSSum(w,1)
except:pass
full=1
rmin=0
rmax=2
val=0
m=1
A=[1]*n
L=[-1]*n+[-.1]
U=[1]*n+[.1]
TopRisk=.004
MaxDalpha=.007
w=[0]*n

nabs=1
Aabs=[1]*n
Uabs=[2]

back=SOCPlstest(n,m,w,A,Qkeep,alpha,full,rmin,rmax,L,U,val,TopRisk,dalpha,MaxDalpha,nabs,Aabs,Uabs)
if back>1:raise SOCPlstestMessage(back)
else:
    print '%20s %20s %20s %20s'%('','Alpha','Alpha error','weight')
    for i in range(n):print '%20s %20.8f %20.8f %20.8f'%('Stock %3d'%(i+1),alpha[i],dalpha[i],w[i])
    implied=[]
    Sym_mult(n,Qkeep,w,implied)
    risk=pow(dot(w,implied),.5)
    error=pow(sum([w[i]*w[i]*dalpha[i]*dalpha[i] for i in range(n)]),.5)
    ret=dot(w,alpha)

    print 'Error\t%20.8f (max. required %20.8f)'%((error),MaxDalpha)
    print 'Risk\t%20.8f (max. required %20.8f)'%(risk,TopRisk)
    print 'Return\t%20.8f'%(ret)
    (l,s,g)=longshortgross(w)
    print l,s,-s/l,g,rmin*l+s,rmax*l+s

    for i in range(n):
        if w[i]<0:U[i]=0
        elif w[i]>0:L[i]=0
    again=0
    if back>0:again=1;print 'Extra optimisation starting from signs';back=SOCPlstest(n,m,w,A,Qkeep,alpha,full,rmin,rmax,L,U,val,TopRisk,dalpha,MaxDalpha,nabs,Aabs,Uabs)
    if back:raise SOCPlstestMessage(back)
    elif again:
        print '%20s %20s %20s %20s'%('','Alpha','Alpha error','weight')
        for i in range(n):print '%20s %20.8f %20.8f %20.8f'%('Stock %3d'%(i+1),alpha[i],dalpha[i],w[i])
        implied=[]
        Sym_mult(n,Qkeep,w,implied)
        risk=pow(dot(w,implied),.5)
        error=pow(sum([w[i]*w[i]*dalpha[i]*dalpha[i] for i in range(n)]),.5)
        ret=dot(w,alpha)

        print 'Error\t%20.8f (max. required %20.8f)'%((error),MaxDalpha)
        print 'Risk\t%20.8f (max. required %20.8f)'%(risk,TopRisk)
        print 'Return\t%20.8f'%(ret)
        (l,s,g)=longshortgross(w)
        print l,s,-s/l,g,rmin*l+s,rmax*l+s
        

