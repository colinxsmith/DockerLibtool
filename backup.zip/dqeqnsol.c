/*
	dqeqnsol(a,b,c,pr1,pr2) solves quadratic equation for two real
	roots.

	Equation is a*x*x + b*x + c = 0

	The real roots are returned via the pointers pr1 and pr2
	dqeqnsol returns the number of distinct real roots
*/
#include "ldefns.h"
byte dqeqnsol(real a, real b, real c, real *pr1, real *pr2)
{
	real	d = b*b - 4*a*c, q;
	byte	r;

	if(d>0){	/*distinct real*/
		q = -(b+dsign(sqrt(d),b))/2;
		d = q/a;
		c /= q;
		if(d>c){
			a = d;
			d = c;
			c = a;
			}
		r = 2;
		}
	else if(d==0){	/*two equal real roots*/
		d = c = -b/(a+a);
		r = 1;
		}
	else	{	/*two imaginary roots*/
		a = a+a;
		c = sqrt(-d)/a;
		d = -b/a;
		r = 0;
		}
	*pr1 = d;
	*pr2 = c;
	return r;
}
