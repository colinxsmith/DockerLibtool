#!/bin/env python
datafile='e:/users/colin/safeqp/infreturns.csv'
from Opt import *
from re import sub
eps=pow(epsget(),.5)
sqr=lambda t:t*t
def tonumber(a):
    if a==' null':return missing
    else:return float(a)
def countmissing(a):
    back=0
    for i in a:
        if i==missing:back+=1
    return back
def covprint(n,c,name='',file=None):
    ij=0
    out=''
    for i in range(n):
        for j in range(i+1):
            out+='%20.8e,'%c[ij]
            ij+=1
        out+='\n'
    if file==None:print name;print out
    else:file.write(out)
def Lprod(n,L):
    Lt=[0]*(n*n)
    Lu=[0]*(n*n)
    LL=[0]*(n*n)
    ij=0
    for i in range(n):
        for j in range(i+1):
            Lt[i+j*n]=L[ij]
            Lu[i*n+j]=L[ij]
            ij+=1
    genmult(n,n,Lu,Lt,LL)
    return LL
def func(nn,L):
    LL=Lprod(nb,L)
    back=0
    square2symm(nb,LL)
    for i in range(nn):
        back+=sqr(COV[i]-LL[i])
    return back
def funceig(nv,eigvl):
    tC=[0]*(nv*(nv+1)/2)
    for i in range(nv):
        jk=0
        for j in range(nv):
            for k in range(j+1):
                tC[jk]+=abs(eigvl[i])*eigv[i*n+j]*eigv[i*n+k]
                jk+=1
    return sum([sqr(tC[i]-COV[i]) for i in range((nv*(nv+1)/2))])
def eigfix(n,C):
    low=epsget()
    nn=n*(n+1)/2
    (eig,eigvec)=eigen(n,C)
    change=0
    for i in range(n):
        if eig[i]<eps:change+=1
    if change>0:
        for i in range(n):
            if eig[i]>low:continue
            jk=0
            for j in range(n):
                for k in range(j+1):
                    C[jk]+=(low-eig[i])*eigvec[i*n+j]*eigvec[i*n+k]
                    jk+=1
def assemble(n,eig):
    C=[0]*(n*(n+1)/2)
    for i in range(n):
        jk=0
        for j in range(n):
            for k in range(j+1):
                C[jk]+=(eig[i])*eigv[i*n+j]*eigv[i*n+k]
                jk+=1
    return C
data=open(datafile)
missing=1e45

names=[]
series=[]
while 1:
    line=data.readline()
    if len(line)>0:
        line=sub(',*$','',line.strip())
        line=line.split(',')
        if len(line)>1:
            if len(line[0])>0:
                series.append([tonumber(i) for i in line[1:]])
                names.append(line[0])
    else:break


nt=len(series[0])
n=len(series)
w=[1]*nt
COV=[]
realength=[nt-countmissing(i) for i in series]

for i in range(n):
    for j in range(i+1):
        COV.append(covariance1(series[i],series[j],w,nt))
"""
mask=[]
for i in range(n):
    for j in range(i+1):
        if realength[i]>nt*.95:
            score=realength[i]*realength[j]
        else:score=0
        mask.append(score)
"""
mask=[0]*(n*(n+1)/2)
for i in range(n):mask[i*(i+3)/2]=realength[i]
covprint(n,mask,'mask',open('mask.csv','w'))

COV1=[i for i in COV]
covprint(n,COV,'Before',open('covbefore.csv','w'))
(eig,eigv)=eigen(n,COV)
eigvalprint(eig)
#"""
if jython:
	COV=array(COV,Double)
quad_fix(n,COV,mask)
if jython:
	COV=[i for i in COV]
covprint(n,COV,'After opt',open('covaftero.csv','w'))
(eig,eigv)=eigen(n,COV)
eigvalprint(eig)
#"""
"""
L=[0]*(len(COV))
ij=0
for i in range(n):
    for j in range(i+1):
        if i==j:L[ij]=pow(abs(COV[ij]),.5)
        ij+=1


nb=n
nn=n*(n+1)/2
print func(nn,L)
f=[1]
if QuasiNewton(nn,L,1,nn*20,f,func,1e-3,2,1):print 'Quasi-Newton step failed'
print f
LL=Lprod(nb,L)
square2symm(nb,LL)
COV=[LL[i] for i in range(len(COV))]
"""
if jython:
	COV=array(COV,Double)
eig_fix(n,COV)
if jython:
	COV=[i for i in COV]
covprint(n,COV,'After eig',open('covafter.csv','w'))
(eig,eigv)=eigen(n,COV)
eigvalprint(eig)
#"""
if jython:
	COV1=array(COV1,Double)
fix_covariancem(n,COV1)
if jython:
	COV1=[i for i in COV1]
covprint(n,COV1,'After fix',open('covafterf.csv','w'))
(eig,eigv)=eigen(n,COV1)
eigvalprint(eig)
#"""

