#!/usr/bin/env python
#Second Order Cone Programming
#Colin Smith
#Started June 28th 2005

from math import log
from safe import Sym_mult,symm_inverse_x

#Helper functions
square=lambda x:x*x
norm2=lambda u:sum([square(i) for i in u])
dot=lambda a,b:sum([a[i]*b[i] for i in range(len(a))])
def epsget():
    """Return machine accuracy."""
    a=1.3333333333333333333333333333333333333
    b=a-1.
    return 1-(b+b+b)
def triprint(n,c,name=''):
    print name
    ij=0
    for i in range(n):
        out=''
        for j in range(i+1):
            out+='%20.8e '%c[ij]
            ij+=1
        print out
def planemin(x,func):
    x=[0,0]
    f0=func(2,x)
#Second order cone barrier function for a cone, defined by vector u and scalar t,
#and its first and second derivatives.
#The barrier function is only defined for norm2(u)<=t i.e. for points which are inside the cone.
barrier=lambda u,t:-log(t*t-norm2(u))
def gbarrier(u,t):
    front=2.0/(square(t)-norm2(u))
    return [front*i for i in u]+[-front*t]
def hbarrier(u,t):
    normu=norm2(u)
    tsqr=square(t)
    front=2.0/square(tsqr-normu)
    m=len(u)+1
    ij=0
    back=[0]*(m*(m+1)/2)
    for i in range(m):
        for j in range(i+1):
            if i==j and i<m-1:
                back[ij]=tsqr-normu + 2*u[i]*u[i]
            elif i==j:
                back[ij]=tsqr+normu
            elif i<m-1:
                back[ij]=2*u[i]*u[j]
            else:
                back[ij]=-2*u[j]*t
            ij+=1
    return [front*i for i in back]
#Inverse of second derivatives
def hbarrier_inv(u,t):
    normu=norm2(u)
    tsqr=square(t)
    front=0.5
    m=len(u)+1
    ij=0
    back=[0]*(m*(m+1)/2)
    for i in range(m):
        for j in range(i+1):
            if i==j and i<m-1:
                back[ij]=tsqr-normu + 2*u[i]*u[i]
            elif i==j:
                back[ij]=tsqr+normu
            elif i<m-1:
                back[ij]=2*u[i]*u[j]
            else:
                back[ij]=2*u[j]*t
            ij+=1
    return [front*i for i in back]

def testbarrier():
    n=1
    t=6
    u=[1]*n

    print 'Barrier value\n',barrier(u,t)
    print 'Barrier gradients\n',gbarrier(u,t)
    print 'Barrier Hessian\n',hbarrier(u,t)
    print 'Barrier inverse Hessian\n',hbarrier_inv(u,t)


def SOCPopt(n,x,alpha,N,A,b,c,d,x1,w=[1]):
    """Minimise t such that norm2(Ax+b)i <= (cx+d)i + t for i=1...N
    A feasible point for this is x=0 t>max i (norm2(bi) - di)
    
    """
    acc=epsget()
    conv=pow(acc,.5)*n
    p=-1e-4
    q=-1e-4
    eta=1.001
    etacon=pow(2.0*N,0.5)
    logN=2*N*log(N)
    startpoint=[i for i in x1]
    print 'start at ',startpoint
    gap=lambda X,z,w:dot(alpha,X)+sum([dot(b[i],z[i]) + d[i]*w[i] for i in range(N)])
    dgapX=lambda X,z,w:alpha
    dgapz=lambda X,z,w:b
    dgapw=lambda X,z,w:d
    z=[[.5]]*N
    def pdpot(X,z,w):
        print 'X',X
        print 'z',z
        print 'w',w
        G=gap(X,z,w)
        back=2*N+etacon*eta*log(G)-logN
        for i in range(N):
            back+=barrier([dot(A[i],X)+b[i][0]],dot(c[i],X)+d[i])
            back+=barrier(z[i],w[i])
        print 'Gap',G
        print 'pot',back
        return back
    g=lambda X:[gbarrier([dot(A[i],X)+b[i][0]],dot(c[i],X)+d[i]) for i in range(N)]
    def planefunc(p,q,dx,dz,dw,x,z,w):
        x1=[x[i]+dx[i]*p for i in range(len(x))]
        #print x1
        z1=[[z[i][0]+dz[i]*q for i in range(len(z))]]
        #print z1
        w1=[w[i]+dw[i]*q for i in range(len(w))]
        #print w1
        return pdpot(x1,z1,w1)
    def minfunc(nn,xx):
        (p,q)=tuple(xx)
        bb=planefunc(p,q,dx,dz,dw,startpoint,z,w)
        return bb
    while(1):
        print 'start gap ',gap(startpoint,z,w)
        Gap=gap(startpoint,z,w)
        if Gap<conv:break
        print 'start pot ',pdpot(startpoint,z,w)
        print 'start g ',g(startpoint)
        G=g(startpoint)
        hm1=lambda X:[hbarrier_inv([dot(A[i],X)+b[i][0]],dot(c[i],X)+d[i]) for i in range(N)]
        print 'start hm-1 ',hm1(startpoint)
        Hm1=hm1(startpoint)
        rho=(2*N+etacon*eta)/Gap
        Z=[z[i][0] for i in range(N)]+[w[0]]
        print 'Z ',Z
        rhs=[]
        hh=[-rho*Z[i] - G[0][i] for i in range(2)]
        print 'hh ',hh
        Sym_mult(2,Hm1[0],hh,rhs)
        print 'rhs ',rhs
        BIGH=[0]*((n+2)*(n+3)/2)
        for i in range(3):BIGH[i]=Hm1[0][i]
        ij=0
        for i in range(n+2):
            for j in range(i+1):
                if j==0 and i>1:
                    BIGH[ij]=A[0][i-2]
                elif j==1 and i>1:
                    BIGH[ij]=c[0][i-2]
                ij+=1
        triprint(n+2,BIGH,'BIGH ')
        rhs+=[0]*n
        dZ=[]
        symm_inverse_x(n+2,BIGH,rhs,dZ)
        print 'dZ ',dZ
        dx=[dZ[i+2] for i in range(len(x))]
        dz=[dZ[i] for i in range(len(z))]
        dw=[dZ[i+1] for i in range(len(w))]
        print dx,dz,dw
        p=.995
        q=.995
        for i in range(N):
            AA=square(dot(A[i],dx)-dot(c[i],dx))
            if AA<acc:p=0
            else:
                BB=2*(dot(A[i],dx)*(dot(A[i],startpoint)+b[i][0])-dot(c[i],dx)*(dot(c[i],startpoint)+d[i]))
                CC=dot(A[i],startpoint)+b[i][0]-(dot(c[i],startpoint)+d[i])
                inner=square(BB)-4*AA*CC
                p=max(0,min(p,(-BB+pow(inner,.5))/2/AA))
            print p
            AA=dot(dz,dz)-square(dw[i])
            if AA<acc:q=0
            else:
                BB=dot(dz,z[i])-w[i]*dw[i]
                CC=dot(z[i],z[i])-square(w[i])
                inner=square(BB)-4*AA*CC
                q=max(0,min(q,(-BB+pow(inner,.5))/2/AA))
            print q
        while(1):
            tx=[startpoint[i]+dx[i]*p for i in range(len(x))]
            tz=[[z[i][0]+dz[i]*q for i in range(len(z))]]
            tw=[w[i]+dw[i]*q for i in range(len(w))]
            Gap=gap(tx,tz,tw)
            if Gap>0:break
            p*=.9
            q*=.9
        startpoint=[i for i in tx]
        z=[i for i in tz]
        w=[i for i in tw]
        print startpoint
        print z
        print w
        print 'p=',p
        print 'q=',q
    for i in range(n):
        x[i]=startpoint[i]
    print z
    print w
            
    
#testbarrier()
n=10
x=[0]*n
alpha=[0 for i in range(n-1)]+[1]
N=1
A=[[0]*(n-1)+[0]]
b=[[0]]
c=[[1]*(n-1)+[1]]
d=[1]
nb=[norm2(i) for i in b]
startpoint=[0]*(n-1)+[max([nb[i]-d[i] for i in range(N)])+1]
SOCPopt(n,x,alpha,N,A,b,c,d,startpoint)
print x
if x[-1]<0:
    del x[-1]
    print '############################################################'
    print '############################################################'
    print '############################################################'
    print '############################################################'
    print '############################################################'
    startpoint=[i for i in x]
    n=9
    alpha=[i for i in range(n)]
    N=1
    A=[[0]*n]
    b=[[0]]
    c=[[1]*n]
    d=[1]
    SOCPopt(n,x,alpha,N,A,b,c,d,startpoint,[alpha[-1]/c[0][-1]])
    print x
