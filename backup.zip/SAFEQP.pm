package SAFEQP;
use safepl;
use strict;

#Using PERL objects to test the optimiser.

my $debug = 1;

sub new
{
	my($class_name) = shift;
	my($self) = {};

	bless($self,$class_name);
	$self->{_created} = 1;

#Here we just set some default values. They will get changed in
#the calling program as necessary.


#Note [] gives a reference to an array.

        $self->{n} = 0;
        $self->{nfac} = -1;
        $self->{stocks}=[];
        $self->{w}=[];
        $self->{m}=0;
        $self->{A}=[];
        $self->{L}=[];
        $self->{U}=[];
        $self->{alpha}=[];
        $self->{benchmark}=[];
        $self->{Q} = [];
        $self->{gamma}=0;
        $self->{initial}=[];
		$self->{mask}=[];
        $self->{delta} = 2;
        $self->{buy}=[];
        $self->{sell}=[];
		$self->{npiece}=0;
		$self->{pgrad}=[];
		$self->{hpiece}=[];
        $self->{kappa}=0;#In Marginal Utility we must put kappa to zero if there are no costs
        $self->{basket}=-1;
        $self->{tradenum}=-1;
        $self->{revise}=0;
        $self->{costs}=0;
        $self->{min_holding}=-1;
        $self->{min_trade}=-1;
        $self->{ls}=0;
        $self->{full}=1;
        $self->{rmin}=-1;
        $self->{rmax}=-1;
        $self->{round}=0;
        $self->{min_lot}=[];
        $self->{size_lot}=[];
        $self->{shake}=[];
		$self->{ncomp}=0;
		$self->{Composites}=[];
		$self->{LS_value}=1;
		$self->{nabs}=0;
		$self->{Abs_A}=[];
		$self->{mabs}=0;
		$self->{I_A}=[];
		$self->{Abs_U}=[];
		$self->{FC}=[];
		$self->{FL}=[];
		$self->{SV}=[];
		$self->{piece_cost}=0;
		$self->{piece_grad}=0;
		$self->{maxRisk}=-1;
		$self->{minRisk}=-1;
		$self->{take_out_costs}=0;
		$self->{log}=1;
		$self->{logfile}="";
		$self->{DoExtraIterations}=1;
		$self->{downrisk}=0;
		$self->{downfactor}=3.0;
		$self->{longbasket}=-1;
		$self->{shortbasket}=-1;
		$self->{tradebuy}=-1;
		$self->{tradesell}=-1;
		$self->{zetaS}=1;
		$self->{zetaF}=1;
		$self->{ShortCostScale}=1;
		$self->{shortalphacost}=[];
		$self->{never_slow}=1;
		$self->{mem_kbytes}=[];
		$self->{soft_m}=0;
		$self->{soft_l}=[];
		$self->{soft_b}=[];
		$self->{soft_L}=[];
		$self->{soft_U}=[];
		$self->{soft_A}=[];
		$self->{LS_valuel}=0;
		$self->{Abs_L}=[];
	return $self;
}
sub piece_hess
{
	#How do we pass zero pointer for a routine? 
	my $n=shift;
	my $w=shift;
	my $q=shift;
}
sub run
{
	my($self) = shift;
	
	print "in run\n" if $debug;

#Copy the references to make the bita call look nicer

    my  $n=$self->{n};
    my  $nfac=$self->{nfac};
    my  $stocks=$self->{stocks};
    my  $m=$self->{m};
    my  $A=$self->{A};
    my  $L=$self->{L};
    my  $U=$self->{U};
    my  $alpha=$self->{alpha};
    my  $benchmark=$self->{benchmark};
    my  $Q=$self->{Q};
    my  $gamma=$self->{gamma};
    my  $initial=$self->{initial};
	my	$mask=$self->{mask};
    my  $delta=$self->{delta};
    my  $buy=$self->{buy};
    my  $sell=$self->{sell};
    my  $kappa=$self->{kappa};
    my  $basket=$self->{basket};
    my  $tradenum=$self->{tradenum};
    my  $revise=$self->{revise};
    my  $costs=$self->{costs};
    my  $min_holding=$self->{min_holding};
    my  $min_trade=$self->{min_trade};
    my  $ls=$self->{ls};
    my  $full=$self->{full};
    my  $rmin=$self->{rmin};
    my  $rmax=$self->{rmax};
    my  $round=$self->{round};
    my  $min_lot=$self->{min_lot};
    my  $size_lot=$self->{size_lot};
    my  $w=[];
    my  $shake=[];
	my	$ncomp=$self->{ncomp};
	my	$Composites=$self->{Composites};
	my	$value=$self->{LS_value};
	my	$nabs=$self->{nabs};
	my	$Abs_A=$self->{Abs_A};
	my	$mabs=$self->{mabs};
	my	$I_A=$self->{I_A};
	my	$Abs_U=$self->{Abs_U};
	my	$FC=$self->{FC};
	my	$FL=$self->{FL};
	my	$SV=$self->{SV};
	my	$piece_cost=$self->{piece_cost};
	my	$piece_grad=$self->{piece_grad};
	my	$ogamma=[];
	my	$log=$self->{log};
	my	$logfile=$self->{logfile};
	my	$maxRisk=$self->{maxRisk};
	my	$minRisk=$self->{minRisk};
	my	$take_out_costs=$self->{take_out_costs};
	my	$DoExtraIterations = $self->{DoExtraIterations};
	my	$downrisk=$self->{downrisk};
	my	$downfactor=$self->{downfactor};
	my	$longbasket=$self->{longbasket};
	my	$shortbasket=$self->{shortbasket};
	my	$tradebuy=$self->{tradebuy};
	my	$tradesell=$self->{tradesell};
	my	$zetaS=$self->{zetaS};
	my	$zetaF=$self->{zetaF};
	my	$ShortCostScale=$self->{ShortCostScale};
	my	$shortalphacost=$self->{shortalphacost};
	my	$never_slow=$self->{never_slow};
	my	$mem_kbytes=$self->{mem_kbytes};
	my	$soft_m=$self->{soft_m};
	my	$soft_l=$self->{soft_l};
	my	$soft_b=$self->{soft_b};
	my	$soft_L=$self->{soft_L};
	my	$soft_U=$self->{soft_U};
	my	$soft_A=$self->{soft_A};
	my	$valuel=$self->{LS_valuel};
	my	$Abs_L=$self->{Abs_L};

			  
    $self->{back}=safepl::Optimise_internalCVPAextcostslSaMSoft($n,$nfac,$stocks,$w,$m,$A,$L,$U,$alpha,$benchmark,$Q,$gamma,$initial,
	$delta,$kappa,$basket,$tradenum,$revise,$min_holding,$min_trade,$ls,$full,$rmin,$rmax,$round,$min_lot,$size_lot,$shake,$ncomp,
	$Composites,$value,$nabs,$Abs_A,$mabs,$I_A,$Abs_U,$FC,$FL,$SV,$piece_cost,$piece_grad,\&piece_hess,$minRisk,$maxRisk,$ogamma,$take_out_costs,
	$mask,$log,$logfile,$DoExtraIterations,$downrisk,$downfactor,$longbasket,$shortbasket,$tradebuy,$tradesell,$zetaS,$zetaF,$ShortCostScale,$valuel,$Abs_L,
	$shortalphacost,$never_slow,$mem_kbytes,$soft_m,$soft_l,$soft_b,$soft_L,$soft_U,$soft_A);
	if($maxRisk>=0&&$minRisk>=0)
	{
		print "Optimal gamma",$$ogamma[0];
	}
#Set the output variables

    $self->{w}=$w;
    $self->{shake}=$shake;

	$self->results;
}
sub run_internal_costs
{
	my($self) = shift;
	
	print "in run_internal_costs\n" if $debug;

#Copy the references to make the bita call look nicer

    my  $n=$self->{n};
    my  $nfac=$self->{nfac};
    my  $stocks=$self->{stocks};
    my  $m=$self->{m};
    my  $A=$self->{A};
    my  $L=$self->{L};
    my  $U=$self->{U};
    my  $alpha=$self->{alpha};
    my  $benchmark=$self->{benchmark};
    my  $Q=$self->{Q};
    my  $gamma=$self->{gamma};
    my  $initial=$self->{initial};
	my	$mask=$self->{mask};
    my  $delta=$self->{delta};
    my  $buy=$self->{buy};
    my  $sell=$self->{sell};
    my  $kappa=$self->{kappa};
    my  $basket=$self->{basket};
    my  $tradenum=$self->{tradenum};
    my  $revise=$self->{revise};
    my  $costs=$self->{costs};
    my  $min_holding=$self->{min_holding};
    my  $min_trade=$self->{min_trade};
    my  $ls=$self->{ls};
    my  $full=$self->{full};
    my  $rmin=$self->{rmin};
    my  $rmax=$self->{rmax};
    my  $round=$self->{round};
    my  $min_lot=$self->{min_lot};
    my  $size_lot=$self->{size_lot};
    my  $w=[];
    my  $shake=[];
	my	$ncomp=$self->{ncomp};
	my	$Composites=$self->{Composites};
	my	$value=$self->{LS_value};
	my	$nabs=$self->{nabs};
	my	$Abs_A=$self->{Abs_A};
	my	$mabs=$self->{mabs};
	my	$I_A=$self->{I_A};
	my	$Abs_U=$self->{Abs_U};
	my	$FC=$self->{FC};
	my	$FL=$self->{FL};
	my	$SV=$self->{SV};
	my	$piece_cost=$self->{piece_cost};
	my	$piece_grad=$self->{piece_grad};
	my	$ogamma=[];
	my	$log=$self->{log};
	my	$logfile=$self->{logfile};
	my	$maxRisk=$self->{maxRisk};
	my	$minRisk=$self->{minRisk};
	my	$take_out_costs=$self->{take_out_costs};
	my	$DoExtraIterations = $self->{DoExtraIterations};
	my	$downrisk=$self->{downrisk};
	my	$downfactor=$self->{downfactor};
	my	$longbasket=$self->{longbasket};
	my	$shortbasket=$self->{shortbasket};
	my	$tradebuy=$self->{tradebuy};
	my	$tradesell=$self->{tradesell};
	my	$zetaS=$self->{zetaS};
	my	$zetaF=$self->{zetaF};
	my	$ShortCostScale=$self->{ShortCostScale};
	my	$npiece=$self->{npiece};
	my	$pgrad=$self->{pgrad};
	my	$hpiece=$self->{hpiece};
	my	$shortalphacost=$self->{shortalphacost};
	my	$never_slow=$self->{never_slow};
	my	$mem_kbytes=$self->{mem_kbytes};
	my	$soft_m=$self->{soft_m};
	my	$soft_l=$self->{soft_l};
	my	$soft_b=$self->{soft_b};
	my	$soft_L=$self->{soft_L};
	my	$soft_U=$self->{soft_U};
	my	$soft_A=$self->{soft_A};
	my	$valuel=$self->{LS_valuel};
	my	$Abs_L=$self->{Abs_L};

#	safepl::Optimise_internalCVPAFb($n,$nfac,$stocks,$w,$m,
#									$A,$L,$U,$alpha,
#									$benchmark,$Q,$gamma,$initial,
#									$delta,$buy,$sell,$kappa,$basket,
#									$tradenum,$revise,$costs,$min_holding,
#									$min_trade,
#									$ls,$full,$rmin,$rmax,
#									$round,$min_lot,$size_lot,$shake,
#									$ncomp,$Composites,$value,
#									$npiece,$hpiece,$pgrad,
#									$nabs,$Abs_A,$mabs,$I_A,$Abs_U,
#									$FC,$FL,$SV,$minRisk,$maxRisk,
#									$ogamma,$mask,$log,$logfile,
#									$downrisk,$downfactor,
#									$longbasket,$shortbasket,
#									$tradebuy,$tradesell,$zetaS,$zetaF,
#									$ShortCostScale);

	$self->{back}=safepl::Optimise_internalCVPAFblSaMSoft($n,$nfac,$stocks,$w,$m,$A,$L,$U,$alpha,$benchmark,$Q,$gamma,$initial,$delta,
	$buy,$sell,$kappa,$basket,$tradenum,$revise,$costs,$min_holding,$min_trade,$ls,$full,$rmin,$rmax,$round,$min_lot,$size_lot,
	$shake,$ncomp,$Composites,$value,$npiece,$hpiece,$pgrad,$nabs,$Abs_A,$mabs,$I_A,$Abs_U,$FC,$FL,$SV,$minRisk,$maxRisk,$ogamma,$mask,$log,
	$logfile,$downrisk,$downfactor,$longbasket,$shortbasket,$tradebuy,$tradesell,$zetaS,$zetaF,$ShortCostScale,$valuel,$Abs_L,$shortalphacost,
	$never_slow,$mem_kbytes,$soft_m,$soft_l,$soft_b,$soft_L,$soft_U,$soft_A);

	if($maxRisk>=0&&$minRisk>=0)
	{
		print "Optimal gamma",$$ogamma[0];
	}
#Set the output variables

    $self->{w}=$w;
    $self->{shake}=$shake;

}


sub results
{
	my($self) = shift;
	print "in results\n" if $debug;
	print safepl::Return_Message($self->{back});
	local $\="\n";
	local $,=" ";

	print "Optimised weights";
	print @{$self->{w}};

	my @trades;
	for (0 .. $self->{n}-1)
	{
		$trades[$_] = ${$self->{w}}[$_] - ${$self->{initial}}[$_];
	}
	print "Optimised trades";
	print @trades;
}

1;
	
