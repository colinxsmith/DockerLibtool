#! /bin/env python

from os import system
from sys import argv


for i in argv:
    if i.find('cpp') > 0:
        i=i.replace('.cpp','.o')
        print "rm %s"%i
        system("rm %s"%i)