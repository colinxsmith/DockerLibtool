#! env python
"""
Colin 30-8-2002
Python program for running an optimisation/risk report using a COR-RS Curve output trace log
as input

Run this by typing:
python runtest.py logfile1 logfile2 .......
for as many logs as you like (don't put the trailing dots in!)

Modified for Tkinter 29-01-2003

Now does full covariance properly 19-9-2003
"""
from bitapy import *
import getf,sys
from math import sqrt
debug=0
def dot(a,b,s=0):
    """scalar product of a and b (with shift s on b)"""
    back=0
    n=len(a)
    for i in range(n):back+=a[i]*b[i+s]
    return back
def turnover(w,wi,mask=[]):
    """The turnover between w and wi (possibly masked)"""
    n=len(w)
    s=0
    if mask==[]:
        for i in range(n):s+=abs(w[i]-wi[i])
    else:
        for i in range(n):s+=abs((w[i]-wi[i])*mask[i])
    return s*0.5
def longshortgross(w):
    p=0
    m=0
    g=0
    for i in w:
        if i>0:p+=i;g+=i
        else:m+=i;g-=i
    return (p,m,g)
def oxprintmat(a,name):
    """Generate a file containing a float list in Ox matrix format for list a"""
    name=name+'.mat'
    length=len(a)
    if length<=0:return
    file=open(name,'w')
    file.write('%d 1\n' % length)
    for i in a:file.write('%-.16e\n' % i)
    file.close()
class testopt:
    def __init__(self):
        self.n=0
        self.nfac=0
        self.names=''
        self.FC=[]
        self.FL=[]
        self.SV=[]
        self.m=0
        self.bench=[]
        self.alpha=[]
        self.A=[]
        self.L=[]
        self.U=[]
        self.gamma=0
        self.kappa=.5
        self.costs=0
        self.initial=[]
        self.delta=2
        self.buy=[]
        self.sell=[]
        self.basket=-1
        self.tradenum=-1
        self.revise=0
        self.min_holding=-1
        self.min_trade=-1
        self.ls=0
        self.full=1
        self.rmin=1
        self.rmax=1
        self.round=0
        self.min_lot=[]
        self.size_lot=[]
        self.shake=[]
        self.ncomp=0
        self.Composites=[]
        self.value=1
        self.npiece=0
        self.hpiece=[]
        self.pgrad=[]
        self.nabs=0
        self.A_abs=[]
        self.mabs=0
        self.I_A=[]
        self.Abs_U=[]
        self.Q=[]
        self.riskc=0
        self.maxrisk=0
        self.minrisk=0
    def process(self):#Process the risk model
        Q=[]
        n=self.n-self.ncomp
        nfac=self.nfac
        
        if n*nfac != len(self.FL):raise 'FL has wrong length (%d,%d)' % (n,len(self.FL))
        if n != len(self.SV):raise 'SV has wrong length (%d,%d)' % (n,len(self.SV))
        
        factor_model_process(n,nfac,self.FL,self.FC,self.SV,Q)
        self.Q=Q
    def opt(self):
        w=[]
        shake=[]
        if self.Q == []:self.process()
        if self.ncomp > 0:
            nc = self.ncomp
            n = self.n - nc
            if n*nc != len(self.Composites):
                raise 'Composites has wrong length (%d,%d)' % (n*nc,len(self.Composites))
        if self.riskc == 0:
            ret = Optimise_internalCVPA(self.n,self.nfac,self.names,w,self.m,self.A,
                                  self.L,self.U,self.alpha,self.bench,self.Q,
                                  self.gamma,self.initial,self.delta,self.buy,
                                  self.sell,self.kappa,self.basket,self.tradenum,
                                  self.revise,self.costs,self.min_holding,
                                  self.min_trade,self.ls,self.full,self.rmin,
                                  self.rmax,self.round,self.min_lot,self.size_lot,
                                  self.shake,self.ncomp,self.Composites,self.value,
                                  self.npiece,self.hpiece,self.pgrad,self.nabs,self.A_abs,
                                  self.mabs,self.I_A,self.Abs_U)
        else:
            gamma = []
            gamma.append(self.gamma)
            ret = OptimiseRiskCVPA(self.n,self.nfac,self.names,w,self.m,self.A,
                                  self.L,self.U,self.alpha,self.bench,self.Q,
                                  gamma,self.initial,self.delta,self.buy,
                                  self.sell,self.kappa,self.basket,self.tradenum,
                                  self.revise,self.costs,self.min_holding,
                                  self.min_trade,self.ls,self.full,self.rmin,
                                  self.rmax,self.round,self.min_lot,self.size_lot,
                                  self.shake,self.ncomp,self.Composites,self.value,
                                  self.npiece,self.hpiece,self.pgrad,self.nabs,self.A_abs,
                                  self.mabs,self.I_A,self.Abs_U,self.minrisk,self.maxrisk)
            self.gamma=gamma[0]
        self.returnmessage=Return_Message(ret)
        print Return_Message(ret)

        self.w=w
        self.shake=shake
    def get_prop(self):
        if debug:
            c=0
            for i in self.__dict__.keys():
                print '%4d\t%20s'%(c+1,i),self.__dict__[i]
                c+=1
        risk=[]
        pbeta=[]
        arisk=[]
        Rrisk=[]
        brisk=[]
        srisk=[]
        breturn=[]
        rreturn=[]
        areturn=[]
        Rreturn=[]
        MCAR=[]
        MCTR=[]
        MCRR=[]
        MCBR=[]
        FMCRR=[]
        FMCAR=[]
        FMCTR=[]
        FMCSR=[]
        FMCBR=[]
        beta=[]
        FX=[]
        AFX=[]
        RFX=[]
        BFX=[]
        SFX=[]
        if self.Q == []:self.process()
        if 0:
            PropertiesC(self.n,self.nfac,self.names,self.w,self.alpha,self.bench,
                    self.Q,risk,arisk,Rrisk,rreturn,areturn,Rreturn,MCAR,MCTR,
                    MCRR,FMCRR,FMCTR,beta,FX,RFX,self.FL,self.FC,self.SV,
                    self.ncomp,self.Composites)
        else:
            PropertiesCA(self.n,self.nfac,self.names,self.w,self.bench,self.alpha,rreturn,
                         areturn,Rreturn,breturn,self.Q,
                         risk,arisk,Rrisk,brisk,srisk,pbeta,MCAR,MCTR,MCRR,MCBR,FMCRR,
                         FMCTR,FMCAR,FMCBR,FMCSR,beta,FX,RFX,AFX,BFX,SFX,self.FL,self.FC,self.SV,
                         self.ncomp,self.Composites)

        #print beta,pbeta[0]
        return (risk[0],rreturn[0],MCTR,MCAR,MCRR)

    def get_util(self):
        TCOST=[]
        UTILITY=[]
        MCTU=[]
        util_per_stock=[]
        cost_per_stock=[]
        kappa=self.kappa
        if self.costs==3:kappa=0
    
        if self.Q == []:self.process()
        MarginalUtility(self.n,self.nfac,self.names,self.w,self.bench,self.initial,self.Q,
                    self.gamma,kappa,self.npiece,self.hpiece,self.pgrad,self.buy,
                    self.sell,self.alpha,TCOST,UTILITY,MCTU,util_per_stock,cost_per_stock,
                    self.ncomp,self.Composites)
        utility=UTILITY[0]
        if self.costs==3:
            MarginalUtility(self.n,self.nfac,self.names,self.w,self.bench,self.initial,self.Q,
                        self.gamma,self.kappa,self.npiece,self.hpiece,self.pgrad,self.buy,
                        self.sell,self.alpha,TCOST,UTILITY,MCTU,util_per_stock,cost_per_stock,
                        self.ncomp,self.Composites)
        return (utility,TCOST[0])

del sys.argv[0] #This will be the string runtest.py
OxPrint=0
Forms=0
logout=0
for arg in sys.argv:
    if arg == '-ox':OxPrint=1;continue
    if arg == '-f':Forms=1;continue
    if arg.find('-l') == 0:logout=arg.replace('-l','');continue
    if Forms==0:print 'Use -f option to get GUI interface'
    print arg
    a=getf.datin()
    a.getBITA5(arg)
    if debug:
        for i in dir(a):print i,getattr(a,i)
    relrisk=testopt()

    relrisk.n=n=a.numAssets
    relrisk.nfac=a.numFactors
    if relrisk.nfac == -1:
        relrisk.Q=a.Q
        if OxPrint:oxprintmat(relrisk.Q,'Q')
    else:
        relrisk.FC=a.FC
        if OxPrint:oxprintmat(relrisk.FC,'FC')
    ncomp = 0
    try:
        relrisk.ncomp=ncomp=a.numCompositeAssets
        Comp=[]
        if a.numCompositeAssets > 0:
            stockcount=0
            for name in a.assetNames:
                if stockcount>=(relrisk.n-relrisk.ncomp):
                    ccc=getattr(a,name)
                    #exec 'ccc = a.%s' % name
                    for i in range(ncomp):
                        del ccc[-1]
                    Comp += ccc
                stockcount+=1
        relrisk.Composites=Comp
        if OxPrint:oxprintmat(relrisk.Composites,'Composites')
    except:pass
    if OxPrint:
        oxf=open('names','w')
        for name in a.assetNames:oxf.write('%s\n'%name)
        oxf.close()
    if relrisk.nfac!=-1:
        FL=[]
        for i in a.FACNAMES:
            FFL=getattr(a,i)
            for i in range(ncomp):
                del FFL[-1]
            FL+=FFL
        SV=a.specificVariance
        for i in range(ncomp):
            del SV[-1]
        relrisk.SV=SV
        if OxPrint:oxprintmat(relrisk.SV,'SV')
        relrisk.FL=FL
        if OxPrint:oxprintmat(relrisk.FL,'FL')
    relrisk.bench=a.benchmarkPortfolio
    if OxPrint:oxprintmat(relrisk.bench,'benchmark')
    relrisk.alpha=a.alphas
    if OxPrint:oxprintmat(relrisk.alpha,'alpha')
    relrisk.names=a.assetNames
    relrisk.initial=a.initialPortfolio
    if OxPrint:oxprintmat(relrisk.initial,'initial')
    relrisk.buy=a.buyCost
    if OxPrint:oxprintmat(relrisk.buy,'buy')
    relrisk.sell=a.sellCost
    if OxPrint:oxprintmat(relrisk.sell,'sell')
    relrisk.m=m=a.numLinearConstraints
    A=[0]*n*m
    L=a.lowerBoundAssetWeight
    U=a.upperBoundAssetWeight
    for cc in range(m):
        aa=getattr(a,'linearConstraint'+str(cc+1))
        #exec 'aa = a.%s' % 'linearConstraint'+str(cc+1)
        for i in range(n):
            A[cc+m*i] = aa[i]
        L.append(a.lower['linearConstraint'+str(cc+1)])
        U.append(a.upper['linearConstraint'+str(cc+1)])
    relrisk.L=L
    if OxPrint:oxprintmat(relrisk.L,'L')
    relrisk.U=U
    if OxPrint:oxprintmat(relrisk.U,'U')
    relrisk.A=A
    if OxPrint:oxprintmat(relrisk.A,'A')

       
    relrisk.gamma=a.returnParameter
    relrisk.kappa=a.costParameter
    relrisk.costs=a.costsOnOff
    relrisk.delta=a.turnoverConstraint
    relrisk.basket=a.maxNumAssetsInOptimisedPortfolio
    relrisk.tradenum=a.maxNumTradesInOptimisedPortfolio
    relrisk.revise=a.reviseOnOff
    relrisk.min_holding=a.minAssetWeight
    relrisk.min_trade=a.minAssetTrade
    relrisk.ls=a.longShortOnOff
    relrisk.full=a.fullyInvested
    relrisk.rmin=a.minShortLongRatio                      
    relrisk.rmax=a.maxShortLongRatio                        
    relrisk.round=a.roundLotsOnOff
    relrisk.maxrisk = a.maxRisk
    relrisk.minrisk = a.minRisk
    
    if a.isRiskConstrained is 'false':
        relrisk.riskc=0
    elif a.isRiskConstrained is 'true':
        relrisk.riskc=1
    else:
        raise 'isRiskConstrained is neither false nor true'

    relrisk.min_lot=a.minLot
    if OxPrint:oxprintmat(relrisk.min_lot,'min_lot')
    relrisk.size_lot=a.sizeLot
    if OxPrint:oxprintmat(relrisk.size_lot,'size_lot')

    root=None
    if Forms==1 and a.optimisationTechnique>-1:
        from scrolled import *
        class Info(Frame):
            def __init__(self,root,name,cnf={},**kw):
                """Associate a text entry with a lable"""
                for i in kw.keys():
                    cnf[i]=kw[i]
                Frame.__init__(self,root,cnf)
                l=Label(self,bg='#33ee22',text=name,justify=LEFT,anchor=W)
                l.config(width=12,relief=SUNKEN)
                l.pack(side=LEFT)
                ents=Entry(self,bg='#dddd22')
                ents.config(relief=SUNKEN)
                ents.pack(side=LEFT)
                self.ents=ents
        class StockGraph(Frame):
            def __init__(self,root,relrisk,cnf={},**kw):
                """Plot stock, initial and trade weights"""
                for i in kw.keys():
                    cnf[i]=kw[i]
                Frame.__init__(self,root,cnf)
                frame=ScrolledCanvas(root)
                frame.canvas.config(width=900,height=500,bg='#ffff55')
                frameb=Frame(root)
                def trades_data():
                    frame.canvas.delete(ALL)
                    np = relrisk.n
                    x=[float(i) for i in range(np)]
                    y=[relrisk.w[i] - relrisk.initial[i] for i in range(np)]
                    (frame.xmin,frame.xmax) = frame.minmaxval(x)
                    (frame.ymin,frame.ymax) = frame.minmaxval(y)
                    (frame.x,frame.y,frame.np) = (x,y,np)
                    frame.stockplot(fill='red',title='Trades')
                    frame.canvas.postscript(file='graph.ps')
                def cost_front():
                    frame.canvas.delete(ALL)
                    for i in scalarnamesI.split():
                        setattr(relrisk,i,int(scalarframes[i].ents.get()))
                    for i in scalarnamesF.split():
                        setattr(relrisk,i,float(scalarframes[i].ents.get()))
                    x=[]
                    y=[]
                    scalr=sqrt(12)*100
                    np=0
                    gamscl=relrisk.gamma/(1-relrisk.gamma)
                    for i in range(1,20):
                        relrisk.kappa=pow(float(i)/80,4)
                        relrisk.opt()
                        (r1,ret1,MCTR,MCAR,MCRR)=relrisk.get_prop()
                        if relrisk.gamma < 1e-6:
                            x.append(r1*scalr)
                        else:
                            x.append((r1*r1*0.5-gamscl*ret1)*1200)
                        (u,tcost)=relrisk.get_util()
                        y.append(tcost*100)
                        np+=1
                    (frame.xmin,frame.xmax) = frame.minmaxval(x)
                    (frame.ymin,frame.ymax) = frame.minmaxval(y)
                    (frame.x,frame.y,frame.np) = (x,y,np)
                    if relrisk.gamma < 1e-6:
                        frame.plotnojoin(fill='red',title='Cost vs risk')
                    else:
                        frame.plotnojoin(fill='red',title='Cost vs risk/return utility')
                    frame.canvas.postscript(file='graph.ps')
                def stocks_data():
                    frame.canvas.delete(ALL)
                    np = relrisk.n
                    x=[float(i) for i in range(np)]
                    y=relrisk.w
                    (frame.xmin,frame.xmax) = frame.minmaxval(x)
                    (frame.ymin,frame.ymax) = frame.minmaxval(y)
                    (frame.x,frame.y,frame.np) = (x,y,np)
                    ret1=retval.get()
                    r1=riskval.get()
                    u=utilval.get()
                    if 0:
                        wfile=open(arg+'w','a')
                        names=relrisk.names
                        wfile.write(ret1+'\n')
                        wfile.write(r1+'\n')
                        wfile.write(u+'\n')
                        wfile.write('Weights\n')
                        for ii in range(len(x)):
                            wfile.write('%20s %20.8e\n'%(names[ii],y[ii]))
                    frame.stockplot(fill='green',title='%s %s %s'%(ret1,r1,u))
                    frame.canvas.postscript(file='graph.ps')
                def initial_data():
                    frame.canvas.delete(ALL)
                    np = relrisk.n
                    x=[float(i) for i in range(np)]
                    y=relrisk.initial
                    (frame.xmin,frame.xmax) = frame.minmaxval(x)
                    (frame.ymin,frame.ymax) = frame.minmaxval(y)
                    (frame.x,frame.y,frame.np) = (x,y,np)
                    frame.stockplot(fill='#dddd33',title='Initial weights')
                    frame.canvas.postscript(file='graph.ps')
                buttoni=Button(frameb,bg='#ffddaa',command=initial_data,text='initial weights')
                buttons=Button(frameb,bg='#ddaaff',command=stocks_data,text='stock weights')
                buttont=Button(frameb,bg='#ddffaa',command=trades_data,text='trades')
                buttonfc=Button(frameb,bg='#bbaadd',command=cost_front,text='cost frontier')
                frame.pack(expand=1,fill=BOTH)
                frameb.pack(expand=1,fill=X)
                buttons.pack(expand=1,fill=X,side=LEFT)
                buttont.pack(expand=1,fill=X,side=LEFT)
                buttoni.pack(expand=1,fill=X,side=LEFT)
                buttonfc.pack(expand=1,fill=X,side=LEFT)
        root=Tk()
        root.title('Trace file %s; optimiser version %s, expires %s, keys %s'%(arg,version(),expire_date(),
                                                                                     component_key()))
        scalarnamesF='gamma kappa delta min_holding min_trade rmin rmax maxrisk minrisk '
        scalarnamesI='ncomp nfac npiece nabs m mabs costs basket tradenum revise ls full round riskc value '
        scalarframes={}
        vals=Frame(root,relief=SUNKEN)
        vals.pack(side=LEFT)
        vv=Label(vals,text='Scalar values')
        vv.pack(side=TOP)
        retmes=Entry(vals,bg='#33eeff')
        riskval=Entry(vals,bg='#33eeff')
        retval=Entry(vals,bg='#33eeff')
        utilval=Entry(vals,bg='#33eeff')
        def GetValues():
            for i in scalarnamesI.split():
                setattr(relrisk,i,int(scalarframes[i].ents.get()))
            for i in scalarnamesF.split():
                setattr(relrisk,i,float(scalarframes[i].ents.get()))

            relrisk.opt()

            (r1,ret1,aa,bb,cc)=relrisk.get_prop()
            ret1*=12*100
            r1*=sqrt(12)*100
            riskval.delete(0,END)
            riskval.insert(END,'risk\t%20.15e'%r1)
            retval.delete(0,END)
            retval.insert(END,'return\t%20.15e'%ret1)
            scalarframes['gamma'].ents.delete(0,END)
            scalarframes['gamma'].ents.insert(END,str(relrisk.gamma))
            (u,tcost)=relrisk.get_util()
            u*=12*100
            utilval.delete(0,END)
            utilval.insert(END,'utility\t%20.15e'%u)
            print 'Utility %-.8e' % u
            if relrisk.costs:
                print 'Cost %-.8e' % tcost
            if relrisk.costs>1:
                print '1-cost %-.8e'%(1-tcost)
            retmes.delete(0,END)
            retmes.insert(END,relrisk.returnmessage)
            
        optcom=Button(vals,bg='#ffaadd',command=GetValues,text='Optimise')
        for i in (scalarnamesI+scalarnamesF).split():
            scalarframes[i]=Info(vals,i,relief=SUNKEN)
            scalarframes[i].ents.insert(END,str(getattr(relrisk,i)))
            scalarframes[i].pack(side=TOP)
        optcom.pack(side=TOP,expand=1,fill=X)
        retmes.pack(side=TOP,expand=1,fill=X)
        riskval.pack(side=TOP,expand=1,fill=X)
        retval.pack(side=TOP,expand=1,fill=X)
        utilval.pack(side=TOP,expand=1,fill=X)
        frameg=StockGraph(root,relrisk)
        frameg.pack(side=LEFT)
        finish=Button(root,bg='#eeff33',command=root.destroy,text='Finish')
        finish.pack(side=RIGHT,expand=1,fill=X)
        root.mainloop()
    else:
        if a.optimisationTechnique>-1:
            relrisk.opt()
        else:relrisk.w=a.initialPortfolio

        (r1,ret1,MCTR,MCAR,MCRR)=relrisk.get_prop()

        (u,tcost)=relrisk.get_util()
        print 'Utility %-.8e' % u
        if relrisk.costs:
            print 'Cost %-.8e' % tcost
        if relrisk.costs>1:
            print '1-cost %-.8e'%(1-tcost)
        """
        outrisk=[]
        outcost=[]
        for i in [1e-7,1e-6,1e-5,1e-4,1e-3,1e-2,1e-1,2e-1]:
            relrisk.kappa=i
            relrisk.opt()
            (r1,ret1,MCTR,MCAR,MCRR)=relrisk.get_prop()
            outrisk.append(r1)
            (u,tcost)=relrisk.get_util()
            outcost.append(tcost)
            print 'kappa %f done'%relrisk.kappa
        print outrisk
        print outcost
        """
        if logout:
            fff=open(logout,'w')
            fff.write(version())
            fff.write('\n')
            fff.write('%20s %20s %20s\n'%('Lower','Constraint','Upper'))
            for i in range(relrisk.m):
                con=0
                for j in range(relrisk.n):
                    con+=relrisk.w[j]*relrisk.A[j*relrisk.m+i]
                fff.write('%20.8e %20.8e %20.8e\n'%(relrisk.L[i+relrisk.n],con,relrisk.U[i+relrisk.n]))
                if relrisk.costs>1 and i == 0:
                    fff.write('Take out costs check %-.8e %-.8e\n'%(tcost,1-con))
            fff.write('\n')
            ws=0
            wi=0
            wb=0
            wt=0
            fff.write('%20s %20s %20s %20s %20s %20s %20s %20s %20s %20s\n'%('Name','Initial','Optimised','Benchmark','half Trade','Lower','Upper','MCTR','MCAR','MCRR'))
            for i in range(relrisk.n):
                fff.write('%20s %20.8e %20.8e %20.8e %20.8e %20.8e %20.8e %20.8e %20.8e %20.8e\n'%(relrisk.names[i],relrisk.initial[i],
                                                                    relrisk.w[i],relrisk.bench[i],
                                                                    0.5*abs(relrisk.w[i]-relrisk.initial[i]),
                                                                    relrisk.L[i],relrisk.U[i],MCTR[i],MCAR[i],MCRR[i]))
                ws+=relrisk.w[i]
                wb+=relrisk.bench[i]
                wi+=relrisk.initial[i]
                wt+=abs(relrisk.w[i]-relrisk.initial[i])
            fff.write('%20s %20.8e %20.8e %20.8e %20.8e\n'%('Totals',wi,ws,wb,wt))
            fff.write('\n')
            fff.write('Risk\t\t%20.8e\n'%r1)
            fff.write('Return\t\t%20.8e\n'%ret1)
            fff.write('Utility\t\t%20.8e\n'%u)
            fff.write('\n')
            (l,s,g)=longshortgross(relrisk.w)
            fff.write('Long\t\t%20.8e\tShort\t\t%20.8e\n'%(l,s))
            fff.write('Gross\t\t%20.8e\t-Short/Long\t\t%20.8e\n'%(g,-s/l))

