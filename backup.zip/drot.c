#include "ldefns.h"
/*
	Apply a plane rotation
*/
void drot(dimen n, vector x, stride incx, vector y, stride incy, real c, real s)
{
	register real t;

	if(n <= 0) return;
	if(incx == 1 && incy == 1) drotvec(n,x,y,c,s);
	else	{
    		if(incx < 0) x += (1-n)*incx;
    		if(incy < 0) y += (1-n)*incy;
    		while(n--){
			t  = c * *x + s * *y;
			*y = c * *y - s * *x;
			*x = t;
			x += incx;
			y += incy;
    			}
    		}
}
