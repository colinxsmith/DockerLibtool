#!/bin/env python
import safe
def Symmult(n,n1,n2,n3,S,x,Sx):
#    print 'x ',x
    """Multiply a symmetric matrix S by a vector x to get Sx.
    S is a list of length n*(n+1)/2 containing the lower triangle of a symmetric
    matrix stored in the order [00,10,11,20,21,22,.......]
    x and Sx are lists of length n
    """
    if len(x)<n:raise 'x is not long enough'
    if len(Sx)<n:raise 'Sx is not long enough'
    if len(S)<n*(n+1)/2:raise 'S is not long enough'
    ij=0
    for i in range(n):
        Sx[i]=0
        for j in range(i+1):
            Sx[i]+=S[ij]*x[j]
            if i!=j:Sx[j]+=S[ij]*x[i]
            ij+=1
#    print 'Sx ',Sx

def lsmul(n,n1,n2,n3,H,x,y):
    if len(x)<n:raise 'x is not long enough'
    if len(y)<n:raise 'y is not long enough'
#    print 'x ',x,ns
    w=[0]*ns
    j=0
    for i in range(ns):
        w[i]=x[i]
        if lab[j] == i:
            w[i]+=x[ns+j]
            j+=1
    Symmult(ns,n1,n2,n3,H,w,y)
    j=0
    for i in range(ns):
        if lab[j] == i:
            y[ns+j]=y[i]
            y[i]-=x[ns+j]*pen[i]
            y[ns+j]-=x[i]*pen[i]
            j+=1
#    print 'y ',y
def makepen(n,pen,H,tt):
    x=[0]*n
    y=[0]*n
    for i in range(n):
        x[i]=1
        tt(n,n,n,n,H,x,y)
        pen[i]=2*y[i]
        x[i]=0
def longshortgross(w):
    """Get the total long, short and gross weights for weights in w."""
    p=0
    m=0
    g=0
    for i in w:
        if i>0:p+=i;g+=i
        else:m+=i;g-=i
    return (p,m,g)

ns=4
lab=range(ns)
pen=[0]*ns
o=safe.Optimise()
o.n=4
o.H=[1,0.1,2,0,0.6,3,0,0,0,4]
#makepen(ns,pen,o.H,Symmult)
#pen=[i*.853151815012 for i in pen]
o.hmul=lsmul
o.SetLog()
NN=ns*2
MM=2
AA=[1,1]*NN
for i in range(ns):
    AA[MM*i+1]=0
LL=[-1]*ns+[0]*ns+[0,1]
UU=[0]*ns+[1]*ns+[0,1]

CC=[(i+1) for i in range(ns)]*2
XX=[0]*NN
print AA
pentop=1
penbot=0
pentry=1
if o.OptInterior(NN,MM,XX,AA,LL,UU,CC):
    print 'Interior Point method failed'
while 0:
    print '*'*20,pentry,'+'*20
    makepen(ns,pen,o.H,Symmult)
    pen=[i*pentry for i in pen]
    if o.OptInterior(NN,MM,XX,AA,LL,UU,CC):
        print 'Interior Point method failed'
        pentop=pentry
        pentry=(pentop+penbot)*.5
    else:
        x=[XX[i]+XX[i+ns] for i in range(ns)]
        p=longshortgross(x)[0]
        if p > 1-.00001:break
        penbot=pentry
        pentry=(pentop+penbot)*.5
        
#o.PrintLog()
print XX
x=[XX[i]+XX[i+ns] for i in range(ns)]
print x,longshortgross(x)
A=[1,0]*ns
L=[0]*ns
U=[0]*ns
m=2
for i in range(ns):
    if x[i]<0:
        L[i]=-1
    else:
        U[i]=1
        A[m*i+1]=1
L+=[0,1]
U+=[0,1]
o.hmul=Symmult
o.OptInterior(ns,m,x,A,L,U,CC)
print x,longshortgross(x)
