from Opt import *

n=1
m=2
ncone=[3]
nx=sum(ncone)
r2=pow(2,.5)

c=[1,-1,0.5]
A=[0,0,1.0,
   1,1,0]
b=[r2,1]

x=[0]*nx
s=[0]*nx
y=[0]*m
tau=[0]
kappa=[0]

SOCPinfeasHomogt(n,m,ncone,c,A,b,x,y,s,tau,kappa)

print 'tau\t= %20.12e'%tau[0]
print 'kappa\t= %20.12e'%kappa[0]

print '%20s %20s %20s %20s'%('x','s','x/tau','s/tau')
for i in range(nx):
    print '%20.12e %20.12e %20.12e %20.12e'%(x[i],s[i],x[i]/tau[0],s[i]/tau[0])
print '%20s %20s %20s'%('y',' ','y/tau')
for i in range(m):
    print '%20.12e %20s %20.12e'%(y[i],' ',y[i]/tau[0])