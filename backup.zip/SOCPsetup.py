#!/usr/bin/env python
"""
Colin 3rd. November 2005

This shows how to set up simple quadratic optimisations
using second order cones. Either the primal or the dual
SOCP problem may be used. This shows how the dual leads
to a more efficient use of storage and more importantly
leads to smaller KKT matrices which need to be inverted
at each SOCP iteration.

Both the primal and the dual are seen to give the same
solution.

The optimisation problem here is to reduce scalar V

Reduce V
such that

(0.5x.Q.x-g/(1-g)alpha.x) <= V
L<=x<=U
L<=A.x<+U
"""
from safe import *
def dot(a,b):
    """Scalar product of a and b."""
    back=0
    n=len(a)
    for i in range(n):back+=a[i]*b[i]
    return back
def epsget():
    """Return machine accuracy."""
    a=1.3333333333333333333333333333333333333
    b=a-1.
    return 1-(b+b+b)
def listprnt(a):
    """Print out a list nicely"""
    n=len(a)
    k=0
    while k<n:
        s=''
        for i in range(5):
            if k>=n:break
            s+='%15.8f '%a[k]
            k+=1
        print s
def utility(n,gamma,alpha,Q,w,bench):
    """BITA utility function"""
    cc=-gamma/(1-gamma)
    rel=[w[i]-bench[i] for i in range(n)]
    implied=[]
    Sym_mult(n,Q,rel,implied)
    return cc*dot(alpha,rel)+0.5*dot(rel,implied)
eps=1e-3#epsget()#pow(epsget(),.5)    #Convergence number for SOCP
class SOCPOPT:
    def __init__(self):
        for i in ['n','m']:setattr(self,i,0)
        for i in ['nd','c','A','b','kappa','tau']:setattr(self,i,[])
    def Opt(self):
        nn=sum(self.nd)
        x=[0]*nn        #primal variables
        s=[0]*nn        #complementarity variables
        y=[0]*self.m    #dual variables
        for i in ['tau','kappa']:setattr(self,i,[0])
        #Solve our problem by embedding it in a homogenous SOCO
        back=0
        if SOCPinfeasHomogt(self.n,self.m,self.nd,self.c,self.A,self.b,x,y,s,self.tau,
                            self.kappa,100,1e-8,.5,eps,eps):print 'SOCP failed '*4;back=1
        else:
            if self.tau[0]<self.kappa[0]:
                print 'INFEASIBLE '*5
                if dot(self.b,y)>0:print 'b dot y %20.12e primal is infeasible'%(dot(self.b,y))
                if dot(self.c,x)<0:print 'c dot x is %20.12e dual is infeasible'%(dot(self.c,x))
                back=1
            else:
                print 'It Worked!'
                s=[i/self.tau[0] for i in s]    #Recover our variables from the homogenous problem
                y=[i/self.tau[0] for i in y]
                x=[i/self.tau[0] for i in x]
                print 'x'
                listprnt(x)
                print 'dual variables y'
                listprnt(y)
                print 'complementary variables s'
                listprnt(s)
        self.x=x
        self.y=y
        self.s=s
        print 'KKT matrix has size %d; constraint matrix is %d by %d'%(nn+self.m,nn,self.m)
        return back
    def BITAconvertConstraintsD(self,n,m,A,L,U,alpha,gamma,bench):
        """Set up a BITA optimisation problem using the dual.

        This requires inversion of matrices of size n+1 + 2(n+m)+n+2  in the
        interior point method
        """
        self.m=n+1              #Number of dual variables
        self.n=n+m+1            #NUmber of cones
        self.nd=[n+2]+[2]*(n+m) #Cones needed
        b=[0]*n+[1]             #Dual cost vector
        self.b=b
        cc=-gamma/(1-gamma)
        implied=[0]*n
        if bench!=[]:Sym_mult(n,self.Q,bench,implied)
        avec=[cc*alpha[i]-implied[i] for i in range(n)]
        cvec=[0]*n
        for i in range(n):cvec[i]=-dot(avec,self.rQm1[i*n:(i+1)*n])
        self.A=[]
        #Utility constraint
        for i in range(n):self.A+=self.rQ[i*n:(i+1)*n]+[0]
        self.A+=[0]*(n+1)
        self.A+=[0]*n+[1]
        #Variable bound constraints
        for i in range(n):
            s=[0]*(n+1)
            s[i]=1
            self.A+=s
            self.A+=[0]*(n+1)
        #General Linear Constraint bound constraints
        for i in range(m):
            s=[0]*(n+1)
            for j in range(n):s[j]=A[j*m+i]
            self.A+=s
            self.A+=[0]*(n+1)
        c=cvec+[0]+[0]
        for i in range(n+m):
            c.append((L[i]+U[i])*.5)
            c.append((U[i]-L[i])*.5)
        nn=sum(self.nd)         #Number of primal variables
        x=[0]*nn
        s=[0]*nn
        y=[0]*self.m
        tau=[0]
        kappa=[0]
        #The matrix is the wrong way round, so we transpose it
        dmx_transpose(self.m,nn,self.A,self.A)
        self.c=c
    def BITAconvertConstraintsP(self,n,m,A,L,U,alpha,gamma,bench):
        """Set up a BITA optimisation problem using the primal.
        Note the weights come back as first n entries in self.x

        This requires inversion of matrices of size 2(n+m)+n+1 + 2(n+1+n+m)  in the
        interior point method
        """
        self.n=1+n+m+1                  #Number of cones
        self.m=2*(m+n)+1+n              #Number of constraints (dual) variables
        self.nd=[n+1]+[2]*(n+m)+[n+1]   #Cones needed for the constraints
        nn=sum(self.nd)                 #Number of primal variables

        #Redundant constraint, actually ensures sum(x**2)<=n. Needed to be able
        #to link the cone constraints to the true variables
        self.A=[0]*nn
        self.A[n]=1
        self.b=[n]

        #Variable bound constraints
        for i in range(n):
            pp=[0]*nn
            pp[n+1+i*2+1]=1
            self.A+=pp
            self.b+=[(U[i]-L[i])*.5]
            pp=[0]*nn
            pp[i]=1
            pp[n+1+i*2]=-1
            self.A+=pp
            self.b+=[(U[i]+L[i])*.5]
        #General Linear Constraint bound constraints
        for i in range(m):
            pp=[0]*nn
            pp[n+1+(n+i)*2+1]=1
            self.A+=pp
            self.b+=[(U[i+n]-L[i+n])*.5]
            pp=[A[i+jj*m] for jj in range(n)]+[0]+[0]*(2*(n+m))+[0]*(n+1)
            pp[n+1+(n+i)*2]=-1
            self.A+=pp
            self.b+=[(U[i+n]+L[i+n])*.5]
        """
        Y=The last constraint is the "square root of the utility function" modified
        i.e.
        -a.x+0.5xQx
        becomes
        0.5*(L'x - a.L'-1)**2+0.5*(a.L'-1)**2
        """
        cc=-gamma/(1-gamma)
        implied=[0]*n
        if bench!=[]:Sym_mult(n,self.Q,bench,implied)
        avec=[cc*alpha[i]-implied[i] for i in range(n)]
        cvec=[0]*n
        for i in range(n):cvec[i]=dot(avec,self.rQm1[i*n:(i+1)*n])
        #Utility constraint
        for i in range(n):
            pp=[0]*nn
            for j in range(n):
                pp[j]=self.rQ[j+i*n]
            pp[n+1+2*(n+m)+i]=-1
            self.b+=[-cvec[i]]
            self.A+=pp
        self.c=[0]*(nn-1)+[1]   #Primal cost vector
    def BITAconvertModel(self,n,nfac,SV,FC,FL):
        """Multiply out the risk model to give a
        covariance matrix
        """
        Q=[0]*(n*(n+1)/2)
        Factor2Cov(n,nfac,FC,FL,SV,Q)
        self.Q=Q        #Covariances
    def FactoriseQ(self,n):
        """Factorise the covariance to find a
        representation of its square root and
        also give the inverse of the square
        root
        """
        rQ=[]
        rQm1=[]
        RootQ(n,self.Q,rQ,rQm1)
        self.rQ=rQ      #square root of Q
        self.rQm1=rQm1  #inverse of root Q
if __name__=='__main__':
    #Simple factor model problem to show how to do a BITA type problem. Change n
    #to anything you like.
    print version()     #Optimiser version string
    n=500
    m=1
    nfac=2
    SV=[(i+1)*1e-5 for i in range(n)]
    FL=[1]*n+[1]+[0]*(n-1)
    FC=[1e-4,1e-5,2e-4]
    Opt=SOCPOPT()
    A=[1]*n
    L=[0]*n+[1]
    U=[1]*(n+1)
    gamma=1e-1
    alpha=[(i+1)*.01 for i in range(n)]
    bench=[float(1)/n for i in range(n)]
    Opt.BITAconvertModel(n,nfac,SV,FC,FL)
    Opt.FactoriseQ(n)
    #Use the Dual Problem
    #____________________________________________________________
    Opt.BITAconvertConstraintsD(n,m,A,L,U,alpha,gamma,bench)
    Opt.Opt()
    #This gets the weights we want
    w=Opt.y[:n]
    listprnt(w)
    print 'Sum of weights',sum(w)
    print 'Primal dual utility',Opt.y[-1]
    print 'BITA Utility',utility(n,gamma,alpha,Opt.Q,w,bench)
    #____________________________________________________________
    #Use the Primary Problem
    #____________________________________________________________
    Opt.BITAconvertConstraintsP(n,m,A,L,U,alpha,gamma,bench)
    Opt.Opt()
    #This gets the weights we want
    w=Opt.x[:n]
    listprnt(w)
    print 'Sum of weights',sum(w)
    print 'Primal dual utility',Opt.x[-1]
    print 'BITA Utility',utility(n,gamma,alpha,Opt.Q,w,bench)
    #____________________________________________________________
