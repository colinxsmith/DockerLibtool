#include "baseoptimise.h"
//Remove as we use optimise class now #include "das_sol.h"
/*
	detagen  generates an elimination transformation  e  such that
		e ( alpha )  =  ( delta ) ,
		  (   x   )     (   0   )

	where  e  has the form
		e  =	( 1    ) p
			( z  i )

	for some n-vector  z  and permutation matrix  p  of order  n + 1.
	in certain circumstances ( x  very small in absolute terms or
	x very small compared to  alpha),  e  will be the identity matrix.
	detagen  will then leave  alpha  and  x  unaltered, and will return
	iswap = 0,  itrans = 0

	more generally,  iswap  and  itrans  indicate the various possible
	forms of  p  and  z  as follows
		if  iswap  =  0,  p = i
		if  iswap  gt 0,  p  interchanges  alpha  and  x(iswap)
		if  itrans =  0,  z = 0  and the transformation is just  e = p
		if  itrans gt 0,  z  is nonzero.  its elements are returned in  x.

	detagen  guards against overflow and underflow
	it is assumed that  flmin < epsmch**2 (i.e. rtmin < epsmch).
*/
void detagen(dimen n, real *alpha, vector x, stride incx, integer *iswap, integer *itrans)
{
	int		imax=1000000000;
	dimen		nzero;
	real		xmax, absalf, tol, axi;
	vector		v, vlim;

	*iswap = 0;
	*itrans = 0;
	if (n < 1) return;
	absalf = fabs(*alpha);
	xmax = 0;

	for(v=x, vlim=x+n*incx; v!=vlim ; v += incx)
		if(xmax < (axi = fabs(*v))){
			xmax = axi;
			imax = v - x;
			}

	/* exit if  x  is very small */
	if(xmax <= lm_rootmin) return;

	/* see if an interchange is needed for stability */
	if(absalf < xmax){
		*iswap = imax+1;
		xmax = x[imax];
		x[imax] = *alpha;
		*alpha = xmax;
		}

	/*
	     form the multipliers in  x.  they will be no greater than one
	     in magnitude.  change negligible multipliers to zero
	*/
	tol = fabs(*alpha) * lm_eps;
	nzero = 0;
	for(v=x; v!=vlim ; v += incx)
		if (fabs(*v) > tol) *v = - *v / *alpha;
		else	{
			*v = 0;
			++nzero;
			}
	/*z is zero only if nzero=n*/
	if(nzero < n) *itrans = 1;
}
