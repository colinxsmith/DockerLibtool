/*
	dcossint(t,&s) returns c and sets s where
		c = cos( theta ),   s = sin( theta )
		for a given value of t = tan( theta ).

	c is always non-negative and s has the same sign as t, so that
		c = 1.0/sqrt( 1.0 + t**2 ),   s = t/sqrt( 1.0 + t**2 ).

	If  abs( t ) <= eps, where eps is the relative machine precision
		c = 1.0   and   s = 0.0.

	If  abs( t ) .ge. 1/eps  then c and s are returned as
		c = 0.0   and   s = sign( t ).

	R. G. Becker	October 1992
*/
#include "ldefns.h"
#include "constant.h"

real dcossint(real t, real *s)
{
	real	abst, c;

	abst = fabs(t);

	if (abst <= lm_eps){
		c = 1;
		*s = 0;
		}
	else if(abst >= lm_reps){
		c = 0;
		*s = dsign(CR(1), t);
		}
	else if(abst < lm_rooteps){
		c = 1;
		*s = t;
		}
	else if(abst > lm_rrooteps){
		c = 1 / abst;
		*s = dsign(CR(1), t);
		}
	else	{
		/* Computing 2nd power */
		c = 1 / sqrt(abst * abst + 1);
		*s = c * t;
		}
	return c;
}
