from Optn import *
#Show how to do global exposure report
n=4
nl=2
FL=[1,1,1,1,1,0,1,0]
x=[1,2,3,4]
nsect=0
sectdef=[]
nfgroup=0
fgroupdef=[]
TotalExp=[9.9]*(nl+1)
TotalBreak=[9.9]*(nl+1)*n

if jython:
    FLm=single2double(n,nl,FL)
    TotalExp=Convert(TotalExp)
    TotalBreak=Convert(TotalBreak)
else: FLm=FL
FexposureAttribution(n,nl,FLm,x,nsect,sectdef,nfgroup,
                     fgroupdef,TotalExp,TotalBreak)

print TotalExp
print TotalBreak


ng=3
YS=[1,1,2,2,3,3]
FX=[.0]*nl
if jython:
    FX=Convert(FX)
dmxtmulv(n,nl,FL,x,FX)
#print FX

GTotalExp=[9.9]*(ng+1)
GTotalBreak=[9.9]*(ng+1)*nl

if jython:
    YSm=single2double(nl,ng,YS)
    GTotalExp=Convert(GTotalExp)
    GTotalBreak=Convert(GTotalBreak)
else: YSm=YS
FexposureAttribution(nl,ng,YSm,FX,nsect,sectdef,nfgroup,
                     fgroupdef,GTotalExp,GTotalBreak)

print GTotalExp
print GTotalBreak

YSFL=[]
for i in range(ng):
    if jython:back=Convert([0.]*n)
    else:back=[0]*n
    #dmxmulv(n,nl,FL,YS[nl*i:nl*(i+1)],back) #use either
    dmxtmultv(nl,n,FL,YS[nl*i:nl*(i+1)],back)
    YSFL+=[i for i in back]
print YSFL

GLTotalExp=[9.9]*(ng+1)
GLTotalBreak=[9.9]*(ng+1)*n
if jython:
    YSFLm=single2double(n,ng,[i for i in YSFL])
    GLTotalExp=Convert(GLTotalExp)
    GLTotalBreak=Convert(GLTotalBreak)
else: YSFLm=YSFL
FexposureAttribution(n,ng,YSFLm,x,nsect,sectdef,nfgroup,
                     fgroupdef,GLTotalExp,GLTotalBreak)

print GLTotalExp
print GLTotalBreak
