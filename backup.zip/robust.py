#!/bin/env python
"""
extern "C" void SOCPinfeasHomogt(size_t n,size_t m,size_t *ncone,vector c,vector A,
										 vector b,vector x,vector y,vector s,double *tau,
										 double *kappa,size_t maxit=20,double beta=.9,double delta=.95,
										 double ccomp=1e-4,double cgap=1e-4);
"""
from Opt import *

alpha = [.1,.1,.1,.4,.39999]
#alpha=[-i for i in alpha]
errs = [.005,.004,.001,.002,.0015]
top=.10095238094
top=.101
#top=-.3985
small=0#pow(epsget(),.5)  #square root of machine accuracy
"""
min alpha.w st alpha.w+||errs.w|| < top
0<=w<=1
and sum(w)=1
"""

c=[i for i in alpha]
m=len(alpha)
U=[1]*m
L=[small]*m
n=2+m
ncone=[2,m+1]+[2]*m
nx=sum(ncone)
#____________________ Set Budget Constraint ____________
A=[1]*m+[0]*m
b=[-1,0]            #set bounds lower=upper=1
#____________________ End Budget Constraint ____________
#____________________ Set Alpha Error Constraint _______
for i in range(m):
    a=[0]*m
    a[i]=errs[i]
    A+=a
A+=[-i for i in alpha]
b+=[0]*m+[top]
#____________________ End Alpha Error Constraint _______
#____________________ Set Variable Bounds ______________
for i in range(m):
    a=[0]*m
    a[i]=1
    A+=a
    A+=[0]*m
    b+=[-(U[i]+L[i])*.5,(U[i]-L[i])*.5]
#____________________ End Variable Bounds ______________
dmx_transpose(m,nx,A,A)
#for i in range(m):print A[i*nx:i*nx+nx]
tau=[0]
kappa=[0]
x=[0]*nx
s=[0]*nx
y=[0]*m
if SOCPinfeasHomogt(n,m,ncone,b,A,c,x,y,s,tau,kappa,100,1e-8,.5,1e-9,1e-9):print 'SOCP failed '*10
print tau[0],kappa[0]
if tau[0]<kappa[0]:
    print 'INFEASIBLE '*5
    if dot(c,y)>0:print 'c dot y %20.12e primal is infeasible'%(dot(c,y))
    if dot(b,x)<0:print 'b dot x is %20.12e dual is infeasible (our problem)'%(dot(b,x))
else:
    w=[-i/tau[0] for i in y]
    print '      %20s %20s %20s'%('return est','return standard error','weight')
    for i in range(m):
        print '      %20.12e %20.12e %20.12e'%(alpha[i],errs[i],w[i])
    print 'Total %20.12e %20.12e %20.12e'%(dot(w,alpha),pow(sum([sqr(errs[i]*w[i]) for i in range(m)]),.5),sum(w))
    print 'Total expected return plus error %20.12e (%20.12e)'%(dot(w,alpha)+pow(sum([sqr(errs[i]*w[i]) for i in range(m)]),.5),top)


