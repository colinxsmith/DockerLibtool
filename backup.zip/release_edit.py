"""Code to add extras in the python wrapper
"""
import re,sys

    
fi=sys.stdin
#fi=open('interim')
fo=sys.stdout
name=None
change=0
for i in fi.readlines():
    if i.find('_set(')!= -1:
        name=i.split('_')[-2]
        change=0
    elif i.find('_set_1')!= -1:
        name=i.replace('_1','_').split('_')[-1]
        name=name.split('(')[0]
        change=0
    elif i.find('= new ')!=-1:
        if i.find('Java') == -1:
            change=1
    elif change and i.find('if (arg1) (arg1)->%s ='%name)!=-1:
        fo.write('\tif (arg1) delete[] (arg1)->%s;\n'%name)
    fo.write(i)
