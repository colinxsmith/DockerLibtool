#ifdef PASkeyMAKE
#include<ctime>
#include<sstream>
#include "ldefns.h"
#include "validate.h"
#else
#include "baseoptimise.h"
#endif
#define padbase 0x13101955
#include<fcntl.h>
#include<unistd.h>

/*
extern "C" int my_read(int i,void* backstuff,unsigned int j);
extern "C" int my_write(int i,void* backstuff,unsigned int j);
extern "C" int my_open(const char* filename,int mode);
extern "C" int my_creat(const char* filename,int mode);
extern "C" int my_close(int fileno);
*/
#define my_close close
#define my_read read
#define my_write write
#define my_open open
#define my_creat creat

#if defined( _WINDOWS) && !defined(MSDOSS)
extern "C" int my_setmode(int fileno,int mode);
#endif

#define LIBVER 2.02235
#define	_VER_TOKEN(A) __VER_TOKEN(A)
#define	__VER_TOKEN(A) #A

#define validator_c(z) validator_m[(z+k) % 48]

#ifdef _WINDOWS

#ifdef PAS
extern "C" int RegDelete(HKEY key=HKEY_CURRENT_USER,LPCTSTR lpSubKey=(char*)"Software\\embedded")
#else
extern "C" int RegDelete(HKEY key=HKEY_CURRENT_USER,LPCTSTR lpSubKey=(char*)"Software\\safeqp")
#endif
{
	int back=0;
	LONG result;
	result = RegDeleteKey(key,lpSubKey);
	back=back||result;
	return back;
}
#ifdef PAS
extern "C" int RegWrite(unsigned char*hhh,int len,HKEY key=HKEY_CURRENT_USER,LPCTSTR lpSubKey=(char*)"Software\\embedded")
#else
extern "C" int RegWrite(unsigned char*hhh,int len,HKEY key=HKEY_CURRENT_USER,LPCTSTR lpSubKey=(char*)"Software\\safeqp")
#endif
{
	int back=0;
	LONG result;
	HKEY hKey;
	DWORD dwDisposition;
	result=RegOpenKeyEx(

		key,	// handle of open key 
		lpSubKey ,	// address of name of subkey to open 
		0,	// reserved 
		KEY_ALL_ACCESS,	// security access mask 
		&hKey 	// address of handle of open key 
		);
	if(result!=ERROR_SUCCESS)
	{
		back=0;
		result=RegCreateKeyEx(

			key,	// handle of an open key 
			lpSubKey ,	// address of subkey name 
			0,	// reserved 
			0,	// address of class string 
			0,	// special options flag 
			0,	// desired security access 
			0,	// address of key security structure 
			&hKey,	// address of buffer for opened handle  
			&dwDisposition 	// address of disposition value buffer 
			);	
		back=back||result;
		if(result==ERROR_SUCCESS)
		{
			result=RegOpenKeyEx(

				key,	// handle of open key 
				lpSubKey ,	// address of name of subkey to open 
				0,	// reserved 
				KEY_ALL_ACCESS,	// security access mask 
				&hKey 	// address of handle of open key 
				);
			back=back||result;
		}
	}
	if(result==ERROR_SUCCESS)
	{
		back=0;
		DWORD type=REG_BINARY;
		DWORD datasize=len*sizeof(unsigned char);
		result= RegSetValueEx(

			hKey,	// handle of key to set value for  
			lpSubKey,	// address of value to set 
			0,	// reserved 
			type,	// flag for value type 
			hhh,	// address of value data 
			datasize 	// size of value data 
			);	
		back=back||result;
		result=RegCloseKey(

			hKey 	// handle of key to close  
			);
		back=back||result;
	}
	return back;
}
#ifdef PAS
extern "C" int RegRead(unsigned char*hhh,int len,HKEY key=HKEY_CURRENT_USER,LPCTSTR lpSubKey=(char*)"Software\\embedded")
#else
extern "C" int RegRead(unsigned char*hhh,int len,HKEY key=HKEY_CURRENT_USER,LPCTSTR lpSubKey=(char*)"Software\\safeqp")
#endif
{
	int back=0;
	LONG result;
	HKEY hKey;
	result=RegOpenKeyEx(

		key,	// handle of open key 
		lpSubKey ,	// address of name of subkey to open 
		0,	// reserved 
		KEY_ALL_ACCESS,	// security access mask 
		&hKey 	// address of handle of open key 
		);
	back=back||result;
	if(result==ERROR_SUCCESS)
	{
		back=0;
		DWORD type=REG_BINARY;
		DWORD datasize=len*sizeof(unsigned char);
		result= RegQueryValueEx(

			hKey,	// handle of key to query 
			lpSubKey,	// address of name of value to query 
			0,	// reserved 
			&type,	// address of buffer for value type 
			hhh,	// address of data buffer 
			&datasize 	// address of data buffer size 
			);
		back=back||result;
		result=RegCloseKey(

			hKey 	// handle of key to close  
			);
		back=back||result;
	}
	return back;
}
#endif


void	Validate::modify_licence(validator_t& v,compkeyn &ckey,const char*licfile)
{
	FILE*dd;
	int extras;
	unsigned int hid=v.t.hid;
	unsigned int t1=v.t.start;
	unsigned int t2=v.t.stop;
	unsigned char hhh[20];
#if defined (_WINDOWS) && !defined(MSDOSS) && !defined(MINGW32)
	time_t	timenow;
	time(&timenow);
	if((int) timenow <= t2 && (int) timenow >= t1)
	{
		unsigned char check_hhh[20];
		convert(hhh,&hid,&t1,&t2);
		memcpy(hhh+16,ckey.n,4);
		RegWrite(hhh,20);
		RegRead(check_hhh,20);
		if(strncmp((const char*)hhh,(const char*)check_hhh,20))
		{
			printf((char*)"Registry error\n");
		}
	}
	else
	{
		RegDelete();
		if(!RegRead(hhh,20,HKEY_LOCAL_MACHINE))
		{
			printf((char*)"Use the global key\n");
			RegWrite(hhh,20);
			hid=0;
			convert(hhh,&hid,&t1,&t2);
			memcpy(ckey.n,hhh+16,4);
			hid -= ckey.key;
			v.t.hid=hid;
			v.t.start=t1;
			v.t.stop=t2;
			if((timenow-t1) > 70*3600*24)
			{
				RegDelete(HKEY_LOCAL_MACHINE);
				printf((char*)"Clear up global registry\n");
			}
		}
	}
#else
	if((extras = my_open(licfile,O_RDWR))!=-1)
	{
#if defined( _WINDOWS) && !defined(MSDOSS)
		my_setmode(extras,O_BINARY);
#endif
		convert(hhh,&hid,&t1,&t2);
		my_write(extras,hhh,16);
		my_write(extras,ckey.n,4);
		my_close(extras);
	}
	else if((dd = fopen(licfile,(char*)"w")))
	{
		fclose(dd);
		extras = my_open(licfile,O_RDWR);
#if defined( _WINDOWS) && !defined(MSDOSS)
		my_setmode(extras,O_BINARY);
#endif
		convert(hhh,&hid,&t1,&t2);
		my_write(extras,hhh,16);
		my_write(extras,ckey.n,4);
		my_close(extras);
	}
	else
	{
		fprintf(stderr,(char*)"extras = %lx\n",extras);
	}
#endif
}
Validate::~Validate()
{
	delete[] version_string;
	delete[] validator_m;
	delete[] STOP;
}
Validate::Validate()
{
	vv=(char*)"RdG^AsTi1GgaKa7teDF3E645Fd912j4cB4b0_1|(&50'34$!TzZjkIXlMHPVW*@~";	
	STOP=0;
#ifdef PAS
	progname=(char*)"embedded";
	filename=(char*)"BITA_PAS_key";
#else
	progname=(char*)"safeqp";
#endif
#ifdef _DEBUG
	version_string_raw=(char*)"DEBUG Optimiser from BITA Plus. \0aaaabbbbccccddddeeeeffffgggghhhhiiiiJJJJ";
#else
	version_string_raw=(char*)"Optimiser from BITA Plus. \0aaaabbbbccccddddeeeeffffgggghhhhiiiiJJJJ";
#endif
	rawlen=strlen(version_string_raw)+42;
	version_string=new char[rawlen+1];
	memcpy(version_string,version_string_raw,rawlen);
	version_string[rawlen]='\0';
	validator_m=new char[strlen(vv)+1];
	strcpy(validator_m,vv);
//	std::cout<< "compare "<<strcmp(validator_m,vv)<<std::endl;
	bitaopt = 23;
//	bitaopt = 19;	fame_pox
}
void	Validate::krypton(unsigned char *b)
{
	unsigned int	i, w[16],z[16];
	for(i=0;i<16;i++)
	{
		w[i] = b[i]>>4;
		z[i] = b[i]&0xf;
	}
	for(i=0;i<16;i++) 
	{
		b[i] = (z[15-i]<<4)|(w[15-i]);
	}
}
void Validate::make_valid(validator_t *vp,size_t start,size_t stop,size_t hid)
{
	int	i, j, k;
	unsigned char	c;

	for(j=0;j<48;j+=16) krypton((unsigned char*)validator_m+j);
	vp->t.pad = 0x13101955 + bitaopt;
	vp->t.start = start;
	vp->t.stop = stop;
	vp->t.hid  = hid;
	for(i=j=0;i<16;i++) j += vp->b[i];
	k = (j*147)%48;

	vp->t.pad += stop-start;
	vp->t.pad ^= hid;
	vp->t.start ^= vp->t.pad;
	vp->t.hid ^= stop;

	krypton(vp->b);
	for(j=0;j<3;j++)
	{
		for(i=0;i<16;i++) vp->b[i] ^= validator_c(i+j*16);
		krypton(vp->b);
		for(c=vp->b[i=0];i<15;i++) vp->b[i] = vp->b[i+1];
		vp->b[i] = c;
	}
	for(i=0;i<16;i++) vp->b[i] ^= validator_c(i+j*16);

/*	printf((char*)"%8.8lX %8.8lX %8.8lX %8.8lX\n", */
/*		vp->t.start,vp->t.stop,vp->t.pad,vp->t.hid); */
	for(j=0;j<48;j+=16) krypton((unsigned char*)validator_m+j);
}

int	Validate::check_valid( validator_t *vp)
{
	int	i, j, k; 
	unsigned char	c;
	validator_t	v;

	for(j=0;j<48;j+=16) krypton((unsigned char*)validator_m+j);
	for(k=0;k<48;k++){
		v = *vp;
//	printf((char*)"k=%d\n",k);
//	printf((char*)"%8.8lX %8.8lX %8.8lX %8.8lX\n",
//		v.t.start,v.t.stop,v.t.pad,v.t.hid);
	for(j=3,i=0;i<16;i++) v.b[i] ^= validator_c(i+j*16);
	while(j--){
		for(c=v.b[i=15];i;i--) v.b[i] = v.b[i-1];
		v.b[i] = c;
		krypton(v.b);
		for(i=0;i<16;i++) v.b[i] ^= validator_c(i+j*16);
		}

	krypton(v.b);
//	printf((char*)"%8.8lX %8.8lX %8.8lX %8.8lX\n",
//		v.t.start,v.t.stop,v.t.pad,v.t.hid);
	v.t.hid ^= v.t.stop;
	v.t.start ^= v.t.pad;
	v.t.pad ^= v.t.hid;
	v.t.pad -= v.t.stop-v.t.start;

//	printf((char*)"%8.8lX %8.8lX %8.8lX %8.8lX\n",
//		v.t.start,v.t.stop,v.t.pad,v.t.hid);
	if(v.t.pad==0x13101955 + bitaopt){
		*vp = v;
		break;
		}
	}
	for(j=0;j<48;j+=16) krypton((unsigned char*)validator_m+j);
//	std::cout<< "compare "<<strcmp(validator_m,vv)<<std::endl;

	return k!=48;
}

void Validate::convert(unsigned char* s,unsigned int *h,unsigned int *t0,unsigned int *t1)
{
	validator_t	validator;
	if(*h!=0)
	{
		make_valid(&validator, *t0, *t1,*h );
		memcpy(s,validator.b,16);
	}
	else
	{
		memcpy(validator.b,s,16);
		check_valid(&validator);
		*h=validator.t.hid;
		*t0=validator.t.start;
		*t1=validator.t.stop;
	}
}
#ifdef PAS
DLLEXPORT void create_key(unsigned char*p)
{
	fprintf(stderr,(char*)"create key %s\n",(char*)p);
	Validate VV;
	VV.Password(VV.filename,p,true);
}
DLLEXPORT int check_key(char* filename,unsigned char*p)
{
//	fprintf(stderr,(char*)"check key %s\n",(char*)p);
	Validate VV;
	return VV.Password(filename,p);
}
int Validate::Password(const char* filename1,unsigned char*passkey,bool make)
{
	PASsecret=(char*)"PASkey here code \0aaaaaaaaaaaaaaaa";
	char*secret2=(char*)PASsecret;
	secret2+=strlen(secret2)+1;
	int extras;
	unsigned char secret[16],secret1[16];
	pas_valid ckey;
	memset(ckey.b,0,12);
	validator_t vp;
	memcpy(ckey.b,passkey,12);
	if(strlen(filename1))
		filename=filename1;
	if(make)
	{
		extras = my_open(filename,O_RDWR);
		if(extras==-1)
		{
			FILE*dd=fopen(filename,(char*)"w");
			fclose(dd);
			extras = my_open(filename,O_RDWR);
			if(extras==-1)
			{
				fprintf(stderr,(char*)"There is no file named %s\n",filename);
				return 0;
			}
		}
		make_valid(&vp,ckey.t.t1,ckey.t.t2,ckey.t.hid);
		memcpy(secret,vp.b,16);
#if defined( _WINDOWS) && !defined(MSDOSS)
		my_setmode(extras,O_BINARY);
#endif
		my_write(extras,secret,16);
		my_close(extras);
		return 2;
	}
	else
	{
		extras = my_open(filename,O_RDWR);
		bool nofile=false;
		if(extras==-1)
		{
			fprintf(stderr,(char*)"There is no file named %s or it is open due to another program\n",filename);
			nofile=true;
//			return 0;
		}
#if defined( _WINDOWS) && !defined(MSDOSS)
		my_setmode(extras,O_BINARY);
#endif
		if(nofile)
			memcpy(vp.b,secret2,16);
		else
		{
			my_read(extras,secret1,16);
			memcpy(vp.b,secret1,16);
			my_close(extras);
		}
		if(!check_valid(&vp))
		{
			if(nofile)return -1;
			else return 0;
		}
		if(vp.t.stop>=vp.t.start)
		{
			if(ckey.t.t1==vp.t.start&&ckey.t.t2==vp.t.stop&&ckey.t.hid==vp.t.hid)
				return 1;
		}
		else
		{
//		fprintf(stderr,(char*)"t1 %d %d\n",ckey.t.t1,vp.t.start);
//		fprintf(stderr,(char*)"t2 %d %d\n",ckey.t.t2,vp.t.stop);
			if(ckey.t.t1==vp.t.start&&ckey.t.t2==vp.t.stop)//&&ckey.t.hid==vp.t.hid)
				return 1;
		}
		if(nofile)return -1;
		else		return 0;
	}
}
#endif
int Validate::checklicence(int info)
{
	validator_t	v;
	char* vstr=version_string;
	long curveextra=0;
#ifdef __SYSNT64__
	time_t	i, j, k; 
#else
	long i,j,k;
#endif
	unsigned char	c;
	compkeyn compkeystuff;
	unsigned char compkeys_ok=1;

#define ALLWAYS
#if defined(__SYSNT__) && ! defined(MINGW32)
	#ifdef PAS
	licfile=(char*)"c:/embed2.dll";
		#ifdef ALLWAYS
	number_of_days_left=1;
		time_t	timenow;
		time(&timenow);
		strcpy(NOW,ctime(&timenow));
		NOW[strlen(NOW)-1] = 0;
		timenow+=60*60*24;
			strcpy(EXPIREDATE,ctime(&timenow));
			EXPIREDATE[strlen(EXPIREDATE)-1] = 0;
			EXPIREDATE[0]=-1;
	return 1;
		#endif
	#else
	licfile=(char*)"c:/safeqp2.dll";
		#ifdef ALLWAYS
	number_of_days_left=1;
		time_t	timenow;
		time(&timenow);
		strcpy(NOW,ctime(&timenow));
		NOW[strlen(NOW)-1] = 0;
		timenow+=60*60*24;
			strcpy(EXPIREDATE,ctime(&timenow));
			EXPIREDATE[strlen(EXPIREDATE)-1] = 0;
		tobinary(CURVECOMPS,1023);
	return 1;
		#endif
	#endif
#elif defined(MSDOSS)
	{
		char* home=getenv((char*)"HOME");
		if(home)
		{
			licfile=home;
			licfile+=(char*)"/.safeqp2.so";
		}
		else
			licfile=(char*)"c:/.safeqp2.so";//getenv won't get HOME in CYGWIN for some reason
	}
#elif defined(MINGW32)
	{
		char* home=getenv((char*)"HOME");
		if(home)
		{
			licfile=home;
			licfile+=(char*)"/.safeqp2.so";
		}
		else
			licfile=(char*)"c:/.safeqp2.so";
#ifdef ALLWAYS
		number_of_days_left = 1;
		time_t timenow;
		time(&timenow);
		strcpy(NOW, ctime(&timenow));
		NOW[strlen(NOW) - 1] = 0;
		timenow += 60 * 60 * 24;
		strcpy(EXPIREDATE, ctime(&timenow));
		EXPIREDATE[strlen(EXPIREDATE) - 1] = 0;
		tobinary(CURVECOMPS, 1023);
		return 1;
#endif
	}
#else
	licfile=getenv((char*)"HOME");
	licfile+=(char*)"/.safeqp2.so";
#endif


	vstr += strlen(vstr)+1;
	memcpy(compkeystuff.n,vstr+16,4);
	for(j=0;j<48;j+=16) krypton((unsigned char*)validator_m+j);
	for(k=0;k<48;k++)
	{
		memcpy(v.b,vstr,16);
		for(j=3,i=0;i<16;i++) v.b[i] ^= validator_c(i+j*16);
		while(j--)
		{
			for(c=v.b[i=15];i;i--) v.b[i] = v.b[i-1];
			v.b[i] = c;
			krypton(v.b);
			for(i=0;i<16;i++) v.b[i] ^= validator_c(i+j*16);
		}

		krypton(v.b);

		v.t.hid ^= v.t.stop;
		v.t.start ^= v.t.pad;
		v.t.pad ^= v.t.hid;
		v.t.pad -= v.t.stop-v.t.start;

		if(v.t.pad==(padbase + bitaopt))
		{
			for(i=j=0;i<16;i++) j += v.b[i];
			if(k == (j*147)%48) break;
		}
	}
	if(1)
	{
		time_t	timenow;
		unsigned int t1,t2;
		time(&timenow);
		strcpy(NOW,ctime(&timenow));
		NOW[strlen(NOW)-1] = 0;
		unsigned int	hid;
		char cc;
		unsigned char hhh[20],*hhhp;
		int extras;
		hid=0;
#if defined (_WINDOWS) && ! defined(MSDOSS)
		compkeyn ckey;
		if(RegRead(hhh,20))
		{
			if(RegRead(hhh,20,HKEY_LOCAL_MACHINE))
				*hhh='\0';
			else
			{
				hid=0;
				for(j=0;j<48;j+=16) krypton((unsigned char*)validator_m+j);
				convert(hhh,&hid,&t1,&t2);
				for(j=0;j<48;j+=16) krypton((unsigned char*)validator_m+j);
				if(timenow >= t1 && timenow <= t2)		
				{
					printf((char*)"Read valid global registry key (started %d days ago)\n",(long)((timenow-t1)/3600/24));
					if((timenow-t1) > 70*3600*24)
					{
						RegDelete(HKEY_LOCAL_MACHINE);
						printf((char*)"Clear up global registry\n");
					}
				}
				else
				{
					RegDelete(HKEY_LOCAL_MACHINE);
					printf((char*)"Clear up global registry\n");
				}
			}
		}
		for(j=0;j<48;j+=16) krypton((unsigned char*)validator_m+j);
		hid=0;
		convert(hhh,&hid,&t1,&t2);
		if(t2<v.t.stop)t2=v.t.stop;
		if(t1 <= timenow) t1=timenow;
		else t2=timenow-60*60*24;
		memcpy(ckey.n,hhh+16,4);
		hid -= ckey.key;
		if((hid - guniqid()) == 0 && t1<=timenow && timenow<=t2)
		{
			v.t.hid = hid;
			v.t.start=t1;
			v.t.stop=t2;
			curveextra=ckey.key;
			compkeystuff.key=curveextra=ckey.key;
			v.t.hid+=curveextra;
		}
		else if((hid - 0x13101955) == 0)// && t1<=timenow && timenow<=t2)
		{
#if defined( __SYSNT__) ||defined( MSDOSS)||defined(__linux__)||defined(sun)
			v.t.hid = guniqid();hid=0;
#else
			v.t.hid = hid;hid=0;
#endif
			v.t.start=t1;
			v.t.stop=t2;
			compkeystuff.key=curveextra=ckey.key;
			v.t.hid+=curveextra;
			hhhp=hhh;
		}
		else
			curveextra=compkeystuff.key;
		for(j=0;j<48;j+=16) krypton((unsigned char*)validator_m+j);
#else
		if((extras = my_open(licfile.c_str(),O_RDONLY)) != -1)
		{
			compkeyn ckey;
#if defined( _WINDOWS) && !defined(MSDOSS)
			my_setmode(extras,O_BINARY);
#endif
	for(j=0;j<48;j+=16) krypton((unsigned char*)validator_m+j);
			hhhp=hhh;i=0;
			while(my_read(extras,&cc,1))
			{
				*hhhp++=cc&0xff;i++;
				if(i == 20)
				{
					hid=0;
					convert((unsigned char*)hhh,&hid,&t1,&t2);
					if(t2<v.t.stop)t2=v.t.stop;
					if(t1 <= timenow) t1=timenow;
					else t2=timenow-60*60*24;
					memcpy(ckey.n,hhh+16,4);
					hid -= ckey.key;
					if((hid - guniqid()) == 0 && t1<=timenow && timenow<=t2)
					{
						v.t.hid = hid;
						v.t.start=t1;
						v.t.stop=t2;
						curveextra=ckey.key;
						compkeystuff.key=curveextra=ckey.key;
						v.t.hid+=curveextra;
						break;
					}
					else if((hid - 0x13101955) == 0)// && t1<=timenow && timenow<=t2)
					{
#if defined( __SYSNT__) ||defined( MSDOSS)||defined(__linux__)||defined(sun)
						v.t.hid = guniqid();hid=0;
#else
						v.t.hid = hid;hid=0;
#endif
						v.t.start=t1;
						v.t.stop=t2;
						compkeystuff.key=curveextra=ckey.key;
						v.t.hid+=curveextra;
						break;
					}
					else
						curveextra=compkeystuff.key;
					i=0;hhhp=hhh;
				}
			}
			my_close(extras);
	for(j=0;j<48;j+=16) krypton((unsigned char*)validator_m+j);
		}
#endif
	for(j=0;j<48;j+=16) krypton((unsigned char*)validator_m+j);
		modify_licence(v,compkeystuff,licfile.c_str());
		curveextra=compkeystuff.key;
	for(j=0;j<48;j+=16) krypton((unsigned char*)validator_m+j);
		if(hid)
		{
			tobinary(CURVECOMPS,curveextra);
		}
		else
		{
			hid=guniqid();
			if(hid - (long)v.t.hid + compkeystuff.key == 0)
			{
				v.t.hid -= compkeystuff.key;
				curveextra=compkeystuff.key;
				compkeys_ok=1;
			}
			else if(hid - (long)v.t.hid == 0)
			{
				curveextra=0;
				compkeys_ok=1;
			}
			else
			{
				curveextra = (long)v.t.hid - padbase;
				if(compkeystuff.key && curveextra)
#ifndef _LP64
					compkeys_ok = compkeystuff.key==(size_t)curveextra;
#else
					compkeys_ok = compkeystuff.key==(int)curveextra;
#endif
				if(compkeys_ok)
					v.t.hid=v.t.start;
				else
					v.t.hid -= compkeystuff.key;
				curveextra=compkeystuff.key;
			}
			if(!compkeys_ok)
			{
				fprintf(stderr,(char*)"%s: host invalid/unlicensed due to bad volume identifier %lx instead of %lx\n",progname,hid,v.t.hid);
				k = 48;
			}
				//Here we convert the curveextra integer to binary string
			tobinary(CURVECOMPS,curveextra);
		}
		if(timenow<v.t.start || timenow>v.t.stop)
		{
			fprintf(stderr,(char*)"%s: is outside the licensed period!\n",progname);
			k = 48;
		}
		char sbuf[27], ebuf[27];
		std::stringstream stopstring;
		i = (v.t.stop-timenow)/86400;
		time_t tin=v.t.start;
		if(v.t.start > 0 && tin>0)strcpy(sbuf,ctime(&tin));
		else sbuf[0]='\0';
		tin=v.t.stop;
		if(compkeys_ok)
		{
			strcpy(EXPIREDATE,ctime(&tin));
			strcpy(ebuf,ctime(&tin));
		}
		else
		{
			i = timenow - 86400;
#if defined (_AIX) && !defined(_LP64)
			int ii = (int)i;
			strcpy(EXPIREDATE,ctime(&ii));
#else
			time_t iii=(time_t)i;
			strcpy(EXPIREDATE,ctime(&iii));
#endif
			strcpy(ebuf,ctime(&tin));
		}
		EXPIREDATE[strlen(EXPIREDATE)-1] = 0;
		ebuf[strlen(ebuf)-1] = 0;
		//strcpy(VERSION,_VER_TOKEN(LIBVER));
		strcpy(VERSION,(char*)"Library");
		if(info) fprintf(stderr,(char*)"HID  =%lx\n",hid);
		if(info) fprintf(stderr,(char*)"START=%sSTOP =%s\nTODAY=%s\n",sbuf,ebuf,ctime(&timenow));
		if(hid == (long)v.t.hid)
		{
			//				sprintf(STOPSTRING,(char*)"Version %s, expires %s \r\n%lx only\r\n%s",VERSION,ebuf,hid,CURVECOMPS);
			stopstring<<"Version "<<VERSION<<" expires "<<ebuf<<"\r\n"<<std::hex<<hid<<std::dec<<" only\r\n"<<CURVECOMPS;
		}
		else if(!compkeys_ok)
		{
			//				sprintf(STOPSTRING,(char*)"Version %s, expires %s \r\n%lx only (not on this client)\r\n%s",VERSION,ebuf,(long)v.t.hid,CURVECOMPS);
			stopstring<<"Version "<<VERSION<<" expires "<<ebuf<<"\r\n"<<std::hex<<(long)v.t.hid<<std::dec<<" only (not on this client)\r\n"<<CURVECOMPS;
		}
		else
		{
			//				sprintf(STOPSTRING,(char*)"Version %s, expires %s \r\n%s",VERSION,ebuf,CURVECOMPS);
			stopstring<<"Version "<<VERSION<<" expires "<<ebuf<<" valid everywhere\r\n"<<"Components "<<CURVECOMPS;
		}
		stopstring<<std::ends;
		std::string keeper=stopstring.str();
		const char*keep=keeper.c_str();
		if(!STOP)
			STOP=new char[strlen(keep)+1];
		STOP=strcpy(STOP,keep);
		STOP[strlen(STOP)-1] = 0;
		if(compkeys_ok)
			number_of_days_left = i;
		else
			number_of_days_left = -1234567;
		if(k==48)number_of_days_left=-1234567;
		if(info>1) fprintf(stderr,(char*)"This TIGGA can play %s...\n",v.t.hid==v.t.start?"in all sorts of places":"here");
		if(info) fprintf(stderr,(char*)"%s: licence expires in %ld days\n", progname,i);
	}
	for(j=0;j<48;j+=16) krypton((unsigned char*)validator_m+j);
	
	//	std::cout<< "compare "<<strcmp(validator_m,vv)<<std::endl;
	return k!=48;
}
void Validate::tobinary(char *curve,long curveextra)
{
	curve+=No_of_Curve_Components;
	*curve=0;
	curve--;
	for(size_t i=0;i<No_of_Curve_Components;++i)
	{
		*curve-- = curveextra % 2 + '0';//remainder is what we store in the string
		curveextra = curveextra / 2;
	}
}
