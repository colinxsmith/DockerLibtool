#!/bin/env python
#Colin 13-1-2005
#Semi-definite optimisation interior point algorithm
from safe import OptSemiGen,vec2symm,DOT,combineS
snn=lambda x:x*(x+1)/2
def Amake(n,a,b):
    c=[0]*(snn(n+1))
    ij=0
    for i in range(n):
        for j in range(i+1):
            c[ij]=a[i]*a[j]
            ij+=1
    for i in range(n):
        c[ij]=-a[i]*b
        ij+=1
    c[-1]=b*b
    return c
n=4
b=4
cov=[0.082413214985258054, 0.0085237134681903914, 0.089070270882033536, 0.0052971882656530911, -0.010020600571815669, 0.079791663443914862, 0.016249612103159561, -0.012009661280024869, -0.0056633461502720861, 0.092481531373906162]

C=[0]*(snn(2*n+1))
for i in range(len(cov)):C[i]=cov[i]

m=3+2*n
A1=Amake(2*n,[1]*n+[0]*n,1)

A2=[0]*(snn(2*n+1)-1)+[1]

A3=Amake(2*n,[0]*n+[1]*n,b)

AA=[]
for i in range(n):
    AA.append([0]*(snn(2*n+1)))
    AA[i][snn(2*n)+i]=1
    AA[i][snn(2*n)+n+i]=-1
for i in range(n):
    AA.append([0]*(snn(2*n+1)))
    AA[n+i][snn(n+i)+n+i]=1
    AA[n+i][snn(2*n)+n+i]=-1


b=[0,1,0]+[0]*(2*n)
A=A1+A2+A3
for i in range(2*n):
    A+=AA[i]

X=[0]*(snn(2*n+1))
print OptSemiGen(2*n+1,m,X,C,A,b,100)

print X[snn(2*n+1)-2*n-1:snn(2*n+1)-1]

