#include "ldefns.h"
#include "constant.h"
/*
	This routine finds the sqrt decomposition of the symmetric
	matrix
		/	\
		| a   b	|
		| b   c |
		\	/

	The resultant triplet of numbers is stored in the 2 by 2
	matrix R
*/

void	dsmx22sqrt( real a, real b, real c, vector R )
{
	real	lambda[2];
	dimen	i;

	/*find the eigen decomposition*/
	dsmx22ev( a, b, c, lambda, R );

	for(i=0;i<2;i++){
		real s = lambda[i];
		s = (s<lm_rooteps?lm_eps : sqrt(s));
		dscalvec( 2, s, R+2*i );
		}
}
