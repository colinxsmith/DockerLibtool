public class front
{
	static void dcopyvec(int n,double [] a,double [] b,int c)
	{
		int i;
		for(i=0;i<n;++i)
		{
			b[i]=a[i+c];
		}
	}
	static void dcopyvec(int n,double [] a,double [] b)
	{
		int i;
		for(i=0;i<n;++i)
		{
			b[i]=a[i];
		}
	}
	public static void main(String args[])
	{
		int n=10; 
		int nfac=2; 
		int npoints=10;
		double[] frontarisk=new double[n*npoints];
		double[] frontareturn=new double[n*npoints];
		double[] frontrisk=new double[n*npoints];
		double[] frontrreturn=new double[n*npoints];
		String[] stocknames=new String[n]; 
		double[] w_opt=new double[npoints*n]; 
		double[] []FL=new double[n] [nfac]; 
		double[] FC=new double[nfac*(nfac+1)/2]; 
		double[] SV=new double[n]; 
		double[] mask=null;
		int m=1; 
		double[][] CONSTRAINTS=new double[m][n]; 
		double[] L=new double[n+m]; 
		double[] U=new double[n+m]; 
		double[] alpha=new double[n]; 
		double[] benchmark=new double[n]; 
		double[] Q=new double[n*(nfac+1)]; 
		double gamma=1e-4; 
		double[] initial=new double[n]; 
		double delta=2; 
		double[] buy=new double[n]; 
		double[] sell=new double[n]; 
		double kappa=.5; 
		int basket=-1; 
		int trades=-1; 
		int revise=0; 
		int costs=0; 
		double min_holding=-1;
		double min_trade=-1; 
		int m_LS=0; 
		int Fully_Invested=1; 
		double Rmin=-1; 
		double Rmax=-1; 
		int m_Round=0; 
		double[] min_lot=new double[n]; 
		double[] size_lot=new double[n]; 
		int[] shake=new int[n*npoints]; 
		int ncomp=0; 
		double[] Composite=new double[ncomp*n]; 
		double LSValue=1; 
		int npiece=0; 
		double[] hpiece=null;//new double[n*npiece]; 
		double[] pgrad=null;//new double[n*npiece]; 
		int nabs=0; 
		double[] Abs_A=null;//new double[nabs*n]; 
		int mabs=0; 
		long[] I_A=null;//new long[mabs]; 
		double[] Abs_U=null;//new double[nabs+mabs];

		int i,j,ij;
		double oo=1;
		for(i=0;i<n;++i)
		{
			oo=-oo;
			stocknames[i]="jASSET "+(i+1);
			L[i]=0;
			U[i]=1;
			SV[i]=(1.0*(i+1))/n;
			FL[i][0]=1;
			FL[i][1]=1*oo;
			for(j=0;j<m;++j)
			{
				CONSTRAINTS[j][i]=1;//Just to show the order of the constraints
			}
			alpha[i]=(1.0*(i-n/2))/n;
			benchmark[i]=1.0/n;
		}
		FC[0]=1;
		FC[1]=0.1;
		FC[2]=1.01;
		for(i=0;i<m;++i)
		{
			U[i+(int)n]=L[i+(int)n]=1;
		}

		safejava.factor_model_process(n,nfac,FL,FC,SV,Q);

		safejava.FrontierCVPF(npoints,frontrisk,frontarisk,frontrreturn,frontareturn,
		n, nfac, stocknames, w_opt, m, CONSTRAINTS, L, U, 
		alpha, benchmark, Q, initial, delta, buy, sell, kappa, basket, trades, 
		revise,costs, min_holding, min_trade, m_LS, Fully_Invested, Rmin, Rmax, m_Round, 
		min_lot, size_lot, shake, ncomp, Composite, LSValue, npiece, hpiece, pgrad,
		null,null,null,mask,1);

		for(i=0;i<n*npoints;++i)
		{
			System.out.println("w"+(i+1)+"\t"+w_opt[i]);
		}

		double [] w=new double[n];
		double [] risk=new double[1];
		double [] arisk=new double[1];
		double [] Rrisk=new double[1];
		double [] rreturn=new double[1];
		double [] areturn=new double[1];
		double [] Rreturn=new double[1];
		double [] beta=new double[n];
		double [] pbeta=new double[1];
		double [] MCAR=new double[n];
		double [] MCRR=new double[n];
		double [] MCTR=new double[n];
		double [] FMCTR=new double[n];
		double [] FMCRR=new double[n];
		double [] FX=new double[nfac];
		double [] RFX=new double[nfac];

		safejava.factor_model_process(n,nfac,FL,FC,SV,Q);

		dcopyvec(n,w_opt,w);
		safejava.PropertiesCA(n,nfac,stocknames,w,benchmark,alpha,
		rreturn,areturn,Rreturn,null,Q,risk,arisk,Rrisk,null,
			null,pbeta,MCAR,MCTR,MCRR,null,FMCRR,FMCTR,null,null,null,beta,FX,RFX,null,null,null,FL,FC,SV,ncomp,
			Composite);

		for(i=0;i<n;++i)
		{
			System.out.println("MCTR"+(i+1)+"\t"+MCTR[i]);
		}
		safejava.factor_model_process(n,nfac,FL,FC,SV,Q);
		dcopyvec(n,w_opt,w,n);
		safejava.PropertiesCA(n,nfac,stocknames,w,benchmark,alpha,
		rreturn,areturn,Rreturn,null,Q,risk,arisk,Rrisk,null,
			null,pbeta,MCAR,MCTR,MCRR,null,FMCRR,FMCTR,null,null,null,beta,FX,RFX,null,null,null,FL,FC,SV,ncomp,
			Composite);

		for(i=0;i<n;++i)
		{
			System.out.println("MCTR"+(i+1)+"\t"+MCTR[i]);
		}
		safejava.factor_model_process(n,nfac,FL,FC,SV,Q);
		dcopyvec(n,w_opt,w,2*n);
		safejava.PropertiesCA(n,nfac,stocknames,w,benchmark,alpha,
		rreturn,areturn,Rreturn,null,Q,risk,arisk,Rrisk,null,
			null,pbeta,MCAR,MCTR,MCRR,null,FMCRR,FMCTR,null,null,null,beta,FX,RFX,null,null,null,FL,FC,SV,ncomp,
			Composite);
		for(i=0;i<n;++i)
		{
			System.out.println("MCTR"+(i+1)+"\t"+MCTR[i]);
		}
	}
}