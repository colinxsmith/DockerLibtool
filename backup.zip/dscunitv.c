#include "ldefns.h"
/*
	set up a zero n vector of the with a single specified nonzero
*/

void	dscunitvec( dimen n, dimen i, real t, vector v )
{
	dzerovec( n, v );
	if(i<n) v[i] = t;
}
