#include "ldefns.h"
double dsign(double a, double b)
{
	if(a<0) a = -a;
	return (b >= 0 ? a : -a);
}
