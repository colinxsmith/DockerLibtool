public class testmem
{
	public static void main(String args[])
	{
		System.out.println(safejava.version());			
		int n = Integer.parseInt(args[1]),m=1;
		for(int j=0;j<Integer.parseInt(args[0]);++j)
		{
			System.out.println("iteration "+j);

			double Q[] = new double[n*(n+1)/2];
			double d[] = new double[n];
			double L[] = new double[n+m];
			double U[] = new double[n+m];
			double A[][] = new double[m][n];
			double Qm1d[] = new double[n];


			for(int i=0;i<n;++i)
			{
				d[i] = 4/3;
				Q[i*(i+3)/2]=4/3;
				U[i]=4/3;
				A[0][i]=4/3;
			}
			L[n]=1;
			U[n]=1;
			d[0]=1;

			for (int i=0;i<(int)(((n*n)/2)+2);i++)
			{
				safejava.wCovar((long)n,d,d,d);
			}
/*			for (int i=0;i<n;i++)
			{
				safejava.wAve((long)n,d,d);
			}
			//oc.ConstrRegress(n,m,Q,d,Qm1d,L,U,A);*/
			System.out.println(Qm1d[0]);
		}
	}
}