#include "ldefns.h"
#include "constant.h"


real sc_norm(real scale, real ssq)
{

    ssq = sqrt(ssq);
    return (scale < lm_max / ssq ? scale * ssq : lm_max);
}

