#include "baseoptimise.h"

void Base_Optimise::dtqadd(int orthog, logical *unitq, integer *inform, integer *k1, integer *k2, integer *nactiv, integer *ncolz, integer *nfree, integer *n, integer *nq, integer *nrowa, integer *nrowrt, integer *ncolrt, short_vec istate, short_vec kactiv, short_vec kfree, real *condmx, real *a, real *qtg, real *rt, real *zy, real *wrk1, real *wrk2)
{
    integer a_dim1, a_offset, rt_dim1, rt_offset, zy_dim1, zy_offset, i__1;

    integer iadd, jadd, ifix, i, k, l, iswap;
    real cslast, snlast;

/*     TQADD INCLUDES GENERAL LINEAR CONSTRAINTS  K1  THRU  K2  AS NEW */
/*     COLUMNS OF THE TQ FACTORIZATION STORED IN  RT, ZY. */
    --wrk2;
    --wrk1;
    zy_dim1 = *nq;
    zy_offset = zy_dim1 + 1;
    zy -= zy_offset;
    rt_dim1 = *nrowrt;
    rt_offset = rt_dim1 + 1;
    rt -= rt_offset;
    --qtg;
    a_dim1 = *nrowa;
    a_offset = a_dim1 + 1;
    a -= a_offset;
    --kfree;
    --kactiv;
    --istate;

    i__1 = *k2;
    for (k = *k1; k <= i__1; ++k) {
	iadd = kactiv[k];
	jadd = *n + iadd;
	if (*nactiv == *nfree) {
	    goto L20;
	}
	*inform = daddcon(0, 0, orthog, unitq, &ifix, &iadd, &jadd, 
		nactiv, ncolz, ncolz, nfree, CN(*n), nq, nrowa, nrowrt, &
		kfree[1], condmx, &cslast, &snlast, &a[a_offset], &qtg[1], &
		rt[rt_offset], &zy[zy_offset], &wrk1[1], &wrk2[1]);
	if (*inform > 0) {
	    goto L20;
	}
	++(*nactiv);
	--(*ncolz);
	goto L40;
L20:
	istate[jadd] = 0;
	kactiv[k] = -kactiv[k];
L40:
	;
    }
    if (*nactiv == *k2) {
	return;
    }
/*     SOME OF THE CONSTRAINTS WERE CLASSED AS DEPENDENT AND NOT INCLUDED 
*/
/*     IN THE FACTORIZATION.  MOVE ACCEPTED INDICES TO THE FRONT OF */
/*     KACTIV  AND SHIFT REJECTED INDICES (WITH NEGATIVE VALUES) TO */
/*     THE END. */
    l = *k1 - 1;
    i__1 = *k2;
    for (k = *k1; k <= i__1; ++k) {
	i = kactiv[k];
	if (i < 0) {
	    goto L60;
	}
	++l;
	if (l == k) {
	    goto L60;
	}
	iswap = kactiv[l];
	kactiv[l] = i;
	kactiv[k] = iswap;
L60:
	;
    }
    return;
/*     END OF TQADD (TQADD) */
} /* dtqadd */



