try:
    from java.lang import *
    import CostFunc
    System.loadLibrary("safejavajy")
    from jarray import *
    from safejavajy import *
    jython=1
except:
    from safe import *
    jython=0
for i in range(20):
    print '%d\t%s'%(i+1,Return_Message(i))
"""
extern "C" int	fix_covariancem(dimen n,vector Q);
extern "C" void InvQ_d(dimen n,vector Q,vector d,vector Qm1d);
extern "C" short ConstrRegress(dimen n,dimen m,vector Q,vector c,vector w_opt,vector L,vector U,vector A);
extern "C" int	pickout(dimen nstocks,char **stocklist,dimen M_nstocks,char** M_stocklist,vector Q);
"""
n=4
Q=[1,12,2,13,23,3,14,24,34,4]
if jython:Q=array(Q,Double)
if fix_covariancem(n,Q):print '@'*20,'Needed to be fixed','@'*20

print Q
Q=[1,pow(2,.5),2,13e-4,23e-4,3,14e-4,24e-4,34e-4,4]
print Q
if jython:Q=array(Q,Double)
if fix_covariancem(n,Q):print '@'*20,'Needed to be fixed','@'*20

print Q

m=0
A=[]    #It's OK to have no linear constraints now
L=[-1e5]*(n+m)
U=[1e5]*(n+m)
c=[1]*n
if jython:
    w=array([0]*n,Double)
    Q=map(lambda tt:tt,Q)
else:w=[]

print ConstrRegress(n,m,Q,c,w,L,U,A)#This just minimises -cw+0.5wQw
print w
if jython:w1=array([0]*n,Double)
else:w1=[]
print InvQ_d(n,Q,c,w1)
print w1

l1=['a','b','c','d']
l2=['a','b','c','d']

if jython:Q=array(Q,Double)
pickout(n,l1,n,l2,Q)
if jython:Q=map(lambda tt:tt,Q)

print Q
l2=['c','d','a','b']
if jython:Q=array(Q,Double)
pickout(n,l1,n,l2,Q)
if jython:Q=map(lambda tt:tt,Q)

print Q

