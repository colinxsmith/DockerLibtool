#include "baseoptimise.h"
/*
	findp computes the following quantities for  lpcore,  qpcore  and
		lccore ..
	(1)	the search direction  p  (and its 2-norm)
	(2)	the vector	v  such that  r(t)v = - z(t)g(free).  this vector
		is required by	lccore	only
	(3)	the vector	ap,  where  a  is the matrix of linear
		constraints. and, if  nullr  is false,
	(4)	the	 (ncolr)-th diagonal element of the cholesky factor of the
		projected hessian
*/
void Base_Optimise::dfindp(logical *nullr, logical *unitpg, logical *unitq, dimen n, integer *nclin, integer *Nq, integer *nrowa, integer *Nrowrt, integer *ncolr, integer *ncolz, integer *nfree, short_vec istate, short_vec kfree, int negligible, real *gtp, real *pnorm, real *rdlast, real *a, real *ap, real *p, real *qtg, real *rt, real *v, real *zy, real *work)
{

    integer a_dim1, a_offset, rt_dim1, rt_offset, zy_dim1, zy_offset;
    integer j;
	short idiag;

    --work;
    zy_dim1 = *Nq;
    zy_offset = zy_dim1 + 1;
    zy -= zy_offset;
    --v;
    rt_dim1 = *Nrowrt;
    rt_offset = rt_dim1 + 1;
    rt -= rt_offset;
    --qtg;
    --p;
    --ap;
    a_dim1 = *nrowa;
    a_offset = a_dim1 + 1;
    a -= a_offset;
    --kfree;
    --istate;

    dcopyvec(*ncolr, &qtg[1], &p[1]);
    dscalvec(*ncolr, CR(-1), &p[1]);
    if (*nullr) goto L60;
    *rdlast = rt[*ncolr + *ncolr * rt_dim1];
/*     *** */
/*     CORRECTION INSERTED BY MHW, 22 OCT 1985. */
/*     THIS ENSURES A NON-ZERO SEARCH DIRECTION. */
/*     *** */
    if (*ncolr < *ncolz && negligible) p[*ncolr] = *rdlast;
/* --------------------------------------------------------------------- 
*/
/*     SOLVE THE SYSTEM   R(T)R (PZ) = - Z(T)G(FREE). */
/* --------------------------------------------------------------------- 
*/
    if (*unitpg) {
	goto L20;
    }
/*     PERFORM THE FORWARD SUBSTITUTION  R(T)V = - Z(T)G(FREE). */
    idiag = dtmxsolve(CS(-1), *ncolr, &rt[rt_offset], *Nrowrt, &p[1], CS(1) );
    goto L40;
/*     THE PROJECTED GRADIENT IS A MULTIPLE OF THE UNIT VECTOR, THE */
/*     FORWARD SUBSTITUTION MAY BE AVOIDED. */
L20:
    if (negligible) p[*ncolr] = -1;
	else p[*ncolr] /= *rdlast;
/*     PERFORM THE BACKWARD SUBSTITUTION   R(PZ) = P. */
L40:
    dcopyvec(*ncolr, &p[1], &v[1]);
    idiag = dtmxsolve(CS(1), *ncolr, &rt[rt_offset], *Nrowrt, &p[1], CS(1));
/* --------------------------------------------------------------------- 
*/
/*     THE VECTOR  (PZ)  HAS BEEN COMPUTED. */
/* --------------------------------------------------------------------- 
*/
/*     COMPUTE THE DIRECTIONAL DERIVATIVE  G(T)P = (GZ)(T)(PZ). */
L60:
    *gtp = ddotvec(*ncolr, &qtg[1], &p[1]);
/* --------------------------------------------------------------------- 
*/
/*     COMPUTE  P = Z * PZ. */
/* --------------------------------------------------------------------- 
*/
/*     NACTIV  AND  KACTIV  ARE NOT USED IN  ZYPROD.  N  AND  KFREE */
/*     SERVE AS ARGUMENTS FOR  NACTIV  AND  KACTIV. */
    dzyprod(1, n, n, *ncolr, *nfree, *Nq, *unitq, &kfree[1], &kfree[1], &p[1],
	     &zy[zy_offset], &work[1]);
    *pnorm = dnrm2vec(*nfree, &work[1]);
    if(msg >= 80) lm_mdvwri((char*)"\n//FINDP//   P ... ", n, &p[1]);
/* --------------------------------------------------------------------- 
*/
/*     COMPUTE  AP. */
/* --------------------------------------------------------------------- 
*/
    if (*nclin > 0) {
	dzerovec(*nclin, &ap[1]);
	for (j = 1; j <=  (integer) n; ++j) {
	    if (istate[j] <= 0)
		BITA_daxpy(*nclin, p[j], &a[j * a_dim1 + 1], 1, &ap[1], 1);
/* L100: */
	}
	if (msg >= 80) lm_mdvwri((char*)"\n//FINDP//  AP ... ",CN(*nclin), &ap[1]);
    }
    return;
/*     END OF FINDP (FINDP) */
} /* dfindp */

#undef msg


