/*
	scale a simple vector
*/
#include "ldefns.h"


void dscalvec(dimen n, real alpha, vector x)
{
	BITA_dscal(n,alpha,x,1);
}
void sscalvec(dimen n, float alpha, float* x)//single precision
{
	BITA_sscal(n,alpha,x,1);
}
