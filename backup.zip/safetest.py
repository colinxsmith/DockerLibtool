#! /bin/env python
from safe import *

"""
extern "C" char* BasicQpOpt(dimen n,dimen m,vector A,vector lower,vector upper,vector x,vector c,
				   vector H,unsigned char lp,pHmul Hmul=0,dimen fixn=-1,dimen ncomp=0,
				   vector Composites=0,dimen nfac=-1,vector SV=0,
				   vector FL=0,dimen LS=0,dimen Full=1,dimen npiece=0,vector costdata=0,
				   pUtility Util=0,
				   pModC ModDeriv=0,void *Hinfo=0,void *Uinfo=0,void *Minfo=0);
extern "C" void	factor_model_process(dimen n,dimen nfac,vector FL,vector FC,vector SV,vector QMATRIX);
"""
cdata=[]
def scale_list(a,s=1):
    for i in range(len(a)):
        a[i]*=s
kkk=1e1
cent=.1
def cost(n,x,c):
    for i in range(n):
        if x[i] < cent:
            c[i]-=kkk*cdata[i]
        else:
            c[i]+=kkk*cdata[i]
    
def extrautil(n,x):
    s=0
    for i in range(n):
        s+=kkk*abs(x[i]-cent)*cdata[i]
    return s
def lscheck(a):
    L=0
    S=0
    for i in a:
        if i < 0:S+=i
        else:L+=i
    print 'Long %-.8e Short %-.8e' % (L,S)
def listsum(a):
    """Sum a list"""
    s=0
    for i in a:
        s+=i
    return s
def testmul(n,n1,n2,n3,H,x,y):
    """Define the Hessian times vector routine here in Python instead of the optimiser dll"""
    ij = 0
#    print n
#    print H
    for i in range(n):
        y[i] = 0
        for j in range(i+1):
            y[i] += H[ij] * x[j]
            if i != j:
                y[j] += H[ij] * x[i]
            ij+=1

"""
TEST 1
"""
n=2
m=1
A=[1]*n
L=[0]*n+[1]
U=[1]*n+[1]
x=[]
c=[.1,-.1]
H=[1,-.001,2]
lp=0

print BasicQpOpt(n,m,A,L,U,x,c,H,lp)

print x,listsum(x)

"""
TEST 2
"""

n=10
m=1
H=[.1,
   1e-5,.2,
   1e-5,1e-5,.3,
   1e-5,1e-5,1e-5,.4,
   1e-5,1e-5,1e-5,1e-5,.5,
   1e-5,1e-5,1e-5,1e-5,1e-5,.6,
   1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,.7,
   1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,.8,
   1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,.9,
   1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1]
A=[1]*n
L=[0]*n+[1]
U=[1]*n+[1]
L[5]=U[5]=.45
U[5]=.4500000001
x=[]
c=[.11,.12,.13,.14,.15,-.5,-.4,-.3,-.2,-.1]
lp = 0
print BasicQpOpt(n,m,A,L,U,x,c,H,lp,testmul,4)

print x,listsum(x)

"""
TEST 3
"""

n=10
m=1
H=[.1,
   1e-5,.2,
   1e-5,1e-5,.3,
   1e-5,1e-5,1e-5,.4,
   1e-5,1e-5,1e-5,1e-5,.5,
   1e-5,1e-5,1e-5,1e-5,1e-5,.6,
   1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,.7,
   1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,.8,
   1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,.9,
   1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1]
A=[1]*n
L=[0]*n+[1]
U=[1]*n+[1]
L[5]=U[5]=.45
#U[5]=.45001
x=[]
c=[.11,.12,.13,.14,.15,-.5,-.4,-.3,-.2,-.1]
lp = 0
print BasicQpOpt(n,m,A,L,U,x,c,H,lp,testmul,4)

print x,listsum(x)

"""
TEST 4
"""
n=12
ncomp=2
Composites=[1]*(n-ncomp)+[1,-1]*((n-ncomp)/2)
m=1
H=[.1,
   1e-5,.2,
   1e-5,1e-5,.3,
   1e-5,1e-5,1e-5,.4,
   1e-5,1e-5,1e-5,1e-5,.5,
   1e-5,1e-5,1e-5,1e-5,1e-5,.6,
   1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,.7,
   1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,.8,
   1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,.9,
   1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1]
A=[1]*n
#L=[0.001,0.002,0.003,0.004,0.005,0.006,0.007,0.008,0.009,0.01,0.011,0.012]+[1]
L=[0]*n+[1]
U=[1]*n+[1]
L[5]=U[5]=.45
#U[5]=.45001
x=[]
c=[.11,.12,.13,.14,.15,-.5,-.4,-.3,-.2,-.1,.1,.2]
print BasicQpOpt(n,m,A,L,U,x,c,H,lp,testmul,2,ncomp,Composites)

print x,listsum(x)

"""
TEST 5
"""
n=12
ncomp=2
Composites=[1]*(n-ncomp)+[1,-1]*((n-ncomp)/2)
m=1
H=[.1,
   1e-5,.2,
   1e-5,1e-5,.3,
   1e-5,1e-5,1e-5,.4,
   1e-5,1e-5,1e-5,1e-5,.5,
   1e-5,1e-5,1e-5,1e-5,1e-5,.6,
   1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,.7,
   1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,.8,
   1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,.9,
   1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1e-5,1]
A=[1]*n
#L=[0.001,0.002,0.003,0.004,0.005,0.006,0.007,0.008,0.009,0.01,0.011,0.012]+[1]
L=[0]*n+[1]
U=[1]*n+[1]
L[5]=U[5]=.45
U[5]=.450000001
x=[]
c=[.11,.12,.13,.14,.15,-.5,-.4,-.3,-.2,-.1,.1,.2]
print BasicQpOpt(n,m,A,L,U,x,c,H,lp,testmul,2,ncomp,Composites)

print x,listsum(x)

"""
TEST 6
"""

n = 6
nfac = 2
m = 1
FC=H = [1,-.01,1.3]
FL = [1,1,1,1,1,1,1,-1,1,-1,1,-1]
SV = [.1,.2,.3,.4,.5,.06]

Q=[]
factor_model_process(n,nfac,FL,FC,SV,Q)
print Q
"""
TEST 7
"""
A=[1]*n
L=[0]*n+[1]
U=[1]*n+[1]
L[2]=U[2]=.1
x=[]
c=[.1,.2,.3,.4,.5,.6,-.6,-.5,-.4,-.3,-.2,-.1]
scale_list(c,.01)
ncomp=0
Composites=None

print BasicQpOpt(n,m,A,L,U,x,c,H,lp,None,2,ncomp,Composites,nfac,SV,FL)

print x,listsum(x)

"""
TEST 8
"""
n = 6
nfac = 2
m = 1
FC=H = [1,-.01,1.3]
FL = [1,1,1,1,1,1,1,-1,1,-1,1,-1]
SV = [.1,.2,.3,.4,.5,.06]
A=[1]*n
L=[-1]*n+[0]
U=[1]*n+[0]
L[2]=U[2]=.1
x=[]
c=[.1,.2,.3,.4,.5,.6,-.6,-.5,-.4,-.3,-.2,-.1]
scale_list(c,.01)
ncomp=0
Composites=None
LS=1
Full=1
print BasicQpOpt(n,m,A,L,U,x,c,H,lp,None,-1,ncomp,Composites,nfac,SV,FL,LS,Full)

print x,listsum(x)
lscheck(x)
"""
TEST 8
"""
L[2]=.1
U[2]=.1000001
print BasicQpOpt(n,m,A,L,U,x,c,H,lp,None,-1,ncomp,Composites,nfac,SV,FL,LS,Full)

print x,listsum(x)
lscheck(x)
"""
TEST 9
"""
print BasicQpOpt(n,m,A,L,U,x,c,H,lp,None,2,ncomp,Composites,nfac,SV,FL,LS,Full)

print x,listsum(x)
lscheck(x)
"""
TEST 10
"""
L=[-1]*n+[0]
U=[1]*n+[0]
npiece=1
cdata=[1]*n
print BasicQpOpt(n,m,A,L,U,x,c,H,lp,None,-1,ncomp,Composites,nfac,SV,FL,LS,Full,npiece,cdata,extrautil,cost)

print x,listsum(x)
lscheck(x)
"""
TEST 11
"""

n = 6
nfac = 2
m = 1
FC=H = [1,-.01,1.3]
FL = [1,1,1,1,1,1,1,-1,1,-1,1,-1]
SV = [.1,.2,.3,.4,.5,.06]
A=[1]*n
L=[0]*n+[1]
U=[1]*n+[1]
L[2]=U[2]=.1
x=[]
c=map(lambda x: x*.1,range(1,7))
scale_list(c,.01)
ncomp=0
Composites=None
LS=0
print BasicQpOpt(n,m,A,L,U,x,c,H,lp,None,-1,ncomp,Composites,nfac,SV,FL,LS,Full,npiece,cdata,extrautil,cost)

print x,listsum(x)
lscheck(x)

