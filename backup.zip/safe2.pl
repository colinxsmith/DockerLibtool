use safepl;

$A = new safepl::FOptimise();

$n=10;
$A->{n}=$n;#Doesn't work due to SWIG I think
$A->{m}=1;
$A->{nfac}=2;
@buy=();
@sell=();
@alpha=();
@bench=();
@initial=();
@L=();
@U=();
@SV=();
@FC=(1e-3,1e-5,2e-3);
@FL=(1,1,1,1,1,1,1,1,1,1,1,-1,1,-1,1,-1,1,-1,1,-1);
@AA=(1,1,1,1,1,1,1,1,1,1);
@stocks=();
for($i=0;$i<$n;++$i)
{
	$buy[$i]=2e-3;
	$sell[$i]=2e-3;
	$alpha[$i]=(1.0*$i-$n/2)/$n;
	$initial[$i]=$bench[$i]=1.0/$n;
	$L[$i]=0;
	$U[$i]=1;
	$SV[$i]=(1.0+$i)*1e-4;
	$stocks="stock".$i;
}
$L[$n]=1;
$U[$n]=1;
$A->{alpha}=\@alpha;
$A->{benchmark}=\@bench;
$A->{initial}=\@initial;
$A->{L}=\@L;
$A->{U}=\@U;
$A->{SV}=\@SV;
$A->{FL}=\@FL;
$A->{FC}=\@FC;
$A->{A}=\@AA;
sub costfunc
{
	my($n,$w)=@_;
    $s=0;
    for($i=0;$i<$n;++$i)
	{
        if ($$w[$i] < $initial[$i])
		{
			$s-=($$w[i]-$initial[$i])*$sell[$i];
		}
		else
		{
			$s+=($w[i]-$initial[$i])*$buy[$i];
		}
	}
    return $s;
}

sub costgrad
{
	my($n,$w,$grad)=@_;
    for ($i=0;$i<$n;++$i)
	{
        if ($$w[$i] < $initial[$i])
		{
			$$grad[$i]=-$sell[$i];
		}
        else
		{
			$$grad[$i]=$buy[$i];
		}
	}
}


$A->{revise}=1;
$A->{gamma}=.1;
$A->{kappa}=.8427;
$A->{piece_cost}=\&costfunc;
$A->{piece_grad}=\&costgrad;

$A->run;




