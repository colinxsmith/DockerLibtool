#include "ldefns.h"
static	void	fevec( real a, real b, vector v )
{
	real	s;

	if(fabs(a)>fabs(b)){
		v[1] = 1.0;
		v[0] = s = -b/a;
		}
	else	{
		v[0] = 1.0;
		v[1] = s = -a/b;
		}
	/*normalise the e-vector*/
	dscalvec( 2, 1/sqrt(CD(1+s*s)), v );
}

/*
	This routine finds the eigen-vector decomposition of the symmetric
	matrix
		/	\
		| a   b	|
		| b   c |
		\	/
*/
void	dsmx22ev( real a, real b, real c, vector lambda, matrix V )
{
	/*first find the eigenvalues*/
	dqeqnsol( 1.0, -(a+c), a*c-b*b, lambda, lambda+1 );

	/*find the eigenvectors*/
	if(b!=0.0){
		fevec( a-lambda[0], b,  V );
		fevec( b, c-lambda[1],  V+2 );
		}
	else	{
		V[0]=V[3]=1.0;
		V[1]=V[2]=0.0;
		}
}
