from safe import *
def dot(a,b,s=0):
    """Scalar product of a and b (with shift s on b)."""
    back=0
    n=len(a)
    for i in range(n):back+=a[i]*b[i+s]
    return back
def epsget():
    """Return machine accuracy."""
    a=1.3333333333333333333333333333333333333
    b=a-1.
    return 1-(b+b+b)
def listprnt(a):
    """Print out a list nicely"""
    n=len(a)
    #if n>5:m=n/5
    #else:m=n
    k=0
    while k<n:
        s=''
        for i in range(5):
            if k>=n:break
            s+='%15.8f '%a[k]
            k+=1
        print s
eps=pow(epsget(),.5)    #Convergence number for SOCP


"""
Problem 1:
find x to minimise c.x such that sum(x*x)<=1 where
c=[.1,.2,.3,.4,.5]

Here we have 1 cone constraint that sum(x*x)<1. The number of optimisation
variables for the primal problem is 6; 5 for the variables above plus one for their sum
of squares.

The primal SOCP problem is
min [.1,.2,.3,.4,.5,0].x    (c.x)
such that
[0,0,0,0,0,1].x=1           (A.x=b)

The dual SOCP problem is
max [1].y                   (b.y)
such that
0        .1
0        .2
0.y + s= .3                 (A'.y+s=c)
0        .4
0        .5
1        0

and we also must solve the complementarity relation
x.s=0

SOCP will find the vectors x,s and y and the optimimum result
will satisfy
c.x = b.y


The result is
x
    -0.13483997     -0.26967994     -0.40451992     -0.53935989     -0.67419986
     1.00000000
min c.x is          -0.74161985
x.x is               1.00000000
|4*x0**2+x1**2|      0.38138504
dual variables y
    -0.74161985
complementary variables s
     0.10000000      0.20000000      0.30000000      0.40000000      0.50000000
     0.74161985

Our answer is
x=[-0.13483997,     -0.26967994,     -0.40451992,     -0.53935989,     -0.67419986]

We monitor the value of |4*x0**2+x1**2|, and try to constrain it to be lower
in problem 2
"""

n=1     #one cone with..
nd=[6]  #..6 variables
m=1     #one constraint
c=[.1,.2,.3,.4,.5,0]
A=[0]*5+[1]
b=[1]
x=[0]*(sum(nd))
y=[0]*m
s=[0]*(sum(nd))
tau=[0]
kappa=[0]



if SOCPinfeasHomogt(n,m,nd,c,A,b,x,y,s,tau,kappa,100,1e-8,.5,eps,eps):print 'SOCP failed '*4
else:
    if tau[0]<kappa[0]:
        print 'INFEASIBLE '*5
        if dot(b,y)>0:print 'c dot y %20.12e primal is infeasible'%(dot(b,w))
        if dot(c,x)<0:print 'b dot x is %20.12e dual is infeasible'%(dot(c,x))
    else:
        print 'Worked'
        s=[i/tau[0] for i in s]
        y=[i/tau[0] for i in y]
        x=[i/tau[0] for i in x]
        print 'x'
        listprnt(x)
        print 'min c.x is\t%15.8f'%dot(x[:5],c)
        print 'x.x is\t\t%15.8f'%dot(x[:5],x[:5])
        print '|4*x0**2+x1**2|\t%15.8f'%pow(4*x[0]*x[0]+x[1]*x[1],.5)
        print 'dual variables y'
        listprnt(y)
        print 'complementary variables s'
        listprnt(s)
"""
Problem 2:
find x to minimise c.x such that
sum(x*x)<=1
and 4*x[0]**2+x[1]**2<=.01

Here we have 2 quadratic conditions so we need 2 cones.
The second cone constraint is written
|4*x[7]*x[7]+x[8]*x[8]|<=.1
We also need 2 constraints to link the two variables in
the second cone with the first two variables in the
first cone; we end up with 4 constraints and 9 optimisation
variables for the primal.
The linking constraints are
x[0]=0.5*x[7]
x[1]=x[8]

This shows how quickly the size of the problem increases.
In problem 1 there are 5 numbers we want to find, and we
have to set set up a primal with 6 varaibles and a dual with
1. The number of linear equations we solve at each iteration is
7. In problem 2 we still only want 5 numbers, but we set up a primal
with 9 variables and a dual with 4, so we need to decompose
a 13 by 13 square symmetric matrix at each iteration.


The result is
x
    -0.01586076     -0.09483535     -0.42229829     -0.56306438     -0.70383048
     1.00000000     -0.03172153     -0.09483535      0.10000000
min c.x is          -0.72438363
x.x is               1.00000000
|4*x0**2+x1**2|      0.10000000
dual variables y
    -0.71039842     -0.13985211      0.08873167      0.13262838
complementary variables s
     0.01126833      0.06737162      0.30000000      0.40000000      0.50000000
     0.71039842      0.04436584      0.13262838      0.13985211

Our answer is
x=[-0.01586076,     -0.09483535,     -0.42229829,     -0.56306438,     -0.70383048]
"""

n=2             #2 cones
nd=[6,3]        #6 variables in first cone 3 variables
m=4             #4 constraints
c=[.1,.2,.3,.4,.5,0,0,0,0]
A=[0]*5+[1]+[0]*3
A+=[0]*6+[0]*2+[1]
A+=[2,0,0,0,0,0,-1,0,0]
A+=[0,1,0,0,0,0,0,-1,0]
b=[1,.1,0,0]
x=[0]*(sum(nd))
y=[0]*m
s=[0]*(sum(nd))
tau=[0]
kappa=[0]



if SOCPinfeasHomogt(n,m,nd,c,A,b,x,y,s,tau,kappa,100,1e-8,.5,eps,eps):print 'SOCP failed '*4
else:
    if tau[0]<kappa[0]:
        print 'INFEASIBLE '*5
        if dot(b,y)>0:print 'c dot y %20.12e primal is infeasible'%(dot(b,w))
        if dot(c,x)<0:print 'b dot x is %20.12e dual is infeasible'%(dot(c,x))
    else:
        print 'Worked'
        s=[i/tau[0] for i in s]
        y=[i/tau[0] for i in y]
        x=[i/tau[0] for i in x]
        print 'x'
        listprnt(x)
        print 'min c.x is\t%15.8f'%dot(x[:5],c)
        print 'x.x is\t\t%15.8f'%dot(x[:5],x[:5])
        print '|4*x0**2+x1**2|\t%15.8f'%pow(4*x[0]*x[0]+x[1]*x[1],.5)
        print 'dual variables y'
        listprnt(y)
        print 'complementary variables s'
        listprnt(s)

"""
Problem 3
find x to minimise c.x such that
sum(x*x)<=1
sum(x)=1

The result is
x
     0.76568542      0.48284271      0.20000000     -0.08284271     -0.36568543
     1.00000000
min c.x is           0.01715729
x.x is               1.00000000
sum(x)       1.00000000
dual variables y
    -0.35355305      0.37071034
complementary variables s
    -0.27071034     -0.17071034     -0.07071034      0.02928966      0.12928966
     0.35355306

Our answer is
x=[0.76568542,      0.48284271,      0.20000000,     -0.08284271,     -0.36568543]
"""
n=1         #one cone
nd=[6]      #number of variables in each cone
m=2         #number of constraints
c=[.1,.2,.3,.4,.5,0]
A=[0]*5+[1]
A+=[1]*5+[0]
b=[1,1]

x=[0]*(sum(nd))
y=[0]*m
s=[0]*(sum(nd))
tau=[0]
kappa=[0]



if SOCPinfeasHomogt(n,m,nd,c,A,b,x,y,s,tau,kappa,100,1e-8,.5,eps,eps):print 'SOCP failed '*4
else:
    if tau[0]<kappa[0]:
        print 'INFEASIBLE '*5
        if dot(b,y)>0:print 'c dot y %20.12e primal is infeasible'%(dot(b,w))
        if dot(c,x)<0:print 'b dot x is %20.12e dual is infeasible'%(dot(c,x))
    else:
        print 'Worked'
        s=[i/tau[0] for i in s]
        y=[i/tau[0] for i in y]
        x=[i/tau[0] for i in x]
        print 'x'
        listprnt(x)
        print 'min c.x is\t%15.8f'%dot(x[:5],c)
        print 'x.x is\t\t%15.8f'%dot(x[:5],x[:5])
        print 'sum(x)\t%15.8f'%sum(x[:5])
        print 'dual variables y'
        listprnt(y)
        print 'complementary variables s'
        listprnt(s)
"""
Problem 4
find x to minimise c.x such that
sum(x*x)<=1
0.5<=sum(x)<=1

The second constraint is written
|sum(x) - .75|<=0.25
The result is
x
     0.71644140      0.40822070      0.10000000     -0.20822070     -0.51644140
     1.00000000     -0.24999999      0.25000000
min c.x is          -0.15822070
x.x is               1.00000000
sum(x)       0.50000000
dual variables y
    -0.32444233     -0.33244325      0.33244325
complementary variables s
    -0.23244325     -0.13244325     -0.03244325      0.06755675      0.16755675
     0.32444233      0.33244325      0.33244325
     
Our result is
x=[0.71644140,      0.40822070,      0.10000000,     -0.20822070,    -0.51644140]
"""
n=2         #number of cones
nd=[6,2]    #number of variables in each cone
m=3         #number of constraints
c=[.1,.2,.3,.4,.5,0,0,0]
A=[0]*5+[1]+[0]*2   #size constraint for first cone
A+=[0]*5+[0]+[0,1]  #size constraint for second cone
A+=[1]*5+[0]+[-1,0] #linking constraint for the cones
b=[1,0.25,0.75]

x=[0]*(sum(nd))
y=[0]*m
s=[0]*(sum(nd))
tau=[0]
kappa=[0]



if SOCPinfeasHomogt(n,m,nd,c,A,b,x,y,s,tau,kappa,100,1e-8,.5,eps,eps):print 'SOCP failed '*4
else:
    if tau[0]<kappa[0]:
        print 'INFEASIBLE '*5
        if dot(b,y)>0:print 'c dot y %20.12e primal is infeasible'%(dot(b,w))
        if dot(c,x)<0:print 'b dot x is %20.12e dual is infeasible'%(dot(c,x))
    else:
        print 'Worked'
        s=[i/tau[0] for i in s]
        y=[i/tau[0] for i in y]
        x=[i/tau[0] for i in x]
        print 'x'
        listprnt(x)
        print 'min c.x is\t%15.8f'%dot(x[:5],c)
        print 'x.x is\t\t%15.8f'%dot(x[:5],x[:5])
        print 'sum(x)\t%15.8f'%sum(x[:5])
        print 'dual variables y'
        listprnt(y)
        print 'complementary variables s'
        listprnt(s)
