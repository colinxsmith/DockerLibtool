
using System;
using System.Reflection;

public class runme
{
	public static void Main(String[] args)
	{
		Console.WriteLine( "Version = " + safecsharp.version() );
	}
}




