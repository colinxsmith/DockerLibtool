#!/usr/bin/env python

from Opt import *
"""
extern "C" int SOCPopt(size_t n,size_t m,size_t *md,vector c,vector A,vector b,vector w,
double delt=1e-2,double nu=1.1,size_t maxiter=1000,double RR=2,gapconv=1e-8);
"""
norm=lambda x:pow(dot(x,x),.5)
sqr=lambda x:x*x
conv=epsget()
n=10
m=1+n
md=[1]*(n+1)
c=[-(i+1) for i in range(n)]
A=[-1]*n
for i in range(n):#to get positive w[i]
    s=[0]*n
    s[i]=1
    A+=s
b=[1]+[0]*n
w=[]

print SOCPopt(n,m,md,c,A,b,w,1e-2,10,1000,10,0)

print w,sum(w)
print c
