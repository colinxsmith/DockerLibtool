/*
	DAXPY performs the operation
	y := alpha*x + y for general vectors x and y
*/
#include "ldefns.h"

void BITA_daxpy(dimen n, real alpha, vector x, stride incx, vector y, stride incy)
{
	if(alpha == 1)
		while(n--)
		{
			*y += *x;
			y += incy;
			x += incx;
		}
	else if(alpha == -1)
		while(n--)
		{
			*y -= *x;
			y += incy;
			x += incx;
		}
	else if(alpha != 0)
		while(n--)
		{
			*y += *x*alpha;
			y += incy;
			x += incx;
		}
}

void BITA_saxpy(dimen n, float alpha, float* x, stride incx, float* y, stride incy)//single precision
{
	if(alpha == 1)
		while(n--)
		{
			*y += *x;
			y += incy;
			x += incx;
		}
	else if(alpha == -1)
		while(n--)
		{
			*y -= *x;
			y += incy;
			x += incx;
		}
	else if(alpha != 0)
		while(n--)
		{
			*y += *x*alpha;
			y += incy;
			x += incx;
		}
}

