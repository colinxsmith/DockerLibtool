/*
	write an item
*/
#include "ldefns.h"
ushort	__lm_item_write_count=0;
void lm_item_write(ushort maxnum, const char *fmt, ...)
{
	VA_START(fmt);
	if(__lm_item_write_count==maxnum){
		lm_putc('\n');
		__lm_item_write_count=1;
		}
	else	if(__lm_item_write_count++) lm_putc(' ');
	_lm_printf(fmt, IVA_LIST(fmt) );
}
