#!/bin/env python
#Colin 12-1-2006 We've decided what the data for robust optimisation looks like!

from Opt import *
def var(x,Q):
    n=len(x)
    y=[]
    Sym_mult(n,Q,x,y)
    return dot(x,y)
def risk(x,Q):
    """risk is sqrt(x'.Q.x); x is a list of length, Q is of length n*(n+1)/2"""
    return pow(var(x,Q),.5)
def meanerror(x,Q):
    """meanerror is sqrt(sum (xiQi)**2); x is a list of length, Q is of length n"""
    return pow(sum([x[i]*x[i]*Q[i]*Q[i] for i in range(len(x))]),.5)
def BITAutil(gamma,w,bench,alpha,Q):
    gamma/=(1-gamma)
    ret=-gamma*dot(w,alpha)
    return ret+0.5*var([w[i]-bench[i] for i in range(len(w))],Q)

#Usual BITA Plus parameters
n=1000
nf=1                           #use FC as covariance matrix if nf is negative
m=1
w=[]
A=[1]*n
SV=[float(i+1)/n for i in range(n)]
FL=[1]*n
FC=[1]
Q=[0]*(n*(n+1)/2)
Factor2Cov(n,nf,FC,FL,SV,Q)
alpha=[i for i in SV]
alpha.reverse()
gamma=0.1
L=[0]*n+[1]
U=[1]*n+[1]
initial=[float(i)/sum(SV) for i in SV]
benchmark=[1.0/n]*n


#New Robust parameters
meanFE=[SV[i] for i in range(n/2)]+[alpha[i] for i in range(n/2)]         #means of forecast errors
covFE=[0]*(n*(n+1)/2)                          #covariance matrix of forecast 2nd moments
Factor2Cov(n,nf,FC,initial,meanFE,covFE)
maxmeanFE=0.009              #max allowed mean of forecast error
maxstderrorFE=0.02             #max allowed standard deviation od forecast error
maxRisk=-0.0108742702402                   #max allowed relative risk


"""
If maxRisk is set negative, the optimisation minimises the usual BITA Plus
utility function, subject to the variable bound constraints, linear
constraints and the 2 new robust constraints.

If max risk is non-negative, the optimisation maximises return suject to
the variable bound constraints, linear constraints, the (relative) risk
constaint and the 2 new robust constraints.
"""

mFE=1
rFE=0


print SOCPlstestMessage(SOCPRobust(n,m,w,A,L,U,nf,SV,FL,FC,alpha,meanFE,covFE,
                                   maxmeanFE,maxstderrorFE,gamma,maxRisk,benchmark,initial,mFE,rFE))
print 'Sum of weights',sum(w)
print 'return',dot(alpha,w)
print 'risk',risk([w[i]-benchmark[i] for i in range(n)],Q)
print 'forcast mean error',meanerror([w[i]-mFE*initial[i] for i in range(n)],meanFE)
print 'forcast error',risk([w[i]-rFE*initial[i] for i in range(n)],covFE)
print 'BITA utility',BITAutil(gamma,w,benchmark,alpha,Q)

"""
With gamma=0.1 and maxmeanFE=.009 and maxstderrorFE=.02
Sum of weights 0.999999999993
return 0.602161720319
risk 0.0108742702402
forcast mean error 0.00900000000585
forcast error 0.0200000000044
BITA utility -0.0668477329366

With maxRisk=0.0108742702402 and maxmeanFE=.009 and maxstderrorFE=.02

Sum of weights 0.999999999999
return 0.602161724155
risk 0.010874270236
forcast mean error 0.00900000000238
forcast error 0.0200000000019
BITA utility -0.0668477333629

We can't expect more than 7 figures accuracy!
"""
