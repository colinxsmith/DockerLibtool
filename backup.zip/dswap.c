/*
	dswap		interchange two general real vectors

	argument	meaning
	n		dimen length of vectors
	a		real vector
	i		increment for vector a
	b		real vector
	j		increment for vector b

	R. G. Becker March 1992
*/
#include "ldefns.h"

void dswap(register dimen n, vector a, increment i, vector b, increment j)
{
	for(;n--; a += i, b += j){
		register real temp = *a;
		*a = *b;
		*b = temp;
		}
}
void sswap(register dimen n, float* a, increment i, float* b, increment j)//single precision
{
	for(;n--; a += i, b += j){
		register float temp = *a;
		*a = *b;
		*b = temp;
		}
}
