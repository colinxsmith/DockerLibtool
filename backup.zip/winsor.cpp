#ifdef __SYSNT__
#ifndef MINGW32 
#include <crtdbg.h>
#else
#define _ASSERT
#endif
#endif
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <valarray>
#include "ldefns.h"
#include "constant.h"

inline double helpfulsqrt(double x)
{
	if(x<=lm_eps) return 0;
	else return sqrt(x);
}
inline double smalltest(double x)
{
	return (fabs(x)<=lm_eps?0:x);
}
typedef int (*cmpfunc)(const void *arg1, const void *arg2);
int compare(const double *arg1, const double *arg2);

extern "C"
{
DLLEXPORT void winsorise(unsigned long noOfPts, double *values, int winsorOption, double scaling, 
			   double *returnArray);
DLLEXPORT double percentile(unsigned long noOfPts, double *values, int num);
DLLEXPORT double average(unsigned long s, double *x);
DLLEXPORT double stddev(unsigned long s, double *x);
DLLEXPORT double covariance1(double *x, double *y, double *w, unsigned long s);
DLLEXPORT void mAve(unsigned long noOfPts, double *values, unsigned long window, unsigned long ignoreMissing, double *returnArray);
DLLEXPORT void mSum(unsigned long noOfPts, double *values, unsigned long window, unsigned long ignoreMissing, double *returnArray);
DLLEXPORT void mProd(unsigned long noOfPts, double *values, unsigned long window, unsigned long ignoreMissing, double *returnArray);
DLLEXPORT void mCovar(unsigned long noOfPts, double *values1, double *values2, unsigned long window, unsigned long ignoreMissing, double *returnArray);
DLLEXPORT void mCorrel(unsigned long noOfPts, double *values1, double *values2, unsigned long window, unsigned long ignoreMissing, double *returnArray);
DLLEXPORT void mVar(unsigned long noOfPts, double *values, unsigned long window, unsigned long ignoreMissing, double *returnArray);
DLLEXPORT void mStddev(unsigned long noOfPts, double *values, unsigned long window, unsigned long ignoreMissing, double *returnArray);
DLLEXPORT void cAve(unsigned long noOfPts, double *values, unsigned long ignoreMissing, double *returnArray);
DLLEXPORT void cSum(unsigned long noOfPts, double *values, unsigned long ignoreMissing, double *returnArray);
DLLEXPORT void cProd(unsigned long noOfPts, double *values, unsigned long ignoreMissing, double *returnArray);
DLLEXPORT void cCovar(unsigned long noOfPts, double *values1, double *values2, unsigned long ignoreMissing, double *returnArray);
DLLEXPORT void cCorrel(unsigned long noOfPts, double *values1, double *values2, unsigned long ignoreMissing, double *returnArray);
DLLEXPORT void cVar(unsigned long noOfPts, double *values, unsigned long ignoreMissing, double *returnArray);
DLLEXPORT void cStddev(unsigned long noOfPts, double *values, unsigned long ignoreMissing, double *returnArray);
DLLEXPORT void prodArrays(unsigned long noOfPts, double *values1, double *values2, double *returnArray);
DLLEXPORT double wAve(unsigned long noOfPts, double *values, double *weights);
DLLEXPORT double wAveProd(unsigned long noOfPts, double *values1, double *values2, double *weights);
DLLEXPORT double wCovar(unsigned long noOfPts, double *values1, double *values2, double *weights);
}
void winsorise(unsigned long noOfPts, double *values, int winsorOption, double scaling, 
			   double *returnArray)
{
    unsigned long i = 0;
    unsigned long j = 0;
    double middle, spread, boundaryValue;
    double *temp = new double[noOfPts];

    if (noOfPts <= 50)
        boundaryValue = 2.3;
    else if (noOfPts <= 100)
        boundaryValue = 2.8;    
    else if (noOfPts <= 200)
        boundaryValue = 3.15;        
    else if (noOfPts <= 500)
        boundaryValue = 3.3;        
    else if (noOfPts <= 1000)
        boundaryValue = 3.5;        
    else if (noOfPts <= 2000)
        boundaryValue = 3.7;        
    else
        boundaryValue = 3.9;

    if(winsorOption==4)
    {
        middle=percentile(noOfPts,values,50);
        spread=fabs(percentile(noOfPts,values,83)-percentile(noOfPts,values,17));
    }
    else
    {
        middle=average(noOfPts,values);
        spread=stddev(noOfPts,values);
        if (winsorOption == 2 || winsorOption == 3)
        {
			dcopyvec(noOfPts,values,temp);
            for(j=0;j<3;j++)
            {
                middle=average(noOfPts,temp);            
                spread=stddev(noOfPts,temp);
				double*tt=temp;
                for(i=0;i<noOfPts;i++,tt++)
                {
                    if(fabs(*tt-middle) > spread*boundaryValue)
                    {
                        *tt = 1e30;
                    }                                  
                }            
                middle=average(noOfPts,temp);            
                spread=stddev(noOfPts,temp);
            }
        }
    }         
	double*ra=returnArray;
	double*va=values;
    for(i=0;i<noOfPts;i++,ra++,va++)
    {
        *ra=(*va-middle)/spread;
        if (winsorOption == 3)
        {
            if (*ra> 2* boundaryValue)
            {
                *ra = boundaryValue;
            }
            else if (*ra< -2* boundaryValue)
            {
                *ra = -boundaryValue;            
            }
        }
        if (*ra>boundaryValue)
        {
            *ra = boundaryValue + scaling * (*ra-boundaryValue);        
        }        
        else if (*(returnArray+i)<-boundaryValue)
        {
            *ra = -boundaryValue + scaling * (*ra+boundaryValue);        
        }
    }
    delete[]temp;
}

int compare(const double *arg1, const double *arg2)
{
    return (*arg1>*arg2?1:-1);
}

double percentile(unsigned long noOfPts, double *values, int num)
{
    unsigned long eltNum1,eltNum2;
    double x,y,z,returnValue;
    double *temp = new double[noOfPts];
	dcopyvec(noOfPts,values,temp);
    qsort(temp,noOfPts,sizeof(*temp),(cmpfunc)compare);
    x=(double) (num)/100.0;
    y=(double) (noOfPts-1)*x;
    z=y-floor(y);
    eltNum1=(int)floor(y); 
    eltNum2=(eltNum1<noOfPts?eltNum1+1:noOfPts);
    returnValue=*(temp+eltNum1)*(1.0-z)+*(temp+eltNum2)*z;
    delete[]temp;    
    return returnValue;               
}

double stddev(unsigned long s, double *x)
{
    unsigned long i=0;
    unsigned long notMissing=0;
    double store=0;
    double ave=0;
    double var=0;
    double j=0;
	double*px=x;
    for(i=0;i<s;i++,px++)
    {
        if (*px < 1e25 )
        {
            store+=*px;
            notMissing++;
        }
    }
    ave = (double) store/notMissing;
    store=0;
	px=x;
    for(i=0;i<s;i++,px++)
    {
        if (*px<1e25)
        {
            store+=(*px-ave)*(*px-ave);
        }
    }
    var = (double) store/(notMissing-1);
    j=helpfulsqrt(var);
    return j; 
}

double average(unsigned long s, double *x)
{    
    unsigned long n=0;
    double sum=0;
    while (s--)
    {
        if (*x<1e25)
        {
            sum += *x;
            n++;
        }
		x++;
    }
	if(n)return (double) sum/n;
	else return 1e60;
}

void listProduct(double *x, double *y, unsigned long s, double *z)
{
    while(s--)
    {    
        if (*x<1e25 && *y<1e25)
            *z=*x * *y;
        else
            *z=1e30;   
		x++;
		y++;
		z++;
    }    
}

double product(double *x, unsigned long s)
{
    double store=1;
    while(s--)
	{
        if (*x<1e25)
            store *= *x;
		x++;
	}
    return store;
}

double average1(double *x, double *w, unsigned long s)
{    
    double wSum=0.0;
    double sum=0;
    while(s--)
    {
        if (*x<1e25)
        {
            sum += *x * *w;
            wSum += *w;
        }
		x++;
		w++;
    }   
	if(fabs(wSum)>lm_eps)return sum/wSum;
	else return 1e60;
}

double variance1(double *x, double *w, unsigned long s)
{
    return covariance1(x,x,w,s);
}

double stddev1(double *x, double *w, unsigned long s)
{
    return helpfulsqrt(variance1(x,w,s));
}

double covariance1(double *x, double *y, double *w, unsigned long s)
{
    double ave1 = 0;
    double ave2 = 0;
    double ave3 = 0;
    double *z = new double[s];
    ave1 = average1(x,w,s);
    ave2 = average1(y,w,s);
    listProduct(x,y,s,z);
    ave3 = average1(z,w,s);
    delete[]z;
    return (double) ave3-ave1*ave2; 
}

void mAve(unsigned long noOfPts, double *values, unsigned long window, unsigned long ignoreMissing, double *returnArray)
{
    double sum=0.0;
    unsigned long count=0;
    unsigned long i=0;
    for(i=0;i<window;i++)
    {
        if (*(values+i)<1e60)
        {
            sum+=*(values+i);
            count+=1;
        }
    }
    if ((count==window && ignoreMissing==0) || (count>0 && ignoreMissing==1))
    {
        *returnArray=sum/(double) count;
    }
    else
    {
        *returnArray=1e60;
    }           
    for(i=0;i<noOfPts-window;i++)
    {
        if (*(values+i+window)<1e60)
        {
            sum+=*(values+i+window);
            count+=1;
        }
        if (*(values+i)<1e60)
        {
            sum-=*(values+i);
            count-=1;
        }
        if ((count==window && ignoreMissing==0) || (count>0 && ignoreMissing==1))
        {
            *(returnArray+i+1)=sum/(double) count;
        }
        else
        {
            *(returnArray+i+1)=1e60;
        }        
    }
}

void mSum(unsigned long noOfPts, double *values, unsigned long window, unsigned long ignoreMissing, double *returnArray)
{
    double sum=0.0;
    unsigned long count=0;
    unsigned long i=0;
    for(i=0;i<window;i++)
    {
        if (*(values+i)<1e60)
        {
            sum+=*(values+i);
            count+=1;
        }
    }
    if ((count==window && ignoreMissing==0) || (count>0 && ignoreMissing==1))
    {
        *returnArray=sum;
    }
    else
    {
        *returnArray=1e60;
    }           
    for(i=0;i<noOfPts-window;i++)
    {
        if (*(values+i+window)<1e60)
        {
            sum+=*(values+i+window);
            count+=1;
        }
        if (*(values+i)<1e60)
        {
            sum-=*(values+i);
            count-=1;
        }
        if ((count==window && ignoreMissing==0) || (count>0 && ignoreMissing==1))
        {
            *(returnArray+i+1)=sum;
        }
        else
        {
            *(returnArray+i+1)=1e60;
        }        
    }
}

void mProd(unsigned long noOfPts, double *values, unsigned long window, unsigned long ignoreMissing, double *returnArray)
{
    double prod=1.0;
    unsigned long i=0;
    unsigned long j=0;
    unsigned long count=0;
    for(i=0;i<window;i++)
    {
        if (*(values+i)<1e60)
        {
            if (prod<1e60)
            {
                prod*=*(values+i);
                count+=1;
            }
        }
    }
    if ((count==window && ignoreMissing==0) || (count>0 && ignoreMissing==1))
    {
        *returnArray=prod;        
    }
    else
    {
        *returnArray=1e60;        
    }
    for(i=0;i<noOfPts-window;i++)
    {
        if (*(values+i+window)<1e60)
        {
            prod*=*(values+i+window);
            count+=1;
        }
        if (*(values+i)<1e60)
        {
            count-=1;
            if (*(values+i)!=0.0)
            {
                prod/=*(values+i);
            }
            else
            {
                prod=1;
                count=0;
                for(j=i+1;j<i+1+window;j++)
                {
                    if (*(values+j)<1e60)
                    {
                        prod*=*(values+j);
                        count+=1;                   
                    }
                }
            }
        }
        if ((count==window && ignoreMissing==0) || (count>0 && ignoreMissing==1))
        {
            *(returnArray+i+1)=prod;
        }
        else
        {
            *(returnArray+i+1)=1e60;
        }
    }
}

void mCovar(unsigned long noOfPts, double *values1, double *values2, unsigned long window, unsigned long ignoreMissing, double *returnArray)
{
#ifdef __SYSNT__
	_ASSERT(0);
#endif
    double sum1=0.0;
    double sum2=0.0;
    double sumProd=0.0;
    unsigned long count=0;
    unsigned long i=0;
    for(i=0;i<window;i++)
    {
        if (*(values1+i)<1e60 && *(values2+i)<1e60)
        {
            sum1+=*(values1+i);
            sum2+=*(values2+i);
            sumProd+=*(values1+i)* *(values2+i);
            count+=1;
        }
    }
    if ((count==window && ignoreMissing==0) || (count>1 && ignoreMissing==1))
    {
        *returnArray = smalltest((double) count / (double) (count-1) * ((sumProd/(double) count) - (sum1/(double) count)*(sum2/(double) count)));
    }
    else
    {
        *returnArray = 1e60;    
    }
    for(i=0;i<noOfPts-window;i++)
    {
        if (*(values1+i+window)<1e60 && *(values2+i+window)<1e60)
        {
            sum1+=*(values1+i+window);
            sum2+=*(values2+i+window);
            sumProd+=*(values1+i+window)* *(values2+i+window);
            count+=1;
        }
        if (*(values1+i)<1e60  && *(values2+i)<1e60)
        {
            sum1-=*(values1+i);
            sum2-=*(values2+i);
            sumProd-=*(values1+i) * *(values2+i);
            count-=1;
        }
        if ((count==window && ignoreMissing==0) || (count>1 && ignoreMissing==1))
        {
            *(returnArray+i+1) = smalltest((double) count / (double) (count-1) * ((sumProd/(double) count) - (sum1/(double) count)*(sum2/(double) count)));
        }
        else
        {
            *(returnArray+i+1) = 1e60;
        }        
    }
}

void mCorrel(unsigned long noOfPts, double *values1, double *values2, unsigned long window, unsigned long ignoreMissing, double *returnArray)
{
    double sum1=0.0;
    double sum2=0.0;
    double sumProd=0.0;
    double sumProd1=0.0;
    double sumProd2=0.0;
    double stdev1=0.0;
    double stdev2=0.0;
    double covar=0.0;
    unsigned long count=0;
    unsigned long i=0;
    for(i=0;i<window;i++)
    {
        if (*(values1+i)<1e60 && *(values2+i)<1e60)
        {
            sum1+=*(values1+i);
            sum2+=*(values2+i);
            sumProd+=*(values1+i)* *(values2+i);
            sumProd1+=*(values1+i)* *(values1+i);
            sumProd2+=*(values2+i)* *(values2+i);
            count+=1;
        }
    }
    if ((count==window && ignoreMissing==0) || (count>1 && ignoreMissing==1))
    {
        stdev1=helpfulsqrt((double) count  / (double) (count-1) * ((sumProd1/(double) count) - (sum1/(double) count)*(sum1/(double) count)));
        stdev2=helpfulsqrt((double) count  / (double) (count-1) * ((sumProd2/(double) count) - (sum2/(double) count)*(sum2/(double) count)));
        covar=smalltest((double) count / (double) (count-1) * ((sumProd/(double) count) - (sum1/(double) count)*(sum2/(double) count)));    
        if (stdev1!=0.0 && stdev2!=0.0)
        {
            *returnArray=covar/(stdev1*stdev2);
        }
		else if(covar==0)
        {
            *returnArray=0;
        }
        else
        {
            *returnArray=1e60;
        }
    }
    else
    {
        *returnArray=1e60;        
    }
    for(i=0;i<noOfPts-window;i++)
    {
        if (*(values1+i+window)<1e60 && *(values2+i+window)<1e60)
        {
            sum1+=*(values1+i+window);
            sum2+=*(values2+i+window);
            sumProd+=*(values1+i+window)* *(values2+i+window);
            sumProd1+=*(values1+i+window)* *(values1+i+window);
            sumProd2+=*(values2+i+window)* *(values2+i+window);
            count+=1;
        }
        if (*(values1+i)<1e60  && *(values2+i)<1e60)
        {
            sum1-=*(values1+i);
            sum2-=*(values2+i);
            sumProd-=*(values1+i) * *(values2+i);
            sumProd1-=*(values1+i) * *(values1+i);
            sumProd2-=*(values2+i) * *(values2+i);
            count-=1;
        }
        if ((count==window && ignoreMissing==0) || (count>1 && ignoreMissing==1))
        {
            stdev1=helpfulsqrt((double) count  / (double) (count-1) * ((sumProd1/(double) count) - (sum1/(double) count)*(sum1/(double) count)));
            stdev2=helpfulsqrt((double) count  / (double) (count-1) * ((sumProd2/(double) count) - (sum2/(double) count)*(sum2/(double) count)));
            covar=smalltest((double) count / (double) (count-1) * ((sumProd/(double) count) - (sum1/(double) count)*(sum2/(double) count)));    
            if (stdev1!=0.0 && stdev2!=0.0)
            {
                *(returnArray+i+1)=covar/(stdev1*stdev2);
            }
			else if(covar==0)
			{
				*(returnArray+i+1)=0;
			}
            else
            {
                *(returnArray+i+1)=1e60;
            }
        }
        else
        {
            *(returnArray+i+1)=1e60;        
        }
    }
}

void mVar(unsigned long noOfPts, double *values, unsigned long window, unsigned long ignoreMissing, double *returnArray)
{
    mCovar(noOfPts,values,values,window,ignoreMissing,returnArray);
}

void mStddev(unsigned long noOfPts, double *values, unsigned long window, unsigned long ignoreMissing, double *returnArray)
{
    unsigned long i=0;
    mCovar(noOfPts,values,values,window,ignoreMissing,returnArray);
    for(i=0;i<noOfPts-window+1;i++,returnArray++)
    {
        if (*returnArray<1e60)
        {
            *returnArray=helpfulsqrt(*returnArray);
        }
        else
        {
            *returnArray=1e60;        
        }    
    }
}

void cAve(unsigned long noOfPts, double *values, unsigned long ignoreMissing, double *returnArray)
{
    unsigned long i=0;
    unsigned long count=0;
    unsigned long fill=0;
    double sum=0.0;
    for(i=0;i<noOfPts;i++)
    {
        if (fill==0)
        {
            if (*(values+i)<1e60)
            {
                sum+=*(values+i);
                count+=1;
                *(returnArray+i)=sum/(double) count;
            }
            else
            {
                if (ignoreMissing==0)
                {
                    *(returnArray+i)=1e60;
                    fill=1;
                }
                else if (count==0)
                {
                    *(returnArray+i)=1e60;    
                }
                else
                {
                    *(returnArray+i)=sum/(double) count;
                }
            }
        }
        else
        {
            *(returnArray+i)=1e60;
        }
    }
}

void cSum(unsigned long noOfPts, double *values, unsigned long ignoreMissing, double *returnArray)
{
    unsigned long i=0;
    unsigned long count=0;
    unsigned long fill=0;
    double sum=0.0;
    for(i=0;i<noOfPts;i++)
    {
        if (fill==0)
        {
            if (*(values+i)<1e60)
            {
                sum+=*(values+i);
                count+=1;
                *(returnArray+i)=sum;
            }
            else
            {
                if (ignoreMissing==0)
                {
                    *(returnArray+i)=1e60;
                    fill=1;
                }
                else if (count==0)
                {
                    *(returnArray+i)=1e60;    
                }
                else
                {
                    *(returnArray+i)=sum;
                }
            }
        }
        else
        {
            *(returnArray+i)=1e60;
        }
    }
}

void cProd(unsigned long noOfPts, double *values, unsigned long ignoreMissing, double *returnArray)
{
    unsigned long i=0;
    unsigned long count=0;
    unsigned long fill=0;
    double prod=1.0;
    for(i=0;i<noOfPts;i++)
    {
        if (fill==0)
        {
            if (*(values+i)<1e60)
            {
                prod*=*(values+i);
                count+=1;
                *(returnArray+i)=prod;
            }
            else
            {
                if (ignoreMissing==0)
                {
                    *(returnArray+i)=1e60;
                    fill=1;
                }
                else if (count==0)
                {
                    *(returnArray+i)=1e60;    
                }
                else
                {
                    *(returnArray+i)=prod;
                }
            }
        }
        else
        {
            *(returnArray+i)=1e60;
        }
    }
}

void cCovar(unsigned long noOfPts, double *values1, double *values2, unsigned long ignoreMissing, double *returnArray)
{
    double sum1=0.0;
    double sum2=0.0;
    double sumProd=0.0;
    unsigned long count=0;
    unsigned long i=0;
    unsigned long fill=0;
    for(i=0;i<noOfPts;i++)
    {
        if (fill==0)
        {
            if (*(values1+i)<1e60 && *(values2+i)<1e60)
            {
                sum1+=*(values1+i);
                sum2+=*(values2+i);
                sumProd+=*(values1+i)* *(values2+i);
                count+=1;
            }
            else if (ignoreMissing==0)
            {
                fill=1;
                *(returnArray+i)=1e60;
            }
            if (count>1 && fill==0)
            {
                *(returnArray+i) = smalltest((double) count / (double) (count-1) * ((sumProd/(double) count) - (sum1/(double) count)*(sum2/(double) count)));            
            }
            else
            {
                *(returnArray+i)=1e60;                                            
            }
        }
        else
        {
            *(returnArray+i)=1e60;
        }
    }
}

void cCorrel(unsigned long noOfPts, double *values1, double *values2, unsigned long ignoreMissing, double *returnArray)
{
    double sum1=0.0;
    double sum2=0.0;
    double sumProd=0.0;
    double sumProd1=0.0;
    double sumProd2=0.0;
    double stdev1=0.0;
    double stdev2=0.0;
    double covar=0.0;
    unsigned long count=0;
    unsigned long i=0;
    unsigned long fill=0;
    for(i=0;i<noOfPts;i++)
    {
        if (fill==0)
        {
            if (*(values1+i)<1e60 && *(values2+i)<1e60)
            {
                sum1+=*(values1+i);
                sum2+=*(values2+i);
                sumProd+=*(values1+i)* *(values2+i);
                sumProd1+=*(values1+i)* *(values1+i);
                sumProd2+=*(values2+i)* *(values2+i);
                count+=1;
            }
            else if (ignoreMissing==0)
            {
                fill=1;
                *(returnArray+i)=1e60;
            }
            if (count>1 && fill==0)
            {
                stdev1=helpfulsqrt((double) count  / (double) (count-1) * ((sumProd1/(double) count) - (sum1/(double) count)*(sum1/(double) count)));
                stdev2=helpfulsqrt((double) count  / (double) (count-1) * ((sumProd2/(double) count) - (sum2/(double) count)*(sum2/(double) count)));
                covar=smalltest((double) count / (double) (count-1) * ((sumProd/(double) count) - (sum1/(double) count)*(sum2/(double) count)));    
                if (stdev1!=0.0 && stdev2!=0.0)
                {
                    *(returnArray+i)=covar/(stdev1*stdev2);
                }
                else if(covar==0)
                {
                    *(returnArray+i)=0;
                }
                else
                {
                    *(returnArray+i)=1e60;
                }
            }
            else
            {
                *(returnArray+i)=1e60;                                            
            }
        }
        else
        {
            *(returnArray+i)=1e60;
        }
    }
}

void cVar(unsigned long noOfPts, double *values, unsigned long ignoreMissing, double *returnArray)
{
    cCovar(noOfPts,values,values,ignoreMissing,returnArray);
}

void cStddev(unsigned long noOfPts, double *values, unsigned long ignoreMissing, double *returnArray)
{
    unsigned long i=0;
    cCovar(noOfPts,values,values,ignoreMissing,returnArray);
    for(i=0;i<noOfPts;i++,returnArray++)
    {
        if (*returnArray<1e60)
        {
            *returnArray=helpfulsqrt(*returnArray);
        }
        else
        {
            *returnArray=1e60;        
        }    
    }
}

void prodArrays(unsigned long noOfPts, double *values1, double *values2, double *returnArray)
{
    unsigned long i=0;
    for(i=0;i<noOfPts;i++,values1++,values2++,returnArray++)
    {
        if (*values1<1e60 && *values2<1e60)
        {
            *returnArray=*values1* *values2;
        }
        else 
        {
            *returnArray=1e60;
        }
    }
}

double wAve(unsigned long noOfPts, double *values, double *weights)
{
    unsigned long i=0;
    double num=0.0;
    double denom=0.0;
    double result;
	std::valarray<double>t1(noOfPts);
	double *temp=&t1[0];
    prodArrays(noOfPts,values,weights,temp);
    for(i=0;i<noOfPts;i++,weights++,temp++)
    {
        if (*weights<1e60 && *temp<1e60)
        {
            denom+=*weights;
            num+=*temp;
        }
    }
    if (fabs(denom)>lm_eps)
    {
        result=num/denom;    
    }
    else
    {
        result=1e60;    
    }
    return result;           
}

double wAveProd(unsigned long noOfPts, double *values1, double *values2, double *weights)
{
    double result;
    double *temp = new double[noOfPts];
    prodArrays(noOfPts,values1,values2,temp);
    result=wAve(noOfPts,temp,weights);       
    delete[]temp;
    return result;
}

double wCovar(unsigned long noOfPts, double *values1, double *values2, double *weights)
{
    double result;
    double x;
    double y;
    double z;
    x=wAveProd(noOfPts,values1,values2,weights);
    y=wAve(noOfPts,values1,weights);
    z=wAve(noOfPts,values2,weights);
    if (x<1e60 && y<1e60 && z<1e60)
    {
        result=x-y*z;
    }
    else
    {
        result=1e60;
    }
    return result;
}



