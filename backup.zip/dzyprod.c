#include "ldefns.h"
/*
	dzyprod transforms the vector  v  in various ways using the 
	matrix  Q = ( Z  Y )  defined by the input parameters
	MODE	RESULT 
	----	------ 
	1	V = Z*V 
	2	V = Y*V 
	3	V = Q*V       (NOT YET USED) 
				ON INPUT,  V  IS ASSUMED TO BE ORDERED AS  ( V(FREE)  V(FIXED) ). 
				ON OUTPUT, V  IS A FULL N-VECTOR. 

	4	V = Z(T)*V 
	5	V = Y(T)*V 
	6	V = Q(T)*V 
				ON INPUT,  V  IS A FULL N-VECTOR. 
				ON OUTPUT, V  IS ORDERED AS  ( V(FREE)  V(FIXED) ). 

	7	V = Y(T)*V 
	8	V = Q(T)*V 
				ON INPUT,  V  IS A FULL N-VECTOR. 
				ON OUTPUT, V  IS AS IN MODES 5 AND 6 EXCEPT THAT V(FIXED) IS NOT SET. 

	BEWARE THAT  NCOLZ  WILL SOMETIMES BE  NCOLR. 
	ALSO, MODES  1, 4, 7 AND 8  DO NOT INVOLVE  V(FIXED).
	NACTIV  AND  THE ARRAY  KACTIV  ARE NOT USED FOR THOSE CASES. 
*/
void	dzyprod(short mode, dimen n, dimen nactiv, dimen ncolz, dimen nfree, dimen nq, logical unitq, short_vec kactiv, short_vec kfree, vector v, matrix zy, vector wrk)
{

    integer lenv;
    integer j, k, l;
    integer j1, j2, ka, kw, nfixed;
    --wrk;
    zy -= nq + 1;
    --v;
    --kfree;
    --kactiv;

    nfixed = n - nfree;
    j1 = 1;
    j2 = nfree;
    if (mode == 1 || mode == 4) j2 = ncolz;
    else if (mode == 2 || mode == 5 || mode == 7) j1 = ncolz + 1;
    lenv = j2 - j1 + 1;
	if(mode < 4){
		/*MODE = 1, 2  OR  3*/
		if(nfree > 0) dzerovec(nfree, &wrk[1]);
		/*COPY  V(FIXED)  INTO THE END OF  WRK. */
		if(mode != 1 && nfixed != 0)
			dcopyvec(nfixed, &v[nfree + 1], &wrk[nfree + 1]);
		/*SET  WRK  =  RELEVANT PART OF  ZY * V. */
		if(lenv > 0){
			if(unitq) dcopyvec(lenv, &v[j1], &wrk[j1]);
			else for (j = j1; j <= j2; ++j)
				if (v[j] != 0)
				 BITA_daxpy(nfree,v[j],&zy[j*nq+1],1,&wrk[1],1);
			}
		/*EXPAND  WRK  INTO  V  AS A FULL N-VECTOR. */
		dzerovec(n, &v[1]);
		if(nfree>0)
			for (k = 1; k <=  (int)nfree; ++k){
				j = kfree[k];
				v[j] = wrk[k];
				}
		/*COPY  WRK(FIXED)  INTO THE APPROPRIATE PARTS OF  V*/
		if(mode == 1 || nfixed == 0) return;
		for(l = 1; l<=nfixed; ++l) {
			kw = nfree + l;
			ka = nactiv + l;
			j = kactiv[ka];
			v[j] = wrk[kw];
			}
		}
	else	{
		/*
		MODE = 4, 5, 6, 7  OR  8
		PUT THE FIXED COMPONENTS OF  V  INTO THE END OF  WRK
		*/
		if (mode != 4 && mode <= 6 && nfixed != 0)
			for (l = 1; l <= nfixed; ++l) {
				kw = nfree + l;
				ka = nactiv + l;
				j = kactiv[ka];
				wrk[kw] = v[j];
				}
		/*PUT THE FREE  COMPONENTS OF  V  INTO THE BEGINNING OF  WRK. */
		if(nfree != 0){
			for (k = 1; k <=  (int)nfree; ++k) {
				j = kfree[k];
				wrk[k] = v[j];
				}
			/*SET  V  =  RELEVANT PART OF  ZY(T) * WRK*/
			if(lenv > 0){
				if(unitq) dcopyvec(lenv, &wrk[j1], &v[j1]);
				else for(j = j1; j <= j2; ++j)
				v[j] = ddotvec(nfree,zy+j*nq + 1,wrk+1);
				}
			}
		/*COPY THE FIXED COMPONENTS OF WRK INTO THE END OF  V*/
		if (mode != 4 && mode <= 6 && nfixed != 0)
			dcopyvec(nfixed, &wrk[nfree + 1], &v[nfree + 1]);
		}
}
