#ifdef __SYSNT__
#ifndef MINGW32 
#include <crtdbg.h>
#else
#define _ASSERT
#endif
#pragma warning(disable:4786)
#endif
#include "optimise.h"
#define line_len 3000
#define DBAD 1e66
#define IBAD ((size_t) -1)

#if _WINDOWS || __cplusplus >= 201402L
inline auto firstspaceout(std::string a,const char space=' ')
{
	auto tt=a;
	auto i=std::find_if(std::begin(a),std::end(a),[&](auto n){return n!=space;});
	if(i!=std::end(a))
		tt=std::string(tt,i-std::begin(a),tt.length());
	return tt;
}
inline auto lastspaceout(std::string a,const char space=' ')
{
	auto tt=a;
	auto i=std::find_if(std::rbegin(a),std::rend(a),[&](auto n){return n!=space;});
	if(i!=std::rend(a))
		tt=std::string(tt,0,tt.length()-(i-std::rbegin(a)));
	return tt;
}
#else
inline std::string firstspaceout(std::string a,const char space=' ')
{
	std::string tt=a;
	while(tt[0]==space)
		tt=std::string(tt,1,tt.length());
	return tt;
}
inline std::string lastspaceout(std::string a,const char space=' ')
{
	std::string tt=a;
	size_t l=tt.length()-1;
	while(tt[l]==space)
	{
		tt=std::string(tt,0,l);l=tt.length()-1;
	}
	return tt;
}
#endif
inline void linefeedcheck(std::string& t)
{
	/*	This lets us use a dos format file on unix	*/
	std::string::size_type i;
	if((i=t.find('\r'))!=t.npos)
		t.erase(i);
}
template <typename T> inline const T square(T a) { return a*a; }
//auto square = [](auto a) {return a*a; }; //Doesn't work here windows problem, ok with g++
template <typename T> inline const T rr(T x,T y){return x*x+y*y;}
inline double randomm(){return 2*((double)rand())/RAND_MAX - 1;}//Range [-1,1]
inline bool getlongline(std::ifstream& from,char* line,std::string& temp)
{
/*	This will handle lines longer than 3000 characters.
If the the file cannot be opened or is empty we just return false,
if this line is blank, we return true
and if something has been read we return true
	*/
	if(from.fail())
		return 0;
	temp.erase();
	from.getline(line,line_len);
	temp+=line;
	linefeedcheck(temp);
	while(from.fail() && from.is_open() && !from.eof())
	{
		from.clear();
		from.getline(line,line_len);
		temp+=line;
		linefeedcheck(temp);
	}
	if(!temp.empty()) 
		return true;
	else 
		return !from.eof() && from.is_open();
}
bool matchnumber(char a)
{
	int tt=(int)(a-'0');
	return (a=='-'||a=='+'||(tt<=9&&tt>=0));
}
void setvector(std::ifstream &inputs,char* line,std::string& temp,std::vector<double>&prices,std::map<std::string,std::vector<double> >&vecmap,const char* space=(char*)" ")
{
	std::string keyhere=temp;
	prices.erase(prices.begin(),prices.end());
	while(true)
	{
		getlongline(inputs,line,temp);
		if(!matchnumber(*line)) break;
		if(temp.length()>0)
		{
			split(temp,prices,space);
		}	
	}
	if(!prices.empty())
		vecmap[keyhere]=prices;
}

inline double aatof(const char*in,const char* splitter=(char*)" ")
{
	std::string temp;
	temp=in;
	if(strlen(in)&&(temp.find(splitter,0)!=0)) return atof(in);
	else return DBAD;
}
inline int aatoi(const char*in)
{
	if(strlen(in)) return atoi(in);
	else return IBAD;
}
inline void replaceall(std::string& a,const std::string here,const std::string newstr)
{
	std::string::size_type howlong=here.length();
	while(a.find(here)!=a.npos)
	{
		a.replace(a.find(here),howlong,newstr);
	}
}
void split(std::string &temp,std::vector<double> &data,std::string splitter)
{
	/*
	This now works properly for ignoring extra splitter characters at the beginning and end of each line
	and also for multiple line input.
	*/
	std::string::size_type pos,ppos,maxline=1000;
	double back;
	for(ppos=0,pos=temp.find(splitter,ppos);pos<std::string::npos;)
	{
		if((back=aatof((std::string(temp,ppos,pos-ppos)).c_str(),splitter.c_str()))!=DBAD)
		{
			data.push_back(back);
		}
		ppos=pos+1;
		pos=temp.find(splitter,ppos);
//		std::cout<<pos-ppos<<std::endl;
		if(pos>=maxline&&pos<std::string::npos)
		{
			data.push_back(aatof(std::string(temp,ppos,pos-ppos).c_str(),splitter.c_str()));
//			std::cout<<temp.length()<<std::endl;
			temp=std::string(temp,pos+splitter.length(),temp.length());
			ppos=0;
			pos=temp.find(splitter,ppos);
		}
	}
//	std::cout<<"End"<<std::endl;
	data.push_back(aatof(std::string(temp,ppos,pos-ppos).c_str(),splitter.c_str()));
	std::vector<double>::iterator iter;
	for(iter=data.end()-1;iter>=data.begin();iter--)
	{
		if(*iter == DBAD) iter=data.erase(iter);
		else break;
	}
}
void split(std::string &temp,std::vector<std::string> &data,std::string splitter)
{
	std::string::size_type pos;
	for(pos=temp.find(splitter);pos!=std::string::npos;pos=temp.find(splitter))
	{
		data.push_back(std::string(temp,0,pos));
		temp=std::string(temp,pos+splitter.length(),temp.length());
	}
	data.push_back(temp);
	std::vector<std::string>::iterator iter;
	std::vector<std::string>::reverse_iterator riter;
	for(riter=data.rbegin();riter!=data.rend();riter++)
	{
		iter=data.end()-1;
		if(!riter->length()) 
		{
			data.erase(iter);
			riter=data.rbegin();
		}
		else break;
	}
}
void split(std::string &temp,std::vector<char*> &data,std::string splitter)
{
	std::string::size_type pos;
	for(pos=temp.find(splitter);pos!=std::string::npos;pos=temp.find(splitter))
	{
		data.push_back(strdup(std::string(temp,0,pos).c_str()));
		temp=std::string(temp,pos+splitter.length(),temp.length());
	}
	data.push_back(strdup(temp.c_str()));
	std::vector<char*>::iterator iter;
	std::vector<char*>::reverse_iterator riter;
	for(riter=data.rbegin();riter!=data.rend();riter++)
	{
		iter=data.end()-1;
		if(!strlen(*riter)) 
		{
			free(*riter);
			data.erase(iter);
			riter=data.rbegin();
		}
		else break;
	}
}
void deletechar(std::vector<char*> &data)//because we used strdup
{
	std::vector<char*>::iterator iter;
	for(iter=data.begin();iter!=data.end();++iter)
	{
		free(*iter);
	}
}

void split(std::string &temp,std::vector<int> &data,std::string splitter)
{
	std::string::size_type pos;
	for(pos=temp.find(splitter);pos!=std::string::npos;pos=temp.find(splitter))
	{
		data.push_back(atoi(std::string(temp,0,pos).c_str()));
		temp=std::string(temp,pos+splitter.length(),temp.length());
	}
	data.push_back(atoi(temp.c_str()));
	std::vector<int>::iterator iter;
	std::vector<int>::reverse_iterator riter;
	for(riter=data.rbegin();riter!=data.rend();riter++)
	{
		iter=data.end()-1;
		if(*riter == (int)IBAD) {data.erase(iter);riter=data.rbegin();}
		else break;
	}
}
void split(std::string &temp,std::vector<long> &data,std::string splitter)
{
	std::string::size_type pos;
	for(pos=temp.find(splitter);pos!=std::string::npos;pos=temp.find(splitter))
	{
		data.push_back(atoi(std::string(temp,0,pos).c_str()));
		temp=std::string(temp,pos+splitter.length(),temp.length());
	}
	data.push_back(atoi(temp.c_str()));
	std::vector<long>::iterator iter;
	std::vector<long>::reverse_iterator riter;
	for(riter=data.rbegin();riter!=data.rend();riter++)
	{
		iter=data.end()-1;
		if(*riter == (int)IBAD) {data.erase(iter);riter=data.rbegin();}
		else break;
	}
}
size_t get_nfac(char* name)
{
	char line[line_len];
	std::ifstream from;
	
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	from.open(name);
	size_t numfac=0;
	std::string temp;
	std::vector<std::string> factor_names;
	
	while(getlongline(from,line,temp))
	{
		if(!temp.empty())
		{
			if(temp.find((char*)"END_BITA_PLUS_DATA")!=std::string::npos) break;
			else if((temp.find((char*)"FACTOR_NAME"))!=std::string::npos)
			{
				split(temp,factor_names,(char*)",");
				numfac=factor_names.size()-1;
			}
			else if((temp.find((char*)"SpecVar"))!=std::string::npos)
			{
				temp=temp.substr(temp.find((char*)",")+1);
				split(temp,factor_names,(char*)",");
				numfac=factor_names.size()-1;
			}
		}
		if(numfac) break;
	}
	from.close();
	return(numfac);
}
void get_stocknames(char** sname,char*name)
{
	char line[line_len];
	std::ifstream from;
	
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	from.open(name);
	std::string::size_type numfac=0,pos,rf=0,n=0;
	std::string temp;
	std::vector<std::string> factor_names;
	bool myBim=0,doCov=0;
	
	while(getlongline(from,line,temp))
	{
		if(!temp.empty())
		{
			if(n&&!doCov&&temp.find(factor_names[0])!=std::string::npos)
				break;
			if(temp.find((char*)"END_BITA_PLUS_DATA")!=std::string::npos) break;
			else if((temp.find((char*)"FACTOR_NAME"))!=std::string::npos)
			{
				split(temp,factor_names,(char*)",");
				numfac=factor_names.size()-1;
			}
			else if((temp.find((char*)"SpecVar"))!=std::string::npos)
			{
				myBim=1;
				temp=temp.substr(temp.find((char*)",")+1);
				split(temp,factor_names,(char*)",");
				numfac=factor_names.size()-1;
			}
			else if(!myBim&&numfac&&(rf<numfac))
			{
				rf++;
			}
			else if(!myBim&&numfac&&(rf==numfac))
			{
				pos=temp.find((char*)",");
				strcpy(*sname++,temp.substr(0,pos).c_str());
			}
			else if(myBim&&!doCov)
			{
				pos=temp.find((char*)",");
				strcpy(*sname++,temp.substr(0,pos).c_str());
				n++;
			}
		}
	}
	from.close();
}
void get_factornames(char** fname,char*name)
{
	char line[line_len];
	std::ifstream from;
	
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	from.open(name);
	size_t numfac=0,rf=0;
	std::string temp;
	std::vector<std::string> factor_names;
	
	while(getlongline(from,line,temp))
	{
		if(!temp.empty())
		{
			if(temp.find((char*)"END_BITA_PLUS_DATA")!=std::string::npos) break;
			else if((temp.find((char*)"FACTOR_NAME"))!=std::string::npos)
			{
				temp=temp.substr(temp.find((char*)",")+1);
				split(temp,factor_names,(char*)",");
				numfac=factor_names.size();
			}
			else if((temp.find((char*)"SpecVar"))!=std::string::npos)
			{
				temp=temp.substr(temp.find((char*)",")+1);
				split(temp,factor_names,(char*)",");
				factor_names.erase(factor_names.end()-1,factor_names.end());
				numfac=factor_names.size();
			}
			else if(numfac)
			{
				break;
			}
		}
	}
	for(rf=0;rf<numfac;++rf)
		strcpy(*fname++,factor_names[rf].c_str());
	from.close();
}
size_t get_nstocks(char*name)
{
	char line[line_len];
	std::ifstream from;
	
	from.open(name);
	size_t numfac=0,rf=0,n=0;
	std::string temp;
	std::vector<std::string> factor_names;
	bool myBim=0,doCov=0;
	
	while(getlongline(from,line,temp))
	{
		if(!temp.empty())
		{
			if(n&&!doCov&&temp.find(factor_names[0])!=std::string::npos)
				break;
			if(temp.find((char*)"END_BITA_PLUS_DATA")!=std::string::npos) break;
			else if((temp.find((char*)"FACTOR_NAME"))!=std::string::npos)
			{
				split(temp,factor_names,(char*)",");
				numfac=factor_names.size()-1;
			}
			else if((temp.find((char*)"SpecVar"))!=std::string::npos)
			{
				myBim=1;
				temp=temp.substr(temp.find((char*)",")+1);
				split(temp,factor_names,(char*)",");
				numfac=factor_names.size()-1;
			}
			else if(!myBim&&numfac&&(rf<numfac))
			{
				rf++;
			}
			else if(!myBim&&numfac&&(rf==numfac))
			{
				n++;
			}
			else if(myBim&&!doCov)
			{
				n++;
			}
		}
	}
	from.close();
	return n;
}
void getdata(size_t nstocks,size_t nfac,char** namelist,double* FFL,double* SSV,double* FFC,char* name)
{
	char line[line_len];
	std::ifstream from;
	
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	from.open(name);
	
	std::vector<double>FC,FL,SV,doubleline;
	std::string modelname;
	std::string date;
	std::string temp;
	std::vector<std::string> factor_names;
	std::vector<char*> mstocks;
	std::string::size_type numfac=0,pos,rf=0,n=0;
	bool myBim=0,doCov=0;
	
	while(getlongline(from,line,temp))
	{
		if(!temp.empty())
		{
			if(n&&!doCov&&temp.find(factor_names[0])!=std::string::npos)
				doCov=1;
			if(temp.find((char*)"END_BITA_PLUS_DATA")!=std::string::npos) break;
			else if((temp.find((char*)"MODEL_NAME"))!=std::string::npos)
			{
				modelname=temp.substr(temp.find((char*)",")+1);
			}
			else if((temp.find((char*)"DATE"))!=std::string::npos)
			{
				date=temp.substr(temp.find((char*)",")+1);
			}
			else if((temp.find((char*)"FACTOR_NAME"))!=std::string::npos)
			{
				temp=temp.substr(temp.find((char*)",")+1);
				split(temp,factor_names,(char*)",");
				numfac=factor_names.size();
			}
			else if((temp.find((char*)"SpecVar"))!=std::string::npos)
			{
				myBim=1;
				temp=temp.substr(temp.find((char*)",")+1);
				split(temp,factor_names,(char*)",");
				factor_names.erase(factor_names.end()-1,factor_names.end());
				numfac=factor_names.size();
			}
			else if(!myBim&&numfac&&(rf<numfac))
			{
				temp=temp.substr(temp.find((char*)",")+1);
				for(pos=temp.find((char*)",");pos!=std::string::npos;pos=temp.find(","))
				{
					FC.push_back(aatof(temp.substr(0,pos).c_str()));
					temp=temp.substr(pos+1);
				}
				if(!temp.empty())
					FC.push_back(aatof(temp.c_str()));
				rf++;
				std::vector<double>::iterator iter;
				std::vector<double>::reverse_iterator riter;
				for(riter=FC.rbegin();riter!=FC.rend();riter++)
				{
					iter=FC.end()-1;
					if(*riter == DBAD) {FC.erase(iter);riter=FC.rbegin();}
					else break;
				}
			}
			else if(myBim && doCov)
			{
				temp=temp.substr(temp.find((char*)",")+1);
				for(pos=temp.find((char*)",");pos!=std::string::npos;pos=temp.find(","))
				{
					FC.push_back(aatof(temp.substr(0,pos).c_str()));
					temp=temp.substr(pos+1);
				}
				if(!temp.empty())
					FC.push_back(aatof(temp.c_str()));
				rf++;
				std::vector<double>::iterator iter;
				std::vector<double>::reverse_iterator riter;
				for(riter=FC.rbegin();riter!=FC.rend();riter++)
				{
					iter=FC.end()-1;
					if(*riter == DBAD) {FC.erase(iter);riter=FC.rbegin();}
					else break;
				}
			}
			else if(!myBim&&numfac&&(rf==numfac))
			{
				pos=temp.find((char*)",");
				mstocks.push_back(strdup(temp.substr(0,pos).c_str()));
				temp=temp.substr(pos+1);
				doubleline.clear();
				split(temp,doubleline,(char*)",");
				size_t nf;
				for(nf=0;nf<numfac;++nf)
				{
					FL.push_back(doubleline[nf]);
				}
				SV.push_back(doubleline[nf]);
				n++;
			}
			else if(myBim&&!doCov)
			{
				pos=temp.find((char*)",");
				mstocks.push_back(strdup(temp.substr(0,pos).c_str()));
				temp=temp.substr(pos+1);
				doubleline.clear();
				split(temp,doubleline,(char*)",");
				size_t nf;
				for(nf=0;nf<numfac;++nf)
				{
					FL.push_back(doubleline[nf]);
				}
				SV.push_back(doubleline[nf]);
				n++;
			}
		}
	}
	
	if(FL.size() != n*numfac)
		printf((char*)"ERROR in length of Loadings %d %d\n",FL.size(),n*numfac);
	if(nfac!=numfac)
		printf((char*)"ERROR in numfac %d %d\n",nfac,numfac);
	double* FLT=new double[n*numfac];
	dmx_transpose(numfac,n,&FL[0],FLT);
	Extract_Factor_Information(nstocks,numfac,n,FFL,SSV,namelist,FLT,&SV[0],&mstocks[0]);
	dcopyvec(FC.size(),&FC[0],FFC);
	deletechar(mstocks);
	from.close();
	delete [] FLT;
}

extern "C" DLLEXPORT void getBIMcov(char* factorfile,char* covfile,
									size_t* nfac,char** factors,double* COV)
{
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	std::ifstream factorFile;
	std::ifstream covFile;
	std::map <std::string,size_t> facmap;
	char line[line_len];
	std::string temp;
	
	factorFile.open(factorfile);
	std::vector<std::string> linedata;
	std::vector<std::string> factorNames;
	size_t i=1;
	while(factorFile.getline(line,line_len))
	{
		temp=line;
		linefeedcheck(temp);
		if(!temp.empty())
		{
			if((temp.find((char*)"!"))==0)
			{
				continue;
			}
			else if((temp.find((char*)"End of File"))!=temp.npos)
			{
				break;
			}
			else if((temp.find((char*)"|"))!=temp.npos)
			{
				linedata.clear();
				split(temp,linedata,(char*)"|");
				factorNames.push_back(linedata[2]);
				facmap[linedata[2]]=i++;
			}
		}
	}
	factorFile.close();
	
	size_t n=factorNames.size();
	if(*nfac==0)
	{
		*nfac=n;
		return;
	}
	for(i=0;i<n;++i)
		factors[i]=strdup(factorNames[i].c_str());
	covFile.open(covfile);
	size_t j,I,J;
	while(covFile.getline(line,line_len))
	{
		temp=line;
		linefeedcheck(temp);
		if(!temp.empty())
		{
			if((temp.find((char*)"!"))==0)
			{
				continue;
			}
			else if((temp.find((char*)"End of File"))!=temp.npos)
			{
				break;
			}
			else if((temp.find((char*)"|"))!=temp.npos)
			{
				linedata.clear();
				split(temp,linedata,(char*)"|");
				i=facmap[linedata[0]]-1;
				j=facmap[linedata[1]]-1;
				I=max(i,j);
				J=min(i,j);
				COV[I*(I+1)/2+J]=atof(linedata[2].c_str());
			}
		}
	}
	covFile.close();
}
inline void dateget(const char*instring,std::string& day,std::string& month,std::string& year)
{
	std::string temp=(char*)"Jan Feb Mar Apr May Jun Jly Aug Sep Oct Nov Dec";
	std::vector<std::string> months;
	split(temp,months,(char*)" ");
	
	std::vector<std::string> linedata;
	temp=instring;
	split(temp,linedata,(char*)".");
	size_t ll=linedata.size()-1;
	day=linedata[ll].substr(6,2);
	year=linedata[ll].substr(0,4);
	month=months[atoi(linedata[ll].substr(4,2).c_str())-1];
}
extern "C" DLLEXPORT void procBIMcov(char* factorfile,char* covfile,char* outfile)
{
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	bool bad=1;
	std::string day,month,year;
	dateget(covfile,day,month,year);
	std::ifstream factorFile;
	std::ifstream covFile;
	std::ofstream outFile;
	std::map <std::string,size_t> facmap;
	char line[line_len];
	std::string temp;
	
	factorFile.open(factorfile);
	std::vector<std::string> linedata;
	std::vector<std::string> factorNames;
	size_t i=1;
	while(factorFile.getline(line,line_len))
	{
		temp=line;
		linefeedcheck(temp);
		if(!temp.empty())
		{
			if((temp.find((char*)"!"))==0)
			{
				continue;
			}
			else if((temp.find((char*)"End of File"))!=temp.npos)
			{
				break;
			}
			else if((temp.find((char*)"End of file"))!=temp.npos)
			{
				break;
			}
			else if((temp.find((char*)"|"))!=temp.npos)
			{
				bad=0;
				linedata.clear();
				split(temp,linedata,(char*)"|");
				factorNames.push_back(linedata[2]);
				facmap[linedata[2]]=i++;
			}
		}
	}
	factorFile.close();
	if(bad)
	{
		std::cout<<"Bad factorFile"<<std::endl;
		return;
	}
	bad=1;
	size_t n=factorNames.size();
	
	covFile.open(covfile);
	size_t j,I,J;
	std::valarray<std::string> COV(n*(n+1)/2);
	COV=(char*)"0";
	while(covFile.getline(line,line_len))
	{
		temp=line;
		linefeedcheck(temp);
		if(!temp.empty())
		{
			if((temp.find((char*)"!"))==0)
			{
				continue;
			}
			else if((temp.find((char*)"End of File"))!=temp.npos)
			{
				break;
			}
			else if((temp.find((char*)"End of file"))!=temp.npos)
			{
				break;
			}
			else if((temp.find((char*)"|"))!=temp.npos)
			{
				bad=0;
				linedata.clear();
				split(temp,linedata,(char*)"|");
				i=facmap[linedata[0]]-1;
				j=facmap[linedata[1]]-1;
				I=max(i,j);
				J=min(i,j);
				if(linedata[2].find((char*)" ")!=linedata[2].npos)
					linedata[2].replace(linedata[2].find((char*)" "),1,(char*)"");
				COV[I*(I+1)/2+J]=linedata[2];
			}
		}
	}
	covFile.close();
	if(bad)
	{
		std::cout<<"Bad covFile"<<std::endl;
		return;
	}
	outFile.open(outfile);
	
	
	outFile<<"START_BITA_PLUS_DATA,INTEGRATED_RISK_MODEL,1"<<std::endl;
	outFile<<"MODEL_NAME,Temp Model"<<std::endl;
	outFile<<"DATE,(char*)"<<day<<"-"<<month<<"-"<<year<<std::endl;		
	outFile<<"FACTOR_NAME,(char*)";
	
	for(i=0;i<n-1;++i)
	{
		outFile<<factorNames[i]<<",";
	}
	outFile<<factorNames[i]<<std::endl;
	std::string *pCOV=&COV[0];
	for(i=0;i<n-1;++i)
	{
		outFile<<factorNames[i]<<",";
		for(j=0;j<i;++j)
		{
			outFile<<*pCOV++<<",";
		}
		outFile<<*pCOV++<<std::endl;
    }
	outFile<<"END_BITA_PLUS_DATA,INTEGRATED_RISK_MODEL,1"<<std::endl;
	outFile.close();
}
extern "C" DLLEXPORT void procBIMmod(char* modelfile,char* facretfile,char* expfile,char* svfile,char* outfile)
{
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	bool bad=1;
	std::string day,month,year,currency;
	dateget(expfile,day,month,year);
	
	std::ifstream modelFile;
	std::map<std::string,std::string>modelnames;
	
	char line[line_len],linesv[line_len];
	std::string temp;
	std::vector<std::string> linedata,linedatasv;
	std::map <std::string,std::string> name2curr;
	
	name2curr["EGY"]=(char*)"EGP";
	name2curr["NGA"]=(char*)"NGN";
	name2curr["USA"]=(char*)"USD";
	name2curr["ISR"]=(char*)"ILS";
	name2curr["SWE"]=(char*)"SEK";
	name2curr["DEU"]=(char*)"EUR";
	name2curr["PER"]=(char*)"PEN";
	name2curr["LKA"]=(char*)"LKR";
	name2curr["IDN"]=(char*)"IDR";
	name2curr["MEX"]=(char*)"MXN";
	name2curr["GBR"]=(char*)"GBP";
	name2curr["CAN"]=(char*)"CAD";
	name2curr["KOR"]=(char*)"KRW";
	name2curr["COL"]=(char*)"COP";
	name2curr["SVK"]=(char*)"SKK";
	name2curr["JOR"]=(char*)"JOD";
	name2curr["PAK"]=(char*)"PKR";
	name2curr["BEL"]=(char*)"BEF";
	name2curr["SGP"]=(char*)"SGD";
	name2curr["HUN"]=(char*)"HUF";
	name2curr["PRT"]=(char*)"EUR";
	name2curr["POL"]=(char*)"PLN";
	name2curr["NLD"]=(char*)"EUR";
	name2curr["HKG"]=(char*)"HKD";
	name2curr["SAU"]=(char*)"SAR";
	name2curr["FRA"]=(char*)"EUR";
	name2curr["CHE"]=(char*)"CHF";
	name2curr["ESP"]=(char*)"EUR";
	name2curr["TWN"]=(char*)"TWD";
	name2curr["GRC"]=(char*)"EUR";
	name2curr["CHL"]=(char*)"CLP";
	name2curr["DNK"]=(char*)"DKK";
	name2curr["ZWE"]=(char*)"ZWD";
	name2curr["AUS"]=(char*)"AUD";
	name2curr["MAR"]=(char*)"MAD";
	name2curr["IRL"]=(char*)"EUR";
	name2curr["CHN"]=(char*)"CNY";
	name2curr["VEN"]=(char*)"VEB";
	name2curr["FIN"]=(char*)"EUR";
	name2curr["THA"]=(char*)"THB";
	name2curr["NZL"]=(char*)"NZD";
	name2curr["BHR"]=(char*)"BHD";
	name2curr["JPN"]=(char*)"JPY";
	name2curr["ZAF"]=(char*)"ZAR";
	name2curr["TUR"]=(char*)"TRL";
	name2curr["PHL"]=(char*)"PHP";
	name2curr["OMN"]=(char*)"OMR";
	name2curr["ITA"]=(char*)"EUR";
	name2curr["NOR"]=(char*)"NOK";
	name2curr["ARG"]=(char*)"ARS";
	name2curr["IND"]=(char*)"INR";
	name2curr["RUS"]=(char*)"RUB";
	name2curr["CZE"]=(char*)"CZK";
	name2curr["MYS"]=(char*)"MYR";
	name2curr["BRA"]=(char*)"BRL";
	name2curr["AUT"]=(char*)"ATS";
	
	modelFile.open(modelfile);
	while(modelFile.getline(line,line_len))
	{
		temp=line;
		linefeedcheck(temp);
		if(!temp.empty())
		{
			if((temp.find((char*)"!"))==0)
			{
				continue;
			}
			else if((temp.find((char*)"End of File"))!=temp.npos)
			{
				break;
			}
			else if((temp.find((char*)"End of file"))!=temp.npos)
			{
				break;
			}
			else if((temp.find((char*)"|"))!=temp.npos)
			{
				bad=0;
				linedata.clear();
				split(temp,linedata,"|");
				modelnames[linedata[0]]=linedata[2];
			}
		}
	}
	modelFile.close();
	if(bad)
	{
		std::cout<<"Bad modelFile"<<std::endl;
		return;
	}
	bad=1;
	
	std::ifstream facretFile;
	std::ifstream expFile;
	std::ifstream svFile;
	std::ofstream outFile;
	
	
	facretFile.open(facretfile);
	
	std::vector<std::string> facnames;
	std::map<std::string,size_t>facmap;
	size_t i=1;
	while(facretFile.getline(line,line_len))
	{
		temp=line;
		linefeedcheck(temp);
		if(!temp.empty())
		{
			if((temp.find((char*)"!"))==0)
			{
				continue;
			}
			else if((temp.find((char*)"End of File"))!=temp.npos)
			{
				break;
			}
			else if((temp.find((char*)"End of file"))!=temp.npos)
			{
				break;
			}
			else if((temp.find((char*)"|"))!=temp.npos)
			{
				bad=0;
				linedata.clear();
				split(temp,linedata,"|");
				facmap[linedata[0]]=i++;
				facnames.push_back(linedata[0]);
			}
		}
	}
	facretFile.close();
	if(bad)
	{
		std::cout<<"Bad facretFile"<<std::endl;
		return;
	}
	bad=1;
	size_t nf=facnames.size();
	
	expFile.open(expfile);
	svFile.open(svfile);
	
	while(expFile.getline(line,line_len))
	{
		temp=line;
		linefeedcheck(temp);
		if(!temp.empty())
		{
			if((temp.find((char*)"!"))!=0)
			{
				break;
			}
		}
	}
	while(svFile.getline(linesv,line_len))
	{
		temp=linesv;
		linefeedcheck(temp);
		if(!temp.empty())
		{
			if((temp.find((char*)"!"))!=0)
			{
				break;
			}
		}
	}

	temp = expfile;
	linedata.clear();

	if(temp.find((char*)"/")!=temp.npos)
	{
		split(temp,linedata,"/");
	}
	else if(temp.find((char*)"\\")!=temp.npos)
	{
		split(temp,linedata,"\\");
	}

	temp=linesv;
	currency=name2curr[temp.substr(0,3)];//Assume that all stocks are in the same currency (not true for Europe but easy to fiddle with sed!)
	size_t ll=linedata.size();
	outFile.open(outfile);
	outFile<<"START_BITA_PLUS_DATA,CONSTITUENT_RISK_MODEL,1"<<std::endl;			
	std::string type=modelnames[linedata[ll-1].substr(0,4)];
	outFile<<"MODEL_NAME,"<<type<<std::endl;
	outFile<<"INTEGRATED_MODEL_NAME,Temp Model"<<std::endl; 

	temp=type;
	linedata.clear();
	split(temp,linedata," ");
	type=linedata[1];

	outFile<<"INTEGRATED_MODEL_TYPE,"<<type<<std::endl;
	outFile<<"INTEGRATED_MODEL_CURRENCY,"<<currency<<std::endl;	
	outFile<<"DATE,"<<day<<"-"<<month<<"-"<<year<<std::endl;
	outFile<<"FACTOR_NAME,";

	for(i=0;i<nf-1;++i)
		outFile<<facnames[i]<<",";
	outFile<<facnames[i]<<std::endl;
	std::valarray<std::string> factexp(nf);
	while(1)
	{
		temp=linesv;
		linedatasv.clear();
		split(temp,linedatasv,"|");
		temp=line;
		linedata.clear();
		split(temp,linedata,"|");
		factexp=(char*)"0";
		while(linedatasv[0]==linedata[0])
		{
			factexp[facmap[linedata[1]]-1]=linedata[2];
			expFile.getline(line,line_len);
			temp=line;
			linefeedcheck(temp);
			if((temp.find((char*)"End of File"))!=temp.npos)
			{
				break;
			}
			else if((temp.find((char*)"End of file"))!=temp.npos)
			{
				break;
			}
			linedata.clear();
			split(temp,linedata,"|");
		}
		outFile<<linedatasv[0]<<",";
		for(i=0;i<nf;++i)
			outFile<<factexp[i]<<",";
		outFile<<square(atof(linedatasv[3].c_str()))<<std::endl;
		svFile.getline(linesv,line_len);
		temp=linesv;
		linefeedcheck(temp);
		if((temp.find((char*)"End of File"))!=temp.npos)
		{
			break;
		}
		else if((temp.find((char*)"End of file"))!=temp.npos)
		{
			break;
		}
		bad=0;
	}
	svFile.close();
	expFile.close();
	if(bad)
	{
		std::cout<<"Bad svFile or expFile"<<std::endl;
		return;
	}
	
	outFile<<"END_BITA_PLUS_DATA,CONSTITUENT_RISK_MODEL,1"<<std::endl;
	outFile.close();
}

extern "C" DLLEXPORT void genmult(size_t nl,size_t ng,vector Y,vector S,vector YS)
{
/*	YS = S*Y for compatible matrices (same as code using Robin's optimised stuff)
	S is square but not symmetric. It was done like this for BIM.
	YS[i+j*nl]=sum k S[i+k*nl]*Y[k+j*nl]
	size_t i,j,k;
	vector pY,pS,pYS;
	for(i=0;i<nl;i++)
	{
		for(j=0,pYS=YS+i,pY=Y;j<ng;j++,pYS+=nl)
		{
			*pYS=0;
			for(k=0,pS=S+i;k<nl;k++,pS+=nl)
			{
				*pYS += *pS * *pY++;
			}
		}
	}*/
	while(ng--)
	{
		dmxmulv(nl,nl,S,Y,YS);
		Y+=nl;YS+=nl;
	}
}

extern "C" DLLEXPORT void getFSF(size_t n,size_t m,vector S,vector F,vector FSF)
{
	size_t i,j,k,l,kl,nn=n*(n+1)/2,ii,kk,ll;
	vector pF1,pF2,pFSF;
	double ss;

	for(i=0,pFSF=FSF;i<nn;++i,pFSF++)
		*pFSF = 0;

    for(i=0,ii=0;i<n;i++,ii+=i)
	{
        for(k=0,kk=0,pF1=F+i;k<m;++k,kk+=k,pF1+=n)
		{
            if(*pF1!=0)
			{
                for(j=0,pFSF=FSF+ii;j<=i;++j,pFSF++)
				{
                    ss=0;
					if(S)
					{
						for(l=0,ll=0,pF2=F+j;l<m;++l,ll+=l,pF2+=n)
						{
							if(*pF2!=0)
							{
								if(k>=l)
									kl=kk+l;
								else 
									kl=ll+k;
								ss+=*(S+kl)* *pF2;
							}
						}
					}
					else
					{
						ss=*(F+j+n*k+k);
					}
                    *pFSF+=*pF1*ss;
				}
			}
		}
	}
}

extern "C" DLLEXPORT short OptFundClass(size_t nf,size_t nc,vector target,double value,
							  double outvalue,vector w,double factor=0.25,int log=0)
{
/*	nf funds can invest in nc asset classes. Hence nf*nc variables

	The net investment weight of a particular fund in each asset must not exceed factor.
	A set of target weights for each class in each fund is given.
	A total value is given.

	If the optimal total value is less than the given total value the difference
	is attributed to cash.

	We minimise sum (wi - targeti)**2 (i.e. put in unit matrix for covariance matrix and
	gamma=0)
	subject to value and the must not exceed factor constraints. nf*nc+1 constraints
*/
	size_t n=nf*nc,m=n+1,i,j;
	std::valarray<double> A(n*m),L(n+m),U(n+m),C(n*(n+1)/2);
	A=0;
	C=0;
	L=0;
	U=outvalue;
	vector pA,pC,pL,pU;
	for(i=0,pC=&C[0];i<n;++i)
	{
		*pC=1;
		pC+=(i+2);
	}

	for(i=0,pA=&A[0],pL=&L[n+1],pU=&U[n+1];i<n;++i)
	{
		*pA++ =1;
		*pL++ =-1;
		*pU++ =0;
		for(j=0;j<n;++j)
		{
			if(i%nc == j%nc) *pA=-factor;
			else *pA=0;
			if(i==j)*pA += 1;
			pA++;
		}
	}
	L[n]=value;
	U[n]=outvalue;

	return Optimise_internalCVPAFb(n,-1,0,w,m,&A[0],&L[0],&U[0],0,target,&C[0],0,0,2,0,0,.5,
		-1,-1,0,0,-1,-1,0,1,-1,-1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,-1,-1,0,0,log,0,
		0,3,-1,-1,-1,-1,1,1,1);

}
extern "C" DLLEXPORT void basic_factor_global_local_attribution
(size_t n,size_t nl,size_t ng,
 vector FL,vector x,
 vector Y,vector G,vector S,vector YS,
 vector FC,vector SV,
 vector XMCTR,vector FMCTR,vector SMCTR,
 vector IsFVar,vector IsXVar,
 vector IsFVarpg,vector GFX,vector FMCTRpg,
 vector IsXVarga,
 vector FX,double* facrisk,int print,vector FCgl=0)
{
/*
				n,		Number of stocks
				nl,		Number of factors (= number of local factors)
				ng,		Number of global factors
				FL,		Factor loadings
				w,		Portfolio weights
				Y,		Exposures of local to global factors (rectangular length nl*ng)
				G,		Global factor covariances (lower triangle length ng*(ng+1)/2)
				S,		Scaling matrix (non-symetric length nl*nl)
				FC,		Factor covariances
				SV,		Specific variances
				XMCTR,	Asset level factor mctr (output)
				FMCTR,	Factor level factor mctr (output)
				SMCTR,	Asset level non-factor mctr (output)
				IsFVar,	Isolated Factor variance (output)
				IsXVar,	Isolated Asset variance (output)
				IsFVarpg,	Isolated Global factor variance (output)
				GFX,	Isolated Global factor exposures (output)
				FMCTRpg,Factor level pure global factor mctr (output)
				FX,		Factor exposures (output)
				facrisk	factor risk (output)
				print	log output set to 0 for nothing
				FCgl	global FC is returned if FCgl!=0 and G!=0 S!=0 Y!=0

This expects either 1) FC=0 and S,G and Y given OR 2) FC to be given and S=0, G=0 and Y=0
but NOT both 1) and 2)
In case 1) the outputs FMCTR and XFMCTR are for attributation of global factor variance.
In case 2) the outputs FMCTR and XFMCTR are for attribution of total factor variance.
If XMCTR=0 then no asset level factor attribution is performed.
If FMCTR=0 then no factor level factor attribution is performed.
If SV=0 and SMCTR=0 then no Asset level non-factor attribution is performed.

IsVar outputs are isolated asset or factor values. 
IsXVar gives the diagonal elements of the asset covariance matrix
IsFVar gives the diagonal elements of the factor covariance matrix, 
pg refers to the pure global covariance matrix G

Typically this would be called twice; once with FC=0 and S,G and Y given and then with FC given
and S=0, G=0 and Y=0.

For risks total factor squared=global squared + local squared
*/
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	size_t nnl=nl*(nl+1)/2,i,j;
	std::valarray<double> YSs;
	std::valarray<double> FCg;
	if(!FC && Y && G && S)
	{
		if(!YS)
		{
			YSs.resize(nl*ng);
			YSs=0;
			YS=&YSs[0];
			genmult(nl,ng,Y,S,YS);
		}
		if(FCgl)
			FC=FCgl;
		else
		{
			FCg.resize(nnl);
			FCg=0;
			FC=&FCg[0];
		}
		getFSF(nl,ng,G,YS,FC);
	}
	else if(!(FC && !Y && !G && !S))
	{
		if(print)printf((char*)"Error in basic_factor_global_local_attribution\n");
		return;
	}
	


	if(facrisk)
	{
		if(XMCTR||IsXVar)
		{
			std::valarray<short_scl> P(nl);
			std::valarray<double> FCgc(nnl),FLcop(n*nl);
			vector FL_copy,v;
			FL_copy=&FLcop[0];
			dmx_transpose(n,nl,FL,FL_copy);	
			if(_dsmxmpd_check(nl,FC,&FCgc[0],&P[0],0,0))
			{
				if(print&&Y&&G&&S)
				{
					printf((char*)"The Global Factor Covariance at local level was not positive definite\n");
				}
				else if(print)
				{
					printf((char*)"The Factor Covariance was not positive definite\n");
				}
			}
			for(i = 0,v = FL_copy;i < n;i++,v += nl)
			{
				dsmxasrt(nl,&FCgc[0],&P[0],SMXFAC_LEFT_ROOT,v);
			}
			if(XMCTR)
			{
				dsccopy(n,BITA_ddot(n,FL_copy,nl,x,1),FL_copy,nl,XMCTR,1);
				for(i = 1;i < nl;i++) 
				{
					BITA_daxpy(n,BITA_ddot(n,FL_copy+i,nl,x,1),FL_copy+i,nl,XMCTR,1);
				}
				*facrisk =ddotvec(n,x,XMCTR);
				if(*facrisk>lm_eps)
				{
					*facrisk=sqrt(*facrisk);
					dscalvec(n,1.0/ *facrisk,XMCTR);
				}
				else
				{
					*facrisk=0;
					dzerovec(n,XMCTR);
				}
			}
			if(IsXVar)
			{
				std::valarray<double>Iw(n*2);
				Iw=0;
				for(size_t j=0;j<n;++j)
				{
					Iw[j]=x[j];
					dsccopy(n,BITA_ddot(n,FL_copy,nl,&Iw[0],1),FL_copy,nl,&Iw[n],1);
					for(i = 1;i < nl;i++) 
					{
						BITA_daxpy(n,BITA_ddot(n,FL_copy+i,nl,&Iw[0],1),FL_copy+i,nl,&Iw[n],1);
					}
					IsXVar[j] =ddotvec(n,&Iw[0],&Iw[n]);
					Iw[j]=0;
				}
			}
		}
		if(FX)
		{
			dmxtmulv(n,nl,FL,x,FX);
			if(IsFVarpg)
			{
				std::valarray<double> GFX(ng*3);
				GFX=0;
				dmxtmulv(nl,ng,YS,FX,&GFX[0]);
				for(i=0;i<ng;++i)
				{
					GFX[ng+i]=GFX[i];
					dsmxmulv(ng,G,&GFX[ng],&GFX[2*ng]);
					IsFVarpg[i]=ddotvec(ng,&GFX[ng],&GFX[2*ng]);
					GFX[ng+i]=0;
				}
			}
			if(IsXVarga)
			{
				std::valarray<double> FLSY(n*ng);
				std::valarray<double> xx(n);
				std::valarray<double> ff(2*ng);
				vector pIV;
				xx=0;
				for(i=0;i<ng;++i)
				{
					dmxmulv(n,nl,FL,YS+nl*i,&FLSY[n*i]);
				}
				for(i=0,pIV=IsXVarga;i<n;++i)
				{
					xx[i]=x[i];
					dmxtmulv(n,ng,&FLSY[0],&xx[0],&ff[0]);
					dsmxmulv(ng,G,&ff[0],&ff[ng]);
					for(j=0;j<ng;++j,pIV++)
						*pIV=ff[j]*ff[j+ng];
					xx[i]=0;
				}
			}
			if(FMCTRpg&&GFX)
			{
				dmxtmulv(nl,ng,YS,FX,GFX);
				dsmxmulv(ng,G,GFX,FMCTRpg);
				double gfac=ddotvec(ng,GFX,FMCTRpg);
				if(gfac > lm_eps)
				{
					gfac=sqrt(gfac);
					dscalvec(ng,1./gfac,FMCTRpg);
				}
				else
				{
					gfac=0;
					dzerovec(ng,FMCTRpg);
				}
			}
			if(FMCTR&&facrisk)
			{
				dsmxmulv(nl,FC,FX,FMCTR);
				*facrisk = ddotvec(nl,FMCTR,FX);
				if(*facrisk > lm_eps)
				{
					*facrisk = sqrt(*facrisk);
					dscalvec(nl,1.0 / *facrisk,FMCTR);
				}
				else
				{
					*facrisk = 0;
					dzerovec(nl,FMCTR);
				}
			}
			if(IsFVar)
			{
				std::valarray<double>IFX(nl*2);
				IFX=0;
				for(i=0;i<nl;++i)
				{
					IFX[i]=FX[i];
					dsmxmulv(nl,FC,&IFX[0],&IFX[nl]);
					IsFVar[i] = ddotvec(nl,&IFX[0],&IFX[nl]);
					IFX[i]=0;
				}
			}
		}
	}
	
	if(SMCTR&&SV)
	{
		ddmxmul(n,SV,x,SMCTR);
		double srisk=ddotvec(n,x,SMCTR);
		if(srisk>lm_eps)
		{
			srisk=sqrt(srisk);
			dscalvec(n,1./srisk,SMCTR);
		}
		else
		{
			srisk=0;
			dzerovec(n,SMCTR);
		}
	}
}
extern "C" DLLEXPORT void basic_factor_global_local_attribution1
(size_t n,size_t nl,size_t ng,
 vector FL,vector x,
 vector Y,vector G,vector S,vector YS,
 vector XMCTR,vector FMCTR,
 vector IsFVar,vector IsXVar,
 vector IsFVarpg,vector GFX,
 vector FMCTRpg,
 vector IsXVarga,vector FX,
 double* facrisk,int print)
{
/*
				n,		Number of stocks
				nl,		Number of factors (= number of local factors)
				ng,		Number of global factors
				FL,		Factor loadings
				w,		Portfolio weights
				Y,		Exposures of local to global factors (rectangular length nl*ng)
				G,		Global factor covariances (lower triangle length ng*(ng+1)/2)
				S,		Scaling matrix (non-symetric length nl*nl)
				XMCTR,	Asset level factor mctr (output)
				FMCTR,	Factor level factor mctr (output)
				FX,		Factor exposures
				facrisk	factor risk
				print	log output set to 0 for nothing

If XMCTR=0 then no asset level factor attribution is performed.
If FMCTR=0 then no factor level factor attribution is performed.
*/
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	size_t nng=ng*(ng+1)/2,i,j;
	std::valarray<double> YSs;
	std::valarray<double> FCg;
	vector FC;
	FCg.resize(nng);
	FC=&FCg[0];
	if(!YS)
	{
		YSs.resize(nl*ng);
		YS=&YSs[0];
		for(i=0;i<ng;++i)
		{
			dmxmulv(nl,nl,S,Y+nl*i,&YSs[nl*i]);
		}
	}
	std::valarray<short_scl> P(ng);
	std::valarray<double> Gc(nng);
	if(_dsmxmpd_check(ng,G,&Gc[0],&P[0],0,0))
	{
		if(print)printf((char*)"The Global Factor Covariance at global level was not positive definite\n");
	}
	
	
	if((XMCTR&&facrisk)||IsXVar)
	{
		std::valarray<double>FLSY(n*ng);
		for(i=0;i<ng;++i)
		{
			dmxmulv(n,nl,FL,YS+nl*i,&FLSY[n*i]);
		}
		if(IsXVarga)
		{
			std::valarray<double> xx(n);
			std::valarray<double> ff(2*ng);
			xx=0;
			vector pIV;
			for(i=0,pIV=IsXVarga;i<n;++i)
			{
				xx[i]=x[i];
				dmxtmulv(n,ng,&FLSY[0],&xx[0],&ff[0]);
				dsmxmulv(ng,G,&ff[0],&ff[ng]);
				for(j=0;j<ng;++j,pIV++)
					*pIV=ff[j]*ff[j+ng];
				xx[i]=0;
			}
		}
		vector FL_copy=&FLSY[0],v;
		dmx_transpose(n,ng,FL_copy,FL_copy);	
		for(i = 0,v = FL_copy;i < n;i++,v += ng)
		{
			dsmxasrt(ng,&Gc[0],&P[0],SMXFAC_LEFT_ROOT,v);
		}
		if(XMCTR)
		{
			dsccopy(n,BITA_ddot(n,FL_copy,ng,x,1),FL_copy,ng,XMCTR,1);
			for(i = 1;i < ng;i++) 
			{
				BITA_daxpy(n,BITA_ddot(n,FL_copy + i,ng,x,1),FL_copy + i,ng,XMCTR,1);
			}
			*facrisk=ddotvec(n,x,XMCTR);
			if(*facrisk>lm_eps)
			{
				*facrisk=sqrt(*facrisk);
				dscalvec(n,1.0/ *facrisk,XMCTR);
			}
			else
			{
				*facrisk=0;
				dzerovec(n,XMCTR);
			}
		}
		if(IsXVar)
		{
			std::valarray<double>xx(2*n);
			xx=0;
			for(j=0;j<n;++j)
			{
				xx[j]=x[j];
				dsccopy(n,BITA_ddot(n,FL_copy,ng,&xx[0],1),FL_copy,ng,&xx[n],1);
				for(i = 1;i < ng;i++) 
				{
					BITA_daxpy(n,BITA_ddot(n,FL_copy + i,ng,&xx[0],1),FL_copy + i,ng,&xx[n],1);
				}
				IsXVar[j]=ddotvec(n,&xx[0],&xx[n]);
				xx[j]=0;
			}
		}
	}
	
	if(FMCTR&&FX&&facrisk)
	{
		vector FL_copy,v;
		std::valarray<double>YS1(nl*ng);
		FL_copy=&YS1[0];
		dmx_transpose(nl,ng,YS,FL_copy);	
		for(i = 0,v = FL_copy;i < nl;i++,v += ng)
		{
			dsmxasrt(ng,&Gc[0],&P[0],SMXFAC_LEFT_ROOT,v);
		}
		dmxtmulv(n,nl,FL,x,FX);
		dsccopy(nl,BITA_ddot(nl,FL_copy,ng,FX,1),FL_copy,ng,FMCTR,1);
		for(i = 1;i < ng;i++) 
		{
			BITA_daxpy(nl,BITA_ddot(nl,FL_copy + i,ng,FX,1),FL_copy+i,ng,FMCTR,1);
		}
		*facrisk = ddotvec(nl,FMCTR,FX);
		if(*facrisk > lm_eps)
		{
			*facrisk = sqrt(*facrisk);
			dscalvec(nl,1.0 / *facrisk,FMCTR);
		}
		else
		{
			*facrisk = 0;
			dzerovec(nl,FMCTR);
		}
		if(IsFVar)
		{
			std::valarray<double> xx(2*nl);
			xx=0;
			for(j=0;j<nl;++j)
			{
				xx[j]=FX[j];
				dsccopy(nl,BITA_ddot(nl,FL_copy,ng,&xx[0],1),FL_copy,ng,&xx[nl],1);
				for(i = 1;i < ng;i++) 
				{
					BITA_daxpy(nl,BITA_ddot(nl,FL_copy + i,ng,&xx[0],1),FL_copy+i,ng,&xx[nl],1);
				}
				IsFVar[j] = ddotvec(nl,&xx[0],&xx[nl]);
				xx[j]=0;
			}
		}
		if(GFX&&(IsFVarpg||FMCTRpg))
		{
			dmxtmulv(nl,ng,YS,FX,GFX);
			if(IsFVarpg)
			{
				std::valarray<double> xx(ng*2);
				xx=0;
				for(i=0;i<ng;++i)
				{
					xx[i]=GFX[i];
					dsmxmulv(ng,G,&xx[0],&xx[ng]);
					IsFVarpg[i]=ddotvec(ng,&xx[0],&xx[ng]);
					xx[i]=0;
				}
			}
			if(FMCTRpg&&GFX)
			{
				dsmxmulv(ng,G,GFX,FMCTRpg);
				double gfac=ddotvec(ng,GFX,FMCTRpg);
				if(gfac > lm_eps)
				{
					gfac=sqrt(gfac);
					dscalvec(ng,1./gfac,FMCTRpg);
				}
				else
				{
					gfac=0;
					dzerovec(ng,FMCTRpg);
				}
			}
		}
	}
}
extern "C" DLLEXPORT double xCx(size_t n,vector Q,vector x)
{
	std::valarray<double> yy(n);
	vector y=&yy[0];
	dsmxmulv(n,Q,x,y);
	return ddotvec(n,x,y);
}
void ManyVars(size_t n,vector Q,vector x,vector AssetVars,size_t nmask=0,size_t* masks=0,vector MaskVars=0)
{
	std::valarray<double> yy(n),ww(n);
	size_t i,j;
	ww=0;
	vector y=&yy[0],w=&ww[0];
	if(AssetVars)//Get variances for each variable in x
	{
		for(i=0;i<n;++i)
		{
			w[i]=x[i];
			dsmxmulv(n,Q,w,y);
			AssetVars[i]=ddotvec(n,w,y);
			w[i]=0;
		}
	}
	if(MaskVars)//Get variances for each combination of variables defined in x by masks+n*j
	{
		for(j=0;j<nmask;++j)
		{
			for(i=0;i<n;++i)
			{
				if(masks[i+j*n])
					w[i]=x[i];
			}
			dsmxmulv(n,Q,w,y);
			MaskVars[j]=ddotvec(n,w,y);
			ww=0;
		}
	}
}
extern "C" DLLEXPORT void ManyVarsD(size_t n,vector SV,vector x,vector AssetVars,size_t nmask=0,size_t* masks=0,vector MaskVars=0)
{
	std::valarray<double> yy(n),ww(n);
	size_t i,j;
	ww=0;
	vector y=&yy[0],w=&ww[0];
	if(AssetVars)//Get variances for each variable in x
	{
		for(i=0;i<n;++i)
		{
			w[i]=x[i];
			ddmxmul(n,SV,x,y);
			AssetVars[i]=ddotvec(n,w,y);
			w[i]=0;
		}
	}
	if(MaskVars)//Get variances for each combination of variables defined in x by masks+n*j
	{
		for(j=0;j<nmask;++j)
		{
			for(i=0;i<n;++i)
			{
				if(masks[i+j*n])
					w[i]=x[i];
			}
			ddmxmul(n,SV,x,y);
			MaskVars[j]=ddotvec(n,w,y);
			ww=0;
		}
	}
}
void ManyVars(size_t n,size_t nf,vector Q,vector x,vector AssetVars,size_t nmask=0,size_t* masks=0,vector MaskVars=0)
{
	std::valarray<double> yy(n),ww(n);
	size_t i,j,k;
	ww=0;
	vector y=&yy[0],w=&ww[0];
	Q+=n;
	if(AssetVars)//Get variances for each variable in x
	{
		for(i=0;i<n;++i)
		{
			w[i]=x[i];
			dsccopy(n,BITA_ddot(n,Q,nf,w,1),Q,nf,y,1);
			for(j = 1;j < nf;j++) 
			{
				BITA_daxpy(n,BITA_ddot(n,Q + j,nf,w,1),Q + j,nf,y,1);
			}
			AssetVars[i]=ddotvec(n,w,y);
			w[i]=0;
		}
	}
	if(MaskVars)//Get variances for each combination of variables defined in x by masks+n*j
	{
		for(j=0;j<nmask;++j)
		{
			ww=0;
			for(i=0;i<n;++i)
			{
				if(masks[i+j*n])
					w[i]=x[i];
			}
			dsccopy(n,BITA_ddot(n,Q,nf,w,1),Q,nf,y,1);
			for(k = 1;k < nf;k++) 
			{
				BITA_daxpy(n,BITA_ddot(n,Q + k,nf,w,1),Q + k,nf,y,1);
			}
			MaskVars[j]=ddotvec(n,w,y);
		}
	}
}
extern "C" DLLEXPORT void manyVars(size_t n,vector Q,vector x,vector AssetVars,
									 size_t nmask=0,size_t* masks=0,vector MaskVars=0)
{
	ManyVars(n,Q,x,AssetVars,nmask,masks,MaskVars);
}
extern "C" DLLEXPORT void manyVarsX(size_t n,size_t nf,vector Q,vector x,vector AssetVars,
									 size_t nmask=0,size_t* masks=0,vector MaskVars=0)
{//Q must be from factor_model_process
	ManyVars(n,nf,Q,x,AssetVars,nmask,masks,MaskVars);
}
extern "C" DLLEXPORT void SriskAttribution(size_t n,vector SV,vector x,size_t nsect,
										   size_t* sectdef,vector Rctr,vector TRctr)
{
/*
	n		number of stocks
	SV		specific variances
	x		weights
	nsect	number of sectors
	sectdef	n*nsect array of 1s and 0s, ith sector weight for jth sector is sectdef[i+j*n]
	Rctr	output risks for stocks length n+sum(non-zeros in each sector)
	TRctr	output risks for sectors size nsect+1, the first total is for the portfolio
*/
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	Optimise O;
	if(!O.licenced)return;
	std::valarray<double>wp(n),mcrt(n);
	size_t i,j;
	vector w=x,xx,MCTR;
	size_t* sect;
	for(i=0;i<1+nsect;++i,TRctr++)
	{
		if(i)
		{
			wp=0;
			for(j=0,xx=x,w=&wp[0],sect=sectdef+(i-1)*n;j<n;++j,sect++,w++,xx++)
			{
				if(*sect)
					*w=*xx;
			}
			w=&wp[0];
		}
		else
			w=x;
		ddmxmul(n,SV,w,&mcrt[0]);
		*TRctr=ddotvec(n,w,&mcrt[0]);
		if(*TRctr<lm_eps)
		{
			*TRctr=0;
			dzerovec(n,&mcrt[0]);
		}
		else
		{
			*TRctr=sqrt(*TRctr);//Sector standard deviation
			dscalvec(n,1.0/ *TRctr,&mcrt[0]);
		}
		for(j=0,MCTR=&mcrt[0],xx=x,sect=sectdef+(i-1)*n;j<n;++j,sect++,xx++,MCTR++)
		{
			if(!i||*sect)
					*Rctr++ = *xx* *MCTR;//Contributed marginal sd for each stock in sector
		}
	}
}
extern "C" DLLEXPORT void SvarianceAttribution(size_t n,vector SV,vector x,size_t nsect,
										   size_t* sectdef,vector Rctr,vector TRctr)
{
/*
	n		number of stocks
	SV		specific variances
	x		weights
	nsect	number of sectors
	sectdef	n*nsect array of 1s and 0s, ith sector weight for jth sector is sectdef[i+j*n]
	Rctr	output variances for stocks length n+sum(non-zeros in each sector)
	TRctr	output variances for sectors size nsect+1, the first total is for the portfolio
*/
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	Optimise O;
	if(!O.licenced)return;
	std::valarray<double>wp(n),mcrt(n);
	size_t i,j;
	vector w=x,xx,Sctr=Rctr,RRctr;
	size_t* sect;
	ddmxmul(n,SV,w,&mcrt[0]);
	*TRctr=ddotvec(n,w,&mcrt[0]);//Portfolio variance
	if(*TRctr<lm_eps)
	{
		*TRctr=0;
	}
	wp=0;
	for(i=0,xx=x;i<n;++i,xx++)
	{
		wp[i]=*xx;
		ddmxmul(n,SV,&wp[0],&mcrt[0]);
		*Sctr++=ddotvec(n,&wp[0],&mcrt[0]);//Individual stock variance
		wp[i]=0;		
	}
	TRctr++;
	for(i=0;i<nsect;++i,TRctr++)
	{
		wp=0;
		for(j=0,RRctr=Rctr,xx=x,w=&wp[0],sect=sectdef+i*n;j<n;++j,sect++,w++,xx++,RRctr++)
		{
			if(*sect)
			{
				*w=*xx;
				*Sctr++ = *RRctr;//Individual stock variance in sector
			}
		}
		w=&wp[0];
		ddmxmul(n,SV,w,&mcrt[0]);
		*TRctr=ddotvec(n,w,&mcrt[0]);//Sector variance
		if(*TRctr<lm_eps)
		{
			*TRctr=0;
		}
	}
}
inline void CProcess(size_t n,size_t nl,vector FC,vector FL,vector Q)
{
	bool print=0;
	std::valarray<short_scl>P(nl);
	std::valarray<double> FCc(nl*(nl+1)/2);
	dmx_transpose(n,nl,FL,Q);
	vector v;
	size_t i;
	if(FC)
	{
		if(_dsmxmpd_check(nl,FC,&FCc[0],&P[0],0,0))
		{
			if(print)
			{
				printf((char*)"The Local Factor Covariance was not positive definite\n");
			}
		}
		for(i = 0,v = Q;i < n;i++,v += nl)
		{
			dsmxasrt(nl,&FCc[0],&P[0],SMXFAC_LEFT_ROOT,v);
		}
	}
}
inline void CQmult(size_t n,size_t nf,vector Q,vector x,vector y)
{
	size_t j;
	dsccopy(n,BITA_ddot(n,Q,nf,x,1),Q,nf,y,1);
	for(j = 1;j < nf;j++) 
	{
		BITA_daxpy(n,BITA_ddot(n,Q+j,nf,x,1),Q+j,nf,y,1);
	}
}
inline double CmakeMC(size_t n,vector MCTR,double variance)
{
	double risk;
	if(variance<lm_eps)
	{
		risk=0;
		dzerovec(n,MCTR);
	}
	else
	{
		risk=sqrt(variance);
		dscalvec(n,1./risk,MCTR);
	}
	return risk;
}
extern "C" DLLEXPORT void FriskAttribution(size_t n,size_t nl,vector FC,vector FL,vector x,
										   size_t nsect,
										   size_t* sectdef,size_t ng,vector G,vector YS,
										   size_t nfgroup,size_t* fgroupdef,
										   size_t nggroup,size_t* ggroupdef,
										   vector TotalRisks,vector GlobalRisks,vector LocalRisks,
										   vector TotalBreak,vector GlobalBreak,vector LocalBreak)
{
/*
	n			number of assets
	nl			number of local factors
	FC			Factor Covariances in lower triangle
	FL			Factor Loadings
	x			assets weights
	nsect		number of sectors
	sectdef		list of length n*nsect sectdef[i+j*n] = 1 if asset is in sector j, 0 otherwise
	ng			number of global factors
	G			global factor covariances in lower trinagle
	YS			exposures of local to global (scaled BARRA way)
	nfgroup		number of local factor sectors
	fgroupdef	list of length n*nfgroup fgroupdef[i+j*n] = 1 if factor i is in sector j, 0 otherwise
	nggroup		number of global factor sectors
	ggroupdef	list of length n*nggroup ggroupdef[i+j*n] = 1 if factor i is in sector j, 0 otherwise
	TotalRisks	array length (1+nsect)*(1+nl+nsl+nfgroup) where nsl is the number of 1s in fgroupdef 
				(i.e. the total number of factors in all the factor groups)
				TotalRisks holds the risks for
				Portfolio		1 element
					then nl factor risks
						then nfgroup groups of
							factor group total risk
							risk for each factor in the group
				Then nsect groups for each
					sector risk
						then nl factor risks
							then nsl groups of
								factor group total risk
								risk for each factor in the group
	GlobalRisks	similar to TotalRisks
	LocalRisks	similar to TotalRisks
	TotalBreak	array length ((n+nssect)*(1+nl+nsl)) where nssect is the total number of assets
				in all sectors
				TotalBreak holds the breakdown of the Totalrisks over the assets
				the first n give the asset contributions for total risk
				the next block of n*nl gives the asset breakdown for each of the nl factors
				then nfgroup blocks of factor group breakdowns
				then the breakdown of the Totalrisks over the assets in each sector (by sector)
					the first n give the asset contributions for total risk
					the next block of n*nl gives the asset breakdown for each of the nl factors
					then nfgroup blocks of factor group breakdowns

	GlobalBreak	similar to TotalBreak
	LocalBreak	similar to TotalBreak
*/
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	Optimise O;
	if(!O.licenced)return;
	std::valarray<double>FLSY(n*ng),wp(n),y(3*max(max(n,nl),ng));
	std::valarray<double> pFX(2*nl),pGFX(2*ng);
	vector FX=&pFX[0],GFX=&pGFX[0];
	vector FXs=FX+nl,GFXs=GFX+ng;
	size_t i,j,k,l;
	for(i=0;i<ng;++i)
	{
		dmxmulv(n,nl,FL,YS+nl*i,&FLSY[n*i]);
	}
	std::valarray<double>FCg(nl*(nl+1)/2);
	getFSF(nl,ng,G,YS,&FCg[0]);
	std::valarray<double> comprisk(nl*n*2+ng*n);
	vector compriskA=&comprisk[0],w;
	vector compriskG=&comprisk[n*nl];
	vector compriskGG=&comprisk[2*n*nl];
	CProcess(n,nl,FC,FL,compriskA);
	CProcess(n,nl,&FCg[0],FL,compriskG);
	CProcess(n,ng,G,&FLSY[0],compriskGG);
	
	vector xx;
	size_t*sect;
	size_t*fsect;
	size_t sectot=0;
	size_t fsectot=0;
	for(i=0,sect=sectdef;i<nsect*n;++i,sect++)
	{
		if(*sect)sectot++;
	}
	for(i=0,sect=fgroupdef;i<nfgroup*nl;++i,sect++)
	{
		if(*sect)fsectot++;
	}
	
	double tr,lr,gr;
	vector BreakTotal=TotalBreak,BreakGlobal=GlobalBreak,BreakLocal=LocalBreak;
	vector FactTotal=TotalRisks,FactGlobal=GlobalRisks,FactLocal=LocalRisks;
	vector FFL;
	for(i=0;i<1+nsect;++i)
	{
		if(i)
		{
			wp=0;
			for(j=0,xx=x,w=&wp[0],sect=sectdef+(i-1)*n;j<n;++j,sect++,w++,xx++)
			{
				if(*sect)
					*w=*xx;
			}
			w=&wp[0];
		}
		else
			w=x;
		
		CQmult(n,nl,compriskA,w,&y[0]);
		CQmult(n,nl,compriskG,w,&y[n]);
		dsubvec(n,&y[0],&y[n],&y[n]);
		CQmult(n,ng,compriskGG,w,&y[2*n]);
		*FactTotal=ddotvec(n,w,&y[0]);
		tr=CmakeMC(n,&y[0],*FactTotal);
		*FactTotal++=tr;
		*FactLocal=ddotvec(n,w,&y[n]);
		lr=CmakeMC(n,&y[n],*FactLocal);
		*FactLocal++=lr;
		*FactGlobal=ddotvec(n,w,&y[2*n]);
		gr=CmakeMC(n,&y[2*n],*FactGlobal);
		*FactGlobal++=gr;
		for(k=0,xx=x,sect=sectdef+(i-1)*n;k<n;++k,sect++,xx++)
		{
			if(!i||*sect)
			{
				*BreakTotal++ = *xx * y[k];
				*BreakLocal++ = *xx * y[k+n];
				*BreakGlobal++ = *xx * y[k+2*n];
			}
		}
		
		dmxtmulv(n,nl,FL,w,FX);
		dsmxmulv(nl,FC,FX,&y[0]);
		dsmxmulv(nl,&FCg[0],FX,&y[nl]);
		dsubvec(nl,&y[0],&y[nl],&y[nl]);
		tr=ddotvec(nl,FX,&y[0]);
		tr=CmakeMC(nl,&y[0],tr);//y is now MCTR for each factor (wrt to w, if w is x sum(MCTR*FX)=risk)
		for(j=0;j<nl;++j)
		{
			*FactTotal++ = FX[j]*y[j];//breakdown of risk for each factor
			for(k=0,sect=sectdef+(i-1)*n,xx=w,FFL=FL+j*n;k<n;++k,FFL++,xx++,sect++)
			{
				if(!i||*sect)
					*BreakTotal++ = *FFL* *xx *y[j];//breakdown of risk in each factor per stock
			}
		}
		lr=ddotvec(nl,FX,&y[nl]);//sim for local
		lr=CmakeMC(nl,&y[nl],lr);
		for(j=0;j<nl;++j)
		{
			*FactLocal++ = FX[j]*y[nl+j];
			for(k=0,sect=sectdef+(i-1)*n,xx=w,FFL=FL+j*n;k<n;++k,FFL++,xx++,sect++)
			{
				if(!i||*sect)
					*BreakLocal++ = *FFL* *xx *y[nl+j];
			}
		}
		
		dmxtmulv(n,ng,&FLSY[0],w,GFX);
		
		dsmxmulv(ng,G,GFX,&y[2*nl]);
		gr=ddotvec(ng,GFX,&y[2*nl]);//sim for global
		gr=CmakeMC(ng,&y[2*nl],gr);
		for(j=0;j<ng;++j)
		{
			*FactGlobal++ = GFX[j]*y[2*nl+j];
			for(k=0,sect=sectdef+(i-1)*n,xx=w,FFL=&FLSY[j*n];k<n;++k,FFL++,xx++,sect++)
			{
				if(!i||*sect)
					*BreakGlobal++ = *FFL* *xx *y[2*nl+j];
			}
		}
		for(l=0;l<nggroup;++l)
		{
			dzerovec(ng,GFXs);
			for(k=0,fsect=ggroupdef+l*ng;k<ng;++k,fsect++)
			{
				if(*fsect)
				{
					GFXs[k]=GFX[k];
				}
			}
			dsmxmulv(ng,G,GFX,&y[2*nl]);
			gr=ddotvec(ng,GFX,&y[2*nl]);
			gr=CmakeMC(ng,&y[2*nl],gr);//total risk
			*FactGlobal++=ddotvec(ng,&y[2*nl],GFXs);//CTR for this group
			for(k=0,sect=sectdef+(i-1)*n,xx=w;k<n;++k,xx++,sect++)
			{
				if(!i||*sect)
				{
					*BreakGlobal=0;
					for(j=0,FFL=&FLSY[k],fsect=ggroupdef+l*ng;j<ng;++j,fsect++,FFL+=n)
					{
						if(*fsect)
						{
							*BreakGlobal += *FFL* *xx*y[2*nl+j];
						}
					}
					BreakGlobal++;
				}
			}
			for(j=0,fsect=ggroupdef+l*ng;j<ng;++j,fsect++)
			{
				if(*fsect)
				{
					*FactGlobal++ = GFXs[j]*y[2*nl+j];
					for(k=0,sect=sectdef+(i-1)*n,xx=w,FFL=&FLSY[j*n];k<n;++k,FFL++,xx++,sect++)
					{
						if(!i||*sect)
							*BreakGlobal++ = *FFL* *xx *y[2*nl+j];
					}
				}
			}
		}
		for(l=0;l<nfgroup;++l)
		{
			dzerovec(nl,FXs);
			for(k=0,fsect=fgroupdef+l*nl;k<nl;++k,fsect++)
			{
				if(*fsect)
				{
					FXs[k]=FX[k];
				}
			}
			dsmxmulv(nl,FC,FX,&y[0]);
			dsmxmulv(nl,&FCg[0],FX,&y[nl]);
			dsubvec(nl,&y[0],&y[nl],&y[nl]);
			tr=ddotvec(nl,FX,&y[0]);
			tr=CmakeMC(nl,&y[0],tr);
			*FactTotal++=ddotvec(nl,FXs,&y[0]);
			for(k=0,sect=sectdef+(i-1)*n,xx=w;k<n;++k,xx++,sect++)
			{
				if(!i||*sect)
				{
					*BreakTotal=0;
					for(j=0,FFL=FL+k,fsect=fgroupdef+l*nl;j<nl;++j,fsect++,FFL+=n)
					{
						if(*fsect)
						{
							*BreakTotal +=*FFL* *xx*y[j];
						}
					}
					BreakTotal++;
				}
			}
			for(j=0,fsect=fgroupdef+l*nl;j<nl;++j,fsect++)
			{
				if(*fsect)
				{
					*FactTotal++ = FXs[j]*y[j];
					for(k=0,sect=sectdef+(i-1)*n,xx=w,FFL=FL+j*n;k<n;++k,FFL++,xx++,sect++)
					{
						if(!i||*sect)
							*BreakTotal++ = *FFL* *xx *y[j];
					}
				}
			}
			lr=ddotvec(nl,FX,&y[nl]);
			lr=CmakeMC(nl,&y[nl],lr);
			*FactLocal++=ddotvec(nl,FXs,&y[nl]);
			for(k=0,sect=sectdef+(i-1)*n,xx=w;k<n;++k,xx++,sect++)
			{
				if(!i||*sect)
				{
					*BreakLocal=0;
					for(j=0,FFL=FL+k,fsect=fgroupdef+l*nl;j<nl;++j,fsect++,FFL+=n)
					{
						if(*fsect)
						{
							*BreakLocal +=*FFL* *xx*y[nl+j];
						}
					}
					BreakLocal++;
				}
			}
			for(j=0,fsect=fgroupdef+l*nl;j<nl;++j,fsect++)
			{
				if(*fsect)
				{
					*FactLocal++ = FXs[j]*y[nl+j];
					for(k=0,sect=sectdef+(i-1)*n,xx=w,FFL=FL+j*n;k<n;++k,FFL++,xx++,sect++)
					{
						if(!i||*sect)
							*BreakLocal++ = *FFL* *xx *y[nl+j];
					}
				}
			}
		}
	}
/*	printf((char*)"TotalRisks[0] %20.8e\n",TotalRisks[0]);
	printf((char*)"TotalRisks[1] %20.8e\n",TotalRisks[1]);*/
}
inline double cleversqrt(double x,int stdev,size_t& nneg,double& mineg)
{
	if(!stdev)return x;
	if(x<lm_eps) {mineg=(x<mineg)?x:mineg;nneg++;return 0;}
	else return sqrt(x);
}
void ExpAttr(size_t n,size_t nl,vector FL,vector x,vector FX)
{
	size_t i,j;
	vector pFL,pFX,pw;
	for(j=0,pFL=FL,pFX=FX;j<nl;++j)
	{
		for(i=0,pw=x;i < n;i++,pw++)
		{
			*pFX++=*pFL++* *pw;
		}
	}
}

extern "C" DLLEXPORT void FexposureAttribution(size_t n,size_t nl,vector FL,vector x,
											   size_t nsect,size_t* sectdef,size_t nfgroup,
											   size_t* fgroupdef,vector TotalExp,
											   vector TotalBreak)
{
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	Optimise O;
	if(!O.licenced)return;
	std::valarray<double>FX(n*nl),wp(n);
	size_t* sect,*fsect;
	vector w,xx,BreakTotal=TotalBreak;
	vector ExpTotal=TotalExp;
	size_t i,j,k,l;
	for(i=0;i<1+nsect;++i)
	{
		if(i)
		{
			wp=0;
			for(j=0,xx=x,w=&wp[0],sect=sectdef+(i-1)*n;j<n;++j,sect++,w++,xx++)
			{
				if(*sect)
					*w=*xx;
			}
			w=&wp[0];
		}
		else
			w=x;
		ExpAttr(n,nl,FL,w,&FX[0]);
		*ExpTotal++=dsumvec(n*nl,&FX[0]);
		dmx_transpose(n,nl,&FX[0],&FX[0]);
		for(k=0,sect=sectdef+(i-1)*n;k<n;++k,sect++)//Add over factors
		{
			if(!i||(sectdef&&*sect))
			{
				*BreakTotal++ =dsumvec(nl,&FX[k*nl]);
			}
		}
		dmx_transpose(nl,n,&FX[0],&FX[0]);
		for(j=0;j<nl;++j)//Add over stocks
		{
			*ExpTotal++ = dsumvec(n,&FX[j*n]);
			for(k=0,sect=sectdef+(i-1)*n;k<n;++k,sect++)
			{
				if(!i||(sectdef&&*sect))
					*BreakTotal++ = FX[k+j*n];
			}
		}
		for(l=0;l<nfgroup;++l)
		{
			*ExpTotal=0;
			for(k=0,sect=sectdef+(i-1)*n;k<n;++k,sect++)
			{
				if(!i||(sectdef&&*sect))
				{
					*BreakTotal=0;
					if(*x!=0)
					{
						for(j=0,fsect=fgroupdef+l*nl;j<nl;++j,fsect++)
						{
							if(fgroupdef&&*fsect)
							{
								*BreakTotal+=FX[k+j*n];
							}
						}
					}
					*ExpTotal+=*BreakTotal++;
				}
			}
			ExpTotal++;
			for(j=0,fsect=fgroupdef+l*nl;j<nl;++j,fsect++)
			{
				if(fgroupdef&&*fsect)
				{
					*ExpTotal = 0;
					for(k=0,sect=sectdef+(i-1)*n;k<n;++k,sect++)
					{
						if(!i||(sectdef&&*sect))
						{
							*BreakTotal = FX[k+j*n];
							*ExpTotal+=*BreakTotal++;
						}
					}
					ExpTotal++;
				}
			}
		}
	}
}
extern "C" DLLEXPORT size_t FvarianceAttribution(size_t n,size_t nl,vector FC,vector FL,vector x,
										   size_t nsect,
										   size_t* sectdef,size_t ng,vector G,vector YS,
										   size_t nfgroup,size_t* fgroupdef,
										   size_t nggroup,size_t* ggroupdef,
										   vector TotalRisks,vector GlobalRisks,vector LocalRisks,
										   vector TotalBreak,vector GlobalBreak,vector LocalBreak,
										   int stdev,double*Mineg)
{
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	Optimise O;
	size_t nneg=0;
	double mineg=0;
	if(Mineg)*Mineg=mineg;
	if(!O.licenced)return nneg;
	std::valarray<double>FLSY(n*ng),wp(n),y(3*max(max(n,nl),ng));
	std::valarray<double> pFX(2*nl),pGFX(2*ng);
	vector FX=&pFX[0],GFX=&pGFX[0],FFX;
	vector FXs=FX+nl,GFXs=GFX+ng;
	size_t i,j,k,l;
	for(i=0;i<ng;++i)
	{
		dmxmulv(n,nl,FL,YS+nl*i,&FLSY[n*i]);
	}
	std::valarray<double>FCg(nl*(nl+1)/2);
	getFSF(nl,ng,G,YS,&FCg[0]);
	std::valarray<double> comprisk(nl*n*2+ng*n);
	vector compriskA=&comprisk[0],w;
	vector compriskG=&comprisk[n*nl];
	vector compriskGG=&comprisk[2*n*nl];
	CProcess(n,nl,FC,FL,compriskA);
	CProcess(n,nl,&FCg[0],FL,compriskG);
	CProcess(n,ng,G,&FLSY[0],compriskGG);
	
	vector xx;
	size_t*sect;
	size_t*fsect,*fsect1,jj;
	vector FC1,FC2;
	size_t sectot=0;
	double inner,innerr,innerx;
	for(i=0,sect=sectdef;i<nsect*n;++i,sect++)
	{
		if(*sect)sectot++;
	}
	
	vector BreakTotal=TotalBreak,BreakGlobal=GlobalBreak,BreakLocal=LocalBreak;
	vector FactTotal=TotalRisks,FactGlobal=GlobalRisks,FactLocal=LocalRisks;
	vector FFL,FFL1,DIAG,DIAGl;
	for(i=0;i<1+nsect;++i)
	{
		if(i)
		{
			wp=0;
			for(j=0,xx=x,w=&wp[0],sect=sectdef+(i-1)*n;j<n;++j,sect++,w++,xx++)
			{
				if(*sect)
					*w=*xx;
			}
			w=&wp[0];
		}
		else
			w=x;
		
		CQmult(n,nl,compriskA,w,&y[0]);
		CQmult(n,nl,compriskG,w,&y[n]);
		dsubvec(n,&y[0],&y[n],&y[n]);
		CQmult(n,ng,compriskGG,w,&y[2*n]);
		*FactTotal++=cleversqrt(ddotvec(n,w,&y[0]),stdev,nneg,mineg);
		*FactLocal++=cleversqrt(ddotvec(n,w,&y[n]),stdev,nneg,mineg);
		*FactGlobal++=cleversqrt(ddotvec(n,w,&y[2*n]),stdev,nneg,mineg);
		if(!i)
		{
			w=&wp[0];
			wp=0;
		}
		for(k=0,xx=x,sect=sectdef+(i-1)*n;k<n;++k,sect++,xx++)
		{
			if(!i)
			{
				w[k]=x[k];
				CQmult(n,nl,compriskA,w,&y[0]);
				CQmult(n,nl,compriskG,w,&y[n]);
				dsubvec(n,&y[0],&y[n],&y[n]);
				CQmult(n,ng,compriskGG,w,&y[2*n]);
				*BreakTotal++ = cleversqrt(ddotvec(n,w,&y[0]),stdev,nneg,mineg);
				*BreakLocal++ = cleversqrt(ddotvec(n,w,&y[n]),stdev,nneg,mineg);
				*BreakGlobal++ = cleversqrt(ddotvec(n,w,&y[2*n]),stdev,nneg,mineg);
				w[k]=0;
			}
			else if(*sect)
			{
				*BreakTotal++=TotalBreak[k];
				*BreakLocal++=LocalBreak[k];
				*BreakGlobal++=GlobalBreak[k];
			}
		}
		
		if(!i)
		{
			w=x;
		}
		dmxtmulv(n,nl,FL,w,FX);
		for(j=0,FFX=FX,DIAG=FC;j<nl;++j,FFX++,DIAG+=(j+1))
		{
			*FactTotal++ = cleversqrt(*DIAG* *FFX* *FFX,stdev,nneg,mineg);
			for(k=0,sect=sectdef+(i-1)*n,xx=w,FFL=FL+j*n;k<n;++k,FFL++,xx++,sect++)
			{
				if(!i||*sect)
					*BreakTotal++ = cleversqrt(*FFL* *FFL* *DIAG* *xx* *xx,stdev,nneg,mineg);
			}
		}
		for(j=0,FFX=FX,DIAG=FC,DIAGl=&FCg[0];j<nl;++j,FFX++,DIAG+=(j+1),DIAGl+=(j+1))
		{
			*FactLocal++ = cleversqrt(*FFX* *FFX*(*DIAG-*DIAGl),stdev,nneg,mineg);
			for(k=0,sect=sectdef+(i-1)*n,xx=w,FFL=FL+j*n;k<n;++k,FFL++,xx++,sect++)
			{
				if(!i||*sect)
					*BreakLocal++ = cleversqrt(*FFL* *FFL*(*DIAG-*DIAGl)* *xx* *xx,stdev,nneg,mineg);
			}
		}
		
		dmxtmulv(n,ng,&FLSY[0],w,GFX);
		
		for(j=0,FFX=GFX,DIAG=G;j<ng;++j,FFX++,DIAG+=(j+1))
		{
			*FactGlobal++ = cleversqrt(*FFX* *FFX* *DIAG,stdev,nneg,mineg);
			for(k=0,sect=sectdef+(i-1)*n,xx=w,FFL=&FLSY[j*n];k<n;++k,FFL++,xx++,sect++)
			{
				if(!i||*sect)
					*BreakGlobal++ = cleversqrt(*FFL* *FFL* *DIAG* *xx* *xx,stdev,nneg,mineg);
			}
		}
		for(l=0;l<nggroup;++l)
		{
			dzerovec(ng,GFXs);
			for(k=0,fsect=ggroupdef+l*ng;k<ng;++k,fsect++)
			{
				if(*fsect)
				{
					GFXs[k]=GFX[k];
				}
			}
			dsmxmulv(ng,G,GFXs,&y[2*nl]);
			*FactGlobal++=cleversqrt(ddotvec(ng,GFXs,&y[2*nl]),stdev,nneg,mineg);
			for(k=0,sect=sectdef+(i-1)*n,xx=w;k<n;++k,xx++,sect++)
			{
				if(!i||*sect)
				{
					*BreakGlobal=0;
					if(*x!=0)
					{
						innerx=*xx* *xx;
						for(j=0,FFL=&FLSY[k],FC1=G,fsect=ggroupdef+l*ng;j<ng;++j,fsect++,FFL+=n)
						{
							if(*fsect && *FFL!=0)
							{
								inner=innerx* *FFL;
								for(jj=0,FFL1=&FLSY[k],fsect1=ggroupdef+l*ng;jj<=j;++jj,fsect1++,FFL1+=n)
								{
									if(*fsect1 && *FFL1!=0)
									{
										innerr=inner* *FFL1* *FC1;
										*BreakGlobal += innerr;
										if(jj!=j)
											*BreakGlobal+=innerr;
									}
									FC1++;
								}
							}
							else
							{
								FC1+=j+1;
							}
						}
					}
					*BreakGlobal=cleversqrt(*BreakGlobal,stdev,nneg,mineg);
					BreakGlobal++;
				}
			}
			for(j=0,FFX=GFX,DIAG=G,fsect=ggroupdef+l*ng;j<ng;++j,FFX++,fsect++,DIAG+=(j+1))
			{
				if(*fsect)
				{
					*FactGlobal++ = cleversqrt(*FFX* *FFX* *DIAG,stdev,nneg,mineg);
					for(k=0,sect=sectdef+(i-1)*n,xx=w,FFL=&FLSY[j*n];k<n;++k,FFL++,xx++,sect++)
					{
						if(!i||*sect)
							*BreakGlobal++ = cleversqrt(*FFL* *xx* *FFL* *xx* *DIAG,stdev,nneg,mineg);
					}
				}
			}
		}
		for(l=0;l<nfgroup;++l)
		{
			dzerovec(nl,FXs);
			for(k=0,fsect=fgroupdef+l*nl;k<nl;++k,fsect++)
			{
				if(*fsect)
				{
					FXs[k]=FX[k];
				}
			}
			dsmxmulv(nl,FC,FXs,&y[0]);
			dsmxmulv(nl,&FCg[0],FXs,&y[nl]);
			dsubvec(nl,&y[0],&y[nl],&y[nl]);
			*FactTotal++=cleversqrt(ddotvec(nl,FXs,&y[0]),stdev,nneg,mineg);
			for(k=0,sect=sectdef+(i-1)*n,xx=w;k<n;++k,xx++,sect++)
			{
				if(!i||*sect)
				{
					*BreakTotal=0;
					if(*x!=0)
					{
						innerx=*xx* *xx;
						for(j=0,FFL=FL+k,FC1=FC,fsect=fgroupdef+l*nl;j<nl;++j,fsect++,FFL+=n)
						{
							if(*fsect&&*FFL!=0)
							{
								inner=innerx* *FFL;
								for(jj=0,FFL1=FL+k,fsect1=fgroupdef+l*nl;jj<=j;++jj,fsect1++,FFL1+=n)
								{
									if(*fsect1&&*FFL1!=0)
									{
										innerr=inner* *FFL1* *FC1;
										*BreakTotal += innerr;
										if(j!=jj)
											*BreakTotal += innerr;
									}
									FC1++;
								}
							}
							else
							{
								FC1+=j+1;
							}
						}
					}
					*BreakTotal=cleversqrt(*BreakTotal,stdev,nneg,mineg);
					BreakTotal++;
				}
			}
			for(j=0,FFX=FX,DIAG=FC,fsect=fgroupdef+l*nl;j<nl;++j,FFX++,fsect++,DIAG+=(j+1))
			{
				if(*fsect)
				{
					*FactTotal++ = cleversqrt(*DIAG* *FFX* *FFX,stdev,nneg,mineg);
					for(k=0,sect=sectdef+(i-1)*n,xx=w,FFL=FL+j*n;k<n;++k,FFL++,xx++,sect++)
					{
						if(!i||*sect)
							*BreakTotal++ = cleversqrt(*xx* *xx* *FFL* *FFL* *DIAG,stdev,nneg,mineg);
					}
				}
			}
			*FactLocal++=cleversqrt(ddotvec(nl,FXs,&y[nl]),stdev,nneg,mineg);
			for(k=0,sect=sectdef+(i-1)*n,xx=w;k<n;++k,xx++,sect++)
			{
				if(!i||*sect)
				{
					*BreakLocal=0;
					if(*xx!=0)
					{
						innerx=*xx* *xx;
						for(j=0,FFL=FL+k,FC1=FC,FC2=&FCg[0],fsect=fgroupdef+l*nl;j<nl;++j,fsect++,FFL+=n)
						{
							if(*fsect&&*FFL!=0)
							{
								inner=innerx* *FFL;
								for(jj=0,FFL1=FL+k,fsect1=fgroupdef+l*nl;jj<=j;++jj,fsect1++,FFL1+=n)
								{
									if(*fsect1&&*FFL1!=0)
									{
										innerr=inner* *FFL1*(*FC1-*FC2);
										*BreakLocal += innerr;
										if(j!=jj)
											*BreakLocal += innerr;
									}
									FC1++;FC2++;
								}
							}
							else
							{
								FC1+=j+1;FC2+=j+1;
							}
						}
					}
					*BreakLocal=cleversqrt(*BreakLocal,stdev,nneg,mineg);
					BreakLocal++;
				}
			}
			
			for(j=0,FFX=FX,DIAG=FC,DIAGl=&FCg[0],fsect=fgroupdef+l*nl;j<nl;++j,FFX++,fsect++,DIAG+=(j+1),DIAGl+=(j+1))
			{
				if(*fsect)
				{
					inner=*DIAG-*DIAGl;
					*FactLocal++ = cleversqrt(*FFX* *FFX*inner,stdev,nneg,mineg);
					for(k=0,sect=sectdef+(i-1)*n,xx=w,FFL=FL+j*n;k<n;++k,FFL++,xx++,sect++)
					{
						if(!i||*sect)
							*BreakLocal++ = cleversqrt(*FFL* *FFL* *xx* *xx*inner,stdev,nneg,mineg);
					}
				}
			}
		}
	}
	if(Mineg)*Mineg=mineg;
	return nneg;
}
inline void gausspdf_BITA(double& v1,double& v2,double mean=0,double st=1,size_t reseed=0)
{
/*	
	Box-Mueller transformation to get a normal dist from a uniform one.
	gausspdf(v1,v2,mean,st,1)		returns and reseeds rand().
	gausspdf(v1,v2,mean,st,0)		sets random variables v1 and v2.
*/
    if(reseed!=0){srand(time(0));return;}
    
    double x1,x2,w;
    
    while(1)
    {
        if((w=rr(x1=randomm(),x2=randomm())) < 1)break;
    }
    
    w=sqrt((-2.0*log(w))/w);
    v1=mean+st*w*x1;
    v2=mean+st*w*x2;
}
extern "C" DLLEXPORT double gausspdf(double mean=0,double st=1,size_t reseed=0)
{
/*	
	Box-Mueller transformation to get a normal dist from a uniform one.
	gausspdf(mean,st,1)		returns 0 and reseeds rand().
	gausspdf(mean,st,0)		returns the value of a randon variable which is Normal(mean,st)
*/
    if(reseed!=0){srand(time(0));return 0;}
    
	double x1,x2;
	gausspdf_BITA(x1,x2,mean,st,reseed);
	return x1;
}
extern "C" DLLEXPORT void resampfront
(dimen n,long nfac,char** names,dimen m,
 vector A,vector L,vector U,vector alpha,
 vector benchmark,vector Q,vector initial,
 real delta,int revise,vector FC,vector FL,vector SV,dimen ncomp,vector Comp,
 int logg,char* logfile,double gamma,size_t nsamp,vector randrisk,vector randreturn,
 size_t npoints=0,vector risks=0,vector rreturns=0,vector mask=0)
{
/*	
	randreturn and randrisk should have dimension nsamp+1, the last entry of each
	is for the optimal portfolio using true alpha.
*/
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	vector pComp;
	size_t i,j;
	std::valarray<double>arisks(npoints),areturns(npoints);
	std::valarray<double>w(max(n,n*npoints));
	std::valarray<double>rand_alpha(n);
	double arisk,Rrisk,brisk,pbeta,error=.1,ret_bench=ddotvec(n,alpha,benchmark);
	
	if(npoints)
	{
		//Do a frontier
		FrontierCVPAextcosts(npoints,risks,&arisks[0],rreturns,&areturns[0],n,nfac,names,
			&w[0],m,A,L,U,
			alpha,benchmark,Q,initial,delta,.5,-1,-1,revise,-1,-1,0,1,-1,-1,0,0,0,0,ncomp,Comp,
			1,0,0,0,0,0,FC,FL,SV,0,0,0,0,0,0,0,mask,0,0,-1,-1,-1,-1,1);
	}
	
	//Get optimal portfolio at gamma
	Optimise_internalCVPAextcosts(n,nfac,names,&w[0],m,A,L,U,alpha,benchmark,
		Q,gamma,initial,delta,.5,-1,-1,revise,-1,-1,0,1,-1,-1,0,0,0,0,ncomp,Comp,
		1,0,0,0,0,0,FC,FL,SV,0,0,0,-1,-1,0,0,0,0,0,mask,logg,logfile,
		0,0,3,-1,-1,-1,-1,1,1,1);	
	//Find the risk and return for the optimal portfolio
	Get_RisksC(n,nfac,Q,&w[0],benchmark,&arisk,randrisk+nsamp,&Rrisk,&brisk,&pbeta,ncomp,Comp);
	randreturn[nsamp]=ddotvec(n,&w[0],alpha)-ret_bench;


	srand(time(0));//reseed the rand() function using integer representation of current time
	
	double r1,r2;
	for(i=0;i<nsamp;++i)
	{
		//Get randomly perturbed alphas using Normal distribution
		for(j=0;j<n-ncomp;++j)
		{
			if(j%2 == 0)
			{
				gausspdf_BITA(r1,r2,0,error);
				rand_alpha[j]=alpha[j]+r1;
			}
			else
				rand_alpha[j]=alpha[j]+r2;
		}
		for(j=0,pComp=Comp;j<ncomp;++j,pComp+=(n-ncomp))
		{
			rand_alpha[j+n-ncomp]=ddotvec(n-ncomp,pComp,&rand_alpha[0]);
		}
		//Get optimal portfolio with the randon alphas
		Optimise_internalCVPAextcosts(n,nfac,names,&w[0],m,A,L,U,&rand_alpha[0],benchmark,
			Q,gamma,initial,delta,.5,-1,-1,revise,-1,-1,0,1,-1,-1,0,0,0,0,ncomp,Comp,
			1,0,0,0,0,0,FC,FL,SV,0,0,0,-1,-1,0,0,0,0,0,mask,logg,logfile,
			0,0,3,-1,-1,-1,-1,1,1,1);	
		//Find the risk and return for the optimal portfolio using the original alphas
		Get_RisksC(n,nfac,Q,&w[0],benchmark,&arisk,randrisk+i,&Rrisk,&brisk,&pbeta,ncomp,Comp);
		randreturn[i]=ddotvec(n,&w[0],alpha)-ret_bench;
	}
}

extern "C" DLLEXPORT void CurrencyProcessFL(size_t nf,size_t n,vector FL,vector psi,vector FLn)
{
	//FLn = (1+psi)*FL
	//i.e. FLn' =FL'*(1+psi)'
	dmx_transpose(nf,nf,psi,psi);   
	dmx_transpose(n,nf,FL,FL);
	genmult(nf,n,FL,psi,FLn);
	dmx_transpose(nf,n,FL,FL);
	dmx_transpose(nf,n,FLn,FLn);
	dmx_transpose(nf,nf,psi,psi);   
}
extern "C" DLLEXPORT void MCTR_Beta(char** Modelnames,size_t mn,char** names,size_t n,size_t nf,
									vector FC,vector MFL,vector MSV,vector w,vector benchmark,
									vector MCTR,vector Beta)
{
	FOptimise Prop;
	if(!Prop.licenced)return;
	std::valarray<double>FL(n*nf),SV(n);
	Extract_Factor_Information(n,nf,mn,&FL[0],&SV[0],names,MFL,MSV,Modelnames);
	Prop.n=n;
	Prop.nfac=nf;
	Prop.ncomp=0;
	Prop.SV=&SV[0];
	Prop.FL=&FL[0];
	Prop.FC=FC;
	if(nf>0&&Prop.SV&&Prop.FL&&FC)
		Prop.factor_model_process();
	else if(!nf&&Prop.SV)
		Prop.H=Prop.SV;
	else
		Prop.H=0;
	Prop.beta(benchmark,Beta);
	Prop.MC(w,0,MCTR);
}
