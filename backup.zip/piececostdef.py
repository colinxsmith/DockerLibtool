#For jython and jythonc only
import JavaCost
class piececostdef(JavaCost):
    def __init__(self,**a):
        #Overwrites
        for i in a.keys():setattr(self,i,a[i])
    def getNstocks(self):
        return getattr(self,'nstocks')
    def setNstocks(self,a):
        setattr(self,'nstocks',a)
    def modc(self,n,w,c):
        #if not (n==getattr(self,'nstocks')):raise 'n=%d nstocks=%d'%(n,self.nstocks)
        initial=getattr(self,'initial')
        npiece=getattr(self,'npiece')
        hp=getattr(self,'hpiece')
        hpstart=0
        pg=getattr(self,'pgrad')
        for j in range(n):
            done=0
            scale=1
            if w[j]<0:scale=getattr(self,'shortCostScale')
            if initial == []:ww=w[j]
            else:ww=w[j]-initial[j]
            if ww<hp[hpstart]:
                c[j]=pg[hpstart]*scale
                done=1
                hpstart+=npiece
                continue
            for i in range(1,npiece):
                if(ww<hp[hpstart+i] and ww>=hp[hpstart+i-1]):
                   if ww>0:c[j]=pg[hpstart+i]*scale
                   elif ww<0:c[j]=pg[hpstart+i-1]*scale
                   else:c[j]=0
                   done=1
                   break
            if done:
                hpstart+=npiece                
                continue
            c[j]=pg[hpstart+npiece-1]*scale
            hpstart+=npiece                
    def util(self,n,w):
        #if not (n==getattr(self,'nstocks')):raise 'n=%d nstocks=%d'%(n,self.nstocks)
        initial=getattr(self,'initial')
        npiece=getattr(self,'npiece')
        hp=getattr(self,'hpiece')
        hpstart=0
        pg=getattr(self,'pgrad')
        total=0
        nstart=0
        for j in range(n):
            nstart=0
            done=0
            scale=1
            if w[j]<0:scale=getattr(self,'shortCostScale')
            for i in range(npiece):#Get the first positive ordinate; we integrate from 0
                if hp[hpstart+i]>0:nstart=i;break
            if initial == []:ww=w[j]
            else:ww=w[j]-initial[j]
            if ww<=hp[nstart+hpstart] and ww>=0:
                total+=ww*pg[nstart+hpstart]*scale
                done=1
                hpstart+=npiece
                continue
            sofar=hp[nstart+hpstart]*pg[nstart+hpstart]*scale
            if ww>0:
                for i in range(nstart+1,npiece):
                    if ww<hp[i+hpstart] and ww>=hp[i-1+hpstart]:
                        total+=sofar+(ww-hp[i-1+hpstart])*pg[i+hpstart]*scale
                        done=1
                        break
                    sofar+=(hp[i+hpstart]-hp[i-1+hpstart])*pg[i+hpstart]*scale
            if done:
                hpstart+=npiece
                continue
            if ww>=0:
                total+=sofar+(ww-hp[npiece-1+hpstart])*pg[npiece-1+hpstart]*scale
                done=1
                hpstart+=npiece
                continue
            if not ww<0:raise 'BIG ERROR in util'
            sofar=0
            for ii in range(nstart):
                i=nstart-ii
                usehpi=hp[hpstart+i]
                if i == nstart:usehpi=0
                if ww<usehpi and ww>= hp[i-1+hpstart]:
                    total+=sofar+(ww-usehpi)*pg[i-1+hpstart]*scale
                    done=1
                    break
                sofar-=(usehpi-hp[i-1+hpstart])*pg[i-1+hpstart]*scale
            if done:
                hpstart+=npiece
                continue
            total+=sofar+(ww-hp[hpstart])*pg[hpstart]*scale
            hpstart+=npiece
        return total

        
if __name__=='__main__':
    from Opt import *
    model='USE30305_30MAY03.csv'
    opt=Opt()
#    opt.getmodel(model,[])
#    mst=len(opt.mnames)
#    mystocks=[opt.mnames[i] for i in range(mst) if i%20==0]
    mystocks=['USD.UPS', 'USD.39106410', 'USD.NWN']#,'USD.KIRK','USD.CTMI']
    nstocks=len(mystocks)
    npiece=20000
    initial=[1.0/nstocks]*nstocks
    hpiece=[2*float(i-npiece/2)/npiece for i in range(npiece+1) if not (i==(npiece/2) or i>2*(npiece/2))]*nstocks
    npiece=len(hpiece)/nstocks
    print 'nstocks is %d; npiece is %d'%(nstocks,npiece)
    pgrad=[4*i*i*i-2*i for i in hpiece]
    shortCostScale=1
    PC=piececostdef(nstocks=nstocks,npiece=npiece,initial=initial,hpiece=hpiece,pgrad=pgrad,shortCostScale=shortCostScale)
    opt.kappa=.5
    opt.initial=initial
    opt.getmodel(model,mystocks)
#    opt.simplepiece_ext(PC.modc,PC.util)
    opt.simplepiece_ext(PC,PC)
    opt.delta=.1
    opt.opt()
    opt.margutility()
    print opt.tcost,opt.utility
    print opt.gradutility
    opt.simplepiece_int(npiece,hpiece,pgrad)
    opt.opt()
    print opt.tcost,opt.utility
    print opt.gradutility
    
    mystocks=[opt.names[i] for i in range(nstocks) if abs(opt.w[i]-opt.initial[i])>1e-8]
    mystocks.sort()
    nstocks=len(mystocks)
    initial=[1.0/nstocks]*nstocks
    hpiece=[2*float(i-npiece/2)/npiece for i in range(npiece+1) if not (i==(npiece/2) or i>2*(npiece/2))]*nstocks
    npiece=len(hpiece)/nstocks
    print 'nstocks is %d; npiece is %d'%(nstocks,npiece)
    pgrad=[4*i*i*i-2*i for i in hpiece]
    shortCostScale=1
    PC=piececostdef(nstocks=nstocks,npiece=npiece,initial=initial,hpiece=hpiece,pgrad=pgrad,shortCostScale=shortCostScale)
    opt.kappa=.9
    opt.initial=initial
    opt.getmodel(model,mystocks)
#    opt.simplepiece_ext(PC.modc,PC.util)
    opt.simplepiece_ext(PC,PC)
    opt.delta=.1
    opt.opt()
    opt.margutility()
    print opt.tcost,opt.utility
    print opt.gradutility
    opt.simplepiece_int(npiece,hpiece,pgrad)
    opt.opt()
    print opt.tcost,opt.utility
    print opt.gradutility

    

