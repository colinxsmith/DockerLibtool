#include "ldefns.h"
/*extern	int	new_error; */
/*
	dsmxaupt( n, F, P, mode, b )	applies the U & P transformations made by dsmxfac
					to the vector b.

	mode	controls the direction and properties of the transformations
		it can be any of SMXFAC_NORMAL, SMXFAC_INVERSE, SMXFAC_TRANSPOSE
		 & SMXFAC_TRANSPOSE_INVERSE

*/
#pragma optimize( "", off )	/*	This routine cannot be optimised for loops (option g)*/
#pragma optimize( "apstwy", on )

void	dsmxaupt( dimen n, ldl_matrix F, short_vec P, int mode, vector b )
{
	int	p;
	dimen	k, km1,kp1;
	real	t;
	switch(mode)
	{
		case SMXFAC_NORMAL:
		{
			for(k = 0;k < n;F += k)
			{
				if( (p=P[k]) > 0 )
				{
					/*1x1 pivot*/
					kp1 = k + 1;
/*					if(kp1 > 1)*/
					if(k)
					{
/*						lm_wmsg("1x1 k = %d",k);*/
						daxpyvec( k, -b[k], F, b );
						if(--p!=(int) k)
						{
							t = b[k];
							b[k] = b[p];
							b[p] = t;
						}
					}
					k++;
				}
				else
				{
					/*2x2 pivot*/
					kp1 = k + 1;

/*					if(kp1 > 1)*/
					if(k)
					{
/*						lm_wmsg("2x2 k = %d",k);*/
						daxpyvec( k, -b[k], F, b );
						daxpyvec( k, -b[kp1], F+kp1, b );
						if((p = -(p+1)) !=  (int)k)
						{
							t = b[k];
							b[k] = b[p];
							b[p] = t;
						}
					}

					F += kp1;
					k += 2;
				}
			}
		}
			break;
		case SMXFAC_INVERSE:
			F += ((n*(n-1))>>1);
			for(k=n;--k;)
			{
			/*	if(k <= 0)
				{
					Numbered_Info(new_error,1,2126,"Error SMXFAC_INVERSE k is not positive");
				}*/
				if( (p=P[k])>0 ){
					/*1x1 pivot*/
					if(--p!=(int) k){
						t = b[k];
						b[k] = b[p];
						b[p] = t;
						}
					daxpyvec( k, b[k], F, b );
					F -= k;
					}
				else	{
					/*2x2 pivot*/
					if((km1 = k - 1)){
						if((p = -(p+1))!=(int)km1){
							t = b[km1];
							b[km1] = b[p];
							b[p] = t;
							}
						daxpyvec( km1, b[k], F, b );
						daxpyvec( km1, b[km1], F-=k, b );
						}
					F -= --k;
					if(k == 0)
					{
						k++;
						/*Numbered_Info(new_error,1,2139,"k fixed for SMXFAC_INVERSE");*/
					}
					}
			}
			break;
		case SMXFAC_TRANSPOSE:
			F += ((n*(n-1))>>1);
			for(k=n;--k;)
			{
			/*	if(k <= 0)
				{
					Numbered_Info(new_error,1,2126,"Error SMXFAC_TRANSPOSE k is not positive");
				}*/
				if( (p=P[k])>0 ){
					/*1x1 pivot*/
					if(--p!=(int) k){
						t = b[k];
						b[k] = b[p];
						b[p] = t;
						}
					b[k] -= ddotvec( k, F, b );
					F -= k;
					}
				else	{
					/*2x2 pivot*/
					if((km1 = k - 1)){
						if((p = -(p+1))!=(int) km1){
							t = b[km1];
							b[km1] = b[p];
							b[p] = t;
							}
						b[k] -= ddotvec( km1, F, b );
						b[km1] -= ddotvec( km1, F-=k, b );
						}
					F -= --k;
					if(k == 0)
					{
						k++;
						/*Numbered_Info(new_error,1,2139,"k fixed for SMXFAC_TRANSPOSE");*/
					}
					}
			}
			break;
		case SMXFAC_INVERSE_TRANSPOSE:
			for(k=0;k<n;F+=k){
				if( (p=P[k])>0 ){
					/*1x1 pivot*/
					kp1 = k+1;
					if(kp1 > 1)	{
						b[k] += ddotvec( k, F, b );
						if(--p!=(int) k){
							t = b[k];
							b[k] = b[p];
							b[p] = t;
							}
						}
					k++;
					}
				else	{
					/*2x2 pivot*/
					kp1 = k+1;
					if(kp1 > 1)	{
						b[k] += ddotvec( k, F, b );
						b[kp1] += ddotvec( k, F+kp1, b );
						if((p= -(p+1))!=(int) k){
							t = b[k];
							b[k] = b[p];
							b[p] = t;
							}
						}
					F += kp1;
					k += 2;
					}
				}
		}

}
#pragma optimize( "apstwy", off )
#pragma optimize( "", on )
