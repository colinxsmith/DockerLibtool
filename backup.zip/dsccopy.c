/*
	y = alpha*x for general vectors
*/
#include "ldefns.h"

void dsccopy(dimen n, real alpha, vector x, increment incx, vector y, increment incy)
{
    if(n > 0)
	{
		if (alpha == 0) dzero(n, y, incy );
		else if(alpha==1) dcopy(n, x, incx, y, incy);
		else	
		{
			if(incx<0) x -= ((long)(n - 1))*incx;
			if(incy<0) y -= ((long)(n - 1))*incy;
			if(alpha==-1) 
			{
				while(n--)
				{
					*y = -*x;
					x += incx;
					y += incy;
				}
			}
			else	 
			{
				while(n--)
				{
					*y = alpha * *x;
					x += incx;
					y += incy;
				}
			}
		}
	}
}
