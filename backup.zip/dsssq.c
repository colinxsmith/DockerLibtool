/*
	dsssq returns the values scl and smsq such that 
	( scl**2 )*smsq = x( 1 )**2 +...+ x( n )**2 + ( scale**2 )*sumsq, 

	where x( i ) = X( 1 + ( i - 1 )*INCX ). The value of sumsq is assumed 

	to be at least unity and the value of smsq will then satisfy 
	1.0 .le. smsq .le. ( sumsq + n ) . 
	scale is assumed to be non-negative and scl returns the value 
	scl = max( scale, abs( x( i ) ) ) . 
	scale and sumsq must be supplied in SCALE and SUMSQ respectively. 
	scl and smsq are overwritten on SCALE and SUMSQ respectively. 
	The routine makes only one pass through the vector X. 
*/
#include "ldefns.h"

void dsssq(dimen n, vector x, increment incx, real *pscale, real *psumsq)
{
	if(n>0){
		real absxi, d, sumsq= *psumsq, scale = *pscale;
		if(incx<0) x -= ((long)(n-1))*incx;
		while(n--){
			absxi = *x;
			x += incx;
			if(absxi==0) continue;
			if(absxi<0) absxi = -absxi;
			if(scale < absxi){
				/* Computing 2nd power */
		    		d = scale / absxi;
		    		sumsq = sumsq * (d * d) + 1;
		    		scale = absxi;
				}
			else	{
				/* Computing 2nd power */
				d = absxi / scale;
				sumsq += d * d;
				}
			}
		*pscale = scale;
		*psumsq = sumsq;
		}
}
