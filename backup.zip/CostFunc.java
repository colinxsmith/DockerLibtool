public interface	CostFunc
{
	public void modc(long n,double[] x,double[] c);
	public void modq(long n,double[] x,double[] c);
	public double util(long n,double[] x);
	public double f1d(double x);
	public void setHpiece(double[] hpiece);
	public double[] getHpiece();
	public void setPgrad(double[] pgrad);
	public double[] getPgrad();
	public void setInitial(double[] initial);
	public double[] getInitial();
	public void setNpiece(long npiece);
	public long getNpiece();
	public void setNstocks(long nstocks);
	public long getNstocks();
	public void setShortCostScale(double ShortCostScale);
	public double getShortCostScale();
}
