#include "ldefns.h"
void lm_dvwrit(dimen n, real *x)
{
    lm_gdvwri(n, x, 1);
}
