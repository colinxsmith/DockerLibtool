#include "ldefns.h"
void lm_dsmxwri(dimen n, sym_matrix S)
{
	dimen	i;
	for(i=0;i<n;){
		lm_gdvwri(++i,S,1);
		S += i;
		}
}
