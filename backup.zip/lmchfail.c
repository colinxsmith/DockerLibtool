/*
	lm_check_fail is the error-handling routine for the Library. 
	lm_check_fail either returns the value of ierror
	(soft failure), or terminates execution of the program 
	(hard failure). Diagnostic messages may be output. 
	If IERROR = 0 (successful exit from the calling routine), 
	the value 0 is returned through the routine name, and no 
	message is output 
	If IERROR is non-zero (abnormal exit from the calling routine), 
	the action taken depends on the value of IFAIL. 
	IFAIL>0: soft failure, silent exit (i.e. no messages are output) 
	IFAIL<0: soft failure, noisy exit (i.e. messages are output) 
	IFAIL== 0: hard failure, noisy exit 
*/
#include "ldefns.h"

short lm_check_fail(short ifail, short ierror, const char *srname)
{
	if(ierror){
		/*Abnormal exit from calling routine */
		if(ifail<=0){
			/*Noisy exit */
	    		lm_wmsg("Mathematics routine %s: exited with ifail=%6d",
				srname, ierror);
			if(!ifail) Crash("Hard failure");
			}
#if	0
		else	/*Soft failure*/
			lm_wmsg(" ** Soft failure - control returned");
#endif
		}
	return ierror;
}
