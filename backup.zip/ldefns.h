#ifndef	_LDEFNS_H
#define	_LDEFNS_H
#ifdef	__SYSNT__
#include	<windows.h>
#endif
#ifdef	MSDOSS
#include	<windows.h>
#endif
#ifndef	__cplusplus
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#if !defined(fabsf)
#define fabsf(xx) ((float) fabs((double)(xx)))
#endif
#if !defined(sqrtf)
#define sqrtf(xx) ((float) sqrt((double)(xx)))
#endif
#else
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#endif
#ifdef _AIX
#	define	stricmp strcasecmp
#	define STDARG
#ifdef __64BIT__
#define _LP64
#endif
#ifdef _LP64
#	define INTERGER long
#else
#	define INTERGER int
#endif
#ifdef _LP64
#	define T_SHORT long
#else
#	define T_SHORT int
#endif
#endif
#if	defined(__ZTC__)||defined(MSDOSS)||defined(__BORLANDC__)||defined(__SYSNT__)
#	define	__HAVE_ENUM__
#	define STDARG
#	define FPE_EXCEPTIONS_ON()
#	define INTERGER long
#	define __NO_CAST_LVALUE__
#	define __HAVE_ALLOCA__
#	define __HAVE_MALLOC_H__
#	define __HAVE_IO_H__
#	define __HASH_TOKEN__
#	if	defined(__SYSNT__) || defined(MSDOSS)
#		define T_SHORT long
#		define _NEAR
//#		undef LPTR
//#		define LPTR
#	else
#		define T_SHORT short
#		define _NEAR near
#		ifdef	MSDOSS
#			if defined(M_I86CM)||defined(M_I86LM)||defined(M_I86HM)
#				undef LPTR
#				define LPTR
#			endif
#		endif
#		ifdef	__BORLANDC__
#			if defined(__COMPACT__)||defined(__LARGE__)||defined(__HUGE__)
#				undef LPTR
#				define LPTR
#			endif
#		endif
#	endif
#else
#define LMEM_FIXED          0x0000
#define LMEM_ZEROINIT       0x0040
#define LPTR                (LMEM_FIXED | LMEM_ZEROINIT)
#endif
#if	defined(HP_UX)
#	define	STDARG
#	define	__HAVE_ENUM__
#	define	__FORCE_ALIGN__
#	define	FPE_EXCEPTIONS_ON() fpsetmask((fp_except)(FP_X_INV|FP_X_DZ|FP_X_OFL))
#	define	INTERGER int
#	define	T_SHORT int
#	define	stricmp strcasecmp
#	define	__NO_CAST_LVALUE__
#	define	__HAVE_USHORT__
#	define _NEAR
#	define __HASH_TOKEN__
#endif
#if	defined(__linux__)
#	define	STDARG
#	define	__HAVE_ENUM__
#	define	__FORCE_ALIGN__
#	define	FPE_EXCEPTIONS_ON()
#ifdef _LP64
#	define INTERGER long
#else
//#	define INTERGER int
#	define INTERGER long
#endif
#ifdef _LP64
#	define T_SHORT long
#else
#	define T_SHORT int
#endif
#	define	stricmp strcasecmp
#	define	__HAVE_USHORT__
#	define __HAVE_ALLOCA__
#	define _NEAR
#	define __HASH_TOKEN__
#endif
#if	defined(mips)||defined(MIPSEL)
#	define	STDARG
#	define	__HAVE_ENUM__
#	define	const
#	define	__FORCE_ALIGN__
#	define	FPE_EXCEPTIONS_ON() set_fpc_csr(get_fpc_csr()|0xe00)
#	define	INTERGER int
#	define	T_SHORT int
#	define	stricmp strcasecmp
#	define __HAVE_ALLOCA__
#	define _NEAR
#endif
#if	defined(sun)
#	if	defined(__svr4__)
#		define	__HAVE_USHORT__
#		define	__HAVE_ENUM__
#	endif
#	ifdef	__GNUC__
#		define STDARG
#		define	__HAVE_ENUM__
#		define __HAVE_ALLOCA__
#		define __HASH_TOKEN__
#	define	__FORCE_ALIGN__
#	else
#		define const
#	define __NO_CAST_LVALUE__
#	define _PROTO(A) A
#	define _UNPROTO(A)
#	endif
#	if	! ( defined(LDIV_T) || defined(__svr4__) )
#		define _NOLDIV_T
#	endif
#ifdef _LP64
#	define INTERGER long
#else
#	define INTERGER int
#endif
#	if !defined(__svr4__)
#		define	FPE_EXCEPTIONS_ON() ieee_handler("set","common",SIGFPE_ABORT)
#		define NEED_MEMMOVE
#	else
#		ifndef	FP_X_INV
#			include <ieeefp.h>
#		endif
#		define  FPE_EXCEPTIONS_ON() fpsetmask((fp_except)(FP_X_INV|FP_X_DZ|FP_X_OFL))
#	endif
#ifdef _LP64
#	define T_SHORT long
#else
#	define T_SHORT int
#endif
#	define stricmp strcasecmp
#	define _NEAR
#endif
#ifdef	STDARG
#	include <stdarg.h>
#	if defined(__GNUC__)||defined(HP_UX)||defined(__SYSNT__)
#		define	IVA_LIST(a)	_AP
#		define	VA_START(a)	va_list _AP; va_start(_AP,a)
#		define	VA_NEXT(T)	va_arg(_AP,T)
#		define	VA_END		va_end(_AP)
#	else
#		define	IVA_LIST(a)	(ARGADDR)((char *)&a + sizeof(char *))
#		define	VA_START(a)
#		define	VA_NEXT(T)	/*will cause error*/
#		define	VA_END		va_end(_AP)
#	endif
#	define _PROTO(A) A
#	define _UNPROTO(A)
#else
#	include <varargs.h>
#	define	IVA_LIST(a)	_AP
#	define	VA_START(a)	va_list IVA_LIST(a); va_start(IVA_LIST(a))
#	define	VA_NEXT(T)	va_arg(_AP,T)
#	define	VA_END		va_end(_AP)
#endif
#ifndef	_ARGADDR_T
#	define	_ARGADDR_T va_list
#endif
#ifndef	_PROTO
#	define _PROTO(A) ()
#	define _UNPROTO(A) A
#endif
/*
	we ensure here that every architecture dependent thing is defined
*/
#ifndef	FPE_EXCEPTIONS_ON
#define	FPE_EXCEPTIONS_ON()
#endif
#ifdef	sun
#ifndef newCC
#	include <memory.h>
#endif
#	ifndef _FLOATINGPOINT_H
#		include <floatingpoint.h>
#	endif
#ifndef newCC
	extern	int strcasecmp( const char *, const char * );
#endif
#endif
/*******************************************************************************
	global definitions for Library routines

	Copyright 1992 Decision Analysis Software Ltd.
	R. G. Becker August 1992
*/

/*******************************************************************************
	type definitions
*/
#if defined(__linux__) || defined(sun)
#ifdef _LP64
typedef long Integer;//For recent LAPACK
#else
typedef int Integer;//For recent LAPACK
#endif
#else
typedef long Integer;//For recent LAPACK
#endif

typedef _ARGADDR_T ARGADDR;
#undef	_ARGADDR_T
#ifdef	_NOLDIV_T
#ifndef newCC
typedef struct {
        long quot;
        long rem;
} ldiv_t;
#endif
#endif
typedef	T_SHORT			increment;
typedef	T_SHORT		stride;		/*used for vector strides*/
#if !defined(_AIX)&&!defined(__linux__) && !defined(newCC) && !defined(MSDOSS) && !defined(i386) && !defined(sun)
typedef	unsigned T_SHORT	ushort;
typedef unsigned long	ulong;
#else
#include <sys/types.h>
#if defined(MINGW32)
typedef unsigned long	ushort;
typedef unsigned long	ulong;
#endif
#if defined(MSDOSS)
typedef unsigned long	ulong;
#	define	stricmp strcasecmp
#endif
#endif
typedef	unsigned T_SHORT	undex;
typedef	unsigned T_SHORT	dimen;
typedef	unsigned long	ldimen;
typedef unsigned char	byte;
typedef	double		real;
typedef	real*		vector;
typedef	real*		matrix;
typedef	real*		sym_matrix;
typedef	real*		fac_matrix;
typedef	sym_matrix	ldl_matrix;
typedef	sym_matrix	l_matrix;
typedef undex*		undex_vec;
typedef T_SHORT*	short_vec;
typedef T_SHORT		short_scl;
typedef int*		int_vec;
typedef byte*		byte_vec;
typedef byte*		bit_set;
typedef	struct		{
			real	r;
			dimen	d;
			} real_plus_dim;
typedef	struct	{
		real	negscale;
		real	negsum;
		real	posscale;
		real	possum;
		} dd_acc_rec;

/*min-max constraints definitions*/
typedef	struct	{
		dimen	a;	/*the slope*/
		dimen	b;	/*the base point*/
		dimen	x;	/*where the currently implemented bit is in our arrays*/
		int	t;	/*if it's a maximum type*/
		} NXConIT;	/*Min Max Constraint Info Type*/
typedef	struct	{
		dimen	n;		/*length of each constraint*/
		dimen	m;		/*number of max min constraints*/
		dimen	lstorage;	/*the length of the storage*/
		vector	storage;	/*storage for everything*/
		NXConIT	c[1];		/*storage area for each constraint*/
		}	MinMaxConT;
typedef	MinMaxConT	*pMinMaxConT;

typedef	struct	{
		dimen	oneb;
		dimen	twob;
		dimen	ncor;
		real	maxc, maxA, maxE, minA, minE;
		} dsmxmpd_info_rec;

#ifndef	__cdecl
#define	__cdecl
#endif

typedef	int		(*vec_function)_PROTO((dimen /*n*/,vector /*x*/,dimen /*m*/, vector /*y*/));
typedef void		(*H_mul_fp)_PROTO((dimen /*n*/, dimen /*nrh*/, dimen /*nc*/, dimen /*jc*/, vector /*H*/, vector /*x*/, vector /*hx*/));
typedef	real		(*v_r_func)_PROTO((dimen /*n*/,vector /*x*/));
typedef	real		(*r_r_func)_PROTO((real /*x*/,short * /*flag*/));
typedef void		(*ipsw_func)_PROTO((dimen /*k*/, dimen /*j*/));
typedef	void		(*pMxVecMul)_PROTO((dimen /*n*/, dimen /*m*/, matrix /*A*/, vector /*y*/, vector /*x*/));
typedef	void		(*pLDLVecSol)_PROTO((dimen /*n*/, ldl_matrix /*A*/, vector /*y*/, vector /*x*/));
typedef	void		(*pLDLUpdate)_PROTO((dimen /*n*/, ldl_matrix /*A*/, real /*alpha*/, vector /*u*/));
typedef	void		(*pSymMxVecMul)_PROTO((dimen /*n*/, sym_matrix /*Q*/, vector /*y*/, vector /*x*/));
typedef	int		(__cdecl *pQsortCmpFn )_PROTO((const void *, const void *));
typedef	void	(*Ex_Deriv)_PROTO((dimen /*n*/,vector /*derivs*/,vector /*w*/,
								  vector /*Parameter*/));
typedef	real	(*Ex_Utility)_PROTO((dimen /*n*/,vector /*w*/,vector /*c*/,
									vector /*Q*/,vector /*Parameter*/,H_mul_fp /*Hmul*/));
typedef short		(*Opt_Routine)_PROTO((dimen	/*n*/,vector	/*w*/,dimen	/*m*/,matrix	/*A*/,vector	/*L*/,
				   vector	/*U*/,vector	/*alpha*/,vector	/*target*/,
				   vector	/*Q*/,real	/*gamma*/,real	/*featol*/,short	/*qpsol_ifail*/,
				   H_mul_fp	/*Hmul*/,int	/*Fully_Invested*/,real /*Rmin*/,real /*Rmax*/,real LSValue,dimen maxiter));
#undef	T_SHORT

/*******************************************************************************
	Conversion macros
*/
#ifndef	CINCR
#define	CINCR(I) ((INTERGER)I)
#endif
#define CN(i) ((dimen)(i))
#define CNN(i) ((long)(i))
#define CI(i) ((increment)(i))
#define CD(i) ((double)(i))
#define CR(i) ((real)(i))
#define CU(i) ((unsigned)(i))
#define CS(i) ((increment)(i))
#define CUS(i) ((ushort)(i))
#define CL(i) ((long)(i))
#define CUL(i) ((ulong)(i))
#define CC(i)	((char)(i))
#define CB(i)	((byte)(i))
#define CBP(i)	((byte *)(i))

typedef INTERGER integer;
typedef char *address;
typedef short int shortint;
typedef long int logical;
typedef short int shortlogical;

#define TRUE_ (1)
#define FALSE_ (0)
#ifndef	abs
#ifndef newCC
#	define abs(x) ((x) >= 0 ? (x) : -(x))
#endif
#endif
#ifndef	min
#	define min(a,b) ((a) <= (b) ? (a) : (b))
#endif
#ifndef	max
#	define max(a,b) ((a) >= (b) ? (a) : (b))
#endif
#define dabs(x)		fabs(x)
#define dmax(a,b)	((real)((a)>(b)?(a):(b)))
#define dmin(a,b)	((real)((a)<(b)?(a):(b)))

/*******************************************************
	external variables
*/
#ifdef	__cplusplus
extern	"C"{
#endif
extern	ushort __lm_item_write_count;
#ifdef	__cplusplus
	}
#endif

/*******************************************************
	external functions
*/
#ifdef	__cplusplus
extern	"C"{
#endif
/*externstart*/

#if !defined(DLLEXPORT)
#if	defined(__SYSNT__)
#define stricmp _stricmp
#define	DLLEXPORT	__declspec( dllexport )
#else
#define	DLLEXPORT	
#endif
#endif
DLLEXPORT short LPQN(size_t n,size_t m, vector w,vector A,vector b,vector c);
DLLEXPORT void		Hess__FAC(dimen /*n*/,dimen /*nrowh*/,dimen /*ncolh*/,dimen /*jcol*/,
						  double * /*H*/,vector /*x*/,vector /*y*/,dimen /*N*/,dimen /*nf*/);
DLLEXPORT short		General_Opt(char ** /*stocknames*/,dimen	/*n*/,vector	/*w*/,
					dimen	/*m*/,matrix	/*A*/,
					vector	/*L*/,
					vector	/*U*/,vector	/*alphas*/,vector	/*target*/,
					vector	/*Q*/,real	/*gamma*/,real	/*featol*/,short	/*qpsol_ifail*/,
				   H_mul_fp	/*Hmul*/,vector	/*initial*/,real	/*delta*/,vector	/*buy*/,
				   vector	/*sell*/,real	/*kappa*/,int	/*Fully_Invested*/,real /*Rmin*/,
				   real /*Rmax*/,vector	/*min_lot*/,
				   vector	/*size_lot*/,int * /*shake*/,int /*m_LS*/,int /*m_Costs*/,
				   int /*m_Revise*/,
				   int /*m_Round*/,dimen * /*stocks*/,dimen * /*trades*/,
				   real /*drop_factor*/,int /*drop_meth*/,int	/*numfac*/,real	/*min_holding*/,real /*min_trade*/,
				   real LSValue,dimen ncomp);
DLLEXPORT	void	implied_mod(dimen /*n*/,H_mul_fp /*Hmul*/,matrix /*Q*/,vector /*target*/,vector /*implied*/);
DLLEXPORT	void	Cash_Modification(dimen /*n*/,dimen * /*NN*/,real * /*Neg*/,real * /*Pos*/);
//DLLEXPORT short		Simple_Opt(dimen	/*n*/,vector	/*w*/,dimen	/*m*/,matrix	/*A*/,vector	/*L*/,
//				   vector	/*U*/,vector	/*alpha*/,vector	/*target*/,
//				   vector	/*Q*/,real	/*gamma*/,real	/*featol*/,short	/*qpsol_ifail*/,
//				   H_mul_fp	/*Hmul*/,dimen /*maxiter*/);

DLLEXPORT short		Simple_Mixed_Opt(dimen	/*n*/,vector	/*w*/,dimen	/*m*/,matrix	/*A*/,vector	/*L*/,
				   vector	/*U*/,vector	/*alpha*/,vector	/*target*/,
				   vector	/*Q*/,real	/*gamma*/,real	/*featol*/,short	/*qpsol_ifail*/,
				   H_mul_fp	/*Hmul*/,int	/*Fully_Invested*/,real /*Rmin*/,real /*Rmax*/,
				   real LSValue,dimen /*maxiter*/);

DLLEXPORT short		Revision_Opt(dimen	/*n*/,vector	/*w*/,dimen	/*m*/,matrix	/*A*/,vector	/*L*/,
				   vector	/*U*/,vector	/*alpha*/,vector	/*target*/,
				   vector	/*Q*/,real	/*gamma*/,real	/*featol*/,short	/*qpsol_ifail*/,
				   H_mul_fp	/*Hmul*/,vector	/*initial*/,real	/*delta*/,vector	/*buy*/,
				   vector	/*sell*/,real	/*kappa*/,vector	/*min_lot*/,
				   vector	/*size_lot*/,int * /*shake*/,int /*take_off*/,dimen /*maxiter*/);

DLLEXPORT short		Revision_Mixed_Opt(dimen	/*n*/,vector	/*w*/,dimen	/*m*/,matrix	/*A*/,vector	/*L*/,
				   vector	/*U*/,vector	/*alpha*/,vector	/*target*/,
				   vector	/*Q*/,real	/*gamma*/,real	/*featol*/,short	/*qpsol_ifail*/,
				   H_mul_fp	/*Hmul*/,vector	/*initial*/,real	/*delta*/,vector	/*buy*/,
				   vector	/*sell*/,real	/*kappa*/,int	/*Fully_Invested*/,real /*Rmin*/,
				   real /*Rmax*/,vector	/*min_lot*/,
				   vector	/*size_lot*/,int * /*shake*/,int /*take_off*/,real /*enforced_cost*/,
				   real LSValue,dimen /*maxiter*/);

DLLEXPORT short		Revision_Mixed_Opt_t(dimen	/*n*/,vector	/*w*/,dimen	/*m*/,matrix	/*A*/,vector	/*L*/,
				   vector	/*U*/,vector	/*alpha*/,vector	/*target*/,
				   vector	/*Q*/,real	/*gamma*/,real	/*featol*/,short	/*qpsol_ifail*/,
				   H_mul_fp	/*Hmul*/,vector	/*initial*/,real	/*delta*/,vector	/*buy*/,
				   vector	/*sell*/,real	/*kappa*/,int	/*Fully_Invested*/,real /*Rmin*/,
				   real /*Rmax*/,vector	/*min_lot*/,
				   vector	/*size_lot*/,int * /*shake*/,int /*take_off*/,real /*enforced_cost*/,
				   real LSValue,dimen /*maxiter*/);


DLLEXPORT	void	fix_covariance(dimen /*n*/,vector /*Q*/);
DLLEXPORT	int	fix_covariancem(dimen /*n*/,vector /*Q*/);
DLLEXPORT	short	decomp_cov(dimen /*n*/,vector /*Q*/,vector /*Q_Decomp*/);

DLLEXPORT	void	factor_model_process(dimen /*n*/,dimen /*nf*/,vector /*FL*/,vector /*FC*/,
									 vector /*SV*/,vector /*Q*/);
DLLEXPORT	void	apt_model_process(dimen /*n*/,dimen /*nf*/,vector /*FL*/,vector /*FC*/,
									 vector /*SV*/,vector /*Q*/);
DLLEXPORT void		 make_ladder(dimen	/*n*/,vector	/*w*/,vector	/*c_keep*/,
								vector	/*keep_L*/,vector	/*min_lot*/,
								vector	/*size_lot*/,vector	/*L*/,vector	/*U*/,
								vector	/*c*/,int	* /*shake*/,short /*qpsol_ifail*/,
								dimen	/*count6*/);

DLLEXPORT short		Round_Opt(dimen /*n*/,vector /*w*/,dimen /*m*/,matrix /*A*/,
								vector /*L*/,vector /*U*/,vector /*alpha*/,
								vector /*target*/,vector /*initial*/,vector /*Q*/,real /*gamma*/,
								real /*featol*/,short /*qpsol_ifail*/,H_mul_fp /*Hmul*/,
								vector /*min_lot*/,vector /*size_lot*/,
								int	/*Fully_Invested*/,real /*Rmin*/,
								real /*Rmax*/,Opt_Routine /*Opt*/,
								int * /*shake*/,real LSValue,dimen /*maxiter*/);

DLLEXPORT void	 large_eigen(dimen /*n*/,H_mul_fp /*Cmul*/,real * /*eval*/,vector /*Q*/,vector /*evec*/);

DLLEXPORT	unsigned long	guniqid( void );
DLLEXPORT	real dsum(dimen /*n*/, vector /*x*/, increment /*incx*/);
DLLEXPORT	real dv_dmean(dimen /*n*/, vector /*v*/);
DLLEXPORT	void dwvecfnc(dimen /*T*/, real /*d*/, vector /*x*/, real * /*pS*/, real * /*pA*/, real * /*pSS*/);
DLLEXPORT	void dmxaccscopvec(dimen /*n*/, dimen /*m*/, matrix /*A*/, real /*alpha*/, vector /*v*/, vector /*w*/);
DLLEXPORT	void dmx_symmetrise(dimen /*n*/, matrix /*S*/);
DLLEXPORT	short dsmxeigen(dimen /*n*/, matrix /*S*/, dimen /*m*/, vector /*d*/, matrix /*V*/, dimen /*itmax*/, short /*fail*/, vector /*v*/);
DLLEXPORT	void dmxmulmx(dimen /*n*/, dimen /*m*/, dimen /*l*/, matrix /*A*/, matrix /*B*/, matrix /*C*/);
DLLEXPORT	short dstdmxqli(dimen /*n*/, vector /*d*/, vector /*e*/, matrix /*V*/, dimen /*itmax*/, short /*fail*/);
DLLEXPORT	void lm_mgdvwri(const char * /*name*/, dimen /*n*/, real * /*x*/, increment /*incx*/);
DLLEXPORT	void dsmxtridiag(dimen /*n*/, matrix /*S*/, vector /*d*/, vector /*e*/);
DLLEXPORT	void lm_dmxwri(dimen /*n*/, dimen /*m*/, matrix /*x*/);
DLLEXPORT	void lm_mdmxwri(const char * /*name*/, dimen /*n*/, dimen /*m*/, real * /*x*/);
//DLLEXPORT	void dlpprt(	int /*lp*/, dimen /*nrowa*/, dimen /*Nrowrt*/, dimen /*n*/, dimen /*nclin*/, dimen /*nfree*/, dimen /*isdel*/, dimen /*nactiv*/,
//		dimen /*ncolz*/, dimen /*iter*/, dimen /*jadd*/, dimen /*jdel*/, real /*alfa*/, real /*condt*/,
//		dimen /*numinf*/, real /*suminf*/, real /*objlp*/, short_vec /*istate*/, short_vec /*kfree*/, matrix /*a*/,
//		matrix /*rt*/, vector /*x*/, vector /*wrk1*/, vector /*wrk2*/);
DLLEXPORT	void dlpgrad(	int /*lp*/, dimen /*n*/, dimen /*nctotl*/, dimen /*nrowa*/, real /*bigbnd*/, real /*feamin*/,
		integer	* /*numinf*/, real * /*suminf*/, short_vec /*istate*/, matrix /*a*/, vector /*bl*/,
		vector /*bu*/, vector /*cvec*/, vector /*featol*/, vector /*grad*/, vector /*x*/);
DLLEXPORT	void dlpdump(dimen /*n*/, dimen /*nclin*/, dimen /*nctotl*/, dimen /*nrowa*/, int /*lcrash*/, int /*lp*/, int /*minsum*/, int /*vertex*/, short_vec /*istate*/, matrix /*a*/, vector /*ax*/, vector /*bl*/, vector /*bu*/, vector /*cvec*/, vector /*x*/);
//DLLEXPORT	void dlpcrsh(int /*orthog*/, logical * /*unitq*/, int /*vertex*/, byte /*lcrash*/, dimen /*n*/, integer * /*nclin*/, integer * /*nctotl*/, integer * /*Nq*/, integer * /*nrowa*/, integer * /*Nrowrt*/, integer * /*Ncolrt*/, integer * /*nactiv*/, integer * /*ncolz*/, integer * /*nfree*/, short_vec /*istate*/, short_vec /*kactiv*/, short_vec /*kfree*/, real * /*bigbnd*/, real * /*tolact*/, real * /*xnorm*/, real * /*a*/, real * /*anorm*/, real * /*ax*/, real * /*bl*/, real * /*bu*/, real * /*x*/, real * /*qtg*/, real * /*rt*/, real * /*zy*/, real * /*p*/, real * /*wrk1*/, real * /*wrk2*/);
//DLLEXPORT	void dlpcore(	int /*lp*/, int /*minsum*/, int /*orthog*/, logical * /*unitq*/, int /*vertex*/, integer * /*inform*/,
//		integer * /*iter*/, integer * /*itmax*/, byte /*lcrash*/, dimen /*n*/, integer * /*nclin*/,
//		integer * /*nctotl*/, integer * /*nrowa*/, integer * /*nactiv*/, integer * /*nfree*/, integer * /*numinf*/,
//		short_vec /*istate*/, short_vec /*kactiv*/, short_vec /*kfree*/, real * /*obj*/, real * /*xnorm*/,
//		real * /*a*/, real * /*ax*/, real * /*bl*/, real * /*bu*/, real * /*clamda*/, real * /*cvec*/,
//		real * /*featol*/, real * /*x*/, short_vec /*iw*/, real * /*w*/);
//DLLEXPORT	void dlpbgst(	dimen /*n*/, dimen /*nactiv*/, dimen /*nfree*/, integer * /*jbigst*/, integer * /*kbigst*/,
//		short_vec /*istate*/, short_vec /*kactiv*/, real /*dinky*/, real /*feamin*/, real * /*trulam*/,
//		vector /*featol*/, vector /*rlamda*/);
//DLLEXPORT	short dqpsol(short /*itmax*/, short /*msglvl*/, dimen /*n*/, dimen /*nclin*/, dimen /*nctotl*/, dimen /*nrowa*/, dimen /*nrowh*/, dimen /*ncolh*/, real * /*bigbnd*/, real * /*a*/, real * /*bl*/, real * /*bu*/, real * /*cvec*/, real * /*featol*/, real * /*hess*/, H_mul_fp /*qphess*/, int /*cold*/, int /*lp*/, int /*orthog*/, real * /*x*/, short_vec /*istate*/, short * /*iter*/, real * /*obj*/, real * /*clamda*/, short_vec /*iw*/, ulong /*leniw*/, vector /*w*/, ulong /*lenw*/, short /*ifail*/);

DLLEXPORT	real	fitsize(vector /*ww*/,char * /*name*/,vector /*Q*/,int /*have_tcosts*/);
DLLEXPORT	int    Bound_check(vector /*w*/,dimen /*PO_N0*/,real featol);

DLLEXPORT	short	gen_opt(short /*itmax*/, short /*msglvl*/, dimen /*n*/, dimen /*m*/, 
				dimen /*npm*/, dimen /*nrowa*/, dimen /*nrowh*/, dimen /*ncolh*/, 
				real * /*bigbnd*/, real * /*A*/, real * /*L*/, real * /*U*/, real * /* c*/, 
				real * /* featol*/, real * /* Q*/, H_mul_fp /*Hmul*/, int /*cold*/, 
				int /*lp*/, int /*orthog*/, real * /*w*/, short_vec /*istate*/,
				short * /*iter*/, real * /*obj*/, real * /*lamda*/, short_vec /*iw*/, 
				ulong /*leniw*/, vector /*work*/, ulong /*lenw*/, short /*ifail*/,
				vector /*nonlinwrk*/,Ex_Deriv /*Ex_Grad*/,Ex_Deriv /*Ex_Hess*/,
				Ex_Utility /*utility*/,vector /*gg*/,vector /*hh*/,
				vector /*P*/,H_mul_fp /*Hmul_Ex*/);
DLLEXPORT	void detagen(dimen /*n*/, real * /*alpha*/, vector /*x*/, stride /*incx*/, integer * /*iswap*/, integer * /*itrans*/);
DLLEXPORT	void delmgen(int /*orthog*/, real * /*x*/, real * /*y*/, real * /*cs*/, real * /*sn*/);
DLLEXPORT	void delm(int /*orthog*/, dimen /*n*/, vector /*x*/, increment /*incx*/, vector /*y*/, increment /*incy*/, real /*cs*/, real /*sn*/);
//DLLEXPORT	void dqpprt(int /*orthog*/, integer /*isdel*/, integer /*iter*/, integer /*jadd*/, integer /*jdel*/, dimen /*nactiv*/, dimen /*ncolz*/, dimen /*nfree*/, dimen /*n*/, dimen /*nclin*/, dimen /*nrowa*/, dimen /*Nrowrt*/, dimen /*nhess*/, short_vec /*istate*/, short_vec /*kfree*/, real /*alfa*/, real /*condh*/, real /*condt*/, real /*obj*/, real /*gfnorm*/, real /*ztgnrm*/, real /*emax*/, matrix /*a*/, matrix /*rt*/, vector /*x*/, vector /*wrk1*/, vector /*wrk2*/);
//DLLEXPORT	short dqpgrad(short /*mode*/, int /*unitq*/, H_mul_fp /*qphess*/, dimen /*n*/, dimen /*nactiv*/, dimen /*nfree*/,
//		dimen * /*nhess*/, dimen /*Nq*/, dimen /*nrowh*/, dimen /*ncolh*/, dimen /*jadd*/,
//		short_vec /*kactiv*/, short_vec /*kfree*/, real /*alfa*/, real * /*objqp*/, real * /*gfixed*/, real /*gtp*/,
//		vector	/*cvec*/, vector /*hess*/, vector /*p*/, vector /*qtg*/, vector /*scale*/, vector /*x*/, vector /*zy*/,
//		vector /*wrk1*/, vector /*wrk2*/);
//DLLEXPORT	void dqpdump(dimen /*n*/, dimen /*nrowh*/, dimen /*ncolh*/, vector /*cvec*/, real * /*hess*/, H_mul_fp /*qphess*/, vector /*wrk*/, vector /*hx*/);
//DLLEXPORT	dimen dqpcrsh(int /*unitq*/, H_mul_fp /*qphess*/, dimen /*n*/, dimen /*ncolz*/, dimen /*nfree*/, dimen * /*nhess*/, dimen /*Nq*/, dimen /*nrowh*/, dimen /*ncolh*/, dimen /*Nrowrt*/, short_vec /*kfree*/, real * /*hsize*/, real * /*hess*/, matrix /*rt*/, vector /*scale*/, matrix /*zy*/, vector /*hz*/, vector /*wrk*/);
//DLLEXPORT	void dqpcore(int /*orthog*/, logical * /*unitq*/, integer * /*inform*/, integer * /*iter*/, integer * /*itmax*/, dimen /*n*/, integer * /*nclin*/, integer * /*nctotl*/, integer * /*nrowa*/, integer * /*nrowh*/, integer * /*ncolh*/, integer * /*nactiv*/, integer * /*nfree*/, H_mul_fp /*qphess*/, short_vec /*istate*/, short_vec /*kactiv*/, short_vec /*kfree*/, real * /*objqp*/, real * /*xnorm*/, real * /*a*/, real * /*ax*/, real * /*bl*/, real * /*bu*/, real * /*clamda*/, real * /*cvec*/, real * /*featol*/, real * /*hess*/, real * /*scale*/, real * /*x*/, short_vec /*iw*/, real * /*w*/);
//DLLEXPORT	void dqpcolr(logical * /*nocurv*/, logical * /*posdef*/, logical * /*renewr*/, logical * /*unitq*/, H_mul_fp /*qphess*/, dimen /*n*/, integer * /*ncolr*/, integer * /*nfree*/, integer * /*Nq*/, integer * /*nrowh*/, integer * /*ncolh*/, integer * /*Nrowrt*/, integer * /*nhess*/, short_vec /*kfree*/, real * /*cslast*/, real * /*snlast*/, real * /*drmax*/, real * /*emax*/, real * /*hsize*/, real * /*rdlast*/, real * /*hess*/, real * /*rt*/, real * /*scale*/, real * /*zy*/, real * /*hz*/, real * /*wrk*/);
//DLLEXPORT	void dqpchkp(dimen /*n*/, dimen /*nclin*/, dimen /*issave*/, dimen /*jdsave*/, vector /*ap*/, vector /*p*/);
DLLEXPORT	void dzyprod(short /*mode*/, dimen /*n*/, dimen /*nactiv*/, dimen /*ncolz*/, dimen /*nfree*/, dimen /*nq*/, logical /*unitq*/, short_vec /*kactiv*/, short_vec /*kfree*/, vector /*v*/, matrix /*zy*/, vector /*wrk*/);
//DLLEXPORT	void dtqadd(int /*orthog*/, logical * /*unitq*/, integer * /*inform*/, integer * /*k1*/, integer * /*k2*/, integer * /*nactiv*/, integer * /*ncolz*/, integer * /*nfree*/, integer * /*n*/, integer * /*nq*/, integer * /*nrowa*/, integer * /*nrowrt*/, integer * /*ncolrt*/, short_vec /*istate*/, short_vec /*kactiv*/, short_vec /*kfree*/, real * /*condmx*/, real * /*a*/, real * /*qtg*/, real * /*rt*/, real * /*zy*/, real * /*wrk1*/, real * /*wrk2*/);
//DLLEXPORT	void	dprtsol(	dimen /*nfree*/, dimen /*nrowa*/, dimen /*n*/, dimen /*nclin*/, dimen /*ncnln*/, dimen /*nctotl*/,
//			real /*bigbnd*/, dimen /*nactiv*/, short_vec /*istate*/, short_vec /*kactiv*/,
//			matrix /*a*/, vector /*bl*/, vector /*bu*/, vector /*c*/, vector /*clamda*/, vector /*rlamda*/,
//			vector /*x*/);
//DLLEXPORT	void dgetlamd(char * /*lprob*/, dimen /*n*/, dimen /*nactiv*/, dimen /*ncolz*/, dimen /*nfree*/, dimen /*nrowa*/, dimen /*Nrowrt*/, dimen * /*jsmlst*/, dimen * /*ksmlst*/, real * /*smllst*/, short_vec /*istate*/, short_vec /*kactiv*/, real * /*a*/, real * /*anorm*/, real * /*qtg*/, real * /*rlamda*/, real * /*rt*/);
//DLLEXPORT	void dfindp(logical * /*nullr*/, logical * /*unitpg*/, logical * /*unitq*/, dimen /*n*/, integer * /*nclin*/, integer * /*Nq*/, integer * /*nrowa*/, integer * /*Nrowrt*/, integer * /*ncolr*/, integer * /*ncolz*/, integer * /*nfree*/, short_vec /*istate*/, short_vec /*kfree*/, int /*negligible*/, real * /*gtp*/, real * /*pnorm*/, real * /*rdlast*/, real * /*a*/, real * /*ap*/, real * /*p*/, real * /*qtg*/, real * /*rt*/, real * /*v*/, real * /*zy*/, real * /*work*/);
//DLLEXPORT	void ddelcon(int /*modfyg*/, int /*orthog*/, int /*unitq*/, dimen /*jdel*/, dimen /*kdel*/, dimen /*nactiv*/, dimen /*ncolz*/, dimen /*nfree*/, dimen /*n*/, dimen /*Nq*/, dimen /*nrowa*/, dimen /*Nrowrt*/, short_vec /*kactiv*/, short_vec /*kfree*/, matrix /*a*/, vector /*qtg*/, matrix /*rt*/, matrix /*zy*/);
//DLLEXPORT	short dchkdat(ulong /*liwork*/, ulong /*lwork*/, ulong /*litotl*/, ulong /*lwtotl*/, dimen /*nrowa*/, dimen /*n*/, dimen /*nclin*/, dimen /*nctotl*/, short_vec /*istate*/, short_vec /*kactiv*/, int /*lcrash*/, real * /*bigbnd*/, real * /*a*/, real * /*bl*/, real * /*bu*/, real * /*featol*/, real * /*x*/);
//DLLEXPORT	short dbndalf(int /*firstv*/, int * /*hitlow*/, short_vec /*istate*/, integer * /*jadd*/, dimen /*n*/, dimen /*nctotl*/, dimen /*numinf*/, real * /*alfa*/, real * /*palfa*/, real * /*atphit*/, real * /*bigalf*/, real * /*bigbnd*/, real * /*pnorm*/, real * /*anorm*/, real * /*ap*/, real * /*ax*/, real * /*bl*/, real * /*bu*/, real * /*featol*/, real * /*p*/, real * /*x*/);
//DLLEXPORT	void dbdpert(int /*firstv*/, int /*negstp*/, real * /*bigalf*/, real * /*bigbnd*/, real * /*pnorm*/, integer * /*jadd1*/, integer * /*jadd2*/, real * /*palfa1*/, real * /*palfa2*/, short_vec /*istate*/, dimen /*n*/, dimen /*nctotl*/, real * /*anorm*/, real * /*ap*/, real * /*ax*/, real * /*bl*/, real * /*bu*/, real * /*featol*/, real * /*p*/, real * /*x*/);
//DLLEXPORT	void dalloc(byte /*nalg*/, dimen /*n*/, dimen /*nclin*/, dimen /*ncnln*/, dimen /*nctotl*/, short_vec /*iw*/, vector /*w*/, ulong * /*litotl*/, ulong * /*lwtotl*/);
//DLLEXPORT	short daddcon(int /*modfyg*/, int /*modfyr*/, int /*orthog*/, logical * /*unitq*/, integer * /*ifix*/, integer * /*iadd*/, integer * /*jadd*/, integer * /*nactiv*/, integer * /*ncolr*/, integer * /*ncolz*/, integer * /*nfree*/, dimen /*n*/, integer * /*Nq*/, integer * /*nrowa*/, integer * /*Nrowrt*/, short_vec /*kfree*/, real * /*condmx*/, real * /*cslast*/, real * /*snlast*/, real * /*a*/, real * /*qtg*/, real * /*rt*/, real * /*zy*/, real * /*wrk1*/, real * /*wrk2*/);
DLLEXPORT	short dtmxsolve(short /*job*/, dimen /*n*/, matrix /*t*/, dimen /*nrt*/, vector /*b*/, short /*idiag*/);
DLLEXPORT	void drtmxsolve(int /*job*/, dimen /*n*/, real * /*t*/, dimen /*nrt*/, real * /*b*/, integer * /*idiag*/);
DLLEXPORT	void BITA_drotg(real * /*a*/, real * /*b*/, real * /*c*/, real * /*s*/);
DLLEXPORT	real dprotdiv(real * /*a*/, real * /*b*/, int * /*fail*/);
DLLEXPORT	real sc_norm(real /*scale*/, real /*ssq*/);
DLLEXPORT	real BITA_ddot(dimen /*n*/, real * /*x*/, increment /*incx*/, real * /*y*/, increment /*incy*/);
DLLEXPORT	void BITA_daxpy(dimen /*n*/, real /*alpha*/, vector /*x*/, stride /*incx*/, vector /*y*/, stride /*incy*/);
DLLEXPORT	void dswap(register dimen /*n*/, vector /*a*/, increment /*i*/, vector /*b*/, increment /*j*/);
DLLEXPORT	void ddmxmulv(dimen /*n*/, vector /*d*/, increment /*incd*/, vector /*x*/, increment /*incx*/);
DLLEXPORT	void dxminmax(dimen /*n*/, vector /*x*/, stride /*incx*/, real * /*xmax*/, real * /*xmin*/);
DLLEXPORT	void dsymplanerotate(dimen /*n*/, vector /*x*/, increment /*incx*/, vector /*y*/, increment /*incy*/, real /*c*/, real /*s*/);
DLLEXPORT	void dhhrflctgen(integer * /*n*/, real * /*alpha*/, real * /*x*/, integer * /*incx*/, real * /*tol*/, real * /*z1*/);
DLLEXPORT	short lm_check_fail(short /*ifail*/, short /*ierror*/, const char * /*srname*/);
DLLEXPORT	double dsign(double /*a*/, double /*b*/);
DLLEXPORT	real dnrm2(dimen /*n*/, vector /*x*/, increment /*incx*/);
DLLEXPORT	void dsssq(dimen /*n*/, vector /*x*/, increment /*incx*/, real * /*pscale*/, real * /*psumsq*/);
DLLEXPORT	void BITA_dscal(dimen /*n*/, real /*alpha*/, vector /*x*/, increment /*incx*/);
DLLEXPORT	void dzero(dimen /*n*/, vector /*x*/, increment /*incx*/);
DLLEXPORT	void dset(dimen /*n*/, real /*alpha*/, vector /*x*/, increment /*incx*/);
DLLEXPORT	void dscalvec(dimen /*n*/, real /*alpha*/, vector /*x*/);
DLLEXPORT	void dzerovec(dimen /*n*/, vector /*x*/);
DLLEXPORT	void dsetvec(dimen /*n*/, real /*alpha*/, vector /*x*/);
DLLEXPORT	real dcossint(real /*t*/, real * /*s*/);
DLLEXPORT	void dcopy(dimen /*n*/, vector /*x*/, increment /*incx*/, vector /*y*/, increment /*incy*/);
DLLEXPORT	void dcopyvec(dimen /*n*/, vector /*x*/, vector /*y*/);
DLLEXPORT	void dsccopyvec(dimen /*n*/, real /*alpha*/, vector /*x*/, vector /*y*/);
DLLEXPORT	void dsccopy(dimen /*n*/, real /*alpha*/, vector /*x*/, increment /*incx*/, vector /*y*/, increment /*incy*/);
DLLEXPORT	void dmxmulv(dimen /*n*/, dimen /*m*/, matrix /*A*/, vector /*x*/, vector /*y*/);
DLLEXPORT	void dmx_transpose(dimen /*n*/, dimen /*m*/, matrix /*a*/, matrix /*b*/);
DLLEXPORT	void Crash(const char * /*fmt*/, ...);
DLLEXPORT	void lm_assert_fail(const char * /*expr*/, const char * /*f*/, int /*l*/);
DLLEXPORT	void lm_dvwrit(dimen /*n*/, real * /*x*/);
DLLEXPORT	const char *lm_set_gdvwri_fmt( const char * /*new_fmt*/ );
DLLEXPORT	void lm_gdvwri(dimen /*n*/, real * /*x*/, increment /*inc*/);
DLLEXPORT	void lm_item_write(ushort /*maxnum*/, const char * /*fmt*/, ...);
DLLEXPORT	void lm_mivwri(const char * /*name*/, dimen /*n*/, short_vec /*x*/);
DLLEXPORT	void lm_ivwrit(dimen /*n*/, short_vec /*x*/);
DLLEXPORT	void lm_mdvwri(const char * /*name*/, dimen /*n*/, real * /*x*/);
DLLEXPORT	void lm_name_write(const char * /*name*/, ushort /*maxnum*/, ushort /*item_length*/);
DLLEXPORT	void lm_fflushall(void);
DLLEXPORT	int lm_putc(char /*c*/);
DLLEXPORT	void lm_set_files(byte /*n*/, void * /*f*/);
DLLEXPORT	int _lm_printf(const char * /*fmt*/, ARGADDR /*v*/);
DLLEXPORT	int lm_printf(const char * /*fmt*/, ...);
DLLEXPORT	int lm_wmsg(const char * /*fmt*/, ...);
DLLEXPORT	int lm_printr(const char * /*fmt*/, ...);
DLLEXPORT	int _lm_werr(const char * /*fmt*/, ARGADDR /*v*/);
DLLEXPORT	int lm_werr(const char * /*fmt*/, ...);
DLLEXPORT	void itrwri(char * /*name*/, integer /*iter*/);
DLLEXPORT	void wdinky(char * /*name*/, real /*ztgnrm*/, real /*dinky*/);
DLLEXPORT	void wrexit(char * /*name*/, integer /*inform*/, integer /*iter*/);
DLLEXPORT	void wqpexi(char * /*msg*/);
DLLEXPORT	real dsumvec(dimen /*n*/, vector /*v*/);
//DLLEXPORT	double clockit(int /*start*/);
DLLEXPORT	void CFree(void ** /*pp*/);
DLLEXPORT	void CFreep(dimen /*n*/, void *** /*ppp*/);
DLLEXPORT	void dsub(dimen /*n*/, vector /*y*/, increment /*incy*/, vector /*z*/, increment /*incz*/, vector /*x*/, increment /*incx*/);
DLLEXPORT	void dsubvec(dimen /*n*/, vector /*y*/, vector /*z*/, vector /*x*/);
DLLEXPORT	void In_place_swap(dimen /*n*/, undex_vec /*x*/, void * /*v*/, dimen /*s*/, int_vec /*marked*/);
DLLEXPORT	void byte_swap(dimen /*n*/, void * /*a*/, void * /*b*/);
DLLEXPORT	void byte_reverse(dimen /*n*/, void * /*b*/);
DLLEXPORT	void isortndx(dimen /*n*/, undex_vec /*v*/);
DLLEXPORT	undex_vec gsortndx(dimen /*n*/);
DLLEXPORT	void *mem_dup(size_t /*n*/, void * /*v*/);
DLLEXPORT	void dline_fit(dimen /*T*/, real /*decay*/, vector /*x*/, vector /*y*/, real * /*alpha*/, real * /*beta*/, real * /*E*/);
DLLEXPORT	real dmeanvec(dimen /*n*/, vector /*x*/);
DLLEXPORT	real dcovvec(dimen /*n*/, vector /*x*/, vector /*y*/);
DLLEXPORT	real dvarvec(dimen /*n*/, vector /*x*/);
DLLEXPORT	real dserrvec(dimen /*n*/, vector /*x*/);
DLLEXPORT	byte dqeqnsol(real /*a*/, real /*b*/, real /*c*/, real * /*pr1*/, real * /*pr2*/);
DLLEXPORT	int dnmsmplx(dimen /*n*/, v_r_func /*f*/, vector /*x*/, vector /*p*/, real /*alpha*/, real /*beta*/, real /*gamma*/, real /*delta*/, real /*ftol*/, dimen /*maxi*/);
DLLEXPORT	real _dlngamma(register real /*z*/);
DLLEXPORT	real dlngamma(real /*z*/);
DLLEXPORT	void dsmxrcx(dimen /*n*/, sym_matrix /*S*/, dimen /*p*/, dimen /*q*/);
DLLEXPORT	void _In_place_swap(dimen /*n*/, undex_vec /*x*/, ipsw_func /*f*/, int_vec /*marked*/);
DLLEXPORT	void dsmxipp(dimen /*n*/, dimen /*N*/, sym_matrix /*S*/, undex_vec /*x*/, int_vec /*marked*/);
DLLEXPORT	void lm_dsmxwri(dimen /*n*/, sym_matrix /*S*/);
DLLEXPORT	void lm_mdsmxwri(const char * /*name*/, dimen /*n*/, sym_matrix /*S*/);
DLLEXPORT	real didot(dimen /*n*/, vector /*x*/, stride /*iix*/, vector /*y*/, stride /*iy*/);
DLLEXPORT	void dsmxmulv(dimen /*n*/, sym_matrix /*S*/, vector /*x*/, vector /*y*/);
DLLEXPORT	void dsmxmulvT(dimen /*n*/, sym_matrix /*S*/, vector /*x*/, vector /*y*/);
DLLEXPORT	void invert_index_order(dimen /*n*/, undex_vec /*x*/, undex_vec /*y*/);
DLLEXPORT	real dbrentrf(r_r_func /*f*/, real /*a*/, real /*b*/, real /*fa*/, real /*fb*/, real /*tol*/, int /*itmax*/, short * /*ifail*/);
DLLEXPORT	void dadd(dimen /*n*/, vector /*y*/, stride /*incy*/, vector /*z*/, stride /*incz*/, vector /*x*/, stride /*incx*/);
DLLEXPORT	void daddvec(dimen /*n*/, vector /*y*/, vector /*z*/, vector /*x*/);
DLLEXPORT	real dhjucopt(dimen /*n*/, vector /*x*/, vector /*s0*/, v_r_func /*ff*/, real /*eps*/, real /*tau*/, vector /*w*/);
DLLEXPORT	real dlsslsch(dimen /*n*/, vector /*x*/, vector /*y*/, real /*g*/, real /*h*/, bit_set /*d*/, real_plus_dim * /*w*/);
DLLEXPORT	int compare_u_real_plus_dim(real_plus_dim * /*a*/, real_plus_dim * /*b*/);
DLLEXPORT	void dbidiag(matrix /*x*/, dimen /*ldx*/, dimen /*n*/, dimen /*p*/, vector /*q*/, vector /*e*/, vector /*wrk*/);
DLLEXPORT	void drot(dimen /*n*/, vector /*x*/, stride /*incx*/, vector /*y*/, stride /*incy*/, real /*c*/, real /*s*/);
DLLEXPORT	void drotvec(dimen /*n*/, vector /*x*/, vector /*y*/, real /*c*/, real /*s*/);
DLLEXPORT	void dhtr2(matrix /*a*/, dimen /*lda*/, vector /*u*/, real /*s*/, dimen /*i1*/, dimen /*i2*/, dimen /*j1*/, dimen /*j2*/);
DLLEXPORT	void dmxunit(matrix /*x*/, dimen /*ldx*/, dimen /*m*/, dimen /*n*/);
DLLEXPORT	void dqrdc(matrix /*x*/, dimen /*ldx*/, dimen /*n*/, dimen /*p*/, vector /*qraux*/, short_vec /*jpvt*/, vector /*work*/, int /*job*/);
DLLEXPORT	real damin(dimen /*n*/, vector /*x*/, stride /*incx*/);
DLLEXPORT	real daminvec(dimen /*n*/, vector /*x*/);
DLLEXPORT	void dcancel(matrix /*u*/, dimen /*ldu*/, matrix /*v*/, dimen /*ldv*/, vector /*q*/, vector /*e*/, dimen /*m*/, dimen /*n*/, dimen /*i*/, dimen /*k*/, real /*tol*/, int /*wantu*/, int /*wantv*/);
DLLEXPORT	short dpsvd(matrix /*a*/, dimen /*lda*/, dimen /*m*/, dimen /*n*/, stride * /*rank*/, real * /*theta*/, matrix /*u*/, dimen /*ldu*/, matrix /*v*/, dimen /*ldv*/, vector /*q*/, int_vec /*inul*/, vector /*wrk*/, real /*tol1*/, real /*tol2*/, dimen /*mode*/, short * /*iwarn*/);
DLLEXPORT	short dqrql(matrix /*u*/, dimen /*ldu*/, matrix /*v*/, dimen /*ldv*/, dimen /*m*/, dimen /*n*/, stride * /*rank*/, real * /*theta*/, vector /*q*/, vector /*e*/, int_vec /*inul*/, real /*tol1*/, real /*tol2*/, int /*wantu*/, int /*wantv*/, short * /*iwarn*/);
DLLEXPORT	dimen dnsingv(vector /*q*/, vector /*e*/, dimen /*k*/, real /*theta*/, real /*tol1*/, real /*tol2*/);
DLLEXPORT	int destim(vector /*q*/, vector /*e*/, dimen /*n*/, dimen * /*pl*/, real * /*ptheta*/, real /*tol1*/, real /*tol2*/);
DLLEXPORT	sym_matrix	sfmx_solve( dimen /*n*/, dimen /*m*/, vector /*D*/, matrix /*Fac*/, vector /*z*/, vector /*w*/ );
DLLEXPORT	sym_matrix	smx_solve( dimen /*n*/, int /*factorm*/, dimen /*numfac*/, vector /*D*/, matrix /*Fac*/, vector /*z*/, vector /*w*/ );
DLLEXPORT	void	Implied_Alphas(dimen	/*n*/,int	/*factorm*/,dimen /*numfac*/,vector	/*active*/,vector /*Q*/,matrix	/*Qfac*/,vector /*alpha*/);
DLLEXPORT	void drestor(matrix /*x*/, dimen /*ldx*/, dimen /*m*/, dimen /*n*/, matrix /*u*/, dimen /*ldu*/, matrix /*v*/, dimen /*ldv*/, int_vec /*inul*/, real /*tol*/, int /*wantu*/, int /*wantv*/);
DLLEXPORT	void dqlstep(matrix /*u*/, dimen /*ldu*/, matrix /*v*/, dimen /*ldv*/, vector /*q*/, vector /*e*/, dimen /*m*/, dimen /*n*/, dimen /*i*/, dimen /*k*/, real /*shift*/, int /*wantu*/, int /*wantv*/);
DLLEXPORT	void dqrstep(matrix /*u*/, dimen /*ldu*/, matrix /*v*/, dimen /*ldv*/, vector /*q*/, vector /*e*/, dimen /*m*/, dimen /*n*/, dimen /*i*/, dimen /*k*/, real /*shift*/, int /*wantu*/, int /*wantv*/);
DLLEXPORT	void dmxtmulmx(dimen /*n*/, dimen /*m*/, dimen /*l*/, matrix /*A*/, matrix /*B*/, matrix /*C*/);
DLLEXPORT	void dmxmulmxt(dimen /*n*/, dimen /*m*/, dimen /*l*/, matrix /*A*/, matrix /*B*/, matrix /*C*/);
DLLEXPORT	void dmxtmultv(dimen n, dimen m, matrix A, vector x, vector y);
DLLEXPORT	void dmxtmulv(dimen /*n*/, dimen /*m*/, matrix /*A*/, vector /*x*/, vector /*y*/);
DLLEXPORT	short dsvdc(matrix /*x*/, dimen /*ldx*/, dimen /*n*/, dimen /*p*/, vector /*s*/, vector /*e*/, matrix /*u*/, dimen /*ldu*/, matrix /*v*/, dimen /*ldv*/, vector /*w*/, int /*job*/);
DLLEXPORT	void dswapvec(register dimen /*n*/, vector /*a*/, vector /*b*/);
DLLEXPORT	real ddotvbs(dimen /*n*/, vector /*x*/, vector /*y*/, bit_set /*b*/);
DLLEXPORT	real dnrmdist(register real /*z*/);
DLLEXPORT	real dnrmderv(register real /*z*/);
DLLEXPORT	real deccevqf(real /*w*/, real /*y*/, real /*z*/);
DLLEXPORT	real dbmoprm(real /*F*/, real /*E*/, real /*t*/, real /*r*/, real /*sigma*/, int /*kind*/);
DLLEXPORT	real dbmoivol(real /*V*/, real /*F*/, real /*E*/, real /*t*/, real /*r*/, real /*a*/, byte /*kind*/, short * /*flag*/);
DLLEXPORT	void CFree_vec(dimen /*n*/, char ** /*p*/);
DLLEXPORT	pMinMaxConT addnxcon(dimen /*n*/, int /*t*/, dimen /*x*/, vector /*a*/, vector /*b*/, pMinMaxConT /*o*/);
DLLEXPORT	real dbondytm(dimen /*n*/, real /*D*/, real /*fm*/, real /*K1*/, real /*Kom*/, real /*RP*/, real /*a*/, byte /*kind*/, short * /*flag*/);
DLLEXPORT	real dbond_dp(dimen /*n*/, real /*fm*/, real /*K1*/, real /*Kom*/, real /*RP*/, real /*YTM*/, byte /*kind*/);
DLLEXPORT	real dnrm2vec(dimen /*n*/, vector /*x*/);
DLLEXPORT	void dsssqvec(dimen /*n*/, vector /*x*/, real * /*pscale*/, real * /*psumsq*/);
DLLEXPORT	short dqrdiag(dimen /*p*/, vector /*s*/, vector /*e*/, matrix /*u*/, dimen /*ldu*/, dimen /*n*/, int /*wantu*/, matrix /*v*/, dimen /*ldv*/, dimen /*m*/, int /*wantv*/, dimen /*maxit*/);
DLLEXPORT	short dpsvdn(matrix /*a*/, dimen /*lda*/, dimen /*n*/, dimen /*m*/, stride * /*rank*/, real * /*theta*/, matrix /*u*/, dimen /*ldu*/, matrix /*v*/, dimen /*ldv*/, vector /*q*/, int_vec /*inul*/, vector /*wrk*/, real /*tol1*/, real /*tol2*/, dimen /*mode*/, short * /*iwarn*/);
DLLEXPORT	real ddotvec(dimen /*n*/, real * /*x*/, real * /*y*/);
DLLEXPORT	double linfinity(dimen n, vector a);
DLLEXPORT	double linfinityj(dimen n, vector a, dimen jump);
DLLEXPORT	double lmod(dimen n, vector a);
DLLEXPORT void fake_ETL_data(dimen n, dimen tlen, vector w, vector DATA, vector fakeDATA, int plus);
DLLEXPORT void VARproperties(dimen n, dimen number_included, dimen tlen, vector w, vector DATA, double*ETL,
	double*VAR, vector ETLbreakdown, vector etl_per_asset, vector VARbreakdown, vector var_per_asset);
DLLEXPORT	real didotvec(dimen /*n*/, vector /*x*/, stride /*iix*/, vector /*y*/);
DLLEXPORT	real disamax(dimen /*n*/, vector /*v*/, stride /*iv*/, dimen * /*i*/);
DLLEXPORT	real disamaxvec(dimen /*n*/, vector /*v*/, dimen * /*i*/);
DLLEXPORT	void dldlpr1u(dimen /*n*/, ldl_matrix /*f*/, vector /*v*/);
DLLEXPORT	void dldlnr1u(dimen /*n*/, ldl_matrix /*f*/, vector /*v*/);
DLLEXPORT	void dldlscale(dimen /*n*/, ldl_matrix /*v*/, real /*s*/);
DLLEXPORT	real denrm2vec(dimen /*n*/, vector /*x*/, vector /*y*/);
DLLEXPORT	dimen dldlfact(dimen /*n*/, sym_matrix /*S*/, vector /*E*/, undex_vec /*P*/);
DLLEXPORT	void dldlinit(dimen /*n*/, ldl_matrix /*f*/, vector /*d*/);
DLLEXPORT	void dldl_sol(dimen /*n*/, ldl_matrix /*f*/, vector /*y*/, vector /*x*/);
DLLEXPORT	void dldllsol(dimen /*n*/, ldl_matrix /*f*/, vector /*y*/, vector /*x*/);
DLLEXPORT	void dldldsol(dimen /*n*/, ldl_matrix /*f*/, vector /*y*/, vector /*x*/);
DLLEXPORT	void dldlrsol(dimen /*n*/, ldl_matrix /*f*/, vector /*y*/, vector /*x*/);
DLLEXPORT	void lm_muvwri(const char * /*name*/, dimen /*n*/, undex_vec /*x*/);
DLLEXPORT	void lm_uvwrit(dimen /*n*/, undex_vec /*x*/);
DLLEXPORT	real dd_get_acc_sum(dd_acc_rec * /*pS*/);
DLLEXPORT	void dd_acc_sum(register real /*a*/, dd_acc_rec * /*pS*/);
DLLEXPORT	short dpsvdc(matrix /*x*/, dimen /*ldx*/, dimen /*n*/, dimen /*p*/, vector /*s*/, vector /*e*/, matrix /*v*/, dimen /*ldv*/, vector /*w*/);
DLLEXPORT	void ddmxmul(dimen /*n*/, vector /*D*/, vector /*x*/, vector /*y*/);
DLLEXPORT	void ddmxsol(dimen /*n*/, vector /*D*/, vector /*x*/, vector /*y*/);
DLLEXPORT	void dldlr1u(dimen /*n*/, ldl_matrix /*f*/, real /*a*/, vector /*v*/);
DLLEXPORT	real dnrm1vec(dimen /*n*/, vector /*x*/);
DLLEXPORT	void dsortvec(dimen /*n*/, vector /*v*/);
DLLEXPORT	int dcomparu(real * /*i*/, real * /*j*/);
DLLEXPORT	real dmedianvec(dimen /*n*/, vector /*v*/);
DLLEXPORT	short dmsdfit(dimen /*n*/, vector /*r*/, vector /*_s*/, real /*ff*/, vector /*x*/, real /*acc*/, void ** /*ppsp*/);
DLLEXPORT	real dmodevec(dimen /*n*/, vector /*v*/);
DLLEXPORT	short dtridib(dimen /*n*/, real /*eps1*/, vector /*d*/, vector /*e*/, vector /*e2*/, real * /*plb*/, real * /*pub*/, dimen /*m11*/, dimen /*m*/, vector /*w*/, short_vec /*ind*/, vector /*rv4*/);
DLLEXPORT	short dtinvit(dimen /*n*/, vector /*d*/, vector /*e*/, vector /*e2*/, dimen /*m*/, vector /*w*/, short_vec /*ind*/, matrix /*z*/, dimen /*ldz*/, vector /*rv1*/);
DLLEXPORT	void dtrbak1(dimen /*n*/, matrix /*a*/, stride /*lda*/, vector /*e*/, dimen /*m*/, matrix /*z*/, stride /*ldz*/);
DLLEXPORT	real dnrm1(dimen /*n*/, vector /*x*/, stride /*incx*/);
DLLEXPORT	void dtred1(dimen /*n*/, matrix /*a*/, dimen /*lda*/, vector /*d*/, vector /*e*/, vector /*e2*/);
DLLEXPORT	real dsserrs(dimen /*n*/, dimen /*m*/, vector /*y*/, matrix /*A*/, vector /*x*/);
DLLEXPORT	void make_revision_constraints(	dimen /*oon*/, dimen /*on*/, dimen /*om*/, matrix /*oA*/,
				vector /*oL*/, vector /*oU*/, vector /*w0*/, real /*delta*/, real /*big*/,
				int /*zflag*/, dimen * /*pnn*/, dimen * /*pnm*/, matrix * /*pnA*/,
				vector * /*pnL*/, vector * /*pnU*/,
				dimen	/*mx*/, matrix /*xA*/);
DLLEXPORT	void dldlrmul(dimen /*n*/, ldl_matrix /*f*/, vector /*y*/, vector /*x*/);
DLLEXPORT	void daxpyvec(dimen /*n*/, real /*alpha*/, vector /*x*/, vector /*y*/);
DLLEXPORT	void dsmxdadd(dimen /*n*/, sym_matrix /*S*/, vector /*D*/);
DLLEXPORT	void dsmxdcpy(dimen /*n*/, sym_matrix /*S*/, vector /*x*/);
DLLEXPORT	void drootvec(dimen /*n*/, vector /*x*/);
DLLEXPORT	dimen	dfindvec(	dimen	/*n*/,	/*the length of each vector*/
			dimen	/*m*/,	/*the number of vectors*/
			matrix	/*A*/,	/*the n by m matrix of vectors to scan*/
			vector	/*v*/	/*the vector to look for*/
			);
DLLEXPORT	void dnegvec(dimen /*n*/, vector /*x*/);
DLLEXPORT	void dneg(dimen /*n*/, vector /*x*/,increment /*incx*/);
DLLEXPORT	void dldldr1u(
		dimen		n,
		ldl_matrix	f,
		dimen		id,
		real		a,
		vector		v
		);
DLLEXPORT	void	dldl2sym( dimen /*n*/, ldl_matrix /*F*/);
DLLEXPORT	void	dldldel( dimen /*n*/, dimen /*r*/, ldl_matrix /*F*/, vector /*_s*/ );
DLLEXPORT	short	dsmxfac( dimen /*n*/, sym_matrix /*ap*/, short_vec /*kpvt*/);
DLLEXPORT	dimen	idamaxvec( dimen /*n*/,  vector /*x*/ );
DLLEXPORT	short	dpchlfs(dimen /*n*/, sym_matrix /*g*/, vector /*d*/);
DLLEXPORT	void	dllt2sym( dimen /*n*/, ldl_matrix /*F*/);
DLLEXPORT	void	dsmxafpt( dimen /*n*/, ldl_matrix /*F*/, short_vec /*P*/, int /*inv*/, vector /*b*/ );
DLLEXPORT	void	dsmxaupt( dimen /*n*/, ldl_matrix /*F*/, short_vec /*P*/, int /*mode*/, vector /*b*/ );
DLLEXPORT	void	dsmx22ev( real /*a*/, real /*b*/, real /*c*/, vector /*lambda*/, matrix /*V*/ );
DLLEXPORT	void	dsmxmpd( dimen /*n*/, sym_matrix /*S*/, ldl_matrix /*L*/, vector /*v*/, short_vec /*P*/, dsmxmpd_info_rec * /*info*/ );
DLLEXPORT	void	dunitvec( dimen /*n*/, dimen /*i*/, vector /*v*/ );
DLLEXPORT	void	dscunitvec( dimen /*n*/, dimen /*i*/, real /*t*/, vector /*v*/ );
DLLEXPORT	void	dsmxavop( dimen /*n*/, sym_matrix /*S*/, vector /*v*/ );
DLLEXPORT	matrix	dfmxsol( dimen /*n*/, dimen /*m*/, vector /*D*/, matrix /*F*/, int /*nm*/, matrix /*S*/, vector /*y*/, vector /*x*/ );
DLLEXPORT	void	fmxsol( dimen n, dimen m, vector D, matrix F, int nm, matrix S, vector y, vector x );
DLLEXPORT	void	reorder_signals(dimen n,int nfac,vector signals,vector benchmark,vector ferror,
						vector skill,vector Q,
						dimen *neworder,vector alpha,vector h,vector beta);
DLLEXPORT	void	order_signals(dimen n,int nfac,vector signals,vector benchmark,vector ferror,
					  vector skill,vector Q,dimen *neworder,dimen *inverse,vector beta);
//DLLEXPORT	vector	dd_compare_S;
DLLEXPORT	int dd_compare(undex * /*pa*/, undex * /*pb*/);
DLLEXPORT	byte_vec	Elton_and_Gruber_single_index_Beta_Ranking(
			dimen	/*n*/,	/*number of equities*/
			real	/*m*/,	/*the market variance*/
			vector	/*x*/,	/*excess returns*/
			vector	/*b*/,	/*the betas*/
			vector	/*e*/,	/*the residual variances*/
			undex_vec * /*pO*/ );	/*to hold the sort vector if non NULL*/
DLLEXPORT	real	dadpwls(	dimen	/*n*/,
			real	/*t*/,
			real	/*big*/,
			vector	/*p*/,
			vector	/*d*/,
			vector	/*c*/,
			vector	/*L*/,
			vector	/*U*/ );
DLLEXPORT	void	dabsvec(	dimen	/*n*/,
			vector	/*x*/ );
DLLEXPORT	real	dpwcovar( real /*decay*/, dimen /*n*/, bit_set /*B*/, vector /*x*/, vector /*y*/, dimen * /*pcount*/ );
DLLEXPORT	void	dsmx22sqrt( real /*a*/, real /*b*/, real /*c*/, vector /*R*/ );
DLLEXPORT	void	dsmxasrt( dimen /*n*/, ldl_matrix /*F*/, short_vec /*P*/, int /*mode*/, vector /*v*/ );
DLLEXPORT	void	dsmxainv( dimen /*n*/, ldl_matrix /*F*/, short_vec /*P*/, vector /*v*/ );
DLLEXPORT	void	dsmxainvsqrt( dimen /*n*/, ldl_matrix /*F*/, short_vec /*P*/, int /*mode*/, vector /*v*/ );
#ifdef	MEM_DEBUG
DLLEXPORT	void		tmem_free_all( unsigned char /*all*/ );
#endif
DLLEXPORT	void	daddc(dimen /*n*/, vector /*y*/, increment /*incy*/, real /*c*/, vector /*x*/, increment /*incx*/);
DLLEXPORT	void	daddcvec(dimen /*n*/, vector /*y*/, real /*c*/, vector /*x*/ );
DLLEXPORT	void	corr_and_sd_to_cov( dimen /*n*/, sym_matrix /*Corr*/, vector /*SD*/, sym_matrix /*Cov*/ );
DLLEXPORT	void	mx_mul_Dmx(dimen /*n*/, dimen /*m*/, matrix /*X*/, vector /*D*/, matrix /*Y*/);
DLLEXPORT	int	dsmxmpd_check( dimen /*n*/, sym_matrix /*F*/, short /*msglvl*/, sym_matrix * /*pSdecomp*/ );
DLLEXPORT	int	_dsmxmpd_check(dimen /*n*/, sym_matrix /*F*/, ldl_matrix /*L*/, short_vec /*P*/,
			sym_matrix /*S*/, short /*msglvl*/ );
DLLEXPORT	vector	null_to_zero_vec( dimen /*n*/, vector /*v*/, int * /*pflag*/ );
DLLEXPORT	int	dposvec( dimen /*n*/, vector /*v*/ );
DLLEXPORT	void	darflct(
		real		/*c*/,
		real		/*s*/,
		dimen		/*ip*/,
		vector		/*x*/,
		increment	/*incx*/,
		increment	/*idisx*/,
		vector		/*y*/,
		increment	/*incy*/,
		increment	/*idisy*/);
DLLEXPORT	void	dcrflct(real * /*x*/, real * /*y*/, real * /*c*/, real * /*s*/);
DLLEXPORT	short	dinscol(
		dimen	/*n*/,
		dimen	/*m*/,
		matrix	/*q*/,
		matrix	/*r*/,
		dimen	/*k*/,
		vector	/*v*/,
		vector	/*wrk1*/,
		vector	/*wrk2*/,
		vector	/*wrk3*/);
DLLEXPORT	short dortcol	(
		dimen	/*n*/,
		dimen	/*m*/,
		matrix	/*q*/,
		vector	/*v*/,
		vector	/*smallr*/,
		real	* /*rho*/,
		vector	/*wrk1*/,
		vector	/*wrk2*/);

DLLEXPORT	void	dminmax( dimen /*n*/, vector /*v*/, stride /*i*/, real * /*pMin*/, real * /*pMax*/ );
DLLEXPORT	void	dminmaxvec( dimen /*n*/, vector /*v*/, real * /*pMin*/, real * /*pMax*/ );
DLLEXPORT void BITA_dger(size_t m, size_t n, double alpha, 
	double *x, size_t incx, double *y, size_t incy, 
	double *a, size_t lda);
DLLEXPORT void BITA_dgemv(char *trans, size_t m, size_t n, double 
	alpha, double *a, size_t lda, double *x, size_t incx, 
	double beta, double *y, size_t incy);
DLLEXPORT void BITA_dspr(char *uplo, size_t n, double alpha, 
	double *x, size_t incx, double *ap);
DLLEXPORT int dsptrs(char *uplo, size_t n, size_t nrhs, 
	double *ap, short_vec ipiv, double *b, size_t ldb);
DLLEXPORT int applyA(char *uplo, size_t n, size_t nrhs, 
	double *ap, short_vec ipiv, double *b, size_t ldb);
DLLEXPORT int applyrootA(size_t n, size_t nrhs, 
	double *ap, short_vec ipiv, double *b, size_t ldb);
DLLEXPORT int applyinverserootA(size_t n, size_t nrhs, 
	double *ap, short_vec ipiv, double *b, size_t ldb);
DLLEXPORT int dsptrf(char *uplo, size_t n, double *ap, short_vec
	ipiv);
DLLEXPORT  Integer dsytrf_BITA(char *uplo, Integer *n, double *a, Integer *	lda, Integer *ipiv, double *work, Integer *lwork, Integer *info);
DLLEXPORT Integer dgerq2_BITA(Integer *m, Integer *n, double *a, Integer *lda, double *tau, double *work, Integer *info);
DLLEXPORT Integer dgerqf_BITA(Integer *m, Integer *n, double *a, Integer *lda, double *tau, double *work, Integer *lwork, Integer *info);
DLLEXPORT double dlapy2_BITA(double *x, double *y);
DLLEXPORT int dlarfb_BITA(char *side, char *trans, char *direct, char *	storev, Integer *m, Integer *n, Integer *k, double *v, Integer *
	ldv, double *t, Integer *ldt, double *c__, Integer *ldc, 	double *work, Integer *ldwork);
DLLEXPORT int dlarf_BITA(char *side, Integer *m, Integer *n, double *v,	 Integer *incv, double *tau, double *c__, Integer *ldc, 	double *work);
DLLEXPORT int dlarfg_BITA(Integer *n, double *alpha, double *x, 	Integer *incx, double *tau);
DLLEXPORT int dlarft_BITA(char *direct, char *storev, Integer *n, Integer *	k, double *v, Integer *ldv, double *tau, double *t,	Integer *ldt);
DLLEXPORT int dormr2_BITA(char *side, char *trans, Integer *m, Integer *n, 	Integer *k, double *a, Integer *lda, double *tau, double *	c__, Integer *ldc, double *work, Integer *info);
DLLEXPORT int dormrq_BITA(char *side, char *trans, Integer *m, Integer *n, 	Integer *k, double *a, Integer *lda, double *tau, double *	c__, Integer *ldc, double *work, Integer *lwork, Integer *info);
DLLEXPORT int dtrmm_BITA(char *side, char *uplo, char *transa, char *diag, 	Integer *m, Integer *n, double *alpha, double *a, Integer *	lda, double *b, Integer *ldb);
DLLEXPORT int dtrmv_BITA(char *uplo, char *trans, char *diag, Integer *n, 	double *a, Integer *lda, double *x, Integer *incx);
DLLEXPORT Integer iladlc_BITA(Integer *m, Integer *n, double *a, Integer *lda);
DLLEXPORT Integer iladlr_BITA(Integer *m, Integer *n, double *a, Integer *lda);

DLLEXPORT void packed2symm(Integer n,double*a);
DLLEXPORT void symm2packed(Integer n,double*a);
DLLEXPORT Integer bunchf(Integer n,double*C,Integer*piv);
DLLEXPORT short lsame_BITA(char*a,char*b);
DLLEXPORT Integer dsytf2_BITA(char *uplo, Integer *n, double *a, Integer *lda, Integer *ipiv, Integer *info);
DLLEXPORT Integer dlasyf_BITA(char *uplo, Integer *n, Integer *nb, Integer *kb,double *a, Integer *lda, Integer *ipiv, double *w, Integer *ldw, Integer *info);
DLLEXPORT void xerbla_BITA(char *s, Integer *info);
DLLEXPORT short disnan_BITA(double *a);
DLLEXPORT int dlaswp_BITA(Integer *n, double *a, Integer *lda, Integer 
	*k1, Integer *k2, Integer *ipiv, Integer *incx);
DLLEXPORT Integer idamax_BITA(Integer *n, double *dx, Integer *incx);
DLLEXPORT Integer dsyr_BITA(char *uplo, Integer *n, double *alpha,double *x, Integer *incx, double *a, Integer *lda);
DLLEXPORT Integer dgemm_BITA(char *transa, char *transb, Integer *m, Integer *n, Integer *k, double *alpha, double *a, Integer *lda,double *b, Integer *ldb, double *beta, double *c__,Integer *ldc);


DLLEXPORT void BITA_sscal(dimen n, float alpha, float* x, increment incx);//single precision
DLLEXPORT Integer sbunchf(Integer n,float*C,Integer*piv);//single precision
DLLEXPORT void scopyvec(dimen n, float* x, float* y);//single precision
DLLEXPORT void spacked2symm(Integer n,float*a);//single precision
DLLEXPORT void ssymm2packed(Integer n,float*a);//single precision
DLLEXPORT Integer ssytrf_BITA(char *uplo, Integer *n, float *a, Integer *lda, Integer *ipiv, float *work, Integer *lwork, Integer *info);//single precision
DLLEXPORT int ssptrf(char *uplo, size_t n, float *ap, short_vec ipiv);// single precision
DLLEXPORT void sswap(register dimen n, float* a, increment i, float* b, increment j);//single precision
DLLEXPORT Integer slasyf_BITA(char *uplo, Integer *n, Integer *nb, Integer *kb, float *a, Integer *lda, Integer *ipiv, float *w, Integer *ldw, Integer *info);//single precision
DLLEXPORT Integer sgemm_BITA(char *transa, char *transb, Integer *m, Integer *
	n, Integer *k, float *alpha, float *a, Integer *lda, 
	float *b, Integer *ldb, float *beta, float *c__, 
	Integer *ldc);//single precision
DLLEXPORT void saxpyvec(dimen n, float alpha, float* x, float* y );//single precision
DLLEXPORT void sscalvec(dimen n, float alpha, float* x);//single precision
DLLEXPORT void scopy(dimen n, float* x, increment incx, float* y, increment incy);//single precision
DLLEXPORT void BITA_sgemv(char *trans, size_t m, size_t n, float 
	alpha, float *a, size_t lda, float *x, size_t incx, 
	float beta, float *y, size_t incy);//single precision
DLLEXPORT float BITA_sdot(dimen n, float *x, increment incx, float *y, increment incy);//single precision
DLLEXPORT float sdotvec(dimen n, float *x, float *y);//single precision
DLLEXPORT void BITA_saxpy(dimen n, float alpha, float* x, stride incx, float* y, stride incy);//single precision
DLLEXPORT void sset(dimen n, float alpha, float* x, increment incx);//single precision
DLLEXPORT void szero(dimen n, float* x, increment incx);//single precision
DLLEXPORT void szerovec(dimen n, float* x);//single precision
DLLEXPORT Integer ssytf2_BITA(char *uplo, Integer *n, float *a, Integer *
	lda, Integer *ipiv, Integer *info);//single precision
DLLEXPORT Integer ssyr_BITA(char *uplo, Integer *n, float *alpha, 
	float *x, Integer *incx, float *a, Integer *lda);//single precision
DLLEXPORT int ssptrs(char *uplo, size_t n, size_t nrhs, 
	float *ap, short_vec ipiv, float *b, size_t ldb);//single precision
DLLEXPORT void BITA_sger(size_t m, size_t n, float alpha, 
	float *x, size_t incx, float *y, size_t incy, 
	float *a, size_t lda);//single precision
DLLEXPORT void BITA_sspr(char *uplo, size_t n, float alpha, 
	float *x, size_t incx, float *ap);//single precision
DLLEXPORT Integer isamax_BITA(Integer *n, float *dx, Integer *incx);//single precision
DLLEXPORT dimen   isamaxvec( dimen n,  float* x );//single precision
DLLEXPORT short sisnan_BITA(float *a);//single precision
DLLEXPORT double small_round(double eps);
/*externend*/
#ifdef	__cplusplus
	}
#endif
#ifndef	NULL
#define NULL ((void *)0)
#endif
#if	defined(DEBUG) || defined(ASSERT)
#	if	defined(ASSERT)
#		undef	ASSERT
#		ifdef	__HASH_TOKEN__
#			define ASSERT(exp) if(!(exp)) lm_assert_fail(#exp,__FILE__,__LINE__)
#		else
#			define ASSERT(exp) if(!(exp)) lm_assert_fail("exp",__FILE__,__LINE__)
#		endif
#	endif
#	define DEBUGGING(S) S
#else
#	define ASSERT(exp)
#	define DEBUGGING(S)
#endif
#define BYTEBITS 8
#define BSETBITS BYTEBITS
#define BSETMASK 07
#define BSETSHFT 3
#define BIT_SET_LEN(N) (((N)+BSETBITS-1)>>BSETSHFT)
#define BIT(a,i) ((((a)[((unsigned)(i))>>BSETSHFT])>>((i)&BSETMASK))&1)
#define SET_BIT(a,i) ((a)[((unsigned)(i))>>BSETSHFT] |= (1<<((i)&BSETMASK)))
#define CLR_BIT(a,i) ((a)[((unsigned)(i))>>BSETSHFT] &= ~(1<<((i)&BSETMASK)))
#define CLEAR_BIT_SET(B,N) memset(B,0,BIT_SET_LEN(N))
#define CFreeC(p) CFree((void **)&(p))
#define CFreepC(n, pp) CFreep( n, (void ***)&(pp))
#define CFree_vecC(n, p ) CFree_vecP( n, (char **)(p))


#define	SMXFAC_NORMAL			0
#define	SMXFAC_TRANSPOSE		1
#define	SMXFAC_INVERSE			2
#define	SMXFAC_INVERSE_TRANSPOSE	3
#define	SMXFAC_TRANSPOSE_INVERSE	3
#define	SMXFAC_RIGHT_ROOT		0
#define	SMXFAC_LEFT_ROOT		1


#endif
