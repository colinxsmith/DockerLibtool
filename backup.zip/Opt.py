#This defines a class-based interface for calling the optimisation and other routines in the safeqp library.
#Extra helper functions are also defined here.
#This has been written so that it should work with python and jython without needing any changes.

try:
    from java.lang import *
    from jarray import *
    from safejavajy import *
    jython=1
    toList=lambda x:[i for i in x]
    jython_set=lambda t:array(t,Double)
    def sum(a):
        back=0
        for i in range(len(a)):
            back+=a[i]
        return back
except:
    from safe import *
    jython=0
debug=0

PYsingle2double=lambda n,m,a:[[a[i*n+j] for i in range(m)] for j in range(n)]
spike=lambda t:1e-6/pow(t,4)
dspike=lambda t:-1e-6*4/pow(t,5)
ddspike=lambda t:1e-6*20/pow(t,6)

sqr=lambda x:x*x
pythag=lambda x,y:pow(x*x+y*y,0.5)
def wlimit(a,eps):
    """Trim away values, a whose size, abs(a) is less than eps"""
    if abs(a)<eps:return 0
    else:return a
def rootQ(n,Q):
    """Use matrix diagonalisation to find square root of
    positive semi-definite symmetric matrix. This is not fast!!
    """
    conv=epsget()
    S=[0]*(n*n)
    (eig,eigv)=eigen(n,Q)
    for l in range(n):
        if eig[l]<conv:eig[l]=conv
        eig[l]=pow(eig[l],.5)
        for i in range(n):
            p1=eig[l]*eigv[l*n+i]
            for j in range(i+1):
                p=p1*eigv[l*n+j]
                S[j+n*i]+=p
                if i!=j:S[i+n*j]+=p
    return S
def rootQinverse(n,Q):
    """Use matrix diagonalisation to find inverse square root of
    positive semi-definite symmetric matrix. Neither is this fast!!
    """
    conv=epsget()
    S=[0]*(n*n)
    (eig,eigv)=eigen(n,Q)
    for l in range(n):
        if eig[l]<conv:eig[l]=0
        else:eig[l]=pow(1.0/eig[l],.5)
        for i in range(n):
            p1=eig[l]*eigv[l*n+i]
            for j in range(i+1):
                p=p1*eigv[l*n+j]
                S[j+n*i]+=p
                if i!=j:S[i+n*j]+=p
    return S
def getnames(fl,dic,sep='|'):
    """Read just the first column to get the factor names"""
    while(1):
        line=fl.readline()
        if len(line)==0:break
        line=line.strip()
        if line[0]=='!' or line.find('[')>-1:continue
        dic[line.split(sep)[0]]=1
def getsym(n,fl,dic,sep='|'):
    """Read symmetric data from file fl"""
    M=[0]*(n*(n+1)/2)
    while(1):
        line=fl.readline()
        if len(line)==0:break
        line=line.strip()
        if line[0]=='!' or line.find('[')>-1:continue
        data=line.split(sep)
        try:
            i=dic[data[0].strip()]-1
            j=dic[data[1].strip()]-1
            I=max(i,j)
            J=min(i,j)
            M[I*(I+1)/2+J]=float(data[2].strip())
        except:pass
    return M
def getnonsym(nl,ng,fl,dic1,dic2,sep='|'):
    """Read non-symmetric data from file fl"""
    M=[0]*(nl*ng)
    while(1):
        line=fl.readline()
        if len(line)==0:break
        line=line.strip()
        if line[0]=='!' or line.find('[')>-1:continue
        data=line.split(sep)
        try:
            i=dic1[data[0].strip()]-1
            j=dic2[data[1].strip()]-1
            M[i+j*nl]=float(data[2].strip())
        except:pass
    return M
def setorder(dic,names):
    i=1
    for name in names:
        dic[name]=i
        i+=1
def sign(x):
	if x>0:return 1
	elif x<0:return -1
	else:return 0
def ticketshape(x,p=spike(1)):
    if abs(x)<p:return spike(p)
    else: return spike(x)
def dticketshape(x,p=spike(1)):
    if abs(x)<p:return 0
    else: return dspike(x)
def ddticketshape(x,p=spike(1)):
	if abs(x)<p:return 0
	else: return ddspike(x)
def ticket(x,strength=1e-1):
    return -(ticketshape(x)-ticketshape(0))*strength/ticketshape(0)
def dticket(x,strength=1e-1):
    return -dticketshape(x)*strength/ticketshape(0)
def ddticket(x,strength=1e-1):
	return -ddticketshape(x)*strength/ticketshape(0)

def numline(llist=[],func=float):
    """Converts a string to number if possible
    To get an int list something like

    func=lambda t:int(float(t))
    
    may be best to convert a string float to an int"""
    for i in range(len(llist)):
        try:llist[i]=func(llist[i])
        except:pass
    return llist
def epsget():
    """Return machine accuracy."""
    a=1.3333333333333333333333333333333333333
    b=a-1.
    return 1-(b+b+b)
def dot(a,b,s=0):
    """Scalar product of a and b (with shift s on b)."""
    back=0
    n=len(a)
    for i in range(n):back+=a[i]*b[i+s]
    return back
def squaremult(n,M,x):return [dot(x,M[n*i:n*i+n]) for i in range(n)]
def turnover(w,wi,mask=[],start=0,stop=-1):
    """The turnover between w and wi (possibly masked)."""
    n=len(w)
    if stop!=-1:n=stop+start
    s=0
    if mask==[]:
        for i in range(start,n):s+=abs(w[i]-wi[i])
    else:
        for i in range(start,n):s+=abs((w[i]-wi[i])*mask[i-start])
    return s*0.5
def GetOrderW(w,sign=1,abs=0):
    """Returns a list of indices for ordering the elements of w (largest first sign=1, smallest first sign=-1).
        If abs is 1, then ordering is done according to absolute value.
        (This is a helper function which calls the function GetOrder(n,w,returned_order,abs=0,badlist=0) in safe wrapper.)
    """
    n=len(w)
    porder=[0]*n
    if jython:porder=array(porder,Long)
    if sign==1:
        GetOrder(n,w,porder,abs,[])
    else:
        GetOrder(n,[i*sign for i in w],porder,abs,[])
    if(jython):porder=[i for i in porder]
    return porder
def basketcount(w,initial=[],thresh=0):
    """Get the size of the basket (or number of trades if initial is not [])."""
    b=0
    longamount=0
    shortamount=0
    zamount=0
    if(thresh==0):thresh=epsget()
    for i in range(len(w)):
        s=0
        if initial != []:s=initial[i]
        tt=w[i]-s
        if abs(tt) > thresh:
            b+=1
            if tt>thresh:longamount+=1
            elif tt<-thresh:shortamount+=1
    return (b,longamount,shortamount)
def Parab(delta,U,prt=0):
    """Fit a parabola a*x2+bx+c to the data in delta and U and output the stationary point and its value"""
    (F1,F2,F3) = tuple(U)
    (d1,d2,d3) = tuple(delta)
    a = (F1*(d2-d3)+F3*(d1-d2)+F2*(d3-d1))/(d1-d3)/(d2-d3)/(d1-d2)
    b = (F1-F3)/(d1-d3)-a*(d1+d3)
    c=F3-d3*b-d3*d3*a
    xmin=-0.5*b/a
    fmin=c-0.25*b*b/a
    if prt:print 'a = %f b = %f c = %f'%(a,b,c)
    return(xmin,fmin)
def Pmin(n,x,f,eps=0.1,conv=1e-9,prt=0):
    """
        Minimise f(n,x) by fitting parabolas to each of the independent directions.
        (Simple-minded approach, only really works for parabolas!)
    """
    fmin=f(n,x)
    if prt:print x,fmin
    f1=1e10
    while abs((f1-fmin)/fmin) > conv:
        f1=fmin
        x1=[k for k in x]
        for i in range(n):
            delt=[-eps,0,eps]
            U=[f(n,x1) for x1[i] in delt]
            (xmin,Umin)=Parab(delt,U,prt)
            x[i]=xmin
        fmin=f(n,x)
        if prt:print x,fmin,(f1-fmin)/fmin
    return fmin
def longshortgross(w):
    """Get the total long, short and gross weights for weights in w."""
    p=0
    m=0
    g=0
    for i in w:
        if i>0:p+=i;g+=i
        else:m+=i;g-=i
    if p!=0:print 'Short/Long',-m/p
    return (p,m,g)
def eigen(n,MM):
    """
    MM can be either a lower triangle or a square matrix. M is
    generated from MM.
    n is the dimension of the problem and M is a square symmetric matrix.
    eigen returns a tuple (eigval,eigvec)
    the order of the eigenvectors in
    eigenvector i is eigvec[j+i*n]

    
    Uses routine eigendecomp in safe optimiser
    eigendecomp(dimen n, matrix S, vector eigval, dimen itmax);
    """
    if len(MM)==(n*n):
        M=MM
    else:
        M=[0]*(n*n)
        ij=0
        for i in range(n):
            for j in range(i+1):
                M[i+j*n]=MM[ij]
                if i != j:
                    M[j+i*n]=MM[ij]
                ij+=1
    if jython:
        S=array(M,Double)
        eigval=array([0]*n,Double)
    else:
        S=map(lambda t:t,M)
        eigval=[]
    itmax=3000
    r=eigendecomp(n,S,eigval,itmax)
    if r != 0:raise 'Eigenvalues were not found properly'
    if jython:
        S=[i for i in S]
        eigval=[i for i in eigval]
    return (eigval,S)
def eigvalprint(e):
    n=len(e)
    print 'Eigenvalues'
    for i in range(n):
        print '%4d %20.8e'%(i+1,e[i])
def eigvecprint(n,e):
    print 'Eigenvectors (as columns)'
    for j in range(n):
        out=''
        for i in range(n):
            out+='%20.8e '%(e[i*n+j])
        print out
def covprint(n,c):
    print 'Covariances'
    ij=0
    for i in range(n):
        out=''
        for j in range(i+1):
            out+='%20.8e '%c[ij]
            ij+=1
        print out
def makeapt(n,nfac,COV):
    """
    Make a principal component model from a covariance matrix which can
    be given either as a lower triangle or a square matrix. n is the number of
    stocks and nfac (must be <= n) is the number of principal components
    required. Principal components are ordered so that the stongest is first.
    The stockvariance list returned contains the stock variances. These
    are NOT equivalent to the specific variances in a factor model. The first
    n elements of Q are the stock residual variances, these are equivalent
    to the specific variances in a factor model.
    """
    (eigval,eigvec)=eigen(n,COV)

    if len(COV)==(n*n):stockvariance=[COV[i+n*i] for i in range(n)]
    else:stockvariance=[COV[i*(i+3)/2] for i in range(n)]

    if jython:Q=array([0]*((nfac+1)*n),Double)
    else:Q=[]

    FL=[0]*(n*nfac)

    for i in range(nfac):
        for j in range(n):
            FL[j+n*i]=eigvec[j+n*i]

    apt_model_process(n,nfac,FL,eigval,stockvariance,Q)
    if jython:Q=[i for i in Q]

    return (FL,eigval,stockvariance,Q)
def printeig(n,eigval,eigvec):
    """
    n is the order of the matrix
    eigval is the vector of size n of eigenvalues
    eigvec contains the n eigenvectors end to end
    """
    
    print '______________________________'
    for i in range(n):
        print 'Eigenvalue %d %12.5f\nEigenvector %d' % (i+1,eigval[i],i+1)
        for j in range(n):
            print '%12.5f' % eigvec[j+i*n]
        print '______________________________'
def decompFC(nl,ng,Y,G,S,FC):
    """Split the factor covariance matrix (FC) into pure global (SYGYS) and pure local (SFS) parts
    (Here we use genmult and getFSF which are written in c++)"""
    nn=nl*(nl+1)/2
    if jython:
        YS=array([0]*(nl*ng),Double)
    else:
        YS=[0]*(nl*ng)
    genmult(nl,ng,Y,S,YS)
    if jython:
        YS=[i for i in YS]
        SYGYS=array([0]*nn,Double)
    else:
        SYGYS=[0]*nn
    getFSF(nl,ng,G,YS,SYGYS)
    if jython:SYGYS=[i for i in SYGYS]
    SFS=[FC[i]-SYGYS[i] for i in range(nn)]
    return(SYGYS,SFS)
class Opt:
    def __init__(self):
        self.n=0
        self.nfac=0
        self.names=[]
        self.FC=[]
        self.FL=[]
        self.SV=[]
        self.m=0
        self.bench=[]
        self.alpha=[]
        self.A=[]
        self.L=[]
        self.U=[]
        self.gamma=0
        self.kappa=.5
        self.costs=0
        self.initial=[]
        self.delta=2
        self.buy=[]
        self.sell=[]
        self.mask=[]
        self.basket=-1
        self.tradenum=-1
        self.revise=0
        self.min_holding=-1
        self.min_trade=-1
        self.ls=0
        self.full=1
        self.rmin=-1
        self.rmax=-1
        self.round=0
        self.min_lot=[]
        self.size_lot=[]
        self.shake=[]
        self.ncomp=0
        self.Composites=[]
        self.value=1
        self.npiece=0
        self.hpiece=[]
        self.pgrad=[]
        self.nabs=0
        self.A_abs=[]
        self.mabs=0
        self.I_A=[]
        self.Abs_U=[]
        self.Q=[]
        self.riskc=0
        self.shake=[]
        self.w=[]
        self.costgrad=None
        self.costfunc=None
        self.costhess=None
        self.SV=[]
        self.FC=[]
        self.FL=[]
        self.npoints=0
        self.frontrisk=[]
        self.frontarisk=[]
        self.frontareturn=[]
        self.frontrreturn=[]
        self.risk=[]
        self.arisk=[]
        self.areturn=[]
        self.rreturn=[]
        self.minrisk=-1
        self.maxrisk=-1
        self.take_out_costs=0
        self.log=1
        self.logfile=""
        self.downrisk=0
        self.downfactor=3
        self.DoByRisks=0
        self.longbasket=-1
        self.shortbasket=-1
        self.tradebuy=-1
        self.tradesell=-1
        self.zetaS=1
        self.zetaF=1
        self.ShortCostScale=1
    def process(self):
        """Get the compressed risk array from risk model data."""
        if self.nfac==-1:raise 'must have 0 or more factors'
        if jython:
            if getattr(self,'Q') == []:
                    Q=array([0]*((self.n-self.ncomp)*(self.nfac+1)),Double)
            else:
                if len(self.Q) != (self.n-self.ncomp)*(self.nfac+1):raise 'member Q is too small'
                Q=array(self.Q,Double)
        else:
            Q=self.Q
        factor_model_process(self.n,self.nfac,self.FL,self.FC,self.SV,Q)
        setattr(self,'Q',map(lambda t:t,Q))
    def props(self):
        """Get the marginal risks and expected risks and returns and also factor exposures."""
        c=0
        if debug:
            for i in self.__dict__.keys():
                print '%4d\t%20s'%(c+1,i),self.__dict__[i]
                c+=1
        FMCAR=[]
        FMCTR=[]
        FMCRR=[]
        FMCBR=[]
        FMCSR=[]
        FX=[]
        AFX=[]
        RFX=[]
        BFX=[]
        SFX=[]
        if getattr(self,'alpha')==[]:
            setattr(self,'alpha',[0]*(self.n))
        if jython:
            arisk=array([0],Double)
            risk=array([0],Double)
            Rrisk=array([0],Double)
            brisk=array([0],Double)
            pbeta=array([0],Double)
            rreturn=array([0],Double)
            areturn=array([0],Double)
            Rreturn=array([0],Double)
            breturn=array([0],Double)
            srisk=array([0],Double)
            MCAR=array([0]*self.n,Double)
            MCTR=array([0]*self.n,Double)
            MCRR=array([0]*self.n,Double)
            MCBR=array([0]*self.n,Double)
            beta=array([0]*self.n,Double)
            if self.nfac>-1:
                FMCAR=array([0]*(self.n+self.nfac),Double)
                FMCTR=array([0]*(self.n+self.nfac),Double)
                FMCRR=array([0]*(self.n+self.nfac),Double)
                FMCBR=array([0]*(self.n+self.nfac),Double)
                FMCSR=array([0]*(self.n+self.nfac),Double)
                FX=array([0]*self.nfac,Double)
                AFX=array([0]*self.nfac,Double)
                BFX=array([0]*self.nfac,Double)
                SFX=array([0]*self.nfac,Double)
                RFX=array([0]*self.nfac,Double)
        else:
            arisk=[]
            risk=[]
            Rrisk=[]
            brisk=[]
            pbeta=[]
            rreturn=[]
            areturn=[]
            Rreturn=[]
            breturn=[]
            srisk=[]
            MCAR=[]
            MCTR=[]
            MCRR=[]
            MCBR=[]
            beta=[]
        if self.Q==[]:
            if jython:
                Q=array([0]*(self.n*(self.nfac+1)),Double)
                factor_model_process(self.n,self.nfac,self.FL,self.FC,self.SV,Q)
                setattr(self,'Q',Q)
            else:factor_model_process(self.n,self.nfac,self.FL,self.FC,self.SV,self.Q)
        PropertiesCA(self.n,self.nfac,self.names,self.w,self.bench,self.alpha,rreturn,
                     areturn,Rreturn,breturn,self.Q,
                     risk,arisk,Rrisk,brisk,srisk,pbeta,MCAR,MCTR,MCRR,MCBR,FMCRR,
                     FMCTR,FMCAR,FMCBR,FMCSR,beta,FX,RFX,AFX,BFX,SFX,self.FL,self.FC,self.SV,
                     self.ncomp,self.Composites)
        for i in ['arisk','risk','Rrisk','brisk','pbeta','areturn',
                  'rreturn','Rreturn','breturn','srisk']:setattr(self,i,map(lambda t:t,eval(i))[0])
        for i in ['MCAR','MCTR','MCRR','MCBR','beta','FMCAR',
                  'FMCTR','FMCRR','FMCSR','FMCBR','FX','AFX','SFX','RFX','BFX']:setattr(self,i,map(lambda t:t,eval(i)))
    def simplepiece_ext(self,costgrad,costfunc):
        """Set up variables for an optimisation with budget constraint and all long with
        piecewise costs define externally"""
        if(self.n==0): raise 'Number of variables has not been set'
        self.m=1
        self.L=[0]*(self.n)+[1]
        self.U=[1]*(self.n+1)
        self.A=[1]*(self.n)
        self.costfunc=costfunc
        self.costgrad=costgrad
        self.npiece=0
        self.hpiece=[]
        self.pgrad=[]
    def simplepiece_int(self,npiece,hpiece,pgrad):
        """Set up variables for an optimisation with budget constraint and all long with
        piecewise costs define internally"""
        if(self.n==0): raise 'Number of variables has not been set'
        self.m=1
        self.L=[0]*(self.n)+[1]
        self.U=[1]*(self.n+1)
        self.A=[1]*(self.n)
        self.costs=1
        self.npiece=npiece
        self.hpiece=hpiece
        self.pgrad=pgrad
        self.costfunc=None
        self.costgrad=None
    def simpleset(self):
        """Set up variables for an optimisation with budget constraint and all long"""
        if(self.n==0): raise 'Number of variables has not been set'
        self.m=1
        self.L=[0]*(self.n)+[1]
        self.U=[1]*(self.n+1)
        self.A=[1]*(self.n)
    def simplehedge(self):
        """Set up long/short/balanced optimisation"""
        if(self.n==0): raise 'Number of variables has not been set'
        self.ls=1
        self.full=1
        self.m=1
        self.L=[-1]*self.n+[0]
        self.U=[1]*self.n+[0]
        self.A=[1]*(self.n)
    def getmodel(self,model,stocknames):
        self.nfac=nfac=get_nfac(model)
        if(nfac==0):raise 'Problem with file %s, there are no factors'%model
        nstocks=get_nstocks(model)
        self.n=n=len(stocknames)
        FL=[]
        SV=[]
        if jython:
            if n:
                FL=array([0]*(n*nfac),Double)
                SV=array([0]*n,Double)
            FC=array([0]*(nfac*(nfac+1)/2),Double)
            fnames=array(['1'*200]*nfac,String)
            mnames=array(['1'*100]*nstocks,String)
        else:
            if n:
                FL=[0]*(n*nfac)
                SV=[0]*n
            FC=[0]*(nfac*(nfac+1)/2)
            fnames=['0'*200]*nfac
            mnames=['1'*100]*nstocks
        get_stocknames(mnames,model)
        get_factornames(fnames,model)
        if n:
            #print n,nfac,stocknames,FL,SV,FC,model
            getdata(n,nfac,stocknames,FL,SV,FC,model)
        names=stocknames
        for i in ['FC','FL','SV','names','fnames','mnames']:setattr(self,i,map(lambda t:t,eval(i)))

    def SOCPopt(self):
        """Very basic set up for Second Order Cone Optimisation"""
        w=[]
        if jython:
            w=array([0]*self.n,Double)
        log=self.log
        SOCPopt(self.n,self.m,self.md,self.c,self.A,self.b,w,1e-2,10,100,1,0,log)
        for i in ['w']:setattr(self,i,map(lambda t:t,eval(i)))
        
    def SOCPquad(self):
        """Use SOCP to do quadratic programming (full covariance Q)
        We do this by solving the SOCP
        min t
        such that
        Li<=xi<=Ui
        L(n+i)<=[Ax]i=U(n+i)
        ||-gamma/(1-gamma)*alpha.x + 0.5 x*Q*x|| <= scalefac*t
        We can write the || || as a square using R*R=Q
        """
        if self.nfac>-1:
            Q=[0]*(self.n*(self.n+1)/2)
            if jython:Q=jython_set(Q)
            Factor2Cov(self.n,self.nfac,self.FC,self.FL,self.SV,Q)
            if jython: Q=[i for i in Q]
            self.Q=Q
        rQ=[]
        rQm1=[]
        scalefac=1
        if jython:
            rQ=array([0.0]*(self.n*self.n),Double)
            rQm1=array([0.0]*(self.n*self.n),Double)
        RootQ(self.n,self.Q,rQ,rQm1)
        if jython:
            rQ=[i for i in rQ]
            rQm1=[i for i in rQm1]
        #for i in range(self.n):#To check that we get the inverse matrix
        #    for j in range(i+1):
        #        print dot(rQ[i*self.n:(i+1)*self.n],rQm1[j*self.n:(j+1)*self.n]),dot(rQ[j*self.n:(j+1)*self.n],rQm1[i*self.n:(i+1)*self.n])
        #implied=[dot(rQ[i*self.n:(i+1)*self.n],self.bench) for i in range(self.n)]
        #print dot(implied,implied)
        #Sym_mult(self.n,self.Q,self.bench,implied)
        #print dot(implied,self.bench)
        #raise 'stop'
        n=self.n+1
        m=self.n+self.m+1
        md=[n+1]+[2]*(self.n+self.m)
        c=[0]*self.n+[1]
        A=[]
        cc=-self.gamma/(1-self.gamma)
        implied=[0]*n
        if jython:implied=jython_set(implied)
        if self.bench!=[]:Sym_mult(self.n,self.Q,self.bench,implied)
        if jython:implied=[i for i in implied]
        avec=[cc*self.alpha[i]-implied[i] for i in range(self.n)]
        cvec=[0]*n
        for i in range(self.n):cvec[i]=dot(avec,rQm1[i*self.n:(i+1)*self.n])
        for i in range(self.n):
            A+=rQ[i*self.n:(i+1)*self.n]
            A+=[0]
        A+=[0]*n
        A+=[0]*self.n
        A+=[scalefac]
        for i in range(self.n):
            s=[0]*n
            s[i]=1
            A+=s
            A+=[0]*n
        for i in range(self.m):
            s=[0]*n
            for j in range(self.n):s[j]=self.A[j*self.m+i]
            A+=s
            A+=[0]*n
        b=[]
        b+=cvec+[0]
        for i in range(self.n+self.m):
            b.append(-(self.L[i]+self.U[i])*.5)
            b.append((self.U[i]-self.L[i])*.5)
        """
        ## Using feasible method ##############################################
        wf=[]
        if jython:wf=array([0]*n,Double)
        SOCPopt(n,m,md,c,A,b,wf,1e-2,10,1000,1,0,self.log)
        print "t is %20.12e; Constant %20.12e"%(scalefac*wf[n-1],(-0.5*dot(cvec,cvec)))
        print 'BITA Utility upper limit\t%20.12e'%(0.5*(scalefac*scalefac*wf[n-1]*wf[n-1]-dot(cvec,cvec)))
        X=[0]*(self.n)
        wf=wf[:(n-1)]
        for i in range(self.n):X[i]=dot(wf,rQ[i*self.n:(i+1)*self.n])
        print 'BITA Utility\t\t\t%20.12e'%(dot(X,X)*.5+dot(X,cvec))
        #######################################################################
        """
        ## Using infeasible method ##############################################
        nx=sum(md)
        x=[0]*nx
        s=[0]*nx
        w=[0]*n
        tau=[0]
        kappa=[0]
        if jython:
            for i in ['x','s','w','tau','kappa','A']:
                exec '%s=array(%s,"d")'%(i,i)
        if self.n < 10:
            for i in range(nx):
                outs='%3d '%(i+1)
                for j in range(n):
                    outs+='%20.12e '%A[j+i*n]
                print outs
                    
        dmx_transpose(n,nx,A,A)
        if self.n < 10:
            for i in range(n):
                outs='%3d '%(i+1)
                for j in range(nx):
                    outs+='%20.12e '%A[j+i*nx]
                print outs
        eps=pow(epsget(),.5)
        if SOCPinfeasHomogt(m,n,md,b,A,c,x,w,s,tau,kappa,100,1e-8,.5,eps,eps,0,4,1e-8,1,""):print 'SOCP failed '*10
        if tau[0]<kappa[0]:
            print 'INFEASIBLE '*5
            if dot(c,w)>0:print 'c dot y %20.12e primal is infeasible'%(dot(c,w))
            if dot(b,x)<0:print 'b dot x is %20.12e dual is infeasible (our problem)'%(dot(b,x))
        else:
            w=[-i/tau[0] for i in w]
            print "t is %20.12e; Constant %20.12e"%(scalefac*w[n-1],(-0.5*dot(cvec,cvec)))
            print 'BITA Utility upper limit\t%20.12e'%(0.5*(scalefac*scalefac*w[n-1]*w[n-1]-dot(cvec,cvec)))
            X=[0]*(self.n)
            w=w[:(n-1)]
            for i in range(self.n):X[i]=dot(w,rQ[i*self.n:(i+1)*self.n])
            print 'BITA Utility\t\t\t%20.12e'%(dot(X,X)*.5+dot(X,cvec))
            for i in ['w']:setattr(self,i,map(lambda t:t,eval(i)))
        #######################################################################
        
    def opt(self):
        from time import clock
        """Optimise, if self.nfac>-1 and self.FC, self.SV and self.FL are all not empty,
            then self.Q is returned as compressed risk array."""
        c=0
        if debug:
            for i in self.__dict__.keys():
                print '%4d\t%20s'%(c+1,i),self.__dict__[i]
                c+=1
        if jython:
            w=array([0]*self.n,Double)          #Need java objects for returned variables
            shake=array([-1]*self.n,Integer)
            ogamma=array([(self.gamma)],Double)
            if getattr(self,'Q') == []:
                if getattr(self,'nfac')>-1:
                    Q=array([0]*((self.n-self.ncomp)*(self.nfac+1)),Double)
            else:
                Q=array(self.Q,Double)
        else:
            w=[]
            shake=[]
            Q=self.Q
            ogamma=[(self.gamma)]
        for i in range(self.n):
            try:
                self.names[i]=str(self.names[i])
            except:pass
        t1=clock()
        if self.costfunc == None or self.costgrad == None:
            if 0:
                """This is for testing the csdp optimiser"""
                import SDPgen
                w=[0]*(self.n)
                if self.maxrisk>0:RR=sqr(self.maxrisk)
                else:RR=0
                cov=[0]*(self.n*(self.n+1)/2)
                if self.nfac>-1:Factor2Cov(self.n,self.nfac,self.FC,self.FL,self.SV,cov)
                else:cov=Q
                ret= SDPgen.Opt(self.n,self.m,w,self.L,self.U,self.alpha,self.bench,self.gamma,self.A,cov,self.basket,RR)
            else:ret = Optimise_internalCVPAFb(self.n,self.nfac,self.names,w,self.m,self.A,
                                    self.L,self.U,self.alpha,self.bench,Q,
                                    self.gamma,self.initial,self.delta,self.buy,
                                    self.sell,self.kappa,self.basket,self.tradenum,
                                    self.revise,self.costs,self.min_holding,
                                    self.min_trade,self.ls,self.full,self.rmin,
                                    self.rmax,self.round,self.min_lot,self.size_lot,
                                    shake,self.ncomp,self.Composites,self.value,
                                    self.npiece,self.hpiece,self.pgrad,self.nabs,self.A_abs,
                                    self.mabs,self.I_A,self.Abs_U,self.FC,self.FL,self.SV,
                                    self.minrisk,self.maxrisk,ogamma,self.mask,self.log,self.logfile,
                                    self.downrisk,self.downfactor,self.longbasket,self.shortbasket,
                                    self.tradebuy,self.tradesell,self.zetaS,self.zetaF,self.ShortCostScale)
        else:
            ret = Optimise_internalCVPAextcosts(self.n,self.nfac,self.names,w,self.m,self.A,
                                    self.L,self.U,self.alpha,self.bench,Q,
                                    self.gamma,self.initial,self.delta,self.kappa,
                                    self.basket,self.tradenum,
                                    self.revise,self.min_holding,
                                    self.min_trade,self.ls,self.full,self.rmin,
                                    self.rmax,self.round,self.min_lot,self.size_lot,
                                    shake,self.ncomp,self.Composites,self.value,
                                    self.nabs,self.A_abs,
                                    self.mabs,self.I_A,self.Abs_U,self.FC,self.FL,self.SV,
                                    self.costfunc,self.costgrad,self.costhess,self.minrisk,self.maxrisk,ogamma,
                                    self.take_out_costs,self.mask,self.log,self.logfile,1,self.downrisk,self.downfactor,
                                    self.longbasket,self.shortbasket,
                                    self.tradebuy,self.tradesell,self.zetaS,self.zetaF,self.ShortCostScale)

        #eigval=eigen(self.nfac,self.FC)[0]
        #print 'Eigenvalues of the factor covariance matrix'
        #for i in range(self.nfac):
        #    print '%4d %20.8e'%(i+1,eigval[i])
        t2=clock()
        print 'Optimisation needed %d secs'%(t2-t1)
        if ret>1:print '@*'*10,' ',ret,' ','*@'*10
        if getattr(self,'Q')==[]:setattr(self,'Q',map(lambda t:t,Q))
        for i in ['w','shake']:setattr(self,i,map(lambda t:t,eval(i)))
        for i in ['ogamma']:setattr(self,i,map(lambda t:t,eval(i))[0])
        if ret >-1:setattr(self,'returnmessage',Return_Message(ret))
        else:setattr(self,'returnmessage','Optimiser is not licensed!')
        return ret
    def risks(self):
        """Get risks and betas."""
        c=0
        if debug:
            for i in self.__dict__.keys():
                print '%4d\t%20s'%(c+1,i),self.__dict__[i]
                c+=1
        if jython:
            arisk=array([0],Double)
            risk=array([0],Double)
            Rrisk=array([0],Double)
            brisk=array([0],Double)
            pbeta=array([0],Double)
        else:
            arisk=[]
            risk=[]
            Rrisk=[]
            brisk=[]
            pbeta=[]
        if self.Q==[]:
            if jython:
                Q=array([0]*(self.n*(self.nfac+1)),Double)
                factor_model_process(self.n,self.nfac,self.FL,self.FC,self.SV,Q)
                setattr(self,'Q',[i for i in Q])
            else:factor_model_process(self.n,self.nfac,self.FL,self.FC,self.SV,self.Q)
        Get_RisksC(self.n,self.nfac,self.Q,self.w,self.bench,arisk,risk,Rrisk,brisk,pbeta,self.ncomp,self.Composites)
        for i in ['arisk','risk','Rrisk','brisk','pbeta']:setattr(self,i,map(lambda t:t,eval(i))[0])
    def margutility(self):
        """Method for getting marginal utility, cost per stock, cost and utility. More needs to be done when
            using external term in the utility function."""
        c=0
        if debug:
            for i in self.__dict__.keys():
                print '%4d\t%20s'%(c+1,i),self.__dict__[i]
                c+=1
        if jython:
            tcost=array([0],Double)
            utility=array([0],Double)
            gradutility=array([0]*self.n,Double)
            utility_per_stock=array([0]*self.n,Double)
            cost_per_stock=array([0]*self.n,Double)
        else:
            tcost=[]
            utility=[]
            gradutility=[]
            utility_per_stock=[]
            cost_per_stock=[]
        kappa=self.kappa
        if self.costs==3:
            kappa=0
        if self.costfunc == None or self.costgrad == None:
            MarginalUtilityb(self.n,self.nfac,self.names,self.w,
                            self.bench,self.initial,
                            self.Q,self.gamma,kappa,
                            self.npiece,self.hpiece,self.pgrad,
                            self.buy,self.sell,
                            self.alpha,tcost,utility,gradutility,utility_per_stock,cost_per_stock,
                            self.ncomp,self.Composites,self.ShortCostScale)
        else:
            if self.kappa<0:self.kappa=gamma
            utility_per_stock=[]
            cost_per_stock=[]
            MarginalUtility_ext(self.n,self.nfac,self.names,self.w,
                            self.bench,self.initial,
                            self.Q,self.gamma,kappa,
                            self.alpha,tcost,utility,gradutility,
                            self.ncomp,self.Composites,self.ShortCostScale,self.costfunc,self.costgrad)
        for i in ['utility']:setattr(self,i,map(lambda t:t,eval(i))[0])
        for i in ['gradutility','utility_per_stock']:setattr(self,i,map(lambda t:t,eval(i)))
        if self.costs==3:
            if self.costfunc == None or self.costgrad == None:
                MarginalUtilityb(self.n,self.nfac,self.names,self.w,
                                self.bench,self.initial,
                                self.Q,self.gamma,self.kappa,
                                self.npiece,self.hpiece,self.pgrad,
                                self.buy,self.sell,
                                self.alpha,tcost,utility,gradutility,utility_per_stock,cost_per_stock,
                                self.ncomp,self.Composites,self.ShortCostScale)
            else:
                utility_per_stock=[]
                cost_per_stock=[]
                MarginalUtility_ext(self.n,self.nfac,self.names,self.w,
                                self.bench,self.initial,
                                self.Q,self.gamma,kappa,
                                self.alpha,tcost,utility,gradutility,
                                self.ncomp,self.Composites,self.ShortCostScale,self.costfunc,self.costgrad)
        for i in ['tcost']:setattr(self,i,map(lambda t:t,eval(i))[0])
        for i in ['cost_per_stock']:setattr(self,i,map(lambda t:t,eval(i)))

    def front(self):
        """The method for getting frontier points."""
        c=0
        if debug:
            for i in self.__dict__.keys():
                print '%4d\t%20s'%(c+1,i),self.__dict__[i]
                c+=1
        if jython:
            w=array([0]*(self.n*self.npoints),Double)          #Need java objects for returned variables
            shake=array([-1]*self.n,Integer)
            frontrisk=array([0]*self.npoints,Double)
            frontarisk=array([0]*self.npoints,Double)
            frontrreturn=array([0]*self.npoints,Double)
            frontareturn=array([0]*self.npoints,Double)
            if getattr(self,'Q') == []:
                if getattr(self,'nfac')>-1:
                    Q=array([0]*((self.n-self.ncomp)*(self.nfac+1)),Double)
            else:
                Q=array(self.Q,Double)
        else:
            w=[]
            shake=[]
            frontrisk=[]
            frontarisk=[]
            frontrreturn=[]
            frontareturn=[]
            Q=self.Q
        if self.costfunc == None or self.costgrad == None:
            ret = FrontierCVPAF(self.npoints,frontrisk,frontarisk,frontrreturn,frontareturn,self.n,
                                self.nfac,self.names,w,self.m,self.A,
                                self.L,self.U,self.alpha,self.bench,Q,
                                self.initial,self.delta,self.buy,
                                self.sell,self.kappa,self.basket,self.tradenum,
                                self.revise,self.costs,self.min_holding,
                                self.min_trade,self.ls,self.full,self.rmin,
                                self.rmax,self.round,self.min_lot,self.size_lot,
                                shake,self.ncomp,self.Composites,self.value,
                                self.npiece,self.hpiece,self.pgrad,self.nabs,self.A_abs,
                                self.mabs,self.I_A,self.Abs_U,self.FC,self.FL,self.SV,self.mask,self.DoByRisks)
        else:
            ret = FrontierCVPAextcosts(self.npoints,frontrisk,frontarisk,frontrreturn,frontareturn,
                                self.n,self.nfac,self.names,w,self.m,self.A,
                                self.L,self.U,self.alpha,self.bench,Q,
                                self.initial,self.delta,self.kappa,
                                self.basket,self.tradenum,
                                self.revise,self.min_holding,
                                self.min_trade,self.ls,self.full,self.rmin,
                                self.rmax,self.round,self.min_lot,self.size_lot,
                                shake,self.ncomp,self.Composites,self.value,
                                self.nabs,self.A_abs,
                                self.mabs,self.I_A,self.Abs_U,self.FC,self.FL,self.SV,
                                self.costfunc,self.costgrad,self.costhess,self.take_out_costs,self.mask,1,
                                self.DoByRisks,self.longbasket,self.shortbasket,self.tradebuy,self.tradesell,
                                self.ShortCostScale)
        if ret>1:print '@*'*10,' ',ret,' ','*@'*10
        if getattr(self,'Q')==[]:
            setattr(self,'Q',map(lambda t:t,Q))
        for i in ['w','shake','frontrisk','frontarisk','frontrreturn',
                  'frontareturn']:setattr(self,i,map(lambda t:t,eval(i)))

