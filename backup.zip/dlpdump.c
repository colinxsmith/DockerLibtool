#include "ldefns.h"
/*
	LPDUMP  PRINTS  A, BL, BU, CVEC, X, A*X
	COLD, LP, MINSUM, VERTEX, AND POSSIBLY ISTATE. 
*/
void dlpdump(dimen n, dimen nclin, dimen nctotl, dimen nrowa, int lcrash, int lp, int minsum, int vertex, short_vec istate, matrix a, vector ax, vector bl, vector bu, vector cvec, vector x)
{
    dimen	j, k;
    real	atx;

	lm_wmsg("\n\n\n\n\n\nOUTPUT FROM LPDUMP\n ******************");
	lm_wmsg("\nLCRASH =%d LP=%d MINSUM=%d VERTEX=%d", lcrash, lp, minsum, vertex);

	/*PRINT  A  BY ROWS AND COMPUTE  AX = A*X. */
	for (k = 0; k < nclin; ++k) {
		lm_wmsg("\nROW%6ld OF A ...",CL(k+1));
		lm_gdvwri(n, a+k, nrowa);
		ax[k] = BITA_ddot(n, a+k, nrowa, x, 1);
		}

	/*PRINT  BL, BU  AND  X OR AX. */
	lm_wmsg("\n              J      BL(J)          BU(J)           X(J)");
	for (j = 0; j < nctotl; ++j) {
		if (j < n){
			k = j;
			atx = x[j];
			}
		else	{
			k = j - n;
			atx = ax[k];
			if(!k)
			lm_wmsg("\n              I    BL(N+I)        BU(N+I)         A(I)*X");
			}
		lm_wmsg("%15ld %15.6lg %15.6lg %15.6lg", CL(k+1), bl[j], bu[j], atx);
    		}
	if(lp&1) lm_mdvwri("\nCVEC ...", n, cvec);
	if(lcrash) lm_mivwri("\nISTATE ...", nctotl, &istate[1]);
}
