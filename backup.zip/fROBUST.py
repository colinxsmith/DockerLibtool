#!/bin/env python
#Colin 12-1-2006 We've decided what the data for robust optimisation looks like!

from Opt import *
def var(x,Q):
    n=len(x)
    y=[]
    Sym_mult(n,Q,x,y)
    return dot(x,y)
def risk(x,Q):
    """risk is sqrt(x'.Q.x); x is a list of length, Q is of length n*(n+1)/2"""
    return pow(var(x,Q),.5)
def meanerror(x,Q):
    """meanerror is sqrt(sum (xiQi)**2); x is a list of length, Q is of length n"""
    return pow(sum([x[i]*x[i]*Q[i]*Q[i] for i in range(len(x))]),.5)

#Usual BITA Plus parameters
n=3
nf=-1                           #use FC as covariance matrix if nf is negative
m=1
w=[]
A=[1,1,1]
SV=[]
FL=[]
FC=[1,.02,3,.04,.05,6]
alpha=[.02,.01,.03]
gamma=0.5
L=[0]*n+[1]
U=[1]*n+[1]
benchmark=[.5,.3,.2]
initial=[0.2,0.5,0.3]


#New Robust parameters
meanFE=[1e-4,3e-4,2e-4]         #means of forecast errors
covFE=[6,.1,5,.2,.3,1]          #covariance matrix of forecast 2nd moments
maxmeanFE=6.95e-05              #max allowed mean of forecast error
maxstderrorFE=1.444             #max allowed standard deviation od forecast error
maxRisk=.0058                   #max allowed relative risk

"""
If maxRisk is set negative, the optimisation minimises the usual BITA Plus
utility function, subject to the variable bound constraints, linear
constraints and the 2 new robust constraints.

If max risk is non-negative, the optimisation maximises return suject to
the variable bound constraints, linear constraints, the (relative) risk
constaint and the 2 new robust constraints.
"""

mFE=1
rFE=0
print SOCPlstestMessage(SOCPRobust(n,m,w,A,L,U,nf,SV,FL,FC,alpha,meanFE,covFE,
                                   maxmeanFE,maxstderrorFE,gamma,maxRisk,benchmark,initial,mFE,rFE))
print w
print 'Sum of weights',sum(w)
print 'return',dot(alpha,w)
print 'risk',risk([w[i]-benchmark[i] for i in range(n)],FC)
print 'forcast mean error',meanerror([w[i]-mFE*initial[i] for i in range(n)],meanFE)
print 'forcast error',risk([w[i]-rFE*initial[i] for i in range(n)],covFE)
