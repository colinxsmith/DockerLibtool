from Opt import *

n=5
R=[11,12,13,14,15,
   21,22,23,24,25,
   31,32,33,34,35,
   41,42,43,44,45,
   51,52,53,54,55]
order=[3,2,4,0,1]
iorder=[0]*n
for i in range(n):
    iorder[order[i]]=i
ReorderSquare(n,order,R)
print R

C=[1,.0012,2,.0013,.0023,3,.0014,.0024,.0034,4,.0015,.0025,.0035,.0045,5]
RQ=[0]*(n*n)
RQm1=[0]*(n*n)
RootQ(n,C,RQ,RQm1)
ReorderSquare(n,order,RQ)
ReorderSquare(n,order,RQm1)
for i in range(n):
    out=''
    for j in range(n):
        out+=str(dot(RQ[i*n:(i+1)*n],RQm1[j*n:(j+1)*n]))+' '
    print out
for i in range(n):
    out=''
    for j in range(n):
        out+=str(dot([RQ[n*k+i] for k in range(n)],[RQ[n*k+j] for k in range(n)]))+' '
    print out

print RQ
x=[.1,.2,.3,0,0]
y=[]
ReorderS(n,order,C)
Sym_mult(n,C,x,y)
print y
print dot(y,x)
y=[0]*n
dmxtmulv(n,3,RQ,x,y)
print dot(y,y)
raise 'ww'
print C
n=3
x=[.1,.2,.3]
RootQ(n,C,RQ,RQm1)
y=[]
Sym_mult(n,C,x,y)
print y
print dot(y,x)
dmxtmulv(n,n,RQ,x,y)
print dot(y,y)
for i in range(n):
    out=''
    for j in range(n):
        out+=str(dot(RQ[i*n:(i+1)*n],RQm1[j*n:(j+1)*n]))+' '
    print out
for i in range(n):
    out=''
    for j in range(n):
        out+=str(dot([RQ[n*k+i] for k in range(n)],[RQ[n*k+j] for k in range(n)]))+' '
    print out
