public abstract class JavaCost
{
    double shortCostScale;
    double[]initial;
    int npiece;
    double[]pgrad;
    double[]hpiece;
	public void setHpiece(double[] hh)
	{
		hpiece=hh;
	}
	public double[] getHpiece()
	{
		return hpiece;
	}
	public void setPgrad(double[] pp)
	{
		pgrad=pp;
	}
	public double[] getPgrad()
	{
		return pgrad;
	}
	public void setInitial(double[] ii)
	{
		initial=ii;
	}
	public double[] getInitial()
	{
		return initial;
	}
	public void setNpiece(int nn)
	{
		npiece=nn;
	}
	public int getNpiece()
	{
		return npiece;
	}
	public void setShortCostScale(double Se)
	{
		shortCostScale=Se;
	}
	public double getShortCostScale()
	{
		return shortCostScale;
	}
    public void modc(long n,double[]w,double[]c)
    {
        int is,j,i;
		boolean done;
		double scale,ww;
        for(j=0,is=0;j<n;++j)
		{
            done=false;
            scale=1;
            if(w[j]<0){scale=shortCostScale;}
            ww=w[j]-initial[j];
            if(ww<hpiece[is])
			{
                c[j]=pgrad[is]*scale;
                done=true;
                is+=npiece;
                continue;
			}
            for(i=1;i<npiece;++i)
			{
                if(ww<hpiece[is+i] && ww>=hpiece[is+i-1])
				{
					if(ww>0){c[j]=pgrad[is+i]*scale;}
					else if(ww<0){c[j]=pgrad[is+i-1]*scale;}
					else{c[j]=0;}
					done=true;
					break;
				}
			}
            if(done)
			{
                is+=npiece;                
                continue;
			}
            c[j]=pgrad[is+npiece-1]*scale;
            is+=npiece;                
		}
    }
    public double util(long n,double[]w)
    {
        int is,nstart,i,j;
		boolean done;
        double usehpiecei,ww,total=0,scale,sofar;
        for(j=0,is=0,nstart=0;j<n;++j)
		{
            done=false;
            scale=1;
            if(w[j]<0){scale=shortCostScale;}
            for(i=0;i<npiece;++i)
			{
                if(hpiece[is+i]>0){nstart=i;break;}
			}
            ww=w[j]-initial[j];
            if(ww<=hpiece[nstart+is] && ww>=0)
			{
                total+=ww*pgrad[nstart+is]*scale;
                done=true;
                is+=npiece;
                continue;
			}
            sofar=hpiece[nstart+is]*pgrad[nstart+is]*scale;
            if(ww>0)
			{
                for(i=nstart+1;i<npiece;++i)
				{
                    if(ww<hpiece[i+is] && ww>=hpiece[i-1+is])
					{
                        total+=sofar+(ww-hpiece[i-1+is])*pgrad[i+is]*scale;
                        done=true;
                        break;
					}
                    sofar+=(hpiece[i+is]-hpiece[i-1+is])*pgrad[i+is]*scale;
				}
			}
            if(done)
			{
                is+=npiece;
                continue;
			}
            if(ww>=0)
			{
                total+=sofar+(ww-hpiece[npiece-1+is])*pgrad[npiece-1+is]*scale;
                done=true;
                is+=npiece;
                continue;
			}
            sofar=0;
			for(i=nstart;i>0;--i)
			{
                usehpiecei=hpiece[is+i];
                if(i == nstart){usehpiecei=0;}
                if(ww<usehpiecei && ww>= hpiece[i-1+is])
				{
                    total+=sofar+(ww-usehpiecei)*pgrad[i-1+is]*scale;
                    done=true;
                    break;
				}
                sofar-=(usehpiecei-hpiece[i-1+is])*pgrad[i-1+is]*scale;
			}
            if(done)
			{
                is+=npiece;
                continue;
			}
            total+=sofar+(ww-hpiece[is])*pgrad[is]*scale;
            is+=npiece;
		}
        return total;
    }
}
