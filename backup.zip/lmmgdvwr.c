#include <string.h>
#include "ldefns.h"
void lm_mgdvwri(const char *name, dimen n, real *x, increment incx)
{
	if(n)	{
		lm_name_write(name,5,16);
		lm_gdvwri(n, x, incx);
		}
}
