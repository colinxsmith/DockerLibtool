/*
	disamaxvec( dimen n, vector v, dimen * i)

		returns the maximum absolute value of n vector, v
		the sequence number of the winner is stored in
		*i unless i is NULL
*/
#include "ldefns.h"
real disamaxvec(dimen n, vector v, dimen *i)
{
	real	temp;
	dimen	j;
	undex	imax = 0;
	real	amax = 0.0;

	for(j=0;n--;v++ )
		if( (temp=fabs(CD(*v))) > amax ){
			imax = j;
			amax = temp;
			}
	if(i) *i = imax;
	return amax;
}
