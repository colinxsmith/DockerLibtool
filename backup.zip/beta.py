#! /bin/env python
"""
Property methods via python and jython
"""

try:
    from java.lang import *
    System.loadLibrary("safejavajy")
    from jarray import *
    from safejavajy import *
except:
    from safe import *
from math import sqrt
def dot(a,b,inc=0):
    s=0
    n=len(a)
    for i in range(n):s+=a[i]*b[i+inc]
    return s

n=11
ncomp=1
nfac=2
SV=[(i+1)*1e-4 for i in range(n-ncomp)]
FL=[1]*(n-ncomp)+[1,-1]*((n-ncomp)/2)
FC=[i*1e-4 for i in [1,.1,1]]

bench=[.1]*(n-ncomp)+[0]*ncomp
w=[1]+[0]*(n-1)

try:
    Q=array([0]*(n-ncomp)*(nfac+1),Double)
except:
    Q=[]
factor_model_process(n-ncomp,nfac,FL,FC,SV,Q)

print Q
Composites=[.1]*(n-ncomp)

try:
    beta=array([0]*n,Double)
except:
    beta=[]
    
QQ=map(lambda i:i,Q)

GetBeta(n,nfac,bench,QQ,beta,ncomp,Composites)

print beta

try:
    arisk=array([0],Double)
    risk=array([0],Double)
    Rrisk=array([0],Double)
    brisk=array([0],Double)
    pbeta=array([0],Double)
except:
    arisk=[]
    risk=[]
    Rrisk=[]
    brisk=[]
    pbeta=[]
Get_RisksC(n,nfac,QQ,w,bench,arisk,risk,Rrisk,brisk,pbeta,ncomp,Composites)

print 'Total risk %e'%arisk[0]
print 'Active risk %e'%risk[0]
print 'Resdiual risk %e'%Rrisk[0]
print 'Benchmark risk %e'%brisk[0]
print 'Portfolio beta %e'%pbeta[0]
print 'Total risk check %e'%sqrt(Rrisk[0]*Rrisk[0]+pbeta[0]*pbeta[0]*brisk[0]*brisk[0])

alpha=map(lambda i:(i-n+ncomp)*1e-3,range(n-ncomp))
alpha.append(dot(Composites,alpha))
try:
    rreturn=array([0],Double)
    areturn=array([0],Double)
    Rreturn=array([0],Double)
    breturn=array([0],Double)
    srisk=array([0],Double)
    MCAR=array([0]*n,Double)
    MCTR=array([0]*n,Double)
    MCRR=array([0]*n,Double)
    MCBR=array([0]*n,Double)
    beta=array([0]*n,Double)
    FMCAR=array([0]*(n+nfac),Double)
    FMCTR=array([0]*(n+nfac),Double)
    FMCRR=array([0]*(n+nfac),Double)
    FMCBR=array([0]*(n+nfac),Double)
    FMCSR=array([0]*(n+nfac),Double)
    FX=array([0]*nfac,Double)
    AFX=array([0]*nfac,Double)
    BFX=array([0]*nfac,Double)
    SFX=array([0]*nfac,Double)
    RFX=array([0]*nfac,Double)
except:
    rreturn=[]
    areturn=[]
    Rreturn=[]
    breturn=[]
    srisk=[]
    MCAR=[]
    MCTR=[]
    MCRR=[]
    MCBR=[]
    FMCAR=[]
    FMCTR=[]
    FMCRR=[]
    FMCBR=[]
    FMCSR=[]
    beta=[]
    FX=[]
    AFX=[]
    RFX=[]
    BFX=[]
    SFX=[]
names=map(lambda i:'Stock %d'%(i+1),range(n-ncomp))
names.append('Composite')
PropertiesCA(n,nfac,names,w,bench,alpha,rreturn,areturn,Rreturn,breturn,QQ,
             risk,arisk,Rrisk,brisk,srisk,pbeta,MCAR,MCTR,MCRR,MCBR,FMCRR,
             FMCTR,FMCAR,FMCBR,FMCSR,beta,FX,RFX,AFX,BFX,SFX,FL,FC,SV,
             ncomp,Composites)

print 'Total return %e'%areturn[0]
print 'Active return %e'%rreturn[0]
print 'Resdiual return %e'%Rreturn[0]
print 'Benchmark return %e'%breturn[0]
print 'Total risk %e'%arisk[0]
print 'Active risk %e'%risk[0]
print 'Resdiual risk %e'%Rrisk[0]
print 'Benchmark risk %e'%brisk[0]
print 'Systematic risk %e'%srisk[0]
print 'Portfolio beta %e'%pbeta[0]
print 'Total risk check %e'%sqrt(Rrisk[0]*Rrisk[0]+pbeta[0]*pbeta[0]*brisk[0]*brisk[0])
print 'brisk check %e'%(srisk[0]/pbeta[0])

print
print '%20s %20s %20s %20s %20s'%('Asset','MCTR','MCAR','MCRR','MCBR')
for i in range(n):
    print '%20s %20.8e %20.8e %20.8e %20.8e'%(names[i],MCTR[i],MCAR[i],MCRR[i],MCBR[i])
print
print '%20s %20s %20s %20s %20s %20s'%('Asset','FMCTR','FMCAR','FMCRR','FMCBR','FMCSR')
for j in range(n):
    i=j+nfac
    print '%20s %20.8e %20.8e %20.8e %20.8e %20.8e'%(names[j],FMCTR[i],FMCAR[i],FMCRR[i],FMCBR[i],FMCSR[i])
print
print '%20s %20s %20s %20s %20s %20s'%('Factor','FMCTR','FMCAR','FMCRR','FMCBR','FMCSR')
for i in range(nfac):
    print '%20s %20.8e %20.8e %20.8e %20.8e %20.8e'%('Factor %d'%(i+1),FMCTR[i],FMCAR[i],FMCRR[i],FMCBR[i],FMCSR[i])
print
print '%20s %20s %20s %20s %20s %20s'%('Factor','FX','AFX','RFX','BFX','SFX')
for i in range(nfac):
    print '%20s %20.8e %20.8e %20.8e %20.8e %20.8e'%('Factor %d'%(i+1),FX[i],AFX[i],RFX[i],BFX[i],SFX[i])
    