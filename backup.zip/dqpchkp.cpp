#include "baseoptimise.h"
/*
	dqpchkp  is called when a constraint has just been deleted and the
	sign of the search direction  p  may be incorrect because of
	rounding errors in the computation of the projected gradient ztg.
	the sign of the search direction (and therefore the product  ap)
	is fixed by forcing p to satisfy the constraint (with index jdsave)
	that was just deleted.  variables that were held temporarily fixed
	(with istate = 4)  are not checked for feasibility
*/
void Base_Optimise::dqpchkp( dimen n, dimen nclin, dimen issave, dimen jdsave, vector ap, vector p)
{
	real	atp = (jdsave <= n ? p[jdsave-1] : ap[jdsave-n-1]);

	if (issave == 4) return;

	if (msg >= 80) lm_wmsg((char*)"\n//QPCHKP//  JDSAVE ISSAVE            ATP\n//QPCHKP//%8ld%7ld%15.5lg",
			CL(jdsave), CL(issave), atp);

	if((issave == 2 && atp <= 0) || (issave == 1 && atp >= 0)) return;

	/*REVERSE THE DIRECTION OF  P  AND  AP. */
	dnegvec( n, p );
	if(nclin > 0) dnegvec( nclin, ap );
}
