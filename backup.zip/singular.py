#!/usr/bin/env python

"""
Colin July 28th. 2005

Using Singular Value Decomposition to find the dual variables for
Second Order Cone Programming
"""

from LAPACK import dgesvd_ as DGESVD
dot=lambda x,y:sum([x[i]*y[i] for i in range(len(x))])
from Opt import *
"""
extern "C" int SOCPgenopt(size_t n,size_t m,size_t *md,vector c,vector A,vector b,
									vector w,size_t nb,vector z,double delt=1e-2,double nu=1.1);
"""
norm=lambda x:pow(dot(x,x),.5)
sqr=lambda x:x*x

#Simple SOCP to do linear programming with budget constraint
n=10
errs=[(i+4)*.01 for i in range(n)]
m=1+n
md=[1]*(n+1)
c=[-(i+1) for i in range(n)]
A=[-1]*n
for i in range(n):#to get positive w[i]
    s=[0]*n
    s[i]=1
    A+=s

b=[1]+[0]*n
w=[.9/n]*n

nb=0
nb=sum(md)
print n*nb,len(A)
AA=[i for i in A]
dmx_transpose(n,nb,AA,AA)
z=[0]*nb
n1=n

#Get singular value decomposition for A
n=[nb]
m=[n1]
LDU=[m[0]]
LDA=[m[0]]
S=[0]*(min(m[0],n[0]))
U=[0]*(LDU[0]*min(m[0],n[0]))
LDVT=[n[0]]
LWORK=[max(3*min(m[0],n[0])+max(m[0],n[0]),5*min(m[0],n[0]))]
WORK=[0]*LWORK[0]
INFO=[0]
VT=[0]*(n[0]*n[0])
DGESVD( 'A', 'A',m,n, A, LDA, S, U, LDU, VT, LDVT,WORK, LWORK, INFO )

print S,len(S)
print U,len(U)
print VT,len(VT)


#Find z so that At.z=c
Uc=[0]*nb
for i in range(n1):
    for j in range(n1):
        Uc[i]+=U[j+i*n1]*c[j]
for i in range(n1):
    Uc[i]/=S[i]
for i in range(nb):
    z[i]=dot(Uc,VT[nb*i:])

print z,len(z)

for i in range(n1):
    print dot(z,AA[i*nb:])


y=[i for i in AA]
zz=dot(z,z)

#find the null space of At, i.e. At.y=0 for y in null space
for i in range(n1):
    dd=dot(z,AA[i*nb:])
    zz=dot(AA[i*nb:i*nb+nb],AA[i*nb:])
    y[i*nb:]=[z[j] - dd/zz*AA[j+i*nb] for j in range(nb)]

for i in range(n1):
    print dot(AA[i*nb:i*nb+nb],y[i*nb:])

#Then we choose a Z=z+ay so that all Zs are positive so that At.Z=c
#is a feasible dual solution.......................................

for j in range(n1):
    print dot([z[i]+y[j*nb+i] for i in range(nb)],AA[j*nb:])
