from Opt import *
from SOCPsetup import *
def var(x,Q):
    n=len(x)
    y=[]
    Sym_mult(n,Q,x,y)
    return dot(x,y)
def risk(x,Q):
    return pow(var(x,Q),.5)
O=SOCPOPT()
n=3
convex_limit=2
alpha=[0]*n#[.1,.2,.3]
Q=[1,-1,1,.2,.2,1]
O.m=(n+1)*(n+2)/2
mm=[1,2,1,2,2,1,2,2,2,1]
QQ=[Q[i]*mm[i] for i in range(len(Q))]+[-i for i in alpha]+[0]
print Q
print QQ
O.b=QQ
O.nd=[2]*n+[2]+[3]*(n*(n+1)/2)+[1]*2+[1]+[2]#+[n+1]
O.n=n + 1 + n*(n+1)/2 +2+1+1#+ 1
nn=sum(O.nd)
O.A=[]
O.c=[]
for i in range(n):#0<=xii<=1
    pp=[0]*O.m
    pp[i*(i+3)/2]=1
    O.A+=pp+[0]*O.m
    O.c+=[-.5,.5]
pp=[0]*O.m#last x = 1
pp[-1]=1
O.A+=pp
O.A+=[0]*O.m
O.c+=[-1,0]
for i in range(n+1):#xij**2 <= xii*xjj
    for j in range(i):
        pp=[0]*O.m
        pp[i*(i+3)/2]=1
        pp[j*(j+3)/2]=-1
        O.A+=pp
        pp=[0]*O.m
        pp[i*(i+1)/2+j]=2
        O.A+=pp
        pp=[0]*O.m
        pp[i*(i+3)/2]=1
        pp[j*(j+3)/2]=1
        O.A+=pp
        O.c+=[0,0,0]
pp=[0]*O.m#x0>=0
pp[n*(n+1)/2]=1
O.A+=pp
O.c+=[0]
pp=[0]*O.m#x1<=0
pp[n*(n+1)/2+1]=-1
O.A+=pp
O.c+=[0]
pp=[0]*O.m#x01<=0
pp[1]=-1
O.A+=pp
O.c+=[0]
pp=[0]*O.m#budget
for i in range(n):pp[n*(n+1)/2+i]=1
O.A+=pp+[0]*O.m
O.c+=[-1,0]
"""
for i in range(n):
    pp=[0]*O.m
    pp[i*(i+3)/2]=1
    O.A+=pp
    O.c+=[0]
O.A+=[0]*O.m
O.c+=[convex_limit]
"""
#"""
for i in range(nn):
    print O.A[i*O.m:(i+1)*O.m]
#"""
dmx_transpose(O.m,nn,O.A,O.A)
if O.Opt():print 'FAILED '*10
else:
    W=[-i for i in O.y]
    try:
        w=[pow(W[i*(i+3)/2],.5) for i in range(n)]
        print w
        print 'should be the same',dot(QQ[:n*(n+1)/2],W),var(w,Q)
        print 'alpha %20.12e'%(dot(w,alpha))
    except:pass
    w=W[n*(n+1)/2:O.m-1]
    print w
    print sum(w)
    print 'should be the same',dot(QQ[:n*(n+1)/2],W),var(w,Q)
    print 'alpha %20.12e'%(dot(w,alpha))
    print '_'*30
    print 'Checking it gets what we expect'
    print eigen(n+1,W)[0]
    for i in range(n+1):
        print 'diag %d %20.12e %20.12e'%(i,W[i*(i+3)/2],sqr(W[6+i]))
        for j in range(i):
            print '%d %d %20.12e %20.12e %20.12e'%(i,j,sqr(W[i*(i+1)/2+j]),W[i*(i+3)/2]*W[j*(j+3)/2],sqr(W[n*(n+1)/2+i]*W[n*(n+1)/2+j]))
    print 'Convex set check',pow(sum([sqr(W[i*(i+3)/2]) for i in range(n)]),.5)
    print '_'*30
print eigen(n,Q)[0]

    