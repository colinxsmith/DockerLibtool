/*
	negate a simple vector
*/
#include "ldefns.h"

void dnegvec(dimen n, vector x)
{
	while(n--){ *x = -*x;x++;}
}

void dneg(dimen n,vector x,increment incx)
{
	while(n--)
	{
		if(incx<0) incx = -incx;	/*cannot matter which order*/
		*x  = -*x;x+=incx;
	}
}
