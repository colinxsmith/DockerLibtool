#include "ldefns.h"
void wrexit(char *name, integer inform, integer iter)
{
	lm_wmsg("\nExit %s phase. Inform=%3ld Iter=%4ld\n",name,
		CL(inform),CL(iter));
}
