#ifdef __SYSNT__
#ifndef MINGW32 
#include <crtdbg.h>
#else
#define _ASSERT
#endif
#endif
#ifdef _OPENMP
#include<omp.h>
#endif
#include "baseoptimise.h"
template <typename T> extern void Reorder_gen(size_t n, size_t* order,T* array,size_t m);

void printx(size_t n,vector A);
void printnx(size_t n,vector A,const std::string& na);
#define PATCH 1865
#define  _VER_TOKEN(A) __VER_TOKEN(A)
#define  __VER_TOKEN(A) #A
struct passtopathmin
{
	Base_Optimise*O;
	double*ww;
	double*XX;
	double*CC;
	dimen NN;
};
static double utehere1(double x,void*info)
{
	passtopathmin*Op=(passtopathmin*)info;
	Base_Optimise*O=Op->O;
	daxpyvec(Op->NN,x,Op->XX,Op->ww);
	double back=O->utility(Op->NN,Op->ww,Op->CC,O->H);
	daxpyvec(Op->NN,-x,Op->XX,Op->ww);
//	printf((char*)"%20.8e\t\t%20.8f\n",x,back);
	return back;
}

inline void cleanZ(size_t n,vector a)
{
	while(n--)
	{
		if(fabs(*a)<10*lm_eps)*a=0;
		a++;
	}
}
inline void PrintC(size_t NN,vector XX,vector LL,vector UU,vector dC,const std::string filename=(char*)"std")
{
	FILE* FF;
	bool dontclose=1;
	if(!filename.find((char*)"std"))
	{
		FF=stdout;
	}
	else
	{
		FF=fopen(filename.c_str(),(char*)"w");dontclose=0;
	}
	fprintf(FF,(char*)"%5s %20s %20s %20s %20s\n",(char*)"n",(char*)"X",(char*)"Lower",(char*)"Upper",(char*)"dC");
	for(size_t iii=0;iii<NN;++iii)
		fprintf(FF,(char*)"%5d %20.8e %20.8e %20.8e %20.8e\n",iii+1,XX[iii],LL[iii],UU[iii],dC[iii]);
	if(!dontclose)
		fclose(FF);
}
inline void Parab(double d1,double d2,double d3,double F1,double F2,
				  double F3,double& xmin,double& fmin)
{
/*
def Parab(delta,U,prt=0):
    """Fit a parabola a*x2+bx+c to the data in delta and U and output the stationary point and its value"""
    (F1,F2,F3) = tuple(U)
    (d1,d2,d3) = tuple(delta)
    a = (F1*(d2-d3)+F3*(d1-d2)+F2*(d3-d1))/(d1-d3)/(d2-d3)/(d1-d2)
    b = (F1-F3)/(d1-d3)-a*(d1+d3)
    c=F3-d3*b-d3*d3*a
    xmin=-0.5*b/a
    fmin=c-0.25*b*b/a
    if prt:print 'a = %f b = %f c = %f'%(a,b,c)
    return(xmin,fmin)
*/
    double a = (F1*(d2-d3)+F3*(d1-d2)+F2*(d3-d1))/(d1-d3)/(d2-d3)/(d1-d2);
    double b = (F1-F3)/(d1-d3)-a*(d1+d3);
    double c = F3-d3*b-d3*d3*a;
    xmin = -0.5*b/a;
    fmin = c-0.25*b*b/a;
}
MemProb::MemProb(std::string m,dimen a,dimen b)
{
	mess=m;
	amount=a;
	n=b;
}
double Base_Optimise::clocker(int start)
{
#ifndef _OPENMP
	clock_t	t = clock();
#else
	double	t = omp_get_wtime();
#endif
	if(!start)
#ifndef _OPENMP
		timeaquired += (double)(t-timebase)/CLOCKS_PER_SEC;
#else
	timeaquired += (t-timebase);
#endif	
	else
		timeaquired = 0;
	timebase=t;
	return timeaquired;
}

void Base_Optimise::SetLog()
{
	logprint=new std::stringstream;
}
void Base_Optimise::PrintLog()
{
	if(logprint)
		std::cout<<(*logprint).str();
}
/*void Base_Optimise::AddLog(const char* mess)
{
	if(!logprint)return;
	*logprint<<mess;
#if defined( MSDOSS ) || defined( _DEBUG ) || defined( __linux__ )
	std::cout<<mess;std::cout.flush();
#endif
}*/
void Base_Optimise::AddLog(const char *mess, ...)
{
	if(!logprint) return;
	char mm[200];
	va_list ttt;
	va_start(ttt,mess);
	int i = vsprintf(mm, mess, ttt);
	if(i>0)
	{
		*logprint<<"\e[1;1;31m"<<mm<<"\e[0;m";
#if defined( MSDOSS ) || defined( _DEBUG ) || defined( __linux__ )
		std::cout<<"\e[1;1;31m"<<mm<<"\e[0;m";std::cout.flush();
#endif
	}
	va_end(ttt);
}


Base_Optimise::Base_Optimise()
{
	gamma_for_eps=0;
	vers=new std::string;
	this->logprint=0;
	std::stringstream dl;
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	checker=new Validate;
	unsigned long hid = 0;
#ifdef _DEBUG
	licenced = 28;
#else
	licenced = checker->checklicence();
	dl << " (after " << checker->number_of_days_left<<" days)";

	hid=guniqid();
#endif
	mem_kbytes=0;
	no_interior_ever=0;
	if(hid)
	{
		dl<<"\r\nHost id ";
		std::cout.precision(8);
		dl<<std::hex<<hid<<std::dec;
	}
	if(licenced)
	{
//		sprintf(version,(char*)"Augmented optimiser version 1; " __DATE__ " " __TIME__" patch level %s\nExpires %s (in %d days)\nCurve Component Keys:%9s"
//			,_VER_TOKEN(PATCH),checker->EXPIREDATE,checker->number_of_days_left,checker->CURVECOMPS);
#if defined( __SYSNT64__) || defined(_LP64)
		vers->assign((char*)"Augmented 64-bit optimiser version 1; " __DATE__ " " __TIME__" patch level ");
#else
		vers->assign((char*)"Augmented 32-bit optimiser version 1; " __DATE__ " " __TIME__" patch level ");
#endif
		vers->append(_VER_TOKEN(PATCH));
		vers->append((char*)"\r\nThe time now is; ");
		vers->append(checker->NOW);
		if(checker->EXPIREDATE&&checker->EXPIREDATE[0]!=-1)
		{
			vers->append((char*)"\r\nExpires: ");
			vers->append(checker->EXPIREDATE);
			vers->append(dl.str());
		}
#ifndef PAS
		vers->append((char*)"\r\nCurve component keys: ");
		vers->append(checker->CURVECOMPS);
#endif
	}
	else
	{
//		sprintf(version,(char*)"Augmented optimiser version 1; " __DATE__ " " __TIME__" patch level %s\n     *******UNLICENCED!!!!!********"
//			,_VER_TOKEN(PATCH));
#if defined( __SYSNT64__) || defined(_LP64)
		vers->assign((char*)"Augmented 64-bit optimiser version 1; " __DATE__ " " __TIME__" patch level ");
#else
		vers->assign((char*)"Augmented 32-bit optimiser version 1; " __DATE__ " " __TIME__" patch level ");
#endif
		vers->append(_VER_TOKEN(PATCH));
		vers->append((char*)"\r\nThe time now is; ");
		vers->append(checker->NOW);
		vers->append((char*)"\r\n     *******UNLICENCED!!!!!********");
		vers->append(dl.str());
	}
	
	sprintf(checker->VERSION,(char*)"3.%s",_VER_TOKEN(PATCH));
	Version=(char*)vers->c_str();
//#ifdef _DEBUG
//	licenced=1;
//#endif

//	printf((char*)"Base_Optimise::Base_Optimise()\n");
//	firstw=0;
	round_result=1;
	CONJ=1;
	useInteriorPoint=1;
	objective=-lm_max;
	scale_utility_external_terms=0;
	featol = small_round(1e-8);						//feasible tolerance for constraint bounds
	lower=0;							//User must set this always
	upper=0;							//User must set this always
	A=0;								//User must set this always
	soft_A=0;
	soft_b=0;
	soft_l=0;
	soft_m=0;
	use_soft_in_hessmult=true;
	n=(dimen)-1;						//User must set this always
	m=(dimen)-1;						//User must set this always
	H=0;								//User must set this for quadratic programming
	H_from_higher_terms=0;
	use_higher_H=0;
	higher_reset=0;
	c=0;								//User must set this for linear and quad
	x=0;								//The outcome solution
	lp=0;
	hmul=0;
	Util=0;
	ModDeriv=0;
	ModHessian=0;						//For non-linear terms which have 2nd order derivatives
	HmulObjectInfo = 0;
	UtilObjectInfo = 0;
	ModCObjectInfo = 0;
	ModQObjectInfo = 0;
	DoExtraIterations = 1;				//Do the extra loop for nonquadratic problem
	ExtraQx=new std::valarray<double>;	//The second order contribution to first derivative
//	costdata=0;
	optimiseorder=0;
	keep_last_C=new std::valarray<double>;
	extraH = new std::valarray<double>;	//The extra part of the Hessian due to a non-quadratic function
	TimeOptData=0;

//Set all the strange stuff to 0
//_____________________________
	DAS_Sol_nout=0;
	DAS_Sol_msg=0;
	DAS_Sol_istart=0;
	DAS_Sol_asize=0;
	DAS_Sol_dtmax=0;
	DAS_Sol_dtmin=0;
	DAS_Sol_nrowrt=0;
	DAS_Sol_ncolrt=0;
	DAS_Sol_nq=0;
	DAS_Sol_ncqp=0;
	DAS_Sol_nrowqp=0;
	DAS_Sol_scldqp=0;
	DAS_Sol_zgfacc=-1.0;
	dimen ii;
	parm[0]=1e10;//bigbnd
	parm[1]=1e20;
	parm[2]=1e-6;//.01;//tolact
	parm[3]=pow(lm_eps,0.9);
	for(ii=4;ii<10;++ii)
		parm[ii]=0;
	for(ii=0;ii<15;++ii)
	{
		DAS_Sol_ploc[ii]=0;
		loclc[ii]=0;
		locnp[ii]=0;
		locnp[ii+15]=0;
	}
//_____________________________

/*	printf((char*)"DAS_Sol_nout %ld\n",nout);
	printf((char*)"DAS_Sol_msg %ld\n",msg);
	printf((char*)"DAS_Sol_asize %f\n",asize);
	printf((char*)"DAS_Sol_dtmax %f\n",dtmax);
	printf((char*)"DAS_Sol_dtmin %f\n",dtmin);
	printf((char*)"DAS_Sol_nrowrt %ld\n",nrowrt);
	printf((char*)"DAS_Sol_nq %ld\n",nq);
	printf((char*)"DAS_Sol_ncqp %ld\n",DAS_Sol_ncqp);
	printf((char*)"DAS_Sol_nrowqp %ld\n",nrowqp);
	printf((char*)"DAS_Sol_scldqp %lx\n",scldqp);
	printf((char*)"DAS_Sol_zgfacc %f\n",DAS_Sol_zgfacc);
	printf((char*)"pKACTV %lx\n",pKACTV);
	printf((char*)"pKFREE %lx\n",pKFREE);
	printf((char*)"pANORM %lx\n",pANORM);
	printf((char*)"pAP %lx\n",pAP);
	printf((char*)"pPX %lx\n",pPX);
	printf((char*)"pQTG %lx\n",pQTG);
	printf((char*)"fpQTG %lx\n",fpQTG);
	printf((char*)"pRLAM %lx\n",pRLAM);
	printf((char*)"pRT %lx\n",pRT);
	printf((char*)"pZY %lx\n",pZY);
	printf((char*)"pWRK %lx\n",pWRK);*/
}

Base_Optimise::~Base_Optimise()
{
//	printf((char*)"Base_Optimise::~Base_Optimise()\n");
	delete keep_last_C;
	delete ExtraQx;
	delete extraH;
	delete checker;
	delete vers;
	if(logprint)delete logprint;
/*	printf((char*)"DAS_Sol_nout %ld\n",nout);
	printf((char*)"DAS_Sol_msg %ld\n",msg);
	printf((char*)"DAS_Sol_asize %f\n",asize);
	printf((char*)"DAS_Sol_dtmax %f\n",dtmax);
	printf((char*)"DAS_Sol_dtmin %f\n",dtmin);
	printf((char*)"DAS_Sol_nrowrt %ld\n",nrowrt);
	printf((char*)"DAS_Sol_nq %ld\n",nq);
	printf((char*)"DAS_Sol_ncqp %ld\n",DAS_Sol_ncqp);
	printf((char*)"DAS_Sol_nrowqp %ld\n",nrowqp);
	printf((char*)"DAS_Sol_scldqp %lx\n",scldqp);
	printf((char*)"DAS_Sol_zgfacc %f\n",DAS_Sol_zgfacc);
	printf((char*)"pKACTV %lx\n",pKACTV);
	printf((char*)"pKFREE %lx\n",pKFREE);
	printf((char*)"pANORM %lx\n",pANORM);
	printf((char*)"pAP %lx\n",pAP);
	printf((char*)"pPX %lx\n",pPX);
	printf((char*)"pQTG %lx\n",pQTG);
	printf((char*)"fpQTG %lx\n",fpQTG);
	printf((char*)"pRLAM %lx\n",pRLAM);
	printf((char*)"pRT %lx\n",pRT);
	printf((char*)"pZY %lx\n",pZY);
	printf((char*)"pWRK %lx\n",pWRK);
	printf((char*)"x %lx\n",x);*/
}
short Base_Optimise::OptAdvanced(dimen NN,dimen MM,vector XX,vector AA,vector LL,
								 vector UU,vector CC,vector LAMBDA)
{
	if(!licenced)
	{
		dzerovec(NN,XX);
		return -1;
	}
	std::valarray<double> c_check;
	double			*vlambda=0;
	short_scl		*vistate;
	std::valarray<double> 	dC;
	size_t	itmax,npm,n2,npm2,lwrk;
	itmax=5000;
	short	msglvl = -10;
	real	bigbnd = 1e10,obj;
	int cold = 1;
	short	iter,back;
	qpsol_ifail = 1;
	npm = NN + MM;
	npm2 = npm << 1;
	n2 = NN << 1;
	lwrk = 2 * (NN * (NN + 2) + MM) + MM;
	std::valarray<double> vvlam;
	try
	{
		vvlam.resize(lwrk + npm2);
		vvlam=0;
		vlambda = &vvlam[0];
		if(NN > 2000)
		{
			AddLog((char*)"n=%lu. Allocated %u bytes\n",NN,(lwrk + npm2)*sizeof(double));
		}
	}
	catch(...)
	{
		vlambda=0;
	}

	if(!vlambda)
	{
		AddLog((char*)"n=%lu. Could not allocate %u bytes\n",NN,(lwrk + npm2)*sizeof(double));
		throw MemProb((char*)"Memory problem for lambda in BaseOptimise::Opt()",(lwrk + npm2)*sizeof(double),n);
	}

	std::valarray<short_scl> vvist;
	try
	{
		vvist.resize(npm + n2);
		vvist=0;
		vistate = &vvist[0];
	}
	catch( ... )
	{
		vistate=0;
	}
	if(!vistate)
	{
		vvlam.resize(0);
		AddLog((char*)"n=%lu. Could not allocate %u bytes\n",NN,(npm + n2)*sizeof(short_scl));
		fflush(stdout);
		throw MemProb((char*)"Memory problem for istate in BaseOptimise::Opt()",(npm + n2)*sizeof(short_scl),n);
	}

	dsetvec(npm,small_round(1e-8),vlambda);
	dzerovec(npm,LAMBDA);

	back = dqpsol(	(short)	itmax,
				msglvl,
				NN,
				MM,
				npm,
				MM,//max(1,MM),	I don't mind optimisations with no linear constraints!
				n2,
				1,
				&bigbnd,
				AA,
				LL,
				UU,
				CC,
				vlambda,	/*feasible tolerance*/
				H,
				cold,
				(int)lp,
				1,		/*let's use orthog for now*/
				XX,
				vistate,
				&iter,
				&obj,
				LAMBDA,		/*lagrange multipliers*/
				vistate+npm,
				n2,
				vlambda+npm,	/*work vector*/
				lwrk,
				qpsol_ifail);
	if((size_t)iter>=itmax)AddLog((char*)"\e[1;4;35mitmax %ld iter %d\e[0;m\n",itmax,iter);
	else if(iter>100)AddLog((char*)"\e[1;4;33mUsed %5d L.P. iterations\e[0;m\n", iter);
	objective=obj;
	return back;
}

#ifdef MEMORYTEST
extern "C" size_t getMaxNumberOfDoubles(int wantedDoubles);
extern "C" size_t memleft();
#endif
void Base_Optimise::TimeOptSetC(size_t Nvab,vector Ls,vector Us,vector As,vector cs,vector initials)
{
	TimeOptData->usethis=true;
	Reorder_gen(n,optimiseorder,TimeOptData->DATA,TimeOptData->tlen);
	Reorder_gen(n,optimiseorder,TimeOptData->meanDATA,1);
	TimeOptData->Lst=Ls;TimeOptData->Ust=Us;TimeOptData->Ast=As;TimeOptData->cst=cs;TimeOptData->initialst=initials;
	vector L=TimeOptData->L;
	vector U=TimeOptData->U;
	vector A=TimeOptData->A;
	vector c=TimeOptData->c;
	vector initial=TimeOptData->initial;
	if(TimeOptData->x)delete[](TimeOptData->x);
	if(L)delete[](L);
	if(U)delete[](U);
	if(A)delete[](A);
	if(c)delete[](c);
	if(initial)delete[](initial);
	TimeOptData->opt=true;
	if(TimeOptData->OptType==GainLossType)
	{
		GainLossVar* GainLossData=(GainLossVar*)TimeOptData;
		GainLossData->UseMaxLoss = false;
		bool UseMaxLoss = GainLossData->UseMaxLoss;


		size_t j;
		vector DATA=GainLossData->DATA;
		dimen t=GainLossData->tlen;
		double MaxLoss = 0.001*t;
		TimeOptData->nextra=TimeOptData->tlen;
		dimen nstocks=GainLossData->n;
		vector R=GainLossData->r;

		if(initials){GainLossData->initial=initial=new double[n+t];}
		GainLossData->c=c=new double[n+t];
		GainLossData->L=L=new double[n+t+m+t+UseMaxLoss];
		GainLossData->U=U=new double[n+t+m+t + UseMaxLoss];
		GainLossData->A=A=new double[(n+t)*(m+t + UseMaxLoss)];
		GainLossData->x=new double[(n+t)];
		double maxret = max(linfinity(nstocks*t,DATA),linfinity(t,R));
		//Variables
		dcopyvec(Nvab,Ls,L);
		dcopyvec(Nvab,Us,U);
		dcopyvec(n-Nvab,Ls+Nvab+m,L+Nvab+t+m+t + UseMaxLoss);
		dcopyvec(n-Nvab,Us+Nvab+m,U+Nvab+t+m+t + UseMaxLoss);
		dzerovec(t,L+Nvab);
		dsetvec(t,maxret,U+Nvab);
		//Constraints
		dcopyvec(m,Ls+Nvab,L+Nvab+t);
		dcopyvec(m,Us+Nvab,U+Nvab+t);
		dcopyvec(t, R, L + Nvab + t + m);							//					r[t] - DATA.w = LOSS variable, LOSS variable > 0
		//dcopyvec(t, R, U + Nvab + t + m);
		//dsetvec(t, 0, L + Nvab + t + m);
		dsetvec(t, maxret, U + Nvab + t + m);

		dzerovec((n + t)*(m + t + UseMaxLoss), A);
		for (j = 0; j < m; ++j)
		{
			dcopy(Nvab, As + j, m, A + j, m + t + UseMaxLoss);
			dcopy(n - Nvab, As + j + m * Nvab, m, A + j + (m + t + UseMaxLoss)*(Nvab + t), m + t + UseMaxLoss);
		}
		for (j = m; j < m + t; j++)
		{
			//A[j + (m + t + UseMaxLoss)*(Nvab + j - m)] = 1;
			dset(1, 1, A + j + (m + t + UseMaxLoss)*(Nvab + j - m), m + t + UseMaxLoss);
			dcopy(Nvab, DATA + j - m, t, A + j, m + t + UseMaxLoss);				//					r[t] - DATA.w = LOSS variable, LOSS variable > 0
			dcopy(n - Nvab, DATA + j - m + t * Nvab, t, A + j + (m + t + UseMaxLoss)*(Nvab + t), m + t + UseMaxLoss);
			if ((n - Nvab)) {
				double fixedReturn = BITA_ddot(n - Nvab, DATA + j - m + t * Nvab, t, x + Nvab, 1);
				*(L + Nvab + t + j) -= fixedReturn;
				*(U + Nvab + t + j) -= fixedReturn;
			}
		}
		if (UseMaxLoss) {
			L[Nvab + 2*t + m] = 0;
			U[Nvab + 2*t + m] = MaxLoss;
		//	dzero(Nvab, A         +(m + t), m + t + UseMaxLoss);
			dset(t, 1,  A + Nvab*(m + t + UseMaxLoss) + (m + t), m + t + UseMaxLoss);
		}
		dcopyvec(nstocks, GainLossData->mean, c + t);
		Reorder_gen(n, optimiseorder, c + t, 1);
		dscalvec(n, GainLossData->utility_multiplier, c + t);
		dsubvec(n, cs, c + t, c + t);
		dcopyvec(Nvab, c + t, c);
		dsetvec(t, GainLossData->utility_multiplier*GainLossData->losslambda / t, c + Nvab);//printnx(n+t,c,(char*)"C");

		if (initials)
		{
			dcopyvec(Nvab, initials, initial);
			dcopyvec(n - Nvab, initials + Nvab, initial + Nvab + t);
			dzerovec(t, initial + Nvab);
		}
		dcopyvec(Nvab, x, GainLossData->x);
		dcopyvec(n - Nvab, x + Nvab, GainLossData->x + Nvab + t);
		dsetvec(t, 1. / t, GainLossData->x + Nvab);//printnx(n+t,GainLossData->x,(char*)"X");
	}
	else if(TimeOptData->OptType==CVarType)
	{
		MVCvar* CVarData=(MVCvar*)TimeOptData;
		size_t j;
		vector DATA=CVarData->DATA;
		dimen t=CVarData->tlen;
		TimeOptData->nextra=TimeOptData->tlen+1;
		dimen nstocks=CVarData->n;
		size_t extram=0;
		if(CVarData->cvarConstraintdata) extram=1;

		if(initials){CVarData->initial=initial=new double[n+t+1];}
		CVarData->A=A=new double[(Nvab+t+1)*(m+t+extram)]; //A only needs to be this small
		CVarData->L=L=new double[(n+t+1)+(m+t+extram)];
		CVarData->U=U=new double[(n+t+1)+(m+t+extram)];
		CVarData->c=c=new double[(n+t+1)];
		CVarData->x=new double[(n+t+1)];

		double maxret;

		maxret = linfinity(nstocks*t, DATA);// *t *nstocks;
		AddLog((char*)"maxret = %e (%e)\n", maxret, linfinity(nstocks*t, DATA));
		//Variables
		dcopyvec(Nvab,Ls,L);
		dcopyvec(Nvab,Us,U);
		dcopyvec(n-Nvab,Ls+Nvab,L+Nvab+1+t+m+t+extram);
		dcopyvec(n-Nvab,Us+Nvab,U+Nvab+1+t+m+t+extram);
		L[Nvab]=0;
		U[Nvab]=maxret;
		dsetvec(t,0,L+Nvab+1);
		dsetvec(t,maxret,U+Nvab+1);
		//Constraints
		dcopyvec(m,Ls+Nvab,L+Nvab+1+t);
		dcopyvec(m,Us+Nvab,U+Nvab+1+t);
		dsetvec(t,-maxret,L+Nvab+1+t+m);
		dsetvec(t,0,U+Nvab+1+t+m);

		dzerovec((Nvab+t+1)*(m+t+extram),A);
		for(j=0;j<m;++j)
		{
			dcopy(Nvab,As+j,m,A+j,m+t+extram);
		}

		for(j=m;j<m+t;j++)
		{
			dcopy(Nvab,     DATA + j - m,            t,                                                                                           A + j, m + t + extram);
		//	dcopy(n - Nvab, DATA + j - m + t * Nvab, t,                                                                                           A + j + (m + t + extram)*(Nvab + t + 1), m + t + extram);
			if ((n - Nvab)) {
				double fixedReturn = BITA_ddot(n - Nvab, DATA + j - m + t * Nvab, t, x + Nvab, 1);
				*(L + Nvab + 1 + t + j) -= fixedReturn;
				*(U + Nvab + 1 + t + j) -= fixedReturn;
			}
			A[Nvab*(m+t+extram)+j]=-1;
			A[(Nvab+1+j-m)*(m+t+extram)+j]=-1;
		}
		dcopyvec(Nvab,cs,c);
		dcopyvec(n-Nvab,cs+Nvab,c+Nvab+1+t);
		c[Nvab]=CVarData->cvar_averse;
		dsetvec(t,CVarData->cvar_averse/CVarData->tail_divisor,c+Nvab+1);
		TimeOptData->opt=true;
		if(CVarData->cvarConstraintdata)
		{
			double scaleCvar = 1;
			dset(Nvab, 0, A + m + t, m + t + extram);
			dset(1,scaleCvar,                       A+m+t+Nvab    *(m+t+extram),m+t+extram);
			dset(t,scaleCvar/CVarData->tail_divisor,A+m+t+(Nvab+1)*(m+t+extram),m+t+extram);
			dsetvec(1, CVarData->cvarL*scaleCvar, L + Nvab + t + 1 + m + t);
			dsetvec(1, CVarData->cvarU*scaleCvar, U + Nvab + t + 1 + m + t);
		}

		if(initials)
		{
			dcopyvec(Nvab,initials,initial);
			dcopyvec(n-Nvab,initials+Nvab,initial+Nvab+t+1);
			dzerovec(t+1,initial+Nvab);
			initial[Nvab]=0;//This ensures that the VAR variable is not doubled in revision or cost jobs. (See L[Nvab] and U[Nvab] aboveand these are adjusted before final calling of optimisation function to allow a wide range for VAR variable.)
		}
		dcopyvec(Nvab, x, CVarData->x);
		dcopyvec(n - Nvab, x + Nvab, CVarData->x + Nvab + t + 1);
		dsetvec(t + 1, 1. / t, CVarData->x + Nvab);
		CVarData->x[Nvab] = maxret;
	}
	else if(TimeOptData->OptType==SemiVarType)
	{
		size_t j;
		vector DATA=TimeOptData->DATA;
		dimen t=TimeOptData->tlen;
		TimeOptData->nextra=TimeOptData->tlen;
		dimen nstocks=TimeOptData->n;

		if(initials){TimeOptData->initial=initial=new double[n+t];}
		TimeOptData->A=A=new double[(n+t)*(m+t)];
		TimeOptData->L=L=new double[(n+t)+(m+t)];
		TimeOptData->U=U=new double[(n+t)+(m+t)];
		TimeOptData->c=c=new double[(n+t)];
		TimeOptData->x=new double[(n+t)];
		if(!TimeOptData->meanDATA)
		{
			TimeOptData->meanDATA=new double[(n)];
			for(j=0;j<n;++j)
				TimeOptData->meanDATA[j]=dsumvec(t,DATA+j*t)/t;
		}

		double maxret;

		maxret=linfinity(nstocks*t,DATA)*nstocks*t;
		//Variables
		dcopyvec(Nvab,Ls,L);
		dcopyvec(Nvab,Us,U);
		dcopyvec(n-Nvab,Ls+Nvab,L+Nvab+t+m+t);
		dcopyvec(n-Nvab,Us+Nvab,U+Nvab+t+m+t);
		dsetvec(t,-maxret,L+Nvab);
		dzerovec(t,U+Nvab);
		//Constraints
		dcopyvec(m,Ls+Nvab,L+Nvab+t);
		dcopyvec(m,Us+Nvab,U+Nvab+t);
		dzerovec(t,L+Nvab+t+m);
		dzerovec(t,U+Nvab+t+m);
		if(TimeOptData->benchmark)
		{
			std::valarray<double>bb(t);
			double bbb=ddotvec(n,TimeOptData->meanDATA,TimeOptData->benchmark);
			for(j=0;j<t;++j)
				bb[j]=BITA_ddot(n,DATA+j,t,TimeOptData->benchmark,1)-bbb;
			daddvec(t,L+Nvab+t+m,&bb[0],L+Nvab+t+m);
		}

		dsetvec(t,maxret,U+Nvab+t+m);

		dzerovec((n+t)*(m+t),A);
		for(j=0;j<m;++j)
		{
			dcopy(Nvab,As+j,m,A+j,m+t);
			dcopy(n-Nvab,As+j+m*Nvab,m,A+j+(m+t)*(Nvab+t),m+t);
		}
		for(j=m;j<m+t;j++)
		{
			dcopy(Nvab,DATA+j-m,t,A+j,m+t);
			dsub(Nvab,A+j,m+t,TimeOptData->meanDATA,1,A+j,m+t);
			dcopy(n-Nvab,DATA+j-m+t*Nvab,t,A+j+(m+t)*(Nvab+t),m+t);
			dsub(n-Nvab,A+j+(m+t)*(Nvab+t),m+t,TimeOptData->meanDATA,1,A+j+(m+t)*(Nvab+t),m+t); //DATA.(x-b) - meanDATA.(x-b) - t > 0 and t<0
			A[(Nvab+j-m)*(m+t)+j]=-1;
			if ((n - Nvab)) {
				double fixedReturn = BITA_ddot(n - Nvab, DATA + j - m + t * Nvab, t, x + Nvab, 1);
				*(L + Nvab + t + j) -= fixedReturn;
				*(U + Nvab + t + j) -= fixedReturn;
			}
		}

		dcopyvec(Nvab,cs,c);
		dzerovec(t,c+Nvab);
		TimeOptData->opt=true;

		if(initials)
		{
			dcopyvec(Nvab,initials,initial);
			dcopyvec(n-Nvab,initials+Nvab,initial+Nvab+t);
			dzerovec(t,initial+Nvab);
		}
		dcopyvec(Nvab,x,TimeOptData->x);
		dcopyvec(n-Nvab,x+Nvab,TimeOptData->x+Nvab+t);
		//The guess for the time variables,if these are set to zero a false result can be found whish is not unique
		dsetvec(t,-1./t,TimeOptData->x+Nvab);
	}
}
short Base_Optimise::Opt(dimen NN,dimen MM,vector XX,vector AA,vector LL,vector UU,vector CC)
{
	bool highertermssethere=0;
	if(!licenced)
	{
		dzerovec(NN,XX);
		return -1;
	}
	bool start_with_true_Q=false;
	if(ModHessian)
		start_with_true_Q=true;
	std::valarray<double> c_check;
	double			*vlambda=0,check=0,checkstart=1,checkold=1e22;
	short_scl		*vistate;
	std::valarray<double> 	dC;
	size_t	itmax = (size_t) 100 + NN + (NN >> 1),npm,n2,npm2,lwrk;
	itmax*=2;
	//if(TimeOptData)itmax=32000;
	short	msglvl = -10;
	real	bigbnd = 1e10,obj;
	int cold = 1,check_count=0,check_count_start=3,check_count_set;
	short	iter,back;
	double Ueps;
	qpsol_ifail = 1;
	npm = NN + MM;
	npm2 = npm << 1;
	n2 = NN << 1;
	lwrk = 2 * (NN * (NN + 2) + MM) + MM;
	std::valarray<double> vvlam;
/*	long step=500000,mm=30000000;
	while(1)
	{
		try
		{
			vvlam.resize(mm);
			vlambda = &vvlam[0];
			printf((char*)"Allocated %u bytes\n",vvlam.size()*sizeof(double));
			printf((char*)"Allocated %u doubles\n",vvlam.size());
			mm+=step;
		}
		catch(...)
		{
			printf((char*)"Allocated %u bytes\n",vvlam.size()*sizeof(double));
			printf((char*)"Allocated %u doubles\n",vvlam.size());
			return 6;
		}	
	}*/
#ifdef MEMORYTEST
	FILE* NEEDMEM=fopen((char*)"memoryinfo.txt",(char*)"a");
	fprintf(NEEDMEM,(char*)"Free memory in windows %u Kbytes\n",memleft());
	fprintf(NEEDMEM,(char*)"Maximum memory we can allocate here %u Kbytes, memory needed this optimisation %u Kbytes\n",
		getMaxNumberOfDoubles(lwrk+npm2)*sizeof(double)/1024,(lwrk + npm2)*sizeof(double)/1024);
	fclose(NEEDMEM);
#endif
	try
	{
		vvlam.resize(lwrk + npm2);
		mem_kbytes=(lwrk + npm2)*sizeof(double)/1024;
		vvlam=0;
		vlambda = &vvlam[0];
		if(NN > 2000)
		{
			AddLog((char*)"n=%lu. Allocated %u bytes\n",NN,(lwrk + npm2)*sizeof(double));
		}
	}
	catch(...)
	{
		AddLog((char*)"Not enough memory, trying Interior Point Method\n");
#ifdef MEMORYTEST
		FILE* MIKEOUT=fopen((char*)"usingintpoint.txt",(char*)"w");
		fprintf(MIKEOUT,(char*)"Not enough memory (need %u bytes, pointer %lu), trying Interior Point Method\n",(lwrk + npm2)*sizeof(double),
			vlambda);
		fclose(MIKEOUT);
#endif
		vlambda=0;
		if(!no_interior_ever)
		return this->OptInterior(NN,MM,XX,AA,LL,UU,CC);
	}

	if(!vlambda)
	{
		AddLog((char*)"n=%lu. Could not allocate %u bytes\n",NN,(lwrk + npm2)*sizeof(double));
		throw MemProb((char*)"Memory problem for lambda in BaseOptimise::Opt()",(lwrk + npm2)*sizeof(double),n);
	}

	std::valarray<short_scl> vvist;
	try
	{
		vvist.resize(npm + n2);
		vvist=0;
		vistate = &vvist[0];
	}
	catch( ... )
	{
		vistate=0;
	}
	if(!vistate)
	{
		vvlam.resize(0);
		AddLog((char*)"n=%lu. Could not allocate %u bytes\n",NN,(npm + n2)*sizeof(short_scl));
		fflush(stdout);
		throw MemProb((char*)"Memory problem for istate in BaseOptimise::Opt()",(npm + n2)*sizeof(short_scl),n);
	}

	dsetvec(npm,small_round(featol),vlambda+npm);
	dzerovec(npm,vlambda);

	if(ModHessian&&ddotvec(NN,XX,XX)<1e-14)
	{
		AddLog((char*)"Use interior point to avoid XX=0\n");
		for(size_t i=0;i<NN;++i)
		{
			if(LL[i]>=0)
				XX[i]=lm_eps;
			else
				XX[i]=-lm_eps;
		}
	}
	dC.resize(max(n,NN));
	bool constraints_ok=false;

	if(ModHessian&&fabs(H[0])<=lm_rooteps)
	{
		constraints_ok=true;
		AddLog((char*)"Try not to use QP generated guess\n");
	}
	std::valarray<double> w0;
	std::valarray<double> implied;
	if(ModDeriv || ModHessian)
	{
		w0.resize(NN);
		implied.resize(NN);
	}
	{
		size_t i;double cc;
		for(i=0;i<MM;++i)
		{
			cc =BITA_ddot(NN,AA+i,MM,XX,1);
			if(cc<LL[i+NN]-1000*lm_eps) {constraints_ok=false;break;}
			if(cc>UU[i+NN]+1000*lm_eps) {constraints_ok=false;break;}
		}
		for(i=0;i<NN;++i)
		{
			if(XX[i]<LL[i]-10*lm_eps) {constraints_ok=false;break;}
			if(XX[i]>UU[i]+10*lm_eps) {constraints_ok=false;break;}
		}
	}

	if(ModHessian && !constraints_ok)
	{
		AddLog((char*)"Initial guess is no good, we must use QP generated guess\n");
	}
				
	double Utest=1e22,Unow,Uprev=1e22,Uold=-1e22;
	Unow=utility(NN,XX,CC,H);
	AddLog((char*)"Utility at first guess %-.8e\n",Unow);
	dC = 0;
	if(ModDeriv)// &&! ModHessian)
	{
		if(ModHessian)	this->ExtraQx->resize(NN);
		higher_reset=this->ModHessian?1:0;use_higher_H=this->ModHessian?1:0;
		ModifyC(NN,H,XX,&dC[0],0);
		qphess(NN,1,1,1,H,XX,&implied[0]);
		c_check.resize(keep_last_C->size());
		c_check=*keep_last_C;
		daddvec(NN,&dC[0],&implied[0],&dC[0]);
		daddvec(NN,CC,&dC[0],CC);
		higher_reset=0;
	}
//#define LISTPR
#ifdef LISTPR
	size_t iii,jjj;
	printf((char*)"Before calling dqpsol\n");
	for(iii=0;iii<NN+MM;++iii)
	{
		printf((char*)"%d %20.8f %20.8f",iii,LL[iii],UU[iii]);
		if(iii<NN)
		{
			printf((char*)"%20.8f %20.8f ",XX[iii],CC[iii]);
			for(jjj=0;jjj<MM;++jjj)
			{
				printf((char*)"%20.8f ",AA[jjj+iii*MM]);
			}
		}
		printf((char*)"\n");
	} 
#undef LISTPR
#endif
//#define DPQDEBUG
#ifdef DPQDEBUG
	PrintC(NN,XX,LL,UU,&dC[0],(char*)"cost0");
#endif
	bool done=0;
	if(!ModHessian||!constraints_ok)
	{
		while(1)
		{
			back = dqpsol(	(short)	itmax,
				msglvl,
				NN,
				MM,
				npm,
				MM,//max(1,MM),	I don't mind optimisations with no linear constraints!
				n2,
				1,
				&bigbnd,
				AA,
				LL,
				UU,
				CC,
				vlambda+npm,	/*feasible tolerance*/
				H,
				cold,
				(int)lp,
				1,		/*let's use orthog for now*/
				XX,
				vistate,
				&iter,
				&obj,
				vlambda,		/*lagrange multipliers*/
				vistate+npm,
				n2,
				vlambda+npm2,	/*work vector*/
				lwrk,
				qpsol_ifail);
			if((size_t)iter>=itmax)AddLog((char*)"itmax %ld iter %d\n",itmax,iter);
			if(back==5)
			{
				back = dqpsol(	(short)	itmax,
					msglvl,
					NN,
					MM,
					npm,
					MM,//max(1,MM),	I don't mind optimisations with no linear constraints!
					n2,
					1,
					&bigbnd,
					AA,
					LL,
					UU,
					CC,
					vlambda+npm,	/*feasible tolerance*/
					H,
					cold,
					(int)lp,
					1,		/*let's use orthog for now*/
					XX,
					vistate,
					&iter,
					&obj,
					vlambda,		/*lagrange multipliers*/
					vistate+npm,
					n2,
					vlambda+npm2,	/*work vector*/
					lwrk,
					qpsol_ifail);
				if((size_t)iter>=itmax)AddLog((char*)"itmax %ld iter %d\n",itmax,iter);
				if(back==5)
				{
					back = dqpsol(	(short)	itmax,
						msglvl,
						NN,
						MM,
						npm,
						MM,//max(1,MM),	I don't mind optimisations with no linear constraints!
						n2,
						1,
						&bigbnd,
						AA,
						LL,
						UU,
						CC,
						vlambda+npm,	/*feasible tolerance*/
						H,
						cold,
						(int)lp,
						0,		/*let's not use orthog this time*/
						XX,
						vistate,
						&iter,
						&obj,
						vlambda,		/*lagrange multipliers*/
						vistate+npm,
						n2,
						vlambda + npm2,	/*work vector*/
						lwrk,
						qpsol_ifail);
					if ((size_t)iter >= itmax)AddLog((char*)"itmax %ld iter %d\n", itmax, iter);
				}
			}
			if (TimeOptData&&TimeOptData->OptType == CVarType) {
				MVCvar* CVarData = (MVCvar*)TimeOptData;
				size_t t = CVarData->tlen;
				size_t tstart = (NN > n ? n : NN) - t - 1;
				double cvarl = sqrt(ddotvec(t + 1, vlambda + tstart, vlambda + tstart));
				double xxxxx = sqrt(ddotvec(t + 1, XX + tstart, XX + tstart));
				double dot = ddotvec(t + 1, XX + tstart, vlambda + tstart);
				double var = XX[tstart];
				double cvar = var + dsumvec(t, XX + tstart + 1) / CVarData->tail_divisor;
				AddLog((char*)"\e[1;4;35mback %d; %d %20.10e %20.10e %20.10e VAR %20.10e CVAR %20.10e\e[0;m\n", back, NN - n, cvarl, xxxxx, dot, var, cvar);
			}
			else if (TimeOptData&&TimeOptData->OptType == GainLossType) {
				GainLossVar* GainLossData = (GainLossVar*)TimeOptData;
				size_t ip,t=TimeOptData->tlen;
				for (ip = 0; ip < NN - t; ++ip) {
					AddLog("%d %20.8f %20.8f %20.8f\n", ip + 1, XX[ip], vlambda[ip], CC[ip]);
				}
				for (ip = NN-t; ip < NN; ++ip) {
					if (ip == (NN - t))
						AddLog("%2s %20s %20s %20s %20s %20s\n", "", "loss var","loss var's lambda","c","target-ret","loss var+ret");
					double loss = GainLossData->r[ip - NN + t] - BITA_ddot(NN - t, TimeOptData->DATA + ip - NN + t, t, XX, 1);
					double vcon = XX[ip] + BITA_ddot(NN - t, TimeOptData->DATA + ip - NN + t, t, XX, 1);
					AddLog("%d %20.8f %20.8f %20.8f %20.8f %20.8f\n", ip+1, XX[ip], vlambda[ip], CC[ip],loss,vcon);
				}
				if (GainLossData->UseMaxLoss){
					AddLog("%20.8f %20.8f %20.8f %20.8f\n", LL[NN + MM - 1], UU[NN + MM - 1], vlambda[NN + MM - 1], vlambda[NN-1]+vlambda[NN + MM - 1]);
					AddLog("Average Loss from constraint\t%20.8f\n", BITA_ddot(NN, XX, 1, AA + MM - 1, MM) / t);
				}
				AddLog("Average Loss\t\t\t%20.8f Total Loss %20.8f\n", dsumvec(t, XX + NN - t)/t, dsumvec(t, XX + NN - t));
			}
			/*	size_t i;
			for(i=0;i<NN+MM;++i)
			{
			printf((char*)"lambda %d %-.8e\n",i+1,vlambda[i]);
			}*/
			//dqpsol writes the utility as cx+.5xqx-lambda(Ax-b)
#ifdef __SYSNT__
			//#define _DEBUGPRINTOPT
#ifdef _DEBUGPRINTOPT
			std::cout<<"____________ "<<NN<<" _________________________"<<std::endl;
			for(size_t ik=0;ik<NN;++ik)
			{
				for(size_t jk=0;jk<MM;++jk)
				{
					std::cout.width(10);
					std::cout<<AA[jk+MM*ik]<<" ";
				}
				std::cout.width(10);
				std::cout<<LL[ik]<<" ";
				std::cout.width(10);
				std::cout<<XX[ik]<<" ";
				std::cout.width(10);
				std::cout<<UU[ik]<<" ";
				std::cout<<std::endl;
			}
			for(size_t jk=0;jk<MM;++jk)
			{
				std::cout.width(10);
				std::cout<<LL[NN+jk]<<" ";
				std::cout.width(10);
				std::cout<<BITA_ddot(NN,AA+jk,MM,XX,1)<<" ";
				std::cout.width(10);
				std::cout<<UU[NN+jk]<<" ";
				std::cout<<std::endl;
			}
			std::cout<<std::endl;
			std::cout<<"_____________________________________"<<std::endl;
#endif
#endif
			if(ModHessian&&!H_from_higher_terms)//This will only happen if this method is called directly by a script
			{
				highertermssethere=1;
				extraH->resize(n*(n+1)/2);
				H_from_higher_terms=&(*extraH)[0];
			}
			if(check_count<1&&!done&&(ModDeriv || ModHessian)&&!start_with_true_Q)
			{
				size_t i;
				dsubvec(NN,CC,&dC[0],CC);
				use_higher_H=0;
				Unow=utility(NN,XX,CC,H);
				if(check_count==0)
				{
					dcopyvec(NN,XX,&w0[0]);
				}
				AddLog((char*)"Optimised Utility at cost regime %d %-.8e\n",check_count,Unow);
				if(check_count>0)
				{
					vector dX=&implied[0];
					dsubvec(NN,&w0[0],XX,dX);
					double pathmin=PathMin(NN,XX,dX,CC,H);
					daxpyvec(NN,pathmin,dX,XX);
					Unow=utility(NN,XX,CC,H);
					if(check_count==check_count_start||(Unow<Uprev&&check_count>check_count_start))
					{
						dcopyvec(NN,XX,&w0[0]);Uprev=Unow;check_count_set=check_count;
					}
					AddLog((char*)"path min: %-.8e  Utility %-.8e (prev %-.8e)\n",pathmin,Unow,Uprev);
				}
				dC = 0;
				//		use_higher_H=1;higher_reset=1;
				ModifyC(NN,H,XX,&dC[0],0);
				//		qphess(NN,1,1,1,H,XX,&implied[0]);
				for(i=0,check=0;i<c_check.size();++i){check+=(c_check[i]-(*keep_last_C)[i])*(c_check[i]-(*keep_last_C)[i]);}
				if(check_count==0)checkstart=check;
				AddLog((char*)"Cost regime checker %-.8e\n",check);
				c_check=*keep_last_C;
				daddvec(NN,CC,&dC[0],CC);
				//		use_higher_H=1;higher_reset=0;
				if(check==0)break;
				if(check/checkstart<1e-6/* || (check_count-check_count_set>2&&fabs(Unow)>0&&fabs(Uprev-Unow)/fabs(Unow)<1e-7)*/)
					break;
				if(fabs((check-checkold)/dmax((fabs(check)),1.0))<lm_eps && Unow<=Uold)break;
				if(fabs((Unow-Uold)/dmax((fabs(Unow)),1.0))<fabs((check-checkold)/dmax((fabs(check)),1.0))&&(check_count >10))break;
				AddLog((char*)"\t\t|(check-checkold)/check| = %20.8e; Uold %20.8e Unow %20.8e\n",
					fabs((check-checkold)/dmax((fabs(check)),1.0)),Uold,Unow);
				AddLog((char*)"\t\t\t\tcheck/checkstart = %20.8e\n",check/checkstart);
				checkold=check;
				check_count++;
				Uold=Unow;
				//done=1;
			}
			else break;		
		}
	}
	else if(constraints_ok)back=0;
	else back=6;
	use_higher_H=0;higher_reset=0;
	size_t nonqpstep=0,nonqpstep_top=1000;//I needed to change this from 100 to 1000 to help GAIN LOSS to converge
	if(ModHessian && constraints_ok)nonqpstep_top=5000;
	dsubvec(NN,CC,&dC[0],CC);
	Unow=utility(NN,XX,CC,H);
	AddLog((char*)"Optimised interim Utility %-.8e\n",Unow);

	short back2=back;
	if(back<2&&DoExtraIterations && (ModDeriv || ModHessian))
	{
		if(this->ModHessian)
			this->ExtraQx->resize(NN);
		size_t i;
		double startval;
		Unow=utility(NN,XX,CC,H);
		AddLog((char*)"Initial interim Utility %-.8e\n",Unow);
//		AddLog((char*)"Startpoint optimisation %d\n",NaiveNonlinearMin(NN,MM,XX,CC,H,AA,LL,UU,vlambda));
		std::valarray<double>  dA(MM);
		std::valarray<double> lA(NN);
		lA=0;
		real pathmin;
		dcopyvec(NN,XX,&w0[0]);
#ifdef DPQDEBUG
		std::string costfilename((char*)"nextcost");
		char iterstring[4];
#endif
		double p1=0;
		do
		{
			real dXX,convkeep=1e22;
			higher_reset=this->ModHessian?1:0;use_higher_H=this->ModHessian?1:0;
			dC=0;
			ModifyC(NN,H,&w0[0],&dC[0],0);
			qphess(NN,1,1,1,H,&w0[0],&implied[0]);
			if(ModHessian)
				dsubvec(NN,&dC[0],&(*ExtraQx)[0],&dC[0]);
#ifdef DPQDEBUG
			sprintf(iterstring,(char*)"%d",nonqpstep);
			PrintC(NN,&w0[0],LL,UU,&dC[0],costfilename+iterstring);
#endif
			if(0)//ModDeriv&&!ModHessian)
			{
				check=0;
				for(i=0;i<c_check.size();++i){check+=(c_check[i]-(*keep_last_C)[i])*(c_check[i]-(*keep_last_C)[i]);}
				if(check < 10*lm_eps && nonqpstep>1)
				{
					AddLog((char*)"No regime change on non-linear step %d\n",nonqpstep);
					break;
				}
				else{c_check=*keep_last_C;}
			}
			higher_reset=0;
			daddvec(NN,CC,&dC[0],CC);

			daddvec(NN,&lA[0],vlambda,&lA[0]);//Variable bounds penalty. This used to cause problems with split variables!!!!
			if(MM)
			{
				for(i=0;i<NN;++i){lA[i]+=ddotvec(MM,AA+MM*i,vlambda+NN);}//Constraint bounds penalty
			}

//			daddvec(NN,CC,&lA[0],CC);
			daddvec(NN,CC,&implied[0],CC);
			dsubvec(NN,LL,&w0[0],LL);
			dsubvec(NN,UU,&w0[0],UU);
			for(i=0;i<MM;++i)
			{
				dA[i] =BITA_ddot(NN,AA+i,MM,&w0[0],1);
			}
			dsubvec(MM,LL+NN,&dA[0],LL+NN);
			dsubvec(MM,UU+NN,&dA[0],UU+NN);
			for(size_t iiii=0;logprint&&(iiii<NN+MM);++iiii)
			{
				if(LL[iiii]>UU[iiii])AddLog((char*)"bad bound %d; %-.8e %-.8e\n",iiii,LL[iiii],UU[iiii]);
			}
			dsetvec(npm,small_round(featol),vlambda+npm);
			dzerovec(npm,vlambda);

			back2 = dqpsol(	(short)	itmax,
						msglvl,
						NN,
						MM,
						npm,
						MM,//max(1,MM),
						n2,
						1,
						&bigbnd,
						AA,
						LL,
						UU,
						CC,
						vlambda+npm,	/*feasible tolerance*/
						H,
						cold,
						(int)lp,//doesn't need to be QP just to get a direction!
						1,		/*let's use orthog for now*/
						XX,
						vistate,
						&iter,
						&obj,
						vlambda,		/*lagrange multipliers*/
						vistate+npm,
						n2,
						vlambda+npm2,	/*work vector*/
						lwrk,
						qpsol_ifail);
                        bool test=false;
			for (size_t kkkk = 0; kkkk < NN; kkkk++) {
				if (XX[kkkk]<LL[kkkk] || XX[kkkk]>UU[kkkk]) {
					/*XX[kkkk] = w0[kkkk];*/
					test = true;
				}
			}
			if (test)
				AddLog((char*)"strange result from dqpopt\n");
			dsubvec(NN,CC,&dC[0],CC);
			dsubvec(NN,CC,&implied[0],CC);
			if(ModHessian)
				daddvec(NN,&dC[0],&(*ExtraQx)[0],&dC[0]);
//			dsubvec(NN,CC,&lA[0],CC);
			daddvec(NN,LL,&w0[0],LL);
			daddvec(NN,UU,&w0[0],UU);
			daddvec(MM,LL+NN,&dA[0],LL+NN);
			daddvec(MM,UU+NN,&dA[0],UU+NN);

			if(back2>1)AddLog((char*)"Bad back %d\n",back2);
			if((dXX=ddotvec(NN,XX,XX)) < lm_eps) break;

			if(p1==0)p1=dXX;
			use_higher_H=0;
			if(1)//nonqpstep>4)
			{
				struct passtopathmin pp;
				pp.CC=CC;
				pp.NN=NN;
				pp.O=this;
				pp.ww=&w0[0];
				pp.XX=XX;
				startval=utility(NN,&w0[0],CC,H);
				AddLog((char*)"Utility at beginning of path %-.16e\n",startval);
				//daddvec(NN,CC,&lA[0],CC);
				pathmin=PathMin(NN,&w0[0],XX,CC,H);
//				printf((char*)"utehere  start %20.8e  end %20.8e dXX%20.8e\n",utehere1(0,&pp),utehere1(1,&pp),dXX);
				//pathmin=::PathMin(utehere1,0,1,lm_rooteps,&pp);
				//dsubvec(NN,CC,&lA[0],CC);
				AddLog((char*)"step %d, dXX %-.8e, pathmin %-.8e, conv %-.8e\n",nonqpstep,dXX,pathmin,(convkeep=pathmin*pathmin*dXX));
			}
			else
			{
				startval=lm_max;
				pathmin=1;
			}
			//if(fabs(Unow-1)>=1e-1&&pathmin==1 && dXX/p1>7e-2)pathmin=.1;//I put this in for GAIN/LOSS, but it can mess up risk parity hence the fabs(Unow-1)>=1e-1
			daxpyvec(NN,pathmin,XX,&w0[0]);
			dscalvec(npm,pathmin,vlambda);
			Unow=utility(NN,&w0[0],CC,H);
			if(Unow>startval+lm_eps8&&pathmin==.1)
			{
				while(pathmin<.95)
				{
					pathmin+=.1;
					daxpyvec(NN,pathmin,XX,&w0[0]);
					dscalvec(npm,pathmin,vlambda);
					Unow=utility(NN,&w0[0],CC,H);
					if(Unow<startval)break;
				}
				AddLog((char*)"Fixup pathmin %-.8e Interim Utility %-.8e\n",pathmin,Unow);
			}
			AddLog((char*)"Interim Utility %-.16e\n",Unow);
			while(Unow>startval+lm_eps8 && fabs(pathmin)>1e-11)
			{
				daxpyvec(NN,-pathmin,XX,&w0[0]);
				dscalvec(npm,1.0/pathmin,vlambda);
				pathmin*=0.1;
				daxpyvec(NN,pathmin,XX,&w0[0]);
				dscalvec(npm,pathmin,vlambda);
				Unow=utility(NN,&w0[0],CC,H);
				AddLog((char*)"Fixup pathmin %-.8e Interim Utility %-.8e\n",pathmin,Unow);
			}
//			AddLog((char*)"%20.8e\n",fabs((Unow-Utest)/Unow));
			//if(fabs((Unow-Utest)/Unow) < 5e-14)
			//if(fabs((Unow-Utest)/Unow) < 1e-12)
			if(gamma_for_eps>.995||NN>2000)Ueps=1e-12;
			else if(ModHessian==ParityHessUV)Ueps=lm_eps;
			else if(ModHessian==ParityHessU)Ueps=lm_eps;
			else Ueps=5e-14;
//The next if statement tries to allow a badly converged result to be accepted to cut down execution time.
//I assume that if the user is doing Hessian updates, the proper answer is worth waiting for.
			if((ModHessian!=BFGSHess)&&(ModHessian!=SharpHess)&&(ModHessian!=SharpHessI)&&(ModHessian!=ParityHessU)&&(ModHessian!=ParityHessUV)&&(nonqpstep>100||(nonqpstep>10&&NN>2000)))
			{
				AddLog((char*)"This non-linear optimisation has not converged to %20.8e in %d iterations\n",Ueps,nonqpstep);
				Ueps=lm_rooteps;
				AddLog((char*)"Change criterion to %20.8e, ratio %20.8e\n",Ueps,Unow/Utest);
				if(convkeep < 2*lm_rooteps) break;
			}
//			if(fabs((Unow-Utest)/dmax(1,(fabs(Unow)))) < Ueps) //This might be better
			if((ModHessian!=ParityHessU)&&(ModHessian!=ParityHessUV)&&fabs((Unow-Utest)/dmax((fabs(Unow)),1.0)) < Ueps)
			{
				AddLog((char*)"Converged on interim utility value\n");
				break;
			}
			if(convkeep < lm_eps)
			{
				AddLog((char*)"Converged; the path is too small\n");
				break;
			}
			if(Unow<Utest)Utest=Unow;
//			if(pathmin*pathmin*dXX < lm_eps*1e6 && nonqpstep) break;
			nonqpstep++;
		}
		while((back2<2||back2==5)&&nonqpstep < nonqpstep_top);
		dcopyvec(NN,&w0[0],XX);
//		printf((char*)"%d path minimisations\n",nonqpstep);
	}
	if(highertermssethere)
		H_from_higher_terms=0;

	objective=obj;
	//printf((char*)"Objective %-.8e; %d iterations\n",obj,iter);
	if((back2<2||back2==5)&&nonqpstep>=nonqpstep_top) {back=11;}
//	cleanZ(NN,XX);
	use_higher_H=0;
	return back;
}

//#define SIGN(a,b) ((b) > 0.0 ? fabs(a) : - fabs(a)) using dsign
template <typename S> void shifter(S &a,S &b,S &c,S &d)
{
	a=b;b=c;c=d;
}

real Base_Optimise::PathMin(dimen n,vector wstart,vector dw,vector c,vector Q,
							double tol)
{
//	Based on routine in "Numerical Recipes in C" page 301.
	double ax = 0,bx = 0.5,cx = 1,ret_val;
	double a,b,d=1e34,etemp,fu,fv,fw,fx,p,q,r,tol1,tol2,u,v,w,x,xm,e = 0.0,base;
	std::valarray<double> ww(n);
	int error = 0;
	dimen count = 0,maxcount=100;

	a = ((ax < cx) ? ax:cx);
	b = ((ax > cx) ? ax:cx);

	x = w = v = ax;

	dcopyvec(n,wstart,&ww[0]);daxpyvec(n,x,dw,&ww[0]);
	fw = fv = fx = utility(n,&ww[0],c,Q);
	base = fabs(fw);if(fw<0){fw = fv = fx=-1;}else{fw = fv = fx=1;}
	if(base==0)
	{
		fw=fv=fx=base;
		base=1;
	}

	ret_val = x;
	while(!error && count < maxcount)
	{
		xm = 0.5 * (a + b);
		tol2 = 2.0 * (tol1 = tol * fabs(x) + lm_eps);
		if(fabs(x - xm) <= (tol2 - 0.5 * (b - a)))
		{
			if(x > 0.5)
				return dmin(1,ret_val+tol2);//If x is close to 1 then x = 1 is probably correct (same pieces throughout)
			else 
				return dmax(0,ret_val-tol2);//If x is close to 0 then x = 0
		}
		if(fabs(e) > tol1)
		{
			r = (x - w) * (fx - fv);
			q = (x - v) * (fx - fw);
			p = (x - v) * q - (x - w) * r;
			q = 2.0 * (q - r);
			if(q > 0.0)
				p = - p;
			q = fabs(q);
			etemp = e;
			e = d;
			if(fabs(p) >= fabs(0.5 * q * etemp) || p <= q * (a - x) || p >= q * (b - x))
			{
				d = (e = (x >= xm ? a - x:b - x)) * lm_golden_ratio;
			}
			else
			{
				d = p / q;
				u = x + d;
				if(u - a < tol2 || b - u < tol2)
					d = dsign(tol1,xm - x);
			}
		}
		else
		{
			d = (e = (x >= xm ? a - x: b - x)) * lm_golden_ratio;
		}
		u = (fabs(d) >= tol1 ? x + d:x + dsign(tol1,d));
		dcopyvec(n,wstart,&ww[0]);
		daxpyvec(n,u,dw,&ww[0]);
		fu = utility(n,&ww[0],c,Q)/base;
		ret_val = u;
		if(fu <= fx)
		{
			if(u >= x)
				a = x;
			else
				b = x;
			shifter(v,w,x,u);
			shifter(fv,fw,fx,fu);
		}
		else
		{
			if(u < x)
				a = u;
			else
				b = u;
			if(fu <= fw || w == x)
			{
				v = w;
				w = u;
				fv = fw;
				fw = fu;
			}
			else if(fu <= fv || v == x || v == w)
			{
				v = u;
				fv = fu;
			}
		}
		count++;
	}

	if(count > maxcount)
	{
		AddLog((char*)"PathMin did not converge\n");
	}
	return ret_val;
}
void Base_Optimise::ModifyC_base(dimen nvab,vector Q,vector x,vector newc)
{
	qphess_base(nvab,1,1,1,Q,x,newc);
}

//extern "C" void Reorder(size_t n, size_t* order,double* array);
//extern "C" void Reorder_mult(size_t n, size_t* order,double* array,size_t m);

real	Base_Optimise::utility_base(dimen nvab,vector X,vector c,vector Q)
{
	std::valarray<double> imp(nvab);
	double ute;
	if(Q&&!lp)qphess_base(nvab,1,1,1,Q,X,&imp[0]);
	ute=ddotvec(nvab,X,c);
	if(Q&&!lp)ute+=0.5*ddotvec(nvab,X,&imp[0]);
	if(Util)
	{
		size_t n_here=n;
		if(TimeOptData&&TimeOptData->usethis)n_here-=TimeOptData->nextra;
		std::valarray<double> ww(n);
		dcopyvec(nvab,X,&ww[0]);
		dcopyvec(n-nvab,x+nvab,&ww[nvab]);
		if(optimiseorder)Reorder_gen(n_here,optimiseorder+n_here,&ww[0],1);
		ResetInitial(0);
		ute+=scale_utility_external_terms*Util(n_here,&ww[0],UtilObjectInfo);
		ResetInitial();
	}
	return ute;
}
void Base_Optimise::qphess_base(dimen nvab,dimen n1,dimen n2,dimen n3,vector Q,vector w,vector y)
{
	size_t t=0;
	if(TimeOptData&&TimeOptData->opt)
	{
		t=TimeOptData->tlen;
		if(TimeOptData->OptType==CVarType)
			t++;
		dzerovec(t,y+nvab-t);
		if(TimeOptData->OptType==SemiVarType)
		{
			dcopyvec(t,w+nvab-t,y+nvab-t);
			dscalvec(t,1./t,y+nvab-t);
		}
	}
	hmul(nvab-t,n1,n2,n3,Q,w,y,HmulObjectInfo);
/*	if(TimeOptData&&TimeOptData->opt&&TimeOptData->OptType==SemiVarType)
	{
		size_t i;
		for(i=0;i<t;++i)
		{
			BITA_daxpy(nvab-t,.25*(w[nvab-t+i]+BITA_ddot(nvab-t,TimeOptData->DATA+i,t,w,1)) /(t-1),TimeOptData->DATA+i,t,y,1);
		}
	}*/
	if(use_soft_in_hessmult&&soft_m)//Won't be right for new Gain/Loss
	{
		size_t i;
		double ss;
		for(i=0;i<soft_m;++i)
		{
			ss=BITA_ddot(nvab,soft_A+i,soft_m,w,1);
			if(ss!=0)
			{
				ss*=soft_l[i];
				BITA_daxpy(nvab,ss,soft_A+i,soft_m,y,1);
			}
		}
	}
}

double	Solve1D(p1DFunc RiskE,double gammabot=0,
							   double gammatop=1-lm_rooteps,double tol=lm_rooteps,void* info=0)
{
	//Numerical Recipes Pages 361-362   9.3 VanWijngaarden�Dekker�BrentMethod
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	size_t	iter,itmax=200;
	short	err;
	short	signk=1;
	double	c=0, d=0, e=0, min1, min2, fc, p, q, r, s, tol1, xm;
	double gamma_opt,a=gammatop,b=gammabot;
	double fa=RiskE(a,info);
	if(fabs(fa)<lm_rooteps)
		return a;
	double fb=RiskE(b,info);
	if(fabs(fb)<lm_rooteps)
		return b;
	double scalelimit=dmax(((fabs(fa)+fabs(fb))*.5),1.0);
	if(tol == 0)
		tol = lm_eps;
	if(fa*fb>0)
	{
		err = 2;	/*argument error*/
		return 1e+10;		
	}
	if(fa < fb)
	{
		double kk=fa;
		signk=-1;
		fa=fb;fb=kk;
	}
	fc = fb;
	gamma_opt = signk == 1?gammabot:gammatop;
	for(iter=0;iter<itmax;iter++)
	{
		if(fb*fc>0)
		{
			c = a;
			fc = fa;
			e = d = b - a;
		}
		if(fabs(fc) < fabs(fb))
		{
			a = b;
			b = c;
			c = a;
			fa = fb;
			fb = fc;
			fc = fa;
		}
		tol1 =  2*lm_rooteps*fabs(b)+0.5*tol;
		xm = 0.5*(c-b);
		if(fabs(xm)<=tol1 || fabs(fb) < 1e-12)
		{
			if(fabs(fb)>1e-02*scalelimit)
			{
				printf((char*)"Problem with the 1d function shape (many valued or not continuous) error\ng1=%-.8e f(g1)=%-.8e\ng2=%-.8e f(g2)=%-.8e\n",b,fb,c,fc);
			}
			if (signk == 1)return b;
			else return (gammatop - b) + gammabot;
		}
		if(fabs(e) >= tol1 && fabs(fa) > fabs(fb))
		{
			s = fb/fa;
			if( a==c)
			{
				p = 2*xm*s;
				q = 1 - s;
			}
			else	
			{
				q = fa/fc;
				r = fb/fc;
				p = s*(2*xm*q*(q-r)-(b-a)*(r-1));
				q = (q-1)*(r-1)*(s-1);
			}
			if( p>0 ) q = - q;
			p = fabs(p);
			min1 = 3*xm*q - fabs(tol1*q);
			min2 = fabs(e*q);
			if(2*p < (min1<min2?min1:min2))
			{
				e = d;
				d = p/q;		
			}
			else
			{
				d = xm;
				e = d;
			}
		}
		else
		{
			d = xm;
			e = d;
		}
		a = b;
		fa = fb;
		b += (fabs(d)>tol1) ? d : (xm>0?fabs(tol1):-fabs(tol1));
		if(signk == 1)
		{
			fb = RiskE(b,info);
			gamma_opt=b;
		}
		else
		{
			double new_b=(gammatop - b) + gammabot;
			fb = RiskE(new_b,info);
			gamma_opt=new_b;
		}
	}
	return gamma_opt;
}

double PathMin(p1DFunc RiskE,double gammabot,
							   double gammatop,double tol,void* info,int stopifpos)
{
//Numerical Recipes page 402-405 10.2 Parabolic Interpolation and Brent�s Method in OneDimension

#ifdef __SYSNT__
	_ASSERT(0);
#endif
	double ax = gammabot,bx = 0.5,cx = gammatop,ret_val;
	double a,b,d=1e34,etemp,fu,fv,fw,fx,p,q,r,tol1,tol2,u,v,w,x,xm,e = 0.0,base;
	int error = 0;
	dimen count = 0,maxcount=100;

	bx=(ax+cx)*.5;
	a = ((ax < cx) ? ax:cx);
	b = ((ax > cx) ? ax:cx);

	x = w = v = bx;

	fw= RiskE(x,info);
	base=fabs(fw);if(fw<0){fw = fv = fx = -1;}else{fw = fv = fx = 1;}
	if(base==0)
	{
		fw=fv=fx=base;
		base=1;
	}
	ret_val = x;
	while(!error && count < maxcount)
	{
		xm = 0.5 * (a + b);
		tol2 = 2.0 * (tol1 = tol * fabs(x) + lm_eps);
		if(fabs(x - xm) <= (tol2 - 0.5 * (b - a)))
		{
			if(x > (gammatop+gammabot)*0.5)
				return dmin(dmax(gammatop,gammabot),ret_val+tol2);//If x is close to gammatop then x = gammatop is probably correct (same pieces throughout)
			else 
				return dmax(dmin(gammatop,gammabot),ret_val-tol2);//If x is close to gammabot then x = gammabot
		}
		if(fabs(e) > tol1)
		{
			r = (x - w) * (fx - fv);
			q = (x - v) * (fx - fw);
			p = (x - v) * q - (x - w) * r;
			q = 2.0 * (q - r);
			if(q > 0.0)
				p = - p;
			q = fabs(q);
			etemp = e;
			e = d;
			if(fabs(p) >= fabs(0.5 * q * etemp) || p <= q * (a - x) || p >= q * (b - x))
			{
				d = (e = (x >= xm ? a - x:b - x)) * lm_golden_ratio;
			}
			else
			{
				d = p / q;
				u = x + d;
				if(u - a < tol2 || b - u < tol2)
					d = dsign(tol1,xm - x);
			}
		}
		else
		{
			d = (e = (x >= xm ? a - x: b - x)) * lm_golden_ratio;
		}
		u = (fabs(d) >= tol1 ? x + d:x + dsign(tol1,d));
		fu=RiskE(u,info)/base;
		ret_val = u;
		if((stopifpos*fu)>0) break;
		if(fu <= fx)
		{
			if(u >= x)
				a = x;
			else
				b = x;
			shifter(v,w,x,u);
			shifter(fv,fw,fx,fu);
		}
		else
		{
			if(u < x)
				a = u;
			else
				b = u;
			if(fu <= fw || w == x)
			{
				v = w;
				w = u;
				fv = fw;
				fw = fu;
			}
			else if(fu <= fv || v == x || v == w)
			{
				v = u;
				fv = fu;
			}
		}
		count++;
	}

	if(count > maxcount)
		printf((char*)"PathMin did not converge\n");
	return ret_val;
}

double boundsearchA(size_t n,size_t m,vector start,vector step,vector L,vector U,vector A)
{
	double stepl = 1e22,starta,stepa;
	size_t i=m;
	while(i--&&stepl>0)
	{
		starta=BITA_ddot(n,A,m,start,1);
		stepa=BITA_ddot(n,A,m,step,1);
		if(fabs(stepa) < 100*lm_eps) break;
		if(starta + stepl * stepa > *U)
			stepl = (*U - starta) / stepa;
		else if(starta + stepl * stepa < *L)
			stepl = (*L - starta) / stepa;
		A++;
		U++;
		L++;
	}
	return dmax(0,stepl);
}
double boundsearch(size_t n,size_t m,vector start,vector step,vector L,vector U,vector A)
{
	double stepl = boundsearchA(n,m,start,step,L+n,U+n,A);
	while(n--&&stepl>0)
	{
		if(*start + stepl * *step > *U)
			stepl = (*U - *start) / *step;
		else if(*start + stepl * *step < *L)
			stepl = (*L - *start) / *step;
		start++;
		step++;
		L++;
		U++;
	}
	return dmax(0,stepl);
}
void orth(size_t n,size_t &nbasis,vector v,vector basis)
{
	size_t i;
	vector newbasis=basis+n*nbasis;
	double proj;
	dcopyvec(n,v,basis+n*nbasis);
	for(i = 0;i < nbasis;++i)
	{
		proj=ddotvec(n,v,basis+n*i);
		daxpyvec(n,-proj,basis+n*i,newbasis);
	}
	proj=ddotvec(n,basis+n*nbasis,newbasis);
	if(proj > lm_eps)
	{
		dscalvec(n,1.0/sqrt(proj),newbasis);
		for(i=0;i<n;++i)
			printf((char*)"basis%d %-.8e\n",nbasis,basis[n*nbasis+i]);
		nbasis++;
	}
}
short Base_Optimise::NaiveNonlinearMin(size_t n,size_t m,vector x,vector c,vector Q,vector A,
									   vector L,vector U,vector work)
{
	size_t fixedC,i,id;
	vector basis=work,lbasis;
	double proj,minp,maxstep,norm,U0,U1;
	dmx_transpose(m,n,A,A);
	for(i=0,fixedC=0;i<m;++i)
	{
		if(U[n+i]-L[n+i] < 10)
		{
			if(fixedC > 0)
			{
				orth(n,fixedC,A+n*i,basis);
			}
			else
			{
				proj=ddotvec(n,A+n*i,A+n*i);
				if(proj > lm_eps)
				{
					dcopyvec(n,A+n*i,basis);
					dscalvec(n,1.0/sqrt(proj),basis);
					fixedC++;
				}
			}
		}
	}
	dmx_transpose(n,m,A,A);
	U0=utility(n,x,c,Q);
	printf((char*)"Utility at initial guess %-.8e\n",U0);
	for(i=0,id=0;i<n;++i)
	{
		lbasis=basis+n*fixedC;
		if(i >= fixedC)
		{
			lbasis=basis+n*fixedC;
			dzerovec(n,lbasis);
			lbasis[id++]+=1;
			orth(n,fixedC,lbasis,basis);
			fixedC--;
		}
		else
			continue;
		minp=0;
		norm=ddotvec(n,lbasis,lbasis);
		maxstep=boundsearch(n,m,x,lbasis,L,U,A);
		if(maxstep>0)
		{
			if(maxstep<1e22)
			{
				dscalvec(n,maxstep,lbasis);
					norm*=maxstep;
			}
			minp=PathMin(n,x,lbasis,c,Q);
		}
		if(minp <= 100*lm_eps)
		{
			dnegvec(n,work+n*fixedC);
			maxstep=boundsearch(n,m,x,lbasis,L,U,A);
			if(maxstep>0)
			{
				if(maxstep<1e22)
				{
					dscalvec(n,maxstep,lbasis);
					norm*=maxstep;
				}
				minp=PathMin(n,x,lbasis,c,Q);
			}
		}
		if(minp>0)
			daxpyvec(n,minp,lbasis,x);
		U1=utility(n,x,c,Q);
		printf((char*)"Utility at next stage %-.8e\n",U1);
	}
	return 0;
}
/*short Base_Optimise::NaiveNonlinearMin(size_t n,size_t m,vector x,vector c,vector Q,vector A,
									   vector L,vector U)
{
	std::valarray<double> startvec(n),basis(n),implied(n);
	size_t iter=0,mused=m;
	double norm,minp,maxstep,U0,U1;
	startvec=0;
	startvec[iter]=1.0;
	qphess(n,1,1,1,Q,c,&implied[0]);
	norm = ddotvec(n,c,&implied[0]);
	U0=utility(n,x,c,Q);
	printf((char*)"Utility at initial guess %-.8e\n",U0);
	if(1||fabs(norm) < lm_eps)
	{
		basis=0.0;
		norm=0;
		while(mused)
		{
			mused--;
			for(size_t i=0;i<n;++i)
				basis[i]=A[m*i];
			if((norm=ddotvec(n,&basis[0],&basis[0]))>lm_eps)
				break;
		}
		if(norm <= lm_eps)
		{
			basis[0]=1.0;
			norm=ddotvec(n,&basis[0],&basis[0]);
		}
		minp=0;
		maxstep=boundsearch(n,m,x,&basis[0],L,U,A);
		if(maxstep>0)
		{
			if(maxstep<1e22)
			{
				dscalvec(n,maxstep,&basis[0]);
				norm*=maxstep;
			}
			minp=PathMin(n,x,&basis[0],c,Q);
		}
		if(minp <= lm_eps)
		{
			basis*=-1.0;
			maxstep=boundsearch(n,m,x,&basis[0],L,U,A);
			if(maxstep>0)
			{
				if(maxstep<1e22)
				{
					dscalvec(n,maxstep,&basis[0]);
					norm*=maxstep;
				}
				minp=PathMin(n,x,&basis[0],c,Q);
			}
		}
		if(minp>0)
			daxpyvec(n,minp,&basis[0],x);
		U1=utility(n,x,c,Q);
		printf((char*)"Utility at modified guess %-.8e\n",U1);
		if(1||U1<U0)
		{
			daxpyvec(n,-ddotvec(n,&startvec[0],&basis[0])/norm,&basis[0],&startvec[0]);
			while(ddotvec(n,&startvec[0],&startvec[0]) > lm_eps && iter++ < n-1)
			{
				minp=0;
				norm=0;
				while(mused&&iter<m)
				{
					mused--;
					for(size_t i=0;i<n;++i)
						basis[i]=A[m*i+iter];
					if((norm=ddotvec(n,&basis[0],&basis[0]))>lm_eps)
						break;
				}
				if(norm <= lm_eps)
				{
					dcopyvec(n,&startvec[0],&basis[0]);
					norm = ddotvec(n,&basis[0],&basis[0]);
				}

				startvec[iter]+=1.0;
				if(fabs(norm) < lm_eps)
					return 0;
				maxstep=boundsearch(n,m,x,&basis[0],L,U,A);
				if(maxstep>0)
				{
					if(maxstep < 1e22)
					{
						dscalvec(n,maxstep,&basis[0]);
						norm*=maxstep;
					}
					minp=PathMin(n,x,&basis[0],c,Q);
				}
				if(minp <= lm_eps)
				{
					basis *= -1.0;
					implied *= -1.0;
					maxstep=boundsearch(n,m,x,&basis[0],L,U,A);
					if(maxstep>0)
					{
						if(maxstep < 1e22)
						{
							dscalvec(n,maxstep,&basis[0]);
							norm*=maxstep;
						}
						minp=PathMin(n,x,&basis[0],c,Q);
					}
				}
				if(minp>0)
					daxpyvec(n,minp,&basis[0],x);
//				if(minp <= 100*lm_eps)break;
				U1=utility(n,x,c,Q);
				printf((char*)"Utility at first next guess %-.8e\n",U1);
				if(U1 > U0) return 1;
				U0=U1;
				daxpyvec(n,-ddotvec(n,&startvec[0],&basis[0])/norm,&basis[0],&startvec[0]);
			}
			return 0;
		}
		else return 1;
	}
	else
		dcopyvec(n,c,&basis[0]);
	maxstep=boundsearch(n,m,x,&basis[0],L,U,A);
	if(maxstep<lm_eps)
	{
		basis*=-1.0;
		maxstep=boundsearch(n,m,x,&basis[0],L,U,A);
	}
	dscalvec(n,maxstep,&basis[0]);
	norm*=maxstep;
	minp=PathMin(n,x,&basis[0],c,Q);
	daxpyvec(n,minp,&basis[0],x);
	U0=utility(n,x,c,Q);
	printf((char*)"Utility at first modified guess %-.8e\n",U0);

	daxpyvec(n,-ddotvec(n,&startvec[0],&implied[0])/norm,&basis[0],&startvec[0]);
	while(ddotvec(n,&startvec[0],&startvec[0]) > lm_eps && iter++ < n-1)
	{
		dcopyvec(n,&startvec[0],&basis[0]);
		startvec[iter]+=1.0;
		qphess(n,1,1,1,Q,&basis[0],&implied[0]);
		norm = ddotvec(n,&basis[0],&implied[0]);
		if(fabs(norm) < lm_eps)
			return 0;
		maxstep=boundsearch(n,m,x,&basis[0],L,U,A);
		dscalvec(n,maxstep,&basis[0]);
		norm*=maxstep;
		minp=PathMin(n,x,&basis[0],c,Q);
		if(minp <= 100*lm_eps)
		{
			basis *= -1.0;
			implied *= -1.0;
			maxstep=boundsearch(n,m,x,&basis[0],L,U,A);
			dscalvec(n,maxstep,&basis[0]);
			norm*=maxstep;
			minp=PathMin(n,x,&basis[0],c,Q);
		}
		daxpyvec(n,minp,&basis[0],x);
		if(minp <= 100*lm_eps)break;
		U1=utility(n,x,c,Q);
		printf((char*)"Utility at first next guess %-.8e\n",U1);
		if(U1 > U0) return 1;
		U0=U1;
		daxpyvec(n,-ddotvec(n,&startvec[0],&implied[0])/norm,&basis[0],&startvec[0]);
	}
	return 0;
}
*/
