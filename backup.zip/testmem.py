try:
    from safejavajy import *
    from jarray import *
    from java.lang import *
    jython = 1
except:
    from safe import *
    jython = 0

n=3000
Q=[0]*(n*(n+1)/2)
for i in range(n):
    Q[i*(i+3)/2]=1
d=[1]+[0]*(n-1)
if jython:
    Qm1d=array([1]+[0]*(n-1),Double)
else:
    Qm1d=[]
for j in range(n):
    print j
    InvQ_d(n,Q,d,Qm1d)
