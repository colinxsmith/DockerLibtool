#include "baseoptimise.h"
static void w_lam(char *msg1, char *msg2, dimen n, short_vec a, real *r)
{
	dimen	i,j;

	lm_wmsg((char*)"\nMULTIPLIERS FOR THE %.2s %s", msg1, msg2);
	for(i=j=0;i<n;i++){
		if(j==4){
			lm_putc('\n');
			j = 1;
			}
		else	j++;
		lm_printf((char*)"%5ld%11.2le",CL(a[i]),r[i]);
		}
	lm_putc('\n');
}

/*
	dgetlamd first computes the lagrange multiplier estimates for the
	given working set.  it then determines the values and indices of
	certain significant multipliers.  in this process, the multipliers
	for inequalities at their upper bounds are adjusted so that a
	negative multiplier for an inequality constraint indicates
	non-optimality.  in the following, the term minimum refers to the
	ordering of numbers on the real line, and not to their magnitude.
	smllst  is the minimum among the inequality constraints of the
	(adjusted) multipliers scaled by the 2-norm of the
	associated constraint row
	jsmlst  is the index of the constraint corresponding to  smllst
	ksmlst  marks its position in  kactiv
	on exit,  elements  1  thru  nactiv  of   rlamda  contain the
	(unadjusted) multipliers for the general constraints.  elements
	nactiv  onwards of  rlamda  contain the (unadjusted) multipliers
	for the simple bounds
*/
void Base_Optimise::dgetlamd(char *lprob, dimen n, dimen nactiv, dimen ncolz, dimen nfree, dimen nrowa, dimen Nrowrt, dimen *jsmlst, dimen *ksmlst, real *smllst, short_vec istate, short_vec kactiv, real *a, real *anorm, real *qtg, real *rlamda, real *rt)
{
	real	blam, rlam, anormj;
	dimen	nlam;
	dimen i, j, k, l, jgfxd, ka, kb, is, nfixed;
	integer	idiag;

	rt -= Nrowrt + 1;
	--rlamda;
	--qtg;
	--anorm;
	a -= nrowa + 1;
	--kactiv;
	--istate;

	/*
	first, compute the lagrange multipliers for the general
	constraints in the working set, by solving
	t(transpose)*rlamda = y(t)*grad
	*/
	nfixed = n - nfree;
	nlam = nfixed + nactiv;
	if(nactiv > 0) {
		dcopyvec(nactiv, &qtg[ncolz + 1], &rlamda[1]);
		idiag = 1;
		drtmxsolve(-2, nactiv, &rt[(ncolz + 1) * Nrowrt + 1], Nrowrt,
			&rlamda[1], &idiag);
		}
	/*
	now set elements nactiv, nactiv+1,... of rlamda equal to the
	multipliers for the bound constraints in the working set
	*/
	for (l = 1; l <= nfixed; ++l) {
		kb = nactiv + l;
		j = kactiv[kb];
		jgfxd = nfree + l;
		blam = qtg[jgfxd];
		for (ka = 1; ka <= nactiv; ++ka) {
	    		i = kactiv[ka];
	    		blam -= a[i + j * nrowa] * rlamda[ka];
			}
		rlamda[kb] = blam;
		}

	/*find  allmax and smllst*/
	*smllst = lm_max;
	*jsmlst = 0;
	*ksmlst = 0;
	for (k = 1; k <= nlam; ++k) {
		j = kactiv[k];
		if (k > nactiv) anormj = 1;
		else	{
	    		anormj = anorm[j];
	    		j += n;
			}
		is = istate[j];
		/*
	 	change the sign of the estimate if the constraint is in the
		working set (or violated) at its upper bound
		if (is == 3) rlam = fabs(rlam);
		*/
		if (is != 3){
			rlam = rlamda[k] * anormj;
			/*not a fixed variable or an equality constraint*/
			if (is == 2) rlam = -rlam;
			else if (is == 4) rlam = -fabs(rlam);
			/*find the smallest multiplier for the inequalities*/
			if(rlam < *smllst) {
				*smllst = rlam;
				*jsmlst = j;
				*ksmlst = k;
				}
			}
		}

	/*if required, print the multipliers*/
	if(msg < 20) return;
	if (nactiv > 0) w_lam(lprob,(char*) "CONSTRAINTS...",nactiv, &kactiv[1], &rlamda[1]);
	l = nactiv + 1;
	if (l <= nlam) w_lam(lprob,(char*) "BOUND CONSTRAINTS...",nlam-nactiv,&kactiv[l],&rlamda[l]);
	if (msg >= 80)
		lm_wmsg((char*)"\n//dgetlam//  JSMLST     SMLLST     KSMLST\n//dgetlam//%8ld%11.2lg%11ld",
			CL(*jsmlst), *smllst, CL(*ksmlst));
}
