#include "ldefns.h"
void lm_mivwri(const char *name, dimen n, short_vec x)
{
	lm_name_write(name, 10, 6 );
	lm_ivwrit(n, x);
}
