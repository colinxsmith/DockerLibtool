#include "baseoptimise.h"
/*
	lpcore finds a feasible point for the general linear constraints
	and bounds. the sum of the infeasibilities is minimized using
	a linear programming algorithm which may perform non-simplex
	steps. at each iteration the direction of search is defined as
	the projection of the steepest-descent direction. this
	projection is computed using an orthogonal factorization of the
	matrix of constraints in the working set
	if  lp = 1,  lpcore will solve the linear programming problem
	defined by the objective cvec, the constraint matrix  a	 and the
	bounds	bl, bu

	values of istate(j)...
	- 2	    - 1		0	    1	       2	 3
	a*x < bl   a*x > bu	a*x free   a*x = bl   a*x = bu	 bl = bu

	if  vertex = 1,	 the initial point  x  will be made into a
	vertex by regarding some of the free variables	x(j)  as being
	on an temporary bound.	some of these variables may remain on
	their temporary bounds.	 if so, their state will be
	istate(j) = 4
*/
void Base_Optimise::dlpcore(	int lp, int minsum, int orthog, logical *unitq, int vertex, integer *inform, integer *iter,
		integer *itmax, byte lcrash, dimen n, integer *nclin, integer *nctotl, integer *nrowa, integer *nactiv,
		integer *nfree, integer *numinf, short_vec istate, short_vec kactiv, short_vec kfree, real *obj, real *xnorm,
		real *a, real *ax, real *bl, real *bu, real *clamda, real *cvec, real *featol, real *x, short_vec iw, real *w)
{

#ifdef	__SYSNT1__
	MSG	message;
#endif
   static char *lprob=(char*)"LP";

    integer a_dim1, a_offset, i__1;
    real d__1;

    integer iadd, jadd;
    real alfa;
    integer jdel, kdel, ndel;
    integer ifix;
    logical prnt;
    logical added;
    real palfa;
    int ifail;
    real bigdx;
    integer isdel=0;
    real objlp, condt;
    real anorm, dinky;
    integer ncnln;
    logical stall;
    real wgfix=1e9;
    integer ncolz;
    real pnorm;
    logical nullr;
    integer nrowj;
    integer nclin0, kb;
    real bigalf, bigbnd, epspt9;
    integer is;
    real feamax, feamin;
    logical delete_;
    integer nfixed;
    integer jbigst, kbigst;
    real tolact;
    int modfyg;
    real condmx, atphit, cslast, rdlast, objsiz, snlast, suminf,
	     trulam;
    integer idummy, msglvl;
	dimen jsmlst, ksmlst;
    real smllst;
	integer mstall;
    real ztgnrm;
    integer nstall;
	int	firstv, hitlow;
	logical unitpg;
    real bnd;
    real gtp;

    --w;
    --iw;
    --x;
    --featol;
    --cvec;
    --clamda;
    --bu;
    --bl;
    --ax;
    a_dim1 = *nrowa;
    a_offset = a_dim1 + 1;
    a -= a_offset;
    --kfree;
    --kactiv;
    --istate;

/*     SPECIFY MACHINE-DEPENDENT PARAMETERS. */
	/*INITIALIZE */
    ncnln = 0;
    nclin0 = max(*nclin,1);
    nrowj = 1;
    *inform = 0;
    *iter = 0;
    jadd = 0;
    jdel = 0;
    ndel = 0;
    nstall = 0;
    *numinf = 1;
    msglvl = msg;
    msg = 0;
    if (*iter >= istart) {
	msg = msglvl;
    }
    bigbnd = parm[0];
    bigdx = parm[1];
    tolact = parm[2];
    epspt9 = parm[3];
    alfa = 0;
    condmx = lm_max;
    objlp = 0;
    added = TRUE_;
    firstv = FALSE_;
    modfyg = 1;
    nullr = TRUE_;
    unitpg = FALSE_;
    dxminmax(*nctotl, &featol[1], 1, &feamax, &feamin);
	/*
	---------------------------------------------------------------------
	given an initial point	x, compute the following....
	(1)	the initial working set
	(2)	the tq factorization of the matrix of constraints in the
		working set
	(3)	the value and gradient of the sum of infeasibilities at the
		point x. if x is feasible and the solution of an lp is
		required, the linear objective function and gradient is
		computed
		the array rlamda is used as temporary work space
	---------------------------------------------------------------------
	*/
    dlpcrsh(orthog, unitq, vertex, lcrash, n, nclin, nctotl, &nq, 
	    nrowa, &nrowrt, &ncolrt, nactiv, &ncolz, nfree, &istate[1], &
	    kactiv[1], &kfree[1], &bigbnd, &tolact, xnorm, &a[a_offset],
	    pANORM, &ax[1], &bl[1], &bu[1], &x[1], pQTG, pRT, pZY,
		pPX, pWRK, pRLAM);
    dlpgrad(lp, n, CN(*nctotl), CN(*nrowa), bigbnd, feamin, numinf, &suminf, &istate[
	    1], &a[a_offset], &bl[1], &bu[1], &cvec[1], &featol[1], pQTG, 
	    &x[1]);
    dzyprod(6, n, *nactiv, ncolz, *nfree, nq, *unitq, &kactiv[1], &kfree[1]
	    , pQTG, pZY, pWRK);
    *obj = suminf;
    if (lp) objlp = ddotvec(n, &cvec[1], &x[1]);
    if (lp && *numinf == 0) *obj = objlp;
    if (*numinf == 0 && ! (lp)) goto L320;
/* .......................START OF THE MAIN LOOP........................ 
*/
/*     DEFINE SMALL QUANTITIES THAT REFLECT THE MAGNITUDE OF  C,  X, */	
/*     AND THE NORM OF THE CONSTRAINTS IN THE WORKING SET. */
L20:
#ifdef	__SYSNT1__
	if(PeekMessage(&message,NULL,0,0,PM_REMOVE))
	{
		lm_fflushall();
		switch(message.message)
		{
/*		case WM_NULL:
		case 4167:message when using COM and close
			lm_wmsg((char*)"qp message %d %d %d %d",message.message,WM_LBUTTONUP,WM_KEYDOWN,WM_LBUTTONDOWN);
			exit(14);*/
		case WM_LBUTTONUP:
		case WM_RBUTTONUP:
		case WM_LBUTTONDOWN:
		case WM_RBUTTONDOWN:
		case WM_KEYDOWN:
			break;
		default:
			TranslateMessage(&message);
			DispatchMessage(&message);
		}
	}
#endif
	clocker();
    objsiz = (1 + fabs(*obj)) / (1 + *xnorm);
    if (*numinf == 0) {
	objsiz = (lm_eps + fabs(*obj)) / (lm_eps + *xnorm);
    }
    anorm = 0;
    if (*nactiv > 0) {
	anorm = fabs(dtmax);
    }
    dinky = epspt9 * dmax(anorm,objsiz);
/*     COMPUTE THE NORMS OF THE PROJECTED GRADIENT AND THE GRADIENT WITH 
*/
/*     RESPECT TO THE FREE VARIABLES. */
    ztgnrm = 0;
    if (ncolz > 0) ztgnrm = dnrm2vec(ncolz, pQTG);
#if	0
    gfnorm = ztgnrm;
    if (*nfree > 0 && *nactiv > 0) {
	gfnorm = dnrm2vec(*nfree, pQTG);
    }
#endif
    if (msg >= 80) wdinky((char*)"LPCORE", ztgnrm, dinky);
    delete_ = ztgnrm <= dinky;
/*     PRINT THE DETAILS OF THIS ITERATION. */
    prnt = added || ndel > 1;
    if (! prnt) goto L40;
    condt = dprotdiv(&dtmax, &dtmin, &ifail);
    if (ifail && dtmax == 0) condt = lm_max;
    dlpprt(lp, CN(*nrowa), nrowrt, n, CN(*nclin), CN(*nfree), isdel, CN(*nactiv),
		CN(ncolz), CN(*iter), jadd, jdel, alfa, condt, CN(*numinf), 
	    suminf, objlp, &istate[1], &kfree[1], &a[a_offset], pRT, &x[1], pWRK, pAP);
    added = FALSE_;
    jadd = 0;
    jdel = 0;
L40:
    if (*numinf == 0 && !lp) {
	goto L320;
    }
    if (! delete_) {
	goto L100;
    }
/* --------------------------------------------------------------------- 
*/
/*     THE PROJECTED GRADIENT IS NEGLIGIBLE. */
/*     WE HAVE TO DELETE A CONSTRAINT BEFORE A MOVE CAN BE MADE. */
/* --------------------------------------------------------------------- 
*/
    dgetlamd(lprob, n, *nactiv, ncolz, *nfree, *nrowa, nrowrt, 
	    &jsmlst, &ksmlst, &smllst, &istate[1], &kactiv[1], &a[
	    a_offset], pANORM, pQTG, pRLAM, pRT);
/* --------------------------------------------------------------------- 
*/
/*     TEST FOR CONVERGENCE.  IF THE LEAST (ADJUSTED) MULTIPLIER IS */
/*     GREATER THAN A SMALL NEGATIVE QUANTITY, AN ADEQUATE  LP  SOLUTION 
*/
/*     HAS BEEN FOUND. */
/* --------------------------------------------------------------------- 
*/
    if (smllst >= -dinky) {
	jsmlst = 0;
    }
    if (jsmlst == 0) {
	goto L60;
    }
    if (vertex && ncolz >= 1) {
	goto L60;
    }
/*     PREPARE TO DELETE THE CONSTRAINT WITH INDEX  JSMLST. */
    jdel = jsmlst;
    kdel = ksmlst;
    isdel = istate[jdel];
    istate[jdel] = 0;
    goto L80;
/* --------------------------------------------------------------------- 
*/
/*     IF STILL INFEASIBLE, WE CAN REDUCE THE SUM OF INFEASIBILITIES */
/*     IF THERE IS A MULTIPLIER GREATER THAN ONE. */
/* --------------------------------------------------------------------- 
*/
/*     INSTEAD OF LOOKING FOR THE LAST VIOLATED CONSTRAINT IN BNDALF, */
/*     WE MUST NOW LOOK FOR THE FIRST VIOLATED CONSTRAINT ALONG  P. */
/*     THIS WILL ENSURE THAT THE WEIGHTED SUM OF INFEASIBILITIES */
/*     DECREASES. */
L60:
    if (*numinf == 0 || !minsum) {
	goto L280;
    }
/*     FIND THE BIGGEST MULTIPLIER LARGER THAN UNITY. */
/*     FOR THE PURPOSES OF THE TEST,  THE  J-TH  MULTIPLIER IS SCALED */
/*     BY  FEATOL(J)/FEAMIN.  THIS FORCES CONSTRAINTS WITH LARGER  FEATOL 
*/
/*     VALUES TO BE DELETED FIRST. */
    dlpbgst(n, CN(*nactiv), CN(*nfree), &jbigst, &kbigst, &istate[1], &kactiv[1], dinky, feamin,
		&trulam, &featol[1], pRLAM);
    if (jbigst == 0) {
	goto L280;
    }
    jdel = jbigst;
    kdel = kbigst;
    isdel = istate[jbigst];
	is = trulam > 0 ? -2 : -1;
    istate[jbigst] = is;
    firstv = TRUE_;
/* --------------------------------------------------------------------- 
*/
/*     UPDATE THE  TQ  FACTORIZATION OF THE MATRIX OF CONSTRAINTS IN THE 
*/
/*     WORKING SET. */
/* --------------------------------------------------------------------- 
*/
L80:
    ++ndel;
    ddelcon(modfyg, orthog, CB(*unitq), CN(jdel), CN(kdel), CN(*nactiv), CN(ncolz), CN(*nfree), n,
		CN(nq), CN(*nrowa), CN(nrowrt), &kactiv[1], &kfree[1], &a[a_offset], 
	    pQTG, pRT, pZY);
    ++ncolz;
    if (jdel <=  (integer)n) {
	++(*nfree);
    }
    if (jdel >  (integer)n) {
	--(*nactiv);
    }
    goto L20;
/* --------------------------------------------------------------------- 
*/
/*     COMPUTE THE SEARCH DIRECTION,  P = - Z*(PROJECTED GRADIENT). */
/* --------------------------------------------------------------------- 
*/
L100:
    if (*iter >= *itmax) {
	goto L400;
    }
    ++(*iter);
    if (*iter >= istart) {
	msg = msglvl;
    }
    dfindp(&nullr, &unitpg, unitq, n, nclin, &nq, nrowa, &
	    nrowrt, &ncolz, &ncolz, nfree, &istate[1], &kfree[1],
	    delete_, &gtp, &pnorm, &rdlast, &a[a_offset], pAP,
	    pPX, pQTG, pRT, pWRK, pZY, pWRK);
/* --------------------------------------------------------------------- 
*/
/*     FIND THE CONSTRAINT WE BUMP INTO ALONG  P. */
/*     UPDATE  X  AND  AX  IF THE STEP  ALFA  IS NONZERO. */
/* --------------------------------------------------------------------- 
*/
/*     ALFA  IS INITIALIZED TO  BIGALF.  IF IT REMAINS THAT WAY AFTER */
/*     THE CALL TO BNDALF, IT WILL BE REGARDED AS INFINITE. */
    bigalf = dprotdiv(&bigdx, &pnorm, &ifail);
    if (ifail && bigdx == 0) bigalf = lm_max;
    *inform = dbndalf(firstv, &hitlow, &istate[1], &jadd, n,
	    CN(*nctotl), CN(*numinf), &alfa, &palfa, &atphit, &bigalf, &bigbnd, 
	    &pnorm, pANORM, pAP, &ax[1], &bl[1], &bu[1], &featol[1], pPX, &x[1]);
    if (*inform != 0 || jadd == 0) {
	goto L300;
    }
/*     TEST IF  ALFA*PNORM  IS NEGLIGIBLE. */
    stall = (d__1 = alfa * pnorm, fabs(d__1)) <= epspt9 * *xnorm;
    if (! stall) {
	goto L120;
    }
/*     TAKE A ZERO STEP. */
/*     IF A NON-ORTHOGONAL  TQ  FACTORIZATION IS BEING RECURRED AND  X */
/*     IS NOT YET FEASIBLE,  THE GRADIENT OF THE SUM OF INFEASIBILITIES */

/*     MUST BE RECOMPUTED. */
    alfa = 0;
    ++nstall;
    mstall = 2000;
    if (nstall <= mstall && orthog) {
	goto L160;
    }
    if (nstall <= mstall && !orthog) {
	goto L140;
    }
    goto L380;
/*     CHANGE  X  TO  X + ALFA*P.  UPDATE  AX  ALSO. */
L120:
    nstall = 0;
    daxpyvec(n, alfa, pPX, &x[1]);
    if (*nclin > 0)
	BITA_daxpy(*nclin, alfa, pAP, 1, &ax[1], 1);
    *xnorm = dnrm2vec(n, &x[1]);
    if (lp) objlp = ddotvec(n, &cvec[1], &x[1]);
/*     IF  X  IS NOT YET FEASIBLE,  COMPUTE  OBJ  AND  GRAD  AS THE VALUE 
*/
/*     AND GRADIENT OF THE SUM OF INFEASIBILITIES (IF  X  IS FEASIBLE, */
/*     THE VECTOR  QTG  IS UPDATED AND  GRAD  NEED NOT BE COMPUTED). */
L140:
    if (*numinf == 0) goto L160;
    dlpgrad(lp, n, CN(*nctotl), CN(*nrowa), bigbnd, feamin, numinf, &suminf, &istate[
	    1], &a[a_offset], &bl[1], &bu[1], &cvec[1], &featol[1], pQTG, 
	    &x[1]);
    if (!orthog && jadd <=  (integer)n) wgfix = pQTG[jadd-1];
    dzyprod(6, n, *nactiv, ncolz, *nfree, nq, *unitq, &kactiv[1], &kfree[1]
	    , pQTG, pZY, pWRK);
    *obj = suminf;
/* --------------------------------------------------------------------- 
*/
/*     ADD A CONSTRAINT TO THE WORKING SET. */
/* --------------------------------------------------------------------- 
*/
/*     UPDATE  ISTATE. */
L160:
    if (lp && *numinf == 0) {
	*obj = objlp;
    }
    if (hitlow) {
	istate[jadd] = 1;
    }
    if (! hitlow) {
	istate[jadd] = 2;
    }
    if (bl[jadd] == bu[jadd]) {
	istate[jadd] = 3;
    }
/*     IF A BOUND IS TO BE ADDED, MOVE  X  EXACTLY ONTO IT, EXCEPT WHEN */

/*     A NEGATIVE STEP WAS TAKEN.  (BNDALF  MAY HAVE HAD TO MOVE TO SOME 
*/
/*     OTHER CLOSER CONSTRAINT.) */
    iadd = jadd - n;
    if (jadd >  (integer)n) goto L200;
	bnd = (hitlow ? bl : bu)[jadd];
    if (alfa >= 0) x[jadd] = bnd;
    i__1 = *nfree;
    for (ifix = 1; ifix <= i__1; ++ifix) {
	if (kfree[ifix] == jadd) {
	    goto L200;
	}
/* L180: */
    }
/*     UPDATE THE  TQ  FACTORS OF THE MATRIX OF CONSTRAINTS IN THE */
/*     WORKING SET.  USE THE ARRAY  P  AS WORK SPACE. */
L200:
    added = TRUE_;
    ndel = 0;
    *inform = daddcon(modfyg, 0, orthog, unitq, &ifix, &iadd, &jadd, 
	    nactiv, &ncolz, &ncolz, nfree, n, &nq, nrowa, &nrowrt, &
	    kfree[1], &condmx, &cslast, &snlast, &a[a_offset], pQTG,
	    pRT, pZY, pWRK, pPX);
    --ncolz;
    nfixed = n - *nfree;
    if (nfixed == 0) {
	goto L240;
    }
    kb = *nactiv + nfixed;
    i__1 = nfixed;
    for (idummy = 1; idummy <= i__1; ++idummy) {
	kactiv[kb + 1] = kactiv[kb];
	--kb;
/* L220: */
    }
L240:
	if (jadd <=  (integer)n){
		/*
		ADD A BOUND.  IF STABILIZED ELIMINATIONS ARE BEING USED TO UPDATE 
		THE  TQ  FACTORIZATION,  RECOMPUTE THE COMPONENT OF THE GRADIENT
		CORRESPONDING TO THE NEWLY FIXED VARIABLE
		*/
		--(*nfree);
		kactiv[*nactiv + 1] = jadd;
		if(!orthog) {
			if (*numinf > 0) pQTG[*nfree] = wgfix;
			else if (lp) pQTG[*nfree] = cvec[jadd];
			}
		}
	else	{
		/*ADD A GENERAL LINEAR CONSTRAINT*/
		++(*nactiv);
		kactiv[*nactiv] = iadd;
		}
	goto L20;
/* .........................END OF MAIN LOOP............................ 
*/
/*     NO CONSTRAINTS TO DROP. */
L280:
    if (*numinf > 0) {
	goto L340;
    }
    goto L320;
/*     ERROR IN  BNDALF  --  PROBABLY UNBOUNDED LP. */
L300:
    if (*numinf == 0) {
	goto L360;
    }
    goto L340;
/*     FEASIBLE SOLUTION FOUND, OR OPTIMAL LP SOLUTION. */
L320:
    *inform = 0;
    goto L420;
/*     THE LINEAR CONSTRAINTS AND BOUNDS APPEAR TO BE INFEASIBLE. */
L340:
    *inform = 1;
    goto L420;
/*     UNBOUNDED LP. */
L360:
    *inform = 2;
    goto L420;
/*     TOO MANY ITERATIONS WITHOUT CHANGING  X. */
L380:
    *inform = 3;
    goto L420;
/*     TOO MANY ITERATIONS. */
L400:
    *inform = 4;
/* --------------------------------------------------------------------- 
*/
/*     PRINT FULL SOLUTION.  IF NECESSARY, RECOMPUTE THE MULTIPLIERS. */
/* --------------------------------------------------------------------- 
*/
L420:
    msg = msglvl;
    if (msg >= 1) {
	wrexit((char*)"LP", *inform, *iter);
    }
    if (*inform > 0) dgetlamd(lprob, n, *nactiv, ncolz, *nfree, *nrowa,
		nrowrt, &jsmlst, &ksmlst, &smllst, &istate[1], &
		kactiv[1], &a[a_offset], pANORM, pQTG, pRLAM,
		pRT);
    if(!lp && *inform == 0) dzerovec(n, pRLAM);
    dprtsol(*nfree, *nrowa, n, *nclin, ncnln, *nctotl, bigbnd,
	    *nactiv, &istate[1], &kactiv[1], &a[a_offset],
	    &bl[1], &bu[1], &x[1], &clamda[1], pRLAM, &x[1]);
}
