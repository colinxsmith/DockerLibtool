/*
	y = alpha*x for vector x and y
*/
#include "ldefns.h"

void dsccopyvec(dimen n, real alpha, vector x, vector y)
{
	dsccopy(n, alpha, x, 1, y, 1);
}
