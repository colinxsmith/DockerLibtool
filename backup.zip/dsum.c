/*
	return sum of general vector elements
	RGB
*/
#include "ldefns.h"
real dsum(dimen n, vector x, increment incx)
{
	register real	sum = 0;
	while(n--){
		sum += *x;
		x += incx;
		}
	return	sum;
}
