/*
	disamax( dimen n, vector v, stride iv, dimen * i)

		returns the maximum absolute value of vector, v
		using n elements with increment iv.
		the sequence number of the winner is stored in
		*i unless i is NULL
*/
#include "ldefns.h"
real disamax(dimen n, vector v, stride iv, dimen *i)
{
	real	temp;
	undex	j;
	undex	imax = 0;
	real	amax = 0.0;

	if(iv==1) return disamaxvec(n,v,i);
	else if( iv<0 ) v += iv*(1-n);

	for(j=0;j<n;j++, v += iv)
		if( (temp=fabs(CD(*v))) > amax ){
			imax = j;
			amax = temp;
			}
	if(i) *i = imax;
	return amax;
}
