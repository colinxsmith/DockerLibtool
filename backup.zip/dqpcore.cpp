#include "baseoptimise.h"
/*
	dqpcore, a subroutine for indefinite quadratic programming.
	it is assumed that a previous call to either  dlpcore  or  dqpcore

	has defined an initial working set of linear constraints and
	bounds. istate, kactiv	and  kfree  will have been set
	accordingly, and the arrays  rt	 and  zy  will contain the TQ
	factorization of the matrix whose rows are the gradients of the
	active linear constraints with the columns corresponding to the
	active bounds removed.	the TQ factorization of the resulting
	(nactiv by nfree) matrix is  a(free)*q = (0 t),	 where	q  is
	(nfree by nfree) and  t	 is reverse-triangular.
	values of istate(j) for the linear constraints.......

	istate(j)
	---------
	0		constraint	j	is not in the working set
	1		constraint	j	is in the working set at its lower bound
	2		constraint	j	is in the working set at its upper bound
	3		constraint	j	is in the working set as an equality
	4		variable	j	is temporarily fixed at the value x(j)
						the corresponding artificial bound is included in the
						working set (the  TQ  factorization is adjusted accordingly)

	constraint  j  may be violated by as much as  featol(j)
*/
void Base_Optimise::dqpcore(int orthog, logical *unitq, integer *inform, integer *iter, integer *itmax, dimen n, integer *nclin, integer *nctotl, integer *nrowa, integer *nrowh, integer *ncolh, integer *nactiv, integer *nfree, short_vec istate, short_vec kactiv, short_vec kfree, real *objqp, real *xnorm, real *a, real *ax, real *bl, real *bu, real *clamda, real *cvec, real *featol, real *hess, real *scale, real *x, short_vec iw, real *w)
{

#ifdef	__SYSNT1__
	MSG	message;
#endif
	static char *lprob =(char*)"QP";
	static integer mstall = 2000;

	dimen	i;

	integer iadd, jadd;
	real	alfa;
	integer jdel, kdel;
	real	emax;
	integer ifix;
	real	palfa;
	int ifail;
	real condh, bigdx;
	integer isdel=0;
	real condt, drmin, anorm, dinky, drmax, hsize;
	integer ncnln, ncolr, ncolz;
	real pnorm;
	integer nrowj;
	integer nhess;
	logical nullr, stall, uncon;
	integer nclin0, kb;
	real bigalf, bigbnd, epspt9;
	real gfixed, alfhit;
	logical refine;
	integer jdsave, nfixed;
	logical posdef;
	int	modfyg, negligible;
	real condmx, atphit, cslast, gfnorm, rdlast, objsiz, snlast;
	integer idummy, issave=0, msglvl;
	dimen	jsmlst, ksmlst;
	real smllst;
	integer nstall, numinf;
	real ztgnrm;
	int	firstv, hitlow;
	logical nocurv, renewr, unitpg, zerolm;
	int	modfyr;
	real bnd;
	real gtp=0;
	--w;
	--iw;
	--x;
	--scale;
	--featol;
	--cvec;
	--clamda;
	--bu;
	--bl;
	--ax;
	--kfree;
	--kactiv;
	--istate;

	/*INITIALIZE */
	*iter = 0;
	jadd = 0;
	jdel = 0;
	jdsave = 0;
	nclin0 = max(*nclin,1);
	ncnln = 0;
	ncolz = *nfree - *nactiv;
	nrowj = 1;
	nstall = 0;
	nhess = 0;
	numinf = 0;
	msglvl = msg;
	msg = 0;
	if (istart == 0) msg = msglvl;
	bigbnd = parm[0];
	bigdx = parm[1];
	epspt9 = parm[3];
	alfa = 0;
	condmx = lm_max;
	drmax = 1;
	drmin = 1;
	emax = 0;
	hsize = 1;
	firstv = 0;
	modfyr = 1;
	modfyg = 1;
	nocurv = 0;
	nullr = 0;
	posdef = 1;
	refine = 0;
	stall = 1;
	uncon = 0;
	unitpg = 0;
	zerolm = 0;

	/*
	given the  TQ  factorization of the matrix of constraints in the
	working set, compute the following quantities....
	(1)	the cholesky factor  r,	 of  z(t)hz  (if  z(t)hz  is not
		positive definite, find a positive-definite  (ncolr)-th	 order
		principal submatrix of	z(t)h z,
	(2)	the  qp	 objective function,
	(3)	the vector  q(free)(t)g(free),
	(4)	the vector  g(fixed).
		use the array  rlam  as temporary work space.
	*/
	dimen nhess_conv=nhess;
	ncolr = dqpcrsh(*unitq, n, ncolz, *nfree, &nhess_conv,
		nq, *nrowh, *ncolh, nrowrt, &kfree[1], &hsize, hess,
		pRT, &scale[1], pZY, pRLAM, pWRK);
	dqpgrad(1, CB(*unitq), n, CN(*nactiv), CN(*nfree), &nhess_conv, nq,
		CN(*nrowh), CN(*ncolh), jadd, &kactiv[1], &kfree[1], alfa, objqp, &gfixed,
		gtp, &cvec[1], hess, pPX, pQTG, &scale[1], &x[1], pZY, pWRK, pRLAM);
	nhess=nhess_conv;

	/*
	during the main loop, one of three things will happen
		(i)	the convergence criterion will be satisfied and the
			algorithm will terminate.
		(ii)	a linear constraint will be deleted.
		(iii)	a direction of search will be computed and a constraint may
			be added to the working set (note that a zero step may be taken
			along the search direction).

	these computations occur in sections i, ii, and iii of the main loop
	*/
	while(1){
		clocker();
#ifdef	__SYSNT1__
	if(PeekMessage(&message,NULL,0,0,PM_REMOVE))
	{
		lm_fflushall();
		switch(message.message)
		{
/*		case WM_NULL:
		case 4167:message when using COM and close
			lm_wmsg((char*)"qp message %d %d %d %d",message.message,WM_LBUTTONUP,WM_KEYDOWN,WM_LBUTTONDOWN);
			exit(14);*/
		case WM_LBUTTONUP:
		case WM_RBUTTONUP:
		case WM_LBUTTONDOWN:
		case WM_RBUTTONDOWN:
		case WM_KEYDOWN:
			break;
		default:
			TranslateMessage(&message);
			DispatchMessage(&message);
		}
	}
#endif
		/*
		******* section i.  test for convergence *******
		compute the norms of the projected gradient and the gradient with
		respect to the free variables.
		*/
		ztgnrm = 0;
		if (ncolr > 0) ztgnrm = dnrm2vec(ncolr, pQTG);
		gfnorm = ztgnrm;
		if (*nfree > 0 && *nactiv > 0) gfnorm = dnrm2vec(*nfree, pQTG);

		/*
		define small quantities that reflect the magnitude of  c,  x,  h
		and the matrix of constraints in the working set
		*/
		objsiz = (lm_eps + fabs(*objqp)) / (lm_eps + *xnorm);
		anorm = 0;
		if(*nactiv > 0) anorm = fabs(dtmax);
		/*Computing MAX */
		dinky = dmax(anorm,objsiz);
		dinky = dmax(epspt9, DAS_Sol_zgfacc) * dmax(dinky,gfnorm);
#ifdef _DEBUG_OPT
		AddLog((char*)"%d objsiz ztgnrm gfnorm dinky%-.10e %-.10e %-.10e %-.10e\n",
			*iter,objsiz,ztgnrm,gfnorm,dinky);
#endif
		if (msg >= 80) wdinky((char*)"QPCORE", ztgnrm, dinky);

		/*
		print the details of this iteration
		use the largest and smallest diagonals of r to estimate the
		condition number of the projected hessian matrix
		*/
		condt = dprotdiv(&dtmax, &dtmin, &ifail);
		if (ifail && dtmax == 0) condt = lm_max;
		if (ncolr > 0) dxminmax(ncolr, pRT, nrowrt+1, &drmax, &drmin);
		condh = dprotdiv(&drmax, &drmin, &ifail);
		if (ifail && drmax == 0) condh = lm_max;
		if (condh >= lm_rootmax) condh = lm_max;
		if (condh < lm_rootmax) condh *= condh;
		dqpprt(orthog, isdel, *iter, jadd, jdel, *nactiv, ncolz, *nfree,
			n, *nclin, *nrowa, *&nrowrt, nhess, &
			istate[1], &kfree[1], alfa, condh, condt, *objqp, gfnorm,
			ztgnrm, emax, a, pRT, &x[1], pWRK, pAP);
		jadd = 0;
		jdel = 0;
		negligible = ztgnrm<=dinky;
		if (posdef){
			if(negligible || (uncon && (ztgnrm <= sqrt(dinky) || refine))){
				/*
				the projected gradient is negligible and the projected hessian
				is positive definite.  if  r  is not complete it must be
				expanded.  otherwise, if the current point is not optimal,
				a constraint must be deleted from the working set
				*/
				unitpg = negligible;
				alfa = 0;
				uncon = 0;
				refine = 0;
				jdel = -(ncolr + 1);
				if (ncolr >= ncolz){
					dgetlamd(lprob, n, *nactiv, ncolz, *nfree, *nrowa, nrowrt,
						&jsmlst, &ksmlst, &smllst, &istate[1], &kactiv[1], a,
						pANORM, pQTG, pRLAM, pRT);

					/*
					test for convergence.  if the least (adjusted) multiplier is
					greater than the small positive quantity  dinky,  an adequate
					solution has been found
					*/
					if (smllst > dinky){
					//AddLog((char*)"smllst %20.8e dinky %20.8e\n",smllst,dinky);
						/*OPTIMAL QP SOLUTION FOUND*/
						i = 0;
						break;
						}

					/*
					***** section ii.  delete a constraint from the working set *****
					delete the constraint with the least (adjusted) multiplier
					first check if there are any tiny multipliers
					*/
					if (smllst > -dinky) zerolm = 1;
					jdel = jsmlst;
					jdsave = jsmlst;
					kdel = ksmlst;
					isdel = istate[jdel];
					issave = isdel;
					istate[jdel] = 0;

					/*update the TQ factorization of the matrix of constraints in the working set*/

					ddelcon(modfyg, orthog, CB(*unitq), CN(jdel), CN(kdel),
						CN(*nactiv), CN(ncolz), CN(*nfree), n,
						CN(nq), CN(*nrowa), CN(nrowrt), &kactiv[1], &kfree[1], a,
						pQTG, pRT, pZY);
					++ncolz;
					if(jdel <= (integer)n) ++(*nfree);
					else --(*nactiv);
					}

				/*
				the projected hessian is expanded by a row and column. compute
				the elements of the new column of the cholesky factor r
				use the vector p as temporary work space
				*/
				renewr = 1;
				++ncolr;
				dqpcolr(&nocurv, &posdef, &renewr, unitq, n, &ncolr,
					nfree, &nq, nrowh, ncolh, &nrowrt, &nhess, &kfree[1], &
					cslast, &snlast, &drmax, &emax, &hsize, &rdlast, hess,
					pRT, &scale[1], pZY, pPX, pWRK);
				/*REPEAT THE MAIN LOOP*/
				continue;
				}
			else	if((refine=uncon)) unitpg = 0;
			}
		/*
		******* section iii.  compute the search direction *******
		first, check for a weak local minimum. exit if the norm of the
		projected gradient is small and the curvature along p is not
		significant.  also, check for too many iterations and update the
		iteration count.  the iteration counter is only updated when a
		search direction is computed
		*/
		if(( negligible && ncolr == ncolz && nocurv) || (zerolm && nocurv)){
		AddLog((char*)"%d\tobjsiz ztgnrm gfnorm dinky%-.10e %-.10e %-.10e %-.10e\n",
			*iter,objsiz,ztgnrm,gfnorm,dinky);
		AddLog((char*)"\tnocurv %ld\n",nocurv);
			/*WEAK LOCAL MINIMUM*/
			i = 1;
			break;
			}
		if(*iter >= *itmax){
			/*too many iterations*/
			i = 5;
			break;
			}

		++(*iter);
		if(*iter >= istart) msg = msglvl;
//		printf("iter %d objective %20.16e\n", *iter, *objqp);
		dfindp(&nullr, &unitpg, unitq, n, nclin, &nq, nrowa, &
			nrowrt, &ncolr, &ncolz, nfree, &istate[1], &kfree[1],
			negligible, &gtp, &pnorm, &rdlast, a, pAP,
			pPX, pQTG, pRT, pWRK, pZY, pWRK);

		/*
		if a constraint has just been deleted and the projected gradient
		is small (this can only occur here when the projected hessian is
		indefinite), the sign of  p  may be incorrect because of rounding
		errors in the computation of  ztg.  fix the sign of  p	by
		forcing it to satisfy the constraint that was just deleted
		*/
		if((jdsave > 0 && negligible) || zerolm) dqpchkp(n, CN(*nclin), issave, jdsave, pAP, pPX);

		/*
		find the constraint we bump into along p
		update x and a*x if the step alfa is nonzero
		alfhit	is initialized to  bigalf.  if it remains that way after
		the call to bndalf, it will be regarded as infinite
		*/
		bigalf = dprotdiv(&bigdx, &pnorm, &ifail);
		if (ifail && bigdx == 0) bigalf = lm_max;
		dbndalf(firstv, &hitlow, &istate[1], &jadd, n,
			CN(*nctotl), numinf, &alfhit, &palfa, &atphit, &bigalf, &
			bigbnd, &pnorm, pANORM, pAP, &ax[1], &bl[1], &bu[1], &
			featol[1], pPX, &x[1]);

		/*
		if the projected hessian is positive definite, the step
		alfa = 1.0 will be the step to the minimum of the quadratic
		function on the current subspace
		*/
		alfa = 1;

		/*
		if the step to the minimum on the subspace is less than the
		distance to the nearest constraint,  the constraint is not added
		to the working set
		*/
		uncon = palfa > 1 && posdef;
		if (uncon) jadd = 0;
		else alfa = alfhit;
		/*check for an unbounded solution*/
		if(alfa >= bigalf){
			/*unbounded QP*/
			i = 2;
			break;
			}
		/*test if the change in	 x  is negligible*/
		stall = fabs(alfa * pnorm) <= epspt9 * *xnorm;
		if(stall){
			/*
			take a zero step
			exit if more than  50  iterations occur without changing  x
			if such an exit is made when there are some near-zero
			multipliers, the user should call a separate routine that
			checks the solution
			*/
			alfa = 0;
			++nstall;
			if (nstall > mstall){
				/*too many iterations without changing x*/
				i = zerolm ? 3 : 4;
				break;
				}
			}
		else	{
			/*
			compute the new value of the qp objective function.  if its
			value has not increased,  update  objqp,  q(free)(t)g(free)  and
			g(fixed). an increase in the objective can occur only after a
			move along a direction of negative curvature from a point with
			tiny multipliers. use the array	 rlam  as temporary storage
			*/
			if(dqpgrad(2, CB(*unitq), n, CN(*nactiv), CN(*nfree), &nhess_conv, nq,
				CN(*nrowh), CN(*ncolh), jadd, &kactiv[1], &kfree[1], alfa, objqp, &
				gfixed, gtp, &cvec[1], hess, pPX, pQTG, &
				scale[1], &x[1], pZY, pWRK, pRLAM)<-lm_eps){nhess=nhess_conv;
					/*weak local minimum*/
			AddLog((char*)"PLACE 2\n");
					i = 1;
					break;
					}
			nhess=nhess_conv;
			/*
			change	x  to  x + alfa*p.  update  ax	also
			we no longer need to remember jdsave, the last constraint deleted
			*/
			nstall = 0;
			jdsave = 0;
			zerolm = 0;
			BITA_daxpy(n, alfa, pPX, 1, &x[1], 1);
			if(*nclin > 0) BITA_daxpy(*nclin, alfa, pAP, 1, &ax[1], 1);
			*xnorm = dnrm2vec(n, &x[1]);
			}

		/*if an unconstrained step was taken, repeat the main loop*/
		if (uncon) continue;

		/*add a constraint to the working set. update  istate*/
		if(hitlow) istate[jadd] = 1;
		else istate[jadd] = 2;
		if(bl[jadd] == bu[jadd]) istate[jadd] = 3;

		/*
		if a bound is to be added, move x exactly onto it, except when
		a negative step was taken.  (bndalf  may have had to move to some
		other closer constraint.)
		*/
		iadd = jadd - n;
		if (jadd <= (integer)n){
			if (hitlow) bnd = bl[jadd];
			else bnd = bu[jadd];
			if (alfa >= 0) x[jadd] = bnd;
			i = *nfree;
			for (ifix = 1; ifix <= (integer)i; ++ifix) if (kfree[ifix] == jadd) break;
			}
		/*
		update the TQ factors of the matrix of constraints in the
		working set.  use the array  p	as temporary work space
		*/
		daddcon(modfyg, modfyr, orthog, unitq, &ifix, &iadd, &jadd,
			nactiv, &ncolr, &ncolz, nfree, n, &nq, nrowa, &nrowrt,
			&kfree[1], &condmx, &cslast, &snlast, a, pQTG,
			pRT, pZY, pWRK, pPX);
		--ncolr;
		--ncolz;
		nfixed = n - *nfree;
		if (nfixed != 0){
			kb = *nactiv + nfixed;
			i = nfixed;
			for(idummy = 1; idummy <= nfixed; ++idummy) {
				kactiv[kb + 1] = kactiv[kb];
				--kb;
				}
			}
		if (jadd <= (integer)n){
			/*
			add a bound.  if stabilized eliminations are being used to update
			the  TQ	 factorization,	 recompute the component of the gradient
			corresponding to the newly fixed variable
			use the array  p  as temporary work space
			*/
			--(*nfree);
			kactiv[*nactiv + 1] = jadd;
			dimen nhess_conv=nhess;
			if (!orthog)
			{
				dqpgrad(3, CB(*unitq), n, CN(*nactiv), CN(*nfree), &nhess_conv, nq,
					CN(*nrowh), CN(*ncolh), jadd, &kactiv[1], &kfree[1], alfa, objqp,
					&pQTG[*nfree], gtp, &cvec[1], hess, pPX, pQTG, &
					scale[1], &x[1], pZY, pWRK, pPX);
				nhess=nhess_conv;
			}
			}
		else	{
			/*add a general linear constraint*/
			++(*nactiv);
			kactiv[*nactiv] = iadd;
			}

		/*
		repeat the main loop if the projected hessian that was used to
		compute this search direction was positive definite
		*/
		if (ncolr == 0) posdef = 1;
		if(ncolr == 0) emax = 0;

		if (!posdef)
			/*
			the projected hessian was not sufficiently positive definite
			before the constraint was added.  either compute the true value
			of the last diagonal of	 r  or	recompute the whole of its last
			column. use the array  rlam  as temporary work space
			*/
			dqpcolr(&nocurv, &posdef, &renewr, unitq, n, &ncolr,
				nfree, &nq, nrowh, ncolh, &nrowrt, &nhess, &
				kfree[1], &cslast, &snlast, &drmax, &emax, &hsize, &rdlast,
				hess, pRT, &scale[1], pZY, pRLAM,
				pWRK);
		/*.........................END OF MAIN LOOP............................*/
		}


	*inform = i;
	/*PRINT FULL SOLUTION*/
	msg = msglvl;
	if(msg >= 1) wrexit(lprob, i, *iter);
	if(i > 0) dgetlamd(lprob, n, *nactiv, ncolz, *nfree, *nrowa,
			nrowrt, &jsmlst, &ksmlst, &smllst, &istate[1], &
			kactiv[1], a, pANORM, pQTG, pRLAM, pRT);
	dprtsol(*nfree, *nrowa, n, *nclin, ncnln, *nctotl, bigbnd,
		*nactiv, &istate[1], &kactiv[1], a,
		&bl[1], &bu[1], &x[1], &clamda[1], pRLAM, &x[1]);
}
