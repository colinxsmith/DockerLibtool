// Optimiser.h : Declaration of the COptimiser
#pragma once
#include "resource.h"       // main symbols
#include <atlctl.h>
#include "safeqp.h"

#if defined(_WIN32_WCE) && !defined(_CE_DCOM) && !defined(_CE_ALLOW_SINGLE_THREADED_OBJECTS_IN_MTA)
#error "Single-threaded COM objects are not properly supported on Windows CE platform, such as the Windows Mobile platforms that do not include full DCOM support. Define _CE_ALLOW_SINGLE_THREADED_OBJECTS_IN_MTA to force ATL to support creating single-thread COM object's and allow use of it's single-threaded COM object implementations. The threading model in your rgs file was set to 'Free' as that is the only threading model supported in non DCOM Windows CE platforms."
#endif


// COptimiser
class ATL_NO_VTABLE COptimiser :
	public CComObjectRootEx<CComSingleThreadModel>,
	public IDispatchImpl<IOptimiser, &IID_IOptimiser, &LIBID_safeqpLib, /*wMajor =*/ 1, /*wMinor =*/ 0>,
	public IPersistStreamInitImpl<COptimiser>,
	public IOleControlImpl<COptimiser>,
	public IOleObjectImpl<COptimiser>,
	public IOleInPlaceActiveObjectImpl<COptimiser>,
	public IViewObjectExImpl<COptimiser>,
	public IOleInPlaceObjectWindowlessImpl<COptimiser>,
	public ISupportErrorInfo,
	public IPersistStorageImpl<COptimiser>,
	public ISpecifyPropertyPagesImpl<COptimiser>,
	public IQuickActivateImpl<COptimiser>,
#ifndef _WIN32_WCE
	public IDataObjectImpl<COptimiser>,
#endif
	public IProvideClassInfo2Impl<&CLSID_Optimiser, NULL, &LIBID_safeqpLib>,
#ifdef _WIN32_WCE // IObjectSafety is required on Windows CE for the control to be loaded correctly
	public IObjectSafetyImpl<COptimiser, INTERFACESAFE_FOR_UNTRUSTED_CALLER>,
#endif
	public CComCoClass<COptimiser, &CLSID_Optimiser>,
	public CComControl<COptimiser>
{
public:


	COptimiser()
	{
	}

DECLARE_OLEMISC_STATUS(OLEMISC_RECOMPOSEONRESIZE |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_INSIDEOUT |
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST
)

DECLARE_REGISTRY_RESOURCEID(IDR_OPTIMISER)


BEGIN_COM_MAP(COptimiser)
	COM_INTERFACE_ENTRY(IOptimiser)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IViewObjectEx)
	COM_INTERFACE_ENTRY(IViewObject2)
	COM_INTERFACE_ENTRY(IViewObject)
	COM_INTERFACE_ENTRY(IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceObject)
	COM_INTERFACE_ENTRY2(IOleWindow, IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceActiveObject)
	COM_INTERFACE_ENTRY(IOleControl)
	COM_INTERFACE_ENTRY(IOleObject)
	COM_INTERFACE_ENTRY(IPersistStreamInit)
	COM_INTERFACE_ENTRY2(IPersist, IPersistStreamInit)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(ISpecifyPropertyPages)
	COM_INTERFACE_ENTRY(IQuickActivate)
	COM_INTERFACE_ENTRY(IPersistStorage)
#ifndef _WIN32_WCE
	COM_INTERFACE_ENTRY(IDataObject)
#endif
	COM_INTERFACE_ENTRY(IProvideClassInfo)
	COM_INTERFACE_ENTRY(IProvideClassInfo2)
#ifdef _WIN32_WCE // IObjectSafety is required on Windows CE for the control to be loaded correctly
	COM_INTERFACE_ENTRY_IID(IID_IObjectSafety, IObjectSafety)
#endif
END_COM_MAP()

BEGIN_PROP_MAP(COptimiser)
	PROP_DATA_ENTRY("_cx", m_sizeExtent.cx, VT_UI4)
	PROP_DATA_ENTRY("_cy", m_sizeExtent.cy, VT_UI4)
	// Example entries
	// PROP_ENTRY("Property Description", dispid, clsid)
	// PROP_PAGE(CLSID_StockColorPage)
END_PROP_MAP()


BEGIN_MSG_MAP(COptimiser)
	CHAIN_MSG_MAP(CComControl<COptimiser>)
	DEFAULT_REFLECTION_HANDLER()
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid)
	{
		static const IID* arr[] =
		{
			&IID_IOptimiser,
		};

		for (int i=0; i<sizeof(arr)/sizeof(arr[0]); i++)
		{
			if (InlineIsEqualGUID(*arr[i], riid))
				return S_OK;
		}
		return S_FALSE;
	}

// IViewObjectEx
	DECLARE_VIEW_STATUS(VIEWSTATUS_SOLIDBKGND | VIEWSTATUS_OPAQUE)

// IOptimiser
public:
	HRESULT __stdcall Version(BSTR* retval);
	HRESULT __stdcall FactorModelProcess(int n,int nfac,VARIANT FL,VARIANT FC,
									 VARIANT SV,VARIANT* Q);
	HRESULT __stdcall OptimiseInternalCVP(int n,int nfac,VARIANT names,
		VARIANT *w_opt,int m,VARIANT A,VARIANT L,VARIANT U,VARIANT alpha,
		VARIANT benchmark,VARIANT Q,double gamma,VARIANT initial,double delta,
		VARIANT buy,VARIANT sell,double kappa,int basket,int trades,int revise,
		int costs,double min_holding,double min_trade,int m_LS,int Fully_Invested,
		double Rmin,double Rmax,int m_Round,VARIANT min_lot,VARIANT size_lot,
		VARIANT *shake,int ncomp,VARIANT Composites,double LSValue,int npiece,
		VARIANT hpiece,VARIANT pgrad,int* retval);
		HRESULT __stdcall GetBetaVector(int n,long nfac,VARIANT benchmark,
		VARIANT Q,VARIANT *beta,int ncomp,VARIANT Composite);
		HRESULT __stdcall SimpOpt(int n,VARIANT start,VARIANT *xmin,
		VARIANT *ynewlo,double reqmin,VARIANT step,int konvge,int kcount,
		VARIANT *icount,VARIANT *numres,VARIANT *ifault,int function);
	HRESULT __stdcall NaiveRounding(int n,VARIANT w,VARIANT initial,
		VARIANT minlot,VARIANT sizelot,VARIANT *roundw);
	HRESULT __stdcall Solve1DFunction(int function,double gammabot,
		double gammatop,double tol,double *retval);
	HRESULT __stdcall PathMinimise(int function,double gammabot,
		double gammatop,double tol,int stopifpos,double *retval);
	HRESULT __stdcall ExtractFactorInformation(int nstocks,int numfac,int Mnstocks,
		VARIANT *FL,VARIANT *SV,VARIANT stocklist,VARIANT MFL,VARIANT MSV,VARIANT Mstocklist);
	HRESULT __stdcall ExpireDate(BSTR* retval);
	HRESULT __stdcall DaysLeft(BSTR* cvers,int* retval);
	HRESULT __stdcall FixCovariancem(int n,VARIANT *Q,int *retval);
	HRESULT __stdcall InverseQtimesD(int n,VARIANT Q,VARIANT d,
											VARIANT *Qm1d,int *retval);
	HRESULT __stdcall ConstrainedRegression(int n,int m,VARIANT Q,VARIANT c,
												   VARIANT *w,VARIANT L,VARIANT U,
												   VARIANT A,int *retval);
	HRESULT __stdcall PickoutCovFromCov(int nstocks,BSTR stocklist,int Mnstocks,
											   BSTR M_stocklist,VARIANT *Q,int *retval);
	HRESULT __stdcall ReturnMessage(int ifail,BSTR* retval);
	HRESULT __stdcall GetRisks(int n,int nfac,VARIANT Q,VARIANT w,VARIANT benchmark,
									  VARIANT *arisk,VARIANT *risk,VARIANT *Rrisk,VARIANT *brisk,
									  VARIANT *pbeta,int ncomp,VARIANT Composite);
	HRESULT __stdcall MarginalUtilityandCost(int n,int nfac,VARIANT Names,VARIANT w,
											 VARIANT benchmark,VARIANT initial,
											 VARIANT Q,double gamma,double kappa,int npiece,
											 VARIANT hpiece,VARIANT pgrad,VARIANT buy,
											 VARIANT sell,VARIANT alpha,VARIANT *tcost,
											 VARIANT *utility,VARIANT *gradutility,
											 VARIANT *utility_per_stock,
											 VARIANT *cost_per_stock,int ncomp,
											 VARIANT Composite);
	HRESULT __stdcall OptimiseInternalCVPA(int n,int nfac,VARIANT Names,VARIANT *w,int m,
												  VARIANT A,VARIANT L,VARIANT U,VARIANT alpha,
												  VARIANT benchmark,VARIANT Q,double gamma,
												  VARIANT initial,double delta,VARIANT buy,
												  VARIANT sell,double kappa,int basket,
												  int trades,int revise,int costs,
												  double min_holding,double min_trade,
												  int m_LS,int Fully_Invested,double Rmin,
												  double Rmax,int m_Round,VARIANT min_lot,
												  VARIANT size_lot,VARIANT *shake,int ncomp,
												  VARIANT Composite,double LSValue,int npiece,
												  VARIANT hpiece,VARIANT pgrad,int nabs,
												  VARIANT Abs_A,int mabs,VARIANT I_A,
												  VARIANT Abs_U,VARIANT mask,int log,
												  BSTR Logfile,int *retval);
	HRESULT __stdcall OptimiseInternalCVPAF(int n,int nfac,VARIANT Names,VARIANT *w,
												   int m,VARIANT A,VARIANT L,VARIANT U,
												   VARIANT alpha,VARIANT benchmark,
												   VARIANT Q,double gamma,VARIANT initial,
												   double delta,VARIANT buy,VARIANT sell,
												   double kappa,int basket,int trades,
												   int revise,int costs,double min_holding,
												   double min_trade,int m_LS,
												   int Fully_Invested,double Rmin,double Rmax,
												   int m_Round,VARIANT min_lot,
												   VARIANT size_lot,VARIANT *shake,int ncomp,
												   VARIANT Composite,double LSValue,
												   int npiece,VARIANT hpiece,VARIANT pgrad,
												   int nabs,VARIANT Abs_A,int mabs,
												   VARIANT I_A,VARIANT Abs_U,VARIANT FC,
												   VARIANT FL,VARIANT SV,double minRisk,
												   double maxRisk,VARIANT *ogamma,VARIANT mask,
												   int log,BSTR Logfile,int downrisk,
												   double downfactor,int *retval);
	HRESULT __stdcall Properties(int n,int nfac,VARIANT Names,VARIANT w,
										  VARIANT benchmark,VARIANT alpha,VARIANT *rreturn,
										  VARIANT *areturn,VARIANT *Rreturn,VARIANT *breturn,
										  VARIANT Q,VARIANT *risk,VARIANT *arisk,
										  VARIANT *Rrisk,VARIANT *brisk,VARIANT *srisk,
										  VARIANT *pbeta,VARIANT *MCAR,VARIANT *MCTR,
										  VARIANT *MCRR,VARIANT *MCBR,VARIANT *FMCRR,
										  VARIANT *FMCTR,VARIANT *FMCAR,VARIANT *FMCBR,
										  VARIANT *FMCSR,VARIANT *beta,VARIANT *FX,
										  VARIANT *RFX,VARIANT *AFX,VARIANT *BFX,VARIANT *SFX,
										  VARIANT  FL,VARIANT FC,VARIANT SV,int ncomp,
										  VARIANT Composite);
	HRESULT __stdcall OptimiseInternalCVPAextcosts(int n,int nfac,VARIANT Names,
														  VARIANT *w,int m,VARIANT A,
														  VARIANT L,VARIANT U,VARIANT alpha,
														  VARIANT benchmark,VARIANT Q,
														  double gamma,VARIANT initial,
														  double delta,double kappa,
														  int basket,int trades,
														  int revise,double min_holding,
														  double min_trade,int m_LS,
														  int Fully_Invested,double Rmin,
														  double Rmax,int m_Round,
														  VARIANT min_lot,VARIANT size_lot,
														  VARIANT *shake,int ncomp,
														  VARIANT Composite,double LSValue,
														  int nabs,VARIANT Abs_A,int mabs,
														  VARIANT I_A,VARIANT Abs_U,
														  VARIANT FC,VARIANT FL,VARIANT SV,
														  int Util,int ModDeriv,
														  int ModHessian,double minRisk,
														  double maxRisk,VARIANT *ogamma,
														  int take_out_costs,VARIANT mask,
														  int log,BSTR Logfile,
														  int DoExtraIterations,int downrisk,
														  double downfactor,int *retval);
	HRESULT __stdcall TestDeriv(int n,VARIANT x,VARIANT *c,int func);
	HRESULT __stdcall Frontier(int npoints,VARIANT *risk,VARIANT *arisk,
										   VARIANT *rreturn,VARIANT *areturn,int n,
										   int nfac,VARIANT Names,VARIANT *w,int m,
										   VARIANT A,VARIANT L,VARIANT U,VARIANT alpha,
										   VARIANT benchmark,VARIANT Q,VARIANT initial,
										   double delta,VARIANT buy,VARIANT sell,
										   double kappa,int basket,int trades,int revise,
										   int costs,double min_holding,double min_trade,
										   int m_LS,int Fully_Invested,double Rmin,
										   double Rmax,int m_Round,VARIANT min_lot,
										   VARIANT size_lot,VARIANT *shake,int ncomp,
										   VARIANT Comp,double LSValue,int npiece,
										   VARIANT hpiece,VARIANT pgrad,int nabs,
										   VARIANT Abs_A,int mabs,VARIANT I_A,VARIANT Abs_U,
										   VARIANT FC,VARIANT FL,VARIANT SV,VARIANT mask,
										   int DoByRisks,int *retval);
	HRESULT __stdcall MultiStage(int n,int y,VARIANT *w,VARIANT *before,
										VARIANT *rebalanced,VARIANT *risks,VARIANT Growth,
										VARIANT Yield,VARIANT Liability,VARIANT lbound,
										VARIANT ubound,VARIANT Names,VARIANT Q,VARIANT first,
										double delta,double maxrisk,VARIANT NumberYears,
										int meth,int print,int *retval);
	HRESULT __stdcall MultistageMessage(int ifail,BSTR* retval);
	HRESULT __stdcall EigenDecomp(int n,VARIANT *S,VARIANT *d,int itmax,int* retval);
	HRESULT __stdcall Get_nfac(BSTR name,int*retval);
	HRESULT __stdcall Getdata(int nstocks,int nfac,VARIANT namelist,VARIANT* FLOUT,VARIANT* SVOUT,VARIANT* FCOUT,BSTR name);
	HRESULT __stdcall Get_stocknames(VARIANT* sname,BSTR name);
	HRESULT __stdcall Get_nstocks(BSTR name,int* retval);
	HRESULT __stdcall Get_factornames(VARIANT* fname, BSTR name);
	HRESULT __stdcall SOCPinfeasHomog(int n,int m,VARIANT ncone,VARIANT c,
											 VARIANT A,VARIANT b,VARIANT *x,VARIANT *y,
											 VARIANT *s,VARIANT *tau,VARIANT *kappa,int*retval);
	HRESULT __stdcall SOCPRobustOpt(int n,int m,VARIANT *w,VARIANT A,VARIANT L,VARIANT U,
										int nf,VARIANT SV,VARIANT FL,VARIANT FC,VARIANT alpha,
										VARIANT meanFE,VARIANT covFE,double maxmeanFE,
										double maxstderrorFE,double gamma,double maxRisk,
										VARIANT bench,VARIANT initial,int mFE,int rFE,int*retval);
	HRESULT __stdcall RootQget(int n,VARIANT Q,VARIANT *RQ,VARIANT *RQm1);
HRESULT __stdcall SOCPlsRobustOpt(int n,int m,VARIANT* w,VARIANT A,int nf,
											 VARIANT SV,VARIANT FL,VARIANT FC,VARIANT alpha,
											 int full,double rmin,double rmax,VARIANT L,
											 VARIANT U,double val,double TopRisk,VARIANT dalpha,
											 double MaxDalpha,VARIANT covalpha,double MaxValpha,
											 int nabs,VARIANT Aabs,VARIANT Uabs,VARIANT bench,
											 VARIANT initialm,VARIANT initials,int signtest,int fast,
											 int*retval);
HRESULT __stdcall SOCPlsRobustOptl(int n,int m,VARIANT* w,VARIANT A,int nf,
											 VARIANT SV,VARIANT FL,VARIANT FC,VARIANT alpha,
											 int full,double rmin,double rmax,VARIANT L,
											 VARIANT U,double val,double TopRisk,VARIANT dalpha,
											 double MaxDalpha,VARIANT covalpha,double MaxValpha,
											 int nabs,VARIANT Aabs,VARIANT Labs,VARIANT Uabs,VARIANT bench,
											 VARIANT initialm,VARIANT initials,int signtest,int fast,int maxrobust,BSTR dump,
											 int*retval);
HRESULT __stdcall Omegaopt(int n,int tlen,VARIANT DATA,VARIANT Names,
						   VARIANT* weights,double C,double R,
						   double Low,VARIANT* Gain,VARIANT* Loss,int log,int*retval);
HRESULT __stdcall OmegaGen(int n,int tlen,int m,VARIANT DATA,
									  VARIANT Names,VARIANT *w,double C,
									  double R,VARIANT L,VARIANT U,VARIANT A,
									  VARIANT *Top,VARIANT *Bot,VARIANT *Prob,
									  int log,int useSV,BSTR outfile,double gpower,double lpower,
									  int *retval);
HRESULT __stdcall OmegaProperties(int n,int tlen,VARIANT DATA,VARIANT w,
								  double R,VARIANT *Prob,VARIANT *Gain,
								  VARIANT *Loss,VARIANT *gains,VARIANT *losses,VARIANT *igains,VARIANT *ilosses);
HRESULT __stdcall SOCPMessage(int ifail,BSTR* retval);
HRESULT __stdcall OptimiseGeneralBAS(int n,VARIANT *w,int m,VARIANT A,VARIANT L,VARIANT U,VARIANT Util,VARIANT ModDeriv,VARIANT ModHessian,int *retval);
		HRESULT OnDraw(ATL_DRAWINFO& di)
		{
		RECT& rc = *(RECT*)di.prcBounds;
		// Set Clip region to the rectangle specified by di.prcBounds
		HRGN hRgnOld = NULL;
		if (GetClipRgn(di.hdcDraw, hRgnOld) != 1)
			hRgnOld = NULL;
		bool bSelectOldRgn = false;

		HRGN hRgnNew = CreateRectRgn(rc.left, rc.top, rc.right, rc.bottom);

		if (hRgnNew != NULL)
		{
			bSelectOldRgn = (SelectClipRgn(di.hdcDraw, hRgnNew) != ERROR);
		}

		Rectangle(di.hdcDraw, rc.left, rc.top, rc.right, rc.bottom);
		SetTextAlign(di.hdcDraw, TA_CENTER|TA_BASELINE);
		LPCTSTR pszText = _T("ATL 8.0 : Optimiser");
#ifndef _WIN32_WCE
		TextOut(di.hdcDraw,
			(rc.left + rc.right) / 2,
			(rc.top + rc.bottom) / 2,
			pszText,
			lstrlen(pszText));
#else
		ExtTextOut(di.hdcDraw,
			(rc.left + rc.right) / 2,
			(rc.top + rc.bottom) / 2,
			ETO_OPAQUE,
			NULL,
			pszText,
			ATL::lstrlen(pszText),
			NULL);
#endif

		if (bSelectOldRgn)
			SelectClipRgn(di.hdcDraw, hRgnOld);

		return S_OK;
	}


	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}

	void FinalRelease()
	{
	}
};

OBJECT_ENTRY_AUTO(__uuidof(Optimiser), COptimiser)
