/*
	DAXPYVEC performs the operation
	y := alpha*x + y for vectors x and y
*/
#include "ldefns.h"

void daxpyvec(dimen n, real alpha, vector x, vector y )
{
	if(alpha == 1)
		while(n--) *y++ += *x++;
	else if(alpha == -1)
		while(n--) *y++ -= *x++;
	else if(alpha != 0)
		while(n--) *y++ += *x++*alpha;
}
void saxpyvec(dimen n, float alpha, float* x, float* y )//single precision
{
	if(alpha == 1)
		while(n--) *y++ += *x++;
	else if(alpha == -1)
		while(n--) *y++ -= *x++;
	else if(alpha != 0)
		while(n--) 
		{
			*y++ += *x++*alpha;
		}
}
