public class compat
{
/*	static 
	{
		try
		{
			System.loadLibrary("safejava");
		}
		catch (UnsatisfiedLinkError e)
		{
			System.err.println("Native code library failed to load.\n" + e);
			System.exit(1);
		}
	}*/
	public static void main(String args[])
	{
		int n=10; 
		int nfac=-1; 
		int npoints=10;
		double[] frontarisk=new double[n*npoints];
		double[] frontareturn=new double[n*npoints];
		double[] frontrisk=new double[n*npoints];
		double[] frontrreturn=new double[n*npoints];
		String[] stocknames=new String[n]; 
		double[] w_opt=new double[npoints*n]; 
		double[] []FL=null; 
		double[] FC=null; 
		double[] SV=null; 
		double[] mask=null;
		int m=1; 
		double[][] CONSTRAINTS=new double[m][n]; 
		double[] L=new double[n+m]; 
		double[] U=new double[n+m]; 
		double[] alpha=new double[n]; 
		double[] benchmark=new double[n]; 
		double[] Q=new double[n*(n+1)/2]; 
		double gamma=1e-4; 
		double[] initial=new double[n]; 
		double delta=2; 
		double[] buy=new double[n]; 
		double[] sell=new double[n]; 
		double kappa=.5; 
		int basket=-1; 
		int trades=-1; 
		int revise=0; 
		int costs=0; 
		double min_holding=-1;
		double min_trade=-1; 
		int m_LS=0; 
		int Fully_Invested=1; 
		double Rmin=-1; 
		double Rmax=-1; 
		int m_Round=0; 
		double[] min_lot=new double[n]; 
		double[] size_lot=new double[n]; 
		int[] shake=new int[n*npoints]; 
		int ncomp=0; 
		double[] Composite=new double[ncomp*n]; 
		double LSValue=1; 
		int npiece=0; 
		double[] hpiece=null;//new double[n*npiece]; 
		double[] pgrad=null;//new double[n*npiece]; 
		int nabs=0; 
		double[] Abs_A=null;//new double[nabs*n]; 
		int mabs=0; 
		long[] I_A=null;//new long[mabs]; 
		double[] Abs_U=null;//new double[nabs+mabs];

		int i,j,ij;
		System.out.println(safejava.expire_date());
		for(i=0;i<n;++i)
		{
			stocknames[i]="jASSET "+(i+1);
			L[i]=0;
			U[i]=1;
			for(j=0;j<m;++j)
			{
				CONSTRAINTS[j][i]=1;//Just to show the order of the constraints
			}
			alpha[i]=(1.0*(i-n/2))/n;
			benchmark[i]=1.0/n;
		}
		for(i=0;i<m;++i)
		{
			U[i+(int)n]=L[i+(int)n]=1;
		}
		for(i=0,ij=0;i<n;++i)
		{
			for(j=0;j<=i;++j)
			{
				if(i==j){Q[ij]=1e-2*(i+1);}
				ij++;
			}
		}

/*		safejava.Optimise_internalCVPA(n, nfac, stocknames, w_opt, m, CONSTRAINTS, L, U, 
		alpha, benchmark, Q, gamma, initial, delta, buy, sell, kappa, basket, trades, 
		revise,costs, min_holding, min_trade, m_LS, Fully_Invested, Rmin, Rmax, m_Round, 
		min_lot, size_lot, shake, ncomp, Composite, LSValue, npiece, hpiece, pgrad, nabs, 
		Abs_A, mabs, I_A, Abs_U,mask,1,null);*/


		for(i=0;i<n;++i)
		{
			System.out.println("Name"+(i+1)+"\t"+stocknames[i]+"\tw"+(i+1)+"\t"+w_opt[i]);
		}

		System.out.println(safejava.version());
/*
		safejava.FrontierCVPAF(npoints,frontrisk,frontarisk,frontrreturn,frontareturn,
		n, nfac, stocknames, w_opt, m, CONSTRAINTS, L, U, 
		alpha, benchmark, Q, initial, delta, buy, sell, kappa, basket, trades, 
		revise,costs, min_holding, min_trade, m_LS, Fully_Invested, Rmin, Rmax, m_Round, 
		min_lot, size_lot, shake, ncomp, Composite, LSValue, npiece, hpiece, pgrad, nabs, 
		Abs_A, mabs, I_A, Abs_U,null,null,null,mask,1);
*/
		safejava.FrontierCVPF(npoints,frontrisk,frontarisk,frontrreturn,frontareturn,
		n, nfac, stocknames, w_opt, m, CONSTRAINTS, L, U, 
		alpha, benchmark, Q, initial, delta, buy, sell, kappa, basket, trades, 
		revise,costs, min_holding, min_trade, m_LS, Fully_Invested, Rmin, Rmax, m_Round, 
		min_lot, size_lot, shake, ncomp, Composite, LSValue, npiece, hpiece, pgrad,
		null,null,null,mask,1);

		for(i=0;i<n*npoints;++i)
		{
			System.out.println("w"+(i+1)+"\t"+w_opt[i]);
		}

	}
}



 
