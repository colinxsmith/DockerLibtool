#ifdef _WINDOWS
#include <io.h>
#endif
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <memory.h>

static	unsigned int bitaopt = 23;
#define No_of_Curve_Components 9

typedef union
{
	unsigned int n;
	unsigned char k[4];
}	compk;

typedef union
{
	unsigned char	b[16];
	struct	
	{
		unsigned int	pad;
		unsigned int	start;
		unsigned int	stop;
		unsigned int	hid;
	} t;
} validator_t;

void halfconvert(unsigned char*b,unsigned char odd)
{
	size_t i;
	for(i=0;i<16;++i,b++)
	{
		if(i%2&&!odd)*b &= 0x0f;
		else if(!(i%2)&&odd) *b &= 0x0f;
		else *b &= 0xf0;
	}
}
void halfjoin(unsigned char*b,unsigned char*beven)
{
	size_t i;
	for(i=0;i<16;++i,b++,beven++)
	{
		*b ^= *beven;
	}
}
void codecopy(unsigned char*b,unsigned char*beven)
{
	size_t i;
	for(i=0;i<16;++i,b++,beven++)
		*beven=*b;
}
static	char	validator_m[]= "RdG^AsTi1GgaKa7teDF3E645Fd912j4cB4b0_1|(&50'34$!TzZjkIXlMHPVW*@~";

#define validator_c(z) validator_m[(z+k) % 48]

void	krypton(unsigned char *b)
{
	unsigned int	i, w[16],z[16];
	for(i=0;i<16;i++)
	{
		w[i] = b[i]>>4;
		z[i] = b[i]&0xf;
	}
	for(i=0;i<16;i++) b[i] = (z[15-i]<<4)|(w[15-i]);
}


static	void	make_valid(validator_t *vp,size_t start,size_t stop,size_t hid)
{
	int	i, j, k;
	unsigned char	c;

	for(j=0;j<48;j+=16) krypton(validator_m+j);
	vp->t.pad = 0x13101955 + bitaopt;
	vp->t.start = start;
	vp->t.stop = stop;
	vp->t.hid  = hid;
	for(i=j=0;i<16;i++) j += vp->b[i];
	k = (j*147)%48;

	vp->t.pad += stop-start;
	vp->t.pad ^= hid;
	vp->t.start ^= vp->t.pad;
	vp->t.hid ^= stop;

	krypton(vp->b);
	for(j=0;j<3;j++)
	{
		for(i=0;i<16;i++) vp->b[i] ^= validator_c(i+j*16);
		krypton(vp->b);
		for(c=vp->b[i=0];i<15;i++) vp->b[i] = vp->b[i+1];
		vp->b[i] = c;
	}
	for(i=0;i<16;i++) vp->b[i] ^= validator_c(i+j*16);

/*	printf("%8.8lX %8.8lX %8.8lX %8.8lX\n", */
/*		vp->t.start,vp->t.stop,vp->t.pad,vp->t.hid); */
	for(j=0;j<48;j+=16) krypton(validator_m+j);
}

static	int	check_valid( validator_t *vp)
{
	int	i, j, k; 
	unsigned char	c;
	validator_t	v;

	for(j=0;j<48;j+=16) krypton(validator_m+j);
	for(k=0;k<48;k++)
	{
		v = *vp;
		/*printf("k=%d\n",k); */
		/*printf("%8.8lX %8.8lX %8.8lX %8.8lX\n", */
		/*	v.t.start,v.t.stop,v.t.pad,v.t.hid); */
		for(j=3,i=0;i<16;i++) v.b[i] ^= validator_c(i+j*16);
		while(j--)
		{
			for(c=v.b[i=15];i;i--) v.b[i] = v.b[i-1];
			v.b[i] = c;
			krypton(v.b);
			for(i=0;i<16;i++) v.b[i] ^= validator_c(i+j*16);
		}

		krypton(v.b);
		/*printf("%8.8lX %8.8lX %8.8lX %8.8lX\n", */
		/*	v.t.start,v.t.stop,v.t.pad,v.t.hid); */
		v.t.hid ^= v.t.stop;
		v.t.start ^= v.t.pad;
		v.t.pad ^= v.t.hid;
		v.t.pad -= v.t.stop-v.t.start;

		/*printf("%8.8lX %8.8lX %8.8lX %8.8lX\n", */
		/*	v.t.start,v.t.stop,v.t.pad,v.t.hid); */
		if((long)v.t.pad==0x13101955 + (long)bitaopt)
		{
			*vp = v;
			break;
		}
	}
	for(j=0;j<48;j+=16) krypton(validator_m+j);

	return k!=48;
}

static void convert(unsigned char* s,size_t *h,size_t* t0,size_t* t1)
{
	validator_t	validator;
	if(*h!=0)
	{
		make_valid(&validator, *t0, *t1,*h );
		memcpy(s,validator.b,16);
	}
	else
	{
		memcpy(validator.b,s,16);
		check_valid(&validator);
		*h=validator.t.hid;
		*t1=validator.t.stop;
		*t0=validator.t.start;
	}
}

static	time_t	get_a_time( char *s )
{
	int	yy, mm, dd;
	struct	tm	ltm;
	time_t	t;

	if(sscanf(s,"%d/%d/%d",&dd,&mm,&yy)!=3)
	{
		if(sscanf(s,"%d-%d-%d",&dd,&mm,&yy)!=3)
			fprintf(stderr,"Bad date\n");
	}
	
	ltm.tm_sec = 59;
	ltm.tm_min = 59;
	ltm.tm_hour = 23;
	ltm.tm_mday = dd;
	ltm.tm_mon = mm-1;
	ltm.tm_year = yy>1970?yy-1900:yy;
	ltm.tm_isdst = 0;
	t = mktime(&ltm);

	return t;
}
void hexwrite(unsigned char *a,char sep,size_t n)
{
	while(n--)printf("%x%c",*a++,sep);
}
void hexread(unsigned char *a,char sep,size_t n)
{
	size_t len=0,k;
	char*lic,*plic;
	char line[1000];/*Make sure this is long enough*/
	scanf("%s",line);
	lic=line;
	len=strlen((char*)lic);
	if((char)lic[len-1]=='"')lic[len-1]=0;/*In case this comes from windows enclosed in "" (system needs "" in unix-like, but DOS does not)*/
	if((char)*lic=='"')lic++;
	plic=lic;
	while(n--)
	{
		while(plic&&*plic++!=sep){;}
		*(plic-1)=0;
		sscanf(lic,"%x",&k);
		*a++=(unsigned char)k;
		lic=plic;
	}
}
int main( int argc, char **argv)
{
	compk ckey;
	size_t	hid,i=0,t1=0,t2=0,compkey=512;//512 means all keys are zero
	time_t tt1,tt2;
	char mode='w',*start=0,*stop=0,code[20],*pc,even[20];
	int split=0,rewrite=0,readable=0;
	argc--;argv++;
	while(argc--)
	{
		pc = *argv++;
		if(!strcmp(pc,"-w"))
			mode='w';
		else if(!strcmp(pc,"-read"))
			readable=1;
		else if(!strcmp(pc,"-ws"))
		{
			mode='w';
			split=1;
		}
		else if(!strcmp(pc,"-r"))
			mode = 'r';
		else if(!strcmp(pc,"-rs"))
		{
			mode = 'r';
			split=1;
		}
		else if(!strcmp(pc,"-rsr"))
		{
			mode = 'r';
			split=1;
			rewrite=1;
		}
		else if(!start)
			start=pc;
		else if(!stop)
			stop=pc;
		else if(compkey==512)
			compkey=atoi(pc);
		else
			break;
	}
	
	if(start)
	{
		if(start[0]=='n' || start[0]=='N')
		{
			time(&tt1);t1=(size_t)tt1;
		}
		else
			t1 = (size_t)get_a_time(start)-60 * 60 * 24;
	}
	if(stop)
	{
		if(stop[0] == '+')
		{
			t2 = t1 + atoi(stop++) * 60 * 60 * 24;
		}
		else
		{
			t2 = (size_t)get_a_time(stop)+60 * 60 * 24;
		}
	}


	if(mode == 'w')
	{
#ifdef _WINDOWS
		if( setmode( fileno(stdout), O_BINARY ) == -1 )
			printf( "Cannot set binary mode for output\n" );
#endif
		while(scanf("%8lx",&hid)>0)
		{
			if(compkey)
			{
				hid+=compkey;
				ckey.n=compkey;
			}
			convert(code,&hid,&t1,&t2);
			if(split)
			{
				codecopy(code,even);
				halfconvert(even,0);
				if(!readable)
					write(fileno(stdout),even,16);
				else
				{
					hexwrite(even,';',16);printf("\n");
				}
				codecopy(code,even);
				halfconvert(even,1);
				if(!readable)
					write(fileno(stdout),even,16);
				else
				{
					hexwrite(even,';',16);
					if(compkey)hexwrite(ckey.k,';',4);
					printf("\n");
				}
			}
			else
			{
				if(!readable)
					write(fileno(stdout),code,16);
				else
				{
					hexwrite(code,';',16);
					if(compkey)hexwrite(ckey.k,';',4);
					printf("\n");
				}
			}
			if(compkey&&!readable)
				write(fileno(stdout),ckey.k,4);
		}
	}
	else if(mode == 'r')
	{
		char ss[26],*curve;
		size_t curveextra;
		hid=0;pc=code;i=0;

#ifdef _WINDOWS
		if( setmode( fileno( stdin ), O_BINARY ) == -1 )
			printf( "Cannot set binary mode for input\n" );
#endif
		if(split)
		{
			if(!readable)
			{
				read(fileno(stdin),code,16);
				read(fileno(stdin),even,16);
				halfjoin(code,even);
				if(compkey)
					read(fileno(stdin),code+16,4);
			}
			else
			{
				hexread(code,';',16);
				if(compkey)
					hexread(even,';',20);
				else
					hexread(even,';',16);
				halfjoin(code,even);
				if(compkey)
					memcpy(code+16,even+16,4);
			}
			if(rewrite)
			{
				int exe;
				FILE*fff;
#ifdef _WINDOWS
				char*filen=(char*)"c:/safeqp2.dll";
#else
				char*ff=(char*)"/.safeqp2.so";
				int namelength=strlen(getenv("HOME"))+strlen(ff);
				char filen[namelength+1];
				strcpy(filen,getenv("HOME"));
				strcpy(filen+strlen(getenv("HOME")),ff);
#endif
				if((fff=fopen(filen,"w")))/*Lazy way to get open to do what we want below*/
					fclose(fff);
				else
					printf("Problems with licence file %s\n",filen);
#ifdef _WINDOWS
				exe = open(filen,O_RDWR|O_BINARY);
				printf("%s: file number %d \n",filen,exe);
#else
				/*exe = open(filen,O_RDWR|O_CREAT,S_IRWXU|S_IRWXG|S_IRWXO);*/
				exe = open(filen,O_RDWR);
				printf("%s: file number %d %m\n",filen,exe);
#endif
				write(exe,code,20);
				close(exe);
			}

		}
		else
		{
			if(!readable)
				read(fileno(stdin),code,20);
			else
				hexread(code,';',20);
		}
		hid=0;
		convert(code,&hid,&t1,&t2);tt1=(time_t)t1;tt2=(time_t)t2;
		memcpy(ckey.k,code+16,4);
		hid -= ckey.n;
		printf("HOST\t%lx\n",hid);
		strcpy(ss,ctime(&tt1));t1=(size_t)tt1;
		printf("START\t%s",ss);
		strcpy(ss,ctime(&tt2));t2=(size_t)tt2;
		printf("STOP\t%s",ss);
		curve=ss+No_of_Curve_Components;
		*curve='\0';
		curve--;
		curveextra=ckey.n;
		for(i=0;i<No_of_Curve_Components;++i)
		{
			*curve-- = curveextra % 2 + '0';
			curveextra = curveextra / 2;
		}
		printf("comps\t%s\n",ss);
	}
	return 0;
}
