#include "ldefns.h"
#include "constant.h"
/*
	dsmxmpd makes an n by n symmetric matrix Positive definite.

	arguments
	n		dimen dimesion of the matrix
	S		sym_matrix the n by n matrix stored in packed form by row.
	L		ldl_matrix pointer to (n*(n+1))/2 reals.
	v		vector of length n
	P		short_vec of length n
	info		pointer to a dsmxmpd_info_rec or NULL

	Method
	1)		Compute a U D U' factorisation using dsmxfac
			here U are upper triangular and D is block diagonal
			with 1x1 or 2x2 blocks.
	2)		find the blocks which need correcting and add an appropriate
			amount of the appropriate eigenvector outer product to D
	3)		correct S by the appropriate amount using the matrices U.
			if S and L are the same then we adjust the values of D
			directly and the adjusted factorisation is returned
			in L
*/

void	dsmxmpd( dimen n, sym_matrix S, ldl_matrix L, vector v, short_vec P, dsmxmpd_info_rec *info )
{
#	define	LDEBUGPR( A )
	dimen	i, j, nn=((n*(n+1))>>1);
	vector	l;
	real	V[4], lambda[2], a, b, c, t;
	int	do_info = info!=NULL;
	int	same = (L==S);

	if(do_info)
	{
		info->ncor = info->twob = info->oneb = 0;
		info->maxc = info->maxA = 0.0;
		info->minA = info->minE = 1e300;
		info->maxE = -1e300;
	}

	if(!same) dcopyvec( nn, S, L );
	dsmxfac( n, L, P );

	for(l=L,i=0;i<n;l+=i+1)
	{
		if(P[i]>0)
		{
			/*1x1 block*/
			t= *l;
			if( do_info )
			{
				info->oneb++;
				if(fabs(t)>info->maxA) info->maxA = t;
				if(fabs(t)<info->minA) info->minA = t;
				if(t<info->minE) info->minE = t;
				if(t>info->maxE) info->maxE = t;
			}
			if( t < lm_eps8 )//Changed from lm_rooteps
			{
				/*we must correct this one*/
				if( !same )
				{
					dscunitvec( n, i, sqrt(t=lm_eps8 - t), v );
					LDEBUGPR(lm_wmsg("i=%u P[i]=%d t=%lg",i,P[i], t ); lm_mdvwri("v", n, v );)
					dsmxaupt( n, L, P, SMXFAC_NORMAL, v );
					dsmxavop( n, S, v );
					LDEBUGPR(lm_mdvwri("v", n, v );)
				}
				if( do_info )
				{
					info->ncor++;
					if( t > info->maxc ) info->maxc = t;
				}
				*l = lm_rooteps;
			}
			i++;
		}
		else
		{
			real	*ol = l;
			/*2x2 block*/
			a = *l;
			l += i+1;
			b = *l++;
			c = *l;
			/*find the eigenvectors and values of the block*/
			dsmx22ev( a, b, c, lambda, V );
			for(j=0;j<2;j++)
			{
				t = lambda[j];
				if( do_info )
				{
					info->twob++;
					if(fabs(t)>info->maxA) info->maxA = t;
					if(fabs(t)<info->minA) info->minA = t;
					if(t<info->minE) info->minE = t;
					if(t>info->maxE) info->maxE = t;
				}
				if( t < lm_eps8 )//Changed from lm_rooteps
				{
					real	s = sqrt(t=lm_eps8 - t);
					if(!same)
					{
						dzerovec( n, v );
						dsccopyvec(2, s, V+2*j, v+i);
						LDEBUGPR(lm_wmsg("i=%u P[i]=%d t=%lg",i,P[i],t); lm_mdvwri("v",n,v);)
						dsmxaupt( n, L, P, SMXFAC_NORMAL, v );
						LDEBUGPR(lm_mdvwri("v", n, v );)
						dsmxavop( n, S, v );
					}
					if( do_info )
					{
						info->ncor++;
						if( t > info->maxc ) info->maxc = t;
					}
					/*s *= s;*/
					s = t;
					j <<= 1;
					ol[0] += s*V[j]*V[j];
					ol[i+1] += s*V[j]*V[j+1];
					ol[i+2] += s*V[j+1]*V[j+1];
					j >>= 1;
				}
			}
			i += 2;
		}
	}
}
