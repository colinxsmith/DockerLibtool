#include "baseoptimise.h"
/*
	dqpcolr  is used to compute elements of the  (ncolr)-th  column of
	r,  the cholesky factor of the projected hessian.  if  renewr  is
	true  on entry,  the complete column is to be computed
	otherwise, only the last diagonal element is required
	if the resulting projected hessian is singular or indefinite, its
	last diagonal element is increased by an amount  emax  that
	ensures positive definiteness.  this diagonal modification will
	alter the scale of the qp search vector  p, but not its
	direction

	on exit,  qpcolr will have stored the  ncolr  elements of the new
	column of  r  in the array  rt,  and set the variables  nocurv,
	posdef,  renewr,  drmax,  emax  and  hsize
*/
void Base_Optimise::dqpcolr(logical *nocurv, logical *posdef, logical *renewr, logical *unitq, dimen n, integer *ncolr, integer *nfree, integer *Nq, integer *nrowh, integer *ncolh, integer *Nrowrt, integer *nhess, short_vec kfree, real *cslast, real *snlast, real *drmax, real *emax, real *hsize, real *rdlast, real *hess, real *rt, real *scale, real *zy, real *hz1, real *wrk)
{

    integer hess_dim1, hess_offset, rt_dim1, rt_offset, zy_dim1, zy_offset, 
	    i__1;
    real d__1, d__2;

    real rdsq, zthz1;
    integer j, k;
    short idiag;
    real s;
    real rnorm;
    integer ncolr1;
    integer jthcol;
    real rdsmin, rdsmax;
    --wrk;
    --hz1;
    zy_dim1 = *Nq;
    zy_offset = zy_dim1 + 1;
    zy -= zy_offset;
    --scale;
    rt_dim1 = *Nrowrt;
    rt_offset = rt_dim1 + 1;
    rt -= rt_offset;
    hess_dim1 = *nrowh;
    hess_offset = hess_dim1 + 1;
    hess -= hess_offset;
    --kfree;

    if (*renewr) {
	goto L20;
    }
	/*
	
	only the last element of the new column of  r  need be computed
	this situation can only occur when a constraint is added to the
	working set with  zthz1  not positive definite
	
	the last diagonal element of  r  is that of  zthz1  plus a diagonal
	modification.  the square of the true diagonal is recovered from
	the rotations used to update  r  when the constraint was added to
	the working set
	*/
    *rdlast = rt[*ncolr + *ncolr * rt_dim1];
    s = fabs(*snlast);
    rdsq = (*cslast - s) * *rdlast * ((*cslast + s) * *rdlast);
    goto L120;
	/*
	the projected hessian is expanded by a row and column.  compute
	the first  (ncolr - 1)  elements of the new column of the
	cholesky factor r.  also, compute  rdsq,  the square of the last
	diagonal element
	*/
L20:
    dzerovec(n, &wrk[1]);
    if (*unitq) goto L60;
	/*
	     expand the new column of z in to an n-vector
	*/
    i__1 = *nfree;
    for (k = 1; k <= i__1; ++k) {
	j = kfree[k];
	wrk[j] = zy[k + *ncolr * zy_dim1];
/* L40: */
    }
    if (scldqp) ddmxmulv(n, &scale[1], 1, &wrk[1], 1);
    jthcol = 0;
    goto L80;
	/*
	     only bounds are in the working set (nfree  is equal to  ncolz)
	     the (ncolr)-th  column of  z  is just a column of the identity
	     matrix
	*/
L60:
    jthcol = kfree[*ncolr];
    wrk[jthcol] = 1;
	/*
	     compute the hessian times the last column of z
	*/
L80:
    qphess(n, CN(*nrowh), CN(*ncolh), CN(jthcol), &hess[hess_offset], &wrk[1], &hz1[1]);
    ++(*nhess);
    if (*unitq && scldqp) dscalvec(n, scale[jthcol], &hz1[1]);
    if (scldqp) ddmxmulv(n, &scale[1], 1, &hz1[1], 1);
	/*
	     compute the  (ncolr)-th  column of  z(t)h z
	*/
    dzyprod(4, n, *nfree, *ncolr, *nfree, *Nq, *unitq, &kfree[1], &kfree[1], &
	    hz1[1], &zy[zy_offset], &wrk[1]);
    dcopyvec(*ncolr, &hz1[1], &rt[*ncolr * rt_dim1 + 1]);
	/*
	compute the first  (ncolr - 1)  elements of the last column of  r.
	*/
    ncolr1 = *ncolr - 1;
    zthz1 = rt[*ncolr + *ncolr * rt_dim1];
    rdsq = zthz1;
    if (ncolr1 == 0) {
	goto L100;
    }
    idiag = dtmxsolve(CS(-1), ncolr1, &rt[rt_offset], *Nrowrt, &rt[*ncolr * rt_dim1 + 1], CS(1));
    rnorm = dnrm2vec(ncolr1, &rt[*ncolr * rt_dim1 + 1]);
	/*
	compute the square of the last diagonal element of  r
	*/
    rdsq = zthz1 - rnorm * rnorm;
	/*
	update the estimate of the norm of the hessian
	*/
L100:
    d__1 = *hsize, d__2 = fabs(zthz1);
    *hsize = max(d__1,d__2);
	/*
	compute  rdlast, the last diagonal of  r.  the variables posdef
	and  nocurv  are set here.  they are used to indicate if the new
	projected hessian is positive definite or singular.  if  posdef
	is set to false,  rdlast  will be that of  zthz1  plus a diagonal
	modification. if the required diagonal modification is large,
	renewr  will be set to be  true,  indicating that the last row
	and column of  r  must be recomputed when a constraint is added
	to the working set during the next iteration
	*/
L120:
    *nocurv = FALSE_;
    *renewr = FALSE_;
    *emax = 0;
	/*
	rdsmin  is the square of the smallest allowable diagonal element
	for a positive-definite cholesky factor.  note that the test for a
	singular matrix is scale dependent
	*/
    rdsmin = ( *ncolr>1? *drmax * *drmax : *hsize )*lm_eps;
    *posdef = rdsq > rdsmin;
    if (*posdef) {
	goto L180;
    }
    if (rdsq < -rdsmin) {
	goto L140;
    }
	/*
	     the projected hessian is singular

	the quadratic has no curvature along at least one direction.  the
	perturbation  emax  is chosen to make the new eigenvalue of  zthz1
	small and positive
	*/
    *emax = rdsmin - rdsq;
    rdsq = rdsmin;
    *nocurv = TRUE_;
    goto L180;
	/*
	the projected hessian is indefinite.  there are two cases

	case 1.  the modulus of the new last diagonal of  r  is not too
	large.  the modulus of  rdsq  is used for the square root
	*/
L140:
    rdsmax = 10 * *hsize;
    if (rdsq < -rdsmax) {
	goto L160;
    }
    *emax = -2 * rdsq;
    goto L180;
	/*
	case 2.  the modulus of the last diagonal of  r  is judged to be
	too large (some loss of precision may have occurred).  set
	renewr  so that the last column is recomputed later
	*/
L160:
    *emax = rdsmax - rdsq;
    *renewr = TRUE_;
    rdsq = rdsmax;
	/*
	compute the last diagonal element
	*/
L180:
    *rdlast = sqrt((fabs(rdsq)));
    rt[*ncolr + *ncolr * rt_dim1] = *rdlast;
    if (msg >= 80 && ! (*posdef))
	lm_wmsg(
"\n//QPCOLR//  POSDEF NOCURV          EMAX        RDLAST\n//QPCOLR//%8ld%7ld%14.4lg%14.4lg",
	CL(*posdef),CL(*nocurv),*emax, *rdlast);
    return;
}
