#include "SparseClass.h"
#ifdef __SYSNT__
#include <crtdbg.h>
#endif
#ifdef USE
SparseLDL::~SparseLDL()
{
	delete spaceI;
	delete spaceD;
	if(indexAI) delete indexAI;
	if(indexAP) delete indexAP;
	if(sparseAX) delete sparseAX;
	if(invorder) delete invorder;
	if(order) delete []order;
}
SparseLDL::SparseLDL(size_t n,size_t* order)
{
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	this->n=n;
	spaceI=new std::valarray<size_t>;
	spaceD=new std::valarray<double>;
	invorder=0;
	indexAI=0;
	indexAP=0;
	sparseAX=0;
	if(order)
	{
		this->order=new size_t[n];
		memmove(this->order,order,n*sizeof(size_t));
	}
	else
		this->order=0;
}
void SparseLDL::SetOrder(size_t n,size_t* order)
{
	if(this->order)
	{
		delete invorder;invorder=0;
		delete[]this->order;
	}
	if(order)
	{
		this->order=new size_t[n];
		memmove(this->order,order,n*sizeof(size_t));
	}
	else
	{
		this->order=0;
	}
}
void SparseLDL::CreateSparseIndices(double* Q)
{
	/*This generates the indicies. If we want to use this then call Factor with AP and AI and AX
	all null, otherwise don't call this and assign AP,AI and AX elsewhere*/
	if(!indexAP)indexAP=new std::valarray<size_t>;
	if(!indexAI)indexAI=new std::vector<size_t>;
	if(!sparseAX)sparseAX=new std::vector<double>;
	indexAI->erase(indexAI->begin(),indexAI->end());
	sparseAX->erase(sparseAX->begin(),sparseAX->end());
	if(indexAP->size()<n+1)indexAP->resize(n+1);
	size_t*AP=&(*indexAP)[0],tot=0,i,j;
	double*pQ=Q,QQ;
	*AP++=0;
//	size_t scount=0;
	for(i=0;i<n;i++)
	{
		for(j=0;j<=i;++j)
		{
			if(*Q != 0)
			{
				sparseAX->push_back(*Q);
				indexAI->push_back(j);
				tot++;
			}
//			else scount++;
			Q++;
		}
		if(order)
		{
			for(j=i+1;j<n;++j)
			{
				if((QQ=pQ[j*(j+1)/2+i])!= 0)
				{
					sparseAX->push_back(QQ);
					indexAI->push_back(j);
					tot++;
				}
			}
		}
		*AP++=tot;
	}
//	if(scount)printf("%d zero entries\n",scount);
}
size_t SparseLDL::Factor(double* AX,size_t*AP,size_t*AI)
{
	if(order)
	{
		if(!invorder)
		{
			invorder=new std::valarray<size_t>;
			invorder->resize(n);
			if(!ldl_valid_perm(n,order,&(*invorder)[0]))
			{
				printf("Invalid permutation given for sparse matrix; ignoring it.\n");
				delete invorder;invorder=0;
				delete []order;order=0;
			}
		}
	}
	if(!AX&&!AP&&!AI)
	{
		AX=&(sparseAX->front());
		AI=&(indexAI->front());
		AP=&(*indexAP)[0];
	}
	else if(!AX || !AP || !AI)
	{
		printf("Exception in SparseLDL::Factor ERROR.\n");
		throw SparseError(0);
	}
	std::valarray<size_t>Parent(n);
	std::valarray<size_t>Pattern(n);
	std::valarray<size_t>Lnz(n+1);
	std::valarray<size_t>Flag(n);
	std::valarray<double>Y(n);
	if(!ldl_valid_matrix(n,AP,AI))
	{
		printf("Exception in SparseLDL::Factor ERROR Invalid indicies.\n");
		throw SparseError(1);
	}
	if(spaceI->size()<n+1)spaceI->resize(n+1);
	Lp=&(*spaceI)[0];
	ldl_symbolic(n,AP,AI,Lp,&Parent[0],&Lnz[0],&Flag[0],order,invorder?&(*invorder)[0]:0);
	memcpy(&Lnz[0],Lp,(n+1)*sizeof(size_t));
	if(spaceI->size()<n+1+Lnz[n])spaceI->resize(n+1+Lnz[n]);
	Lp=&(*spaceI)[0];
	Li=Lp+n+1;
	memcpy(Lp,&Lnz[0],(n+1)*sizeof(size_t));
	if(spaceD->size()<n+Lnz[n])spaceD->resize(n+Lnz[n]);
	Diag=&(*spaceD)[0];
	Lx=Diag+n;
	size_t back= ldl_numeric(n,AP,AI,AX,Lp,&Parent[0],&Lnz[0],Li,Lx,Diag,&Y[0],&Pattern[0],&Flag[0],order,invorder?&(*invorder)[0]:0);
//	if(back!=n)
//		printf("Error in factorisation\n");
	return back;
}
void SparseLDL::Solve(double* g1)
{
	std::valarray<double> wg;
	if(order)
	{
		wg.resize(n);
		if(!invorder)
		{//We should never get in here
			invorder=new std::valarray<size_t>;
			invorder->resize(n);
			if(!ldl_valid_perm(n,order,&(*invorder)[0]))
			{
				printf("Invalid permutation given for sparse matrix; ignoring it.\n");
				delete invorder;invorder=0;
				delete []order;order=0;
			}
		}
		if(order)
		{
			ldl_perm(n, &wg[0], g1, order) ;
			memmove(g1,&wg[0],n*sizeof(double));
		}
	}
	ldl_lsolve(n,g1,Lp,Li,Lx);
	ldl_dsolve(n,g1,Diag);
	ldl_ltsolve(n,g1,Lp,Li,Lx);
	if(order)
	{
		ldl_permt (n, &wg[0], g1, order) ;
		memmove(g1,&wg[0],n*sizeof(double));
	}
}
/* nspiv.f -- translated by f2c (version 20030320).

Source ACM Transactions on Mathematical Software (TOMS) archive
Volume 4 ,  Issue 4  (December 1978) table of contents

Pages: 391 - 398   
Year of Publication: 1978 
ISSN:0098-3500  
Author  Andrew H. Sherman   Department of Computer Sciences, Painter 328, The University of Texas at Austin, Austin, TX  
 

This is not particularly fast; treats non-symmetric matrices
*/
typedef long integer;
typedef double doublereal;

extern "C" int nspiv1_(integer *, integer *, integer *, 
	    doublereal *, doublereal *, integer *, integer *, integer *, 
	    integer *, doublereal *, doublereal *, integer *, integer *, 
	    integer *, doublereal *, integer *);
/* Table of constant values */

extern "C" int nspiv_(integer *n, integer *ia, integer *ja, doublereal *
	a, doublereal *b, integer *max__, integer *r__, integer *c__, integer 
	*ic, doublereal *x, integer *itemp, doublereal *rtemp, integer *ierr)
{
    integer p, u, y, iu, ju;



/*  NSPIV CALLS NSPIV1 WHICH USES SPARSE GAUSSIAN ELIMINATION WITH */
/*  COLUMN INTERCHANGES TO SOLVE THE LINEAR SYSTEM A X = B.  THE */
/*  ELIMINATION PHASE PERFORMS ROW OPERATIONS ON A AND B TO OBTAIN */
/*  A UNIT UPPER TRIANGULAR MATRIX U AND A VECTOR Y.  THE SOLUTION */
/*  PHASE SOLVES U X = Y. */


/*  INPUT ARGUMENTS--- */

/*  N      INTEGER NUMBER OF EQUATIONS AND UNKNOWNS */

/*  IA     INTEGER ARRAY OF N+1 ENTRIES CONTAINING ROW POINTERS TO A */
/*         (SEE MATRIX STORAGE DESCRIPTION BELOW) */

/*  JA     INTEGER ARRAY WITH ONE ENTRY PER NONZERO IN A, CONTAINING */
/*         COLUMN NUMBERS OF THE NONZEROES OF A.  (SEE MATRIX STORAGE */
/*         DESCRIPTION BELOW) */

/*  A      REAL ARRAY WITH ONE ENTRY PER NONZERO IN A, CONTAINING THE */
/*         ACTUAL NONZEROES.  (SEE MATRIX STORAGE DESCRIPTION BELOW) */

/*  B      REAL ARRAY OF N ENTRIES CONTAINING RIGHT HAND SIDE DATA */

/*  MAX    INTEGER NUMBER SPECIFYING MAXIMUM NUMBER OF OFF-DIAGONAL */
/*         NONZERO ENTRIES OF U WHICH MAY BE STORED */

/*  R      INTEGER ARRAY OF N ENTRIES SPECIFYING THE ORDER OF THE */
/*         ROWS OF A (I.E., THE ELIMINATION ORDER FOR THE EQUATIONS) */

/*  C      INTEGER ARRAY OF N ENTRIES SPECIFYING THE ORDER OF THE */
/*         COLUMNS OF A.  C IS ALSO AN OUTPUT ARGUMENT */

/*  IC     INTEGER ARRAY OF N ENTRIES WHICH IS THE INVERSE OF C */
/*         (I.E., IC(C(I)) = I).  IC IS ALSO AN OUTPUT ARGUMENT */

/*  ITEMP  INTEGER ARRAY OF 2*N + MAX + 2 ENTRIES, FOR INTERNAL USE */

/*  RTEMP  REAL ARRAY OF N + MAX ENTRIES FOR INTERNAL USE */


/*  OUTPUT ARGUMENTS--- */

/*  C      INTEGER ARRAY OF N ENTRIES SPECIFYING THE ORDER OF THE */
/*         COLUMNS OF U.  C IS ALSO AN INPUT ARGUMENT */

/*  IC     INTEGER ARRAY OF N ENTRIES WHICH IS THE INVERSE OF C */
/*         (I.E., IC(C(I)) = I).  IC IS ALSO AN INPUT ARGUMENT */

/*  X      REAL ARRAY OF N ENTRIES CONTAINING THE SOLUTION VECTOR */

/*  IERR   INTEGER NUMBER WHICH INDICATES ERROR CONDITIONS OR */
/*         THE ACTUAL NUMBER OF OFF-DIAGONAL ENTRIES IN U (FOR */
/*         SUCCESSFUL COMPLETION) */

/*         IERR VALUES ARE--- */

/*         0 LT IERR             SUCCESSFUL COMPLETION.  U HAS IERR */
/*                               OFF-DIAGONAL NONZERO ENTRIES */

/*         IERR = 0              ERROR.  N = 0 */

/*         -N LE IERR LT 0       ERROR.  ROW NUMBER IABS(IERR) OF A IS */
/*                               IS NULL */

/*         -2*N LE IERR LT -N    ERROR.  ROW NUMBER IABS(IERR+N) HAS A */
/*                               DUPLICATE ENTRY */

/*         -3*N LE IERR LT -2*N  ERROR.  ROW NUMBER IABS(IERR+2*N) */
/*                               HAS A ZERO PIVOT */

/*         -4*N LE IERR LT -3*N  ERROR.  ROW NUMBER IABS(IERR+3*N) */
/*                               EXCEEDS STORAGE */


/*  STORAGE OF SPARSE MATRICES--- */

/*  THE SPARSE MATRIX A IS STORED USING THREE ARRAYS IA, JA, AND A. */
/*  THE ARRAY A CONTAINS THE NONZEROES OF THE MATRIX ROW-BY-ROW, NOT */
/*  NECESSARILY IN ORDER OF INCREASING COLUMN NUMBER.  THE ARRAY JA */
/*  CONTAINS THE COLUMN NUMBERS CORRESPONDING TO THE NONZEROES STORED */
/*  IN THE ARRAY A (I.E., IF THE NONZERO STORED IN A(K) IS IN */
/*  COLUMN J, THEN JA(K) = J).  THE ARRAY IA CONTAINS POINTERS TO THE */
/*  ROWS OF NONZEROES/COLUMN INDICES IN THE ARRAY A/JA (I.E., */
/*  A(IA(I))/JA(IA(I)) IS THE FIRST ENTRY FOR ROW I IN THE ARRAY A/JA). */
/*  IA(N+1) IS SET SO THAT IA(N+1) - IA(1) = THE NUMBER OF NONZEROES IN A */



/*  SET INDICES TO DIVIDE TEMPORARY STORAGE FOR NSPIV1 */

    /* Parameter adjustments */
    --rtemp;
    --itemp;
    --x;
    --ic;
    --c__;
    --r__;
    --b;
    --a;
    --ja;
    --ia;

    /* Function Body */
    y = 1;
    u = y + *n;
    p = 1;
    iu = p + *n + 1;
    ju = iu + *n + 1;

/*  CALL NSPIV1 TO PERFORM COMPUTATIONS */

    nspiv1_(n, &ia[1], &ja[1], &a[1], &b[1], max__, &r__[1], &c__[1], &ic[1], 
	    &x[1], &rtemp[y], &itemp[p], &itemp[iu], &itemp[ju], &rtemp[u], 
	    ierr);
    return 0;
} /* nspiv_ */

extern "C" int nspiv1_(integer *n, integer *ia, integer *ja, doublereal 
	*a, doublereal *b, integer *max__, integer *r__, integer *c__, 
	integer *ic, doublereal *x, doublereal *y, integer *p, integer *iu, 
	integer *ju, doublereal *u, integer *ierr)
{
    /* System generated locals */
    integer i__1, i__2, i__3;
    doublereal d__1;

    /* Local variables */
    static integer i__, j, k, v, ck;
    static doublereal dk;
    static integer pk, vi, vj, vk;
    static doublereal yk;
    static integer pv, jaj;
    static doublereal lki, one;
    static integer juj, ppk;
    static doublereal xpv;
    static integer maxc, jmin, jmax;
    static doublereal zero;
    static integer maxcl, nzcnt, juptr;
    static doublereal xpvmax;



/*  NSPIV1 USES SPARSE GAUSSIAN ELIMINATION WITH */
/*  COLUMN INTERCHANGES TO SOLVE THE LINEAR SYSTEM A X = B.  THE */
/*  ELIMINATION PHASE PERFORMS ROW OPERATIONS ON A AND B TO OBTAIN */
/*  A UNIT UPPER TRIANGULAR MATRIX U AND A VECTOR Y.  THE SOLUTION */
/*  PHASE SOLVES U X = Y. */


/*  SEE NSPIV FOR DESCRIPTIONS OF ALL INPUT AND OUTPUT ARGUMENTS */
/*  OTHER THAN THOSE DESCRIBED BELOW */

/*  INPUT ARGUMENTS (USED INTERNALLY ONLY)--- */

/*  Y   REAL ARRAY OF N ENTRIES USED TO COMPUTE THE UPDATED */
/*      RIGHT HAND SIDE */

/*  P   INTEGER ARRAY OF N+1 ENTRIES USED FOR A LINKED LIST. */
/*      P(N+1) IS THE LIST HEADER, AND THE ENTRY FOLLOWING */
/*      P(K) IS IN P(P(K)).  THUS, P(N+1) IS THE FIRST DATA */
/*      ITEM, P(P(N+1)) IS THE SECOND, ETC.  A POINTER OF */
/*      N+1 MARKS THE END OF THE LIST */

/*  IU  INTEGER ARRAY OF N+1 ENTRIES USED FOR ROW POINTERS TO U */
/*      (SEE MATRIX STORAGE DESCRIPTION BELOW) */

/*  JU  INTEGER ARRAY OF MAX ENTRIES USED FOR COLUMN NUMBERS OF */
/*      THE NONZEROES IN THE STRICT UPPER TRIANGLE OF U.  (SEE */
/*      MATRIX STORAGE DESCRIPTION BELOW) */

/*  U   REAL ARRAY OF MAX ENTRIES USED FOR THE ACTUAL NONZEROES IN */
/*      THE STRICT UPPER TRIANGLE OF U.  (SEE MATRIX STORAGE */
/*      DESCRIPTION BELOW) */


/*  STORAGE OF SPARSE MATRICES--- */

/*  THE SPARSE MATRIX A IS STORED USING THREE ARRAYS IA, JA, AND A. */
/*  THE ARRAY A CONTAINS THE NONZEROES OF THE MATRIX ROW-BY-ROW, NOT */
/*  NECESSARILY IN ORDER OF INCREASING COLUMN NUMBER.  THE ARRAY JA */
/*  CONTAINS THE COLUMN NUMBERS CORRESPONDING TO THE NONZEROES STORED */
/*  IN THE ARRAY A (I.E., IF THE NONZERO STORED IN A(K) IS IN */
/*  COLUMN J, THEN JA(K) = J).  THE ARRAY IA CONTAINS POINTERS TO THE */
/*  ROWS OF NONZEROES/COLUMN INDICES IN THE ARRAY A/JA (I.E., */
/*  A(IA(I))/JA(IA(I)) IS THE FIRST ENTRY FOR ROW I IN THE ARRAY A/JA). */
/*  IA(N+1) IS SET SO THAT IA(N+1) - IA(1) = THE NUMBER OF NONZEROES IN */
/*  A.  IU, JU, AND U ARE USED IN A SIMILAR WAY TO STORE THE STRICT UPPER */
/*  TRIANGLE OF U, EXCEPT THAT JU ACTUALLY CONTAINS C(J) INSTEAD OF J */




    /* Parameter adjustments */
    --u;
    --ju;
    --iu;
    --p;
    --y;
    --x;
    --ic;
    --c__;
    --r__;
    --b;
    --a;
    --ja;
    --ia;

    /* Function Body */
    if (*n == 0) {
	goto L1001;
    }

    one = 1.f;
    zero = 0.f;

/*  INITIALIZE WORK STORAGE AND POINTERS TO JU */

    i__1 = *n;
    for (j = 1; j <= i__1; ++j) {
	x[j] = zero;
/* L10: */
    }
    iu[1] = 1;
    juptr = 0;

/*  PERFORM SYMBOLIC AND NUMERIC FACTORIZATION ROW BY ROW */
/*  VK (VI,VJ) IS THE GRAPH VERTEX FOR ROW K (I,J) OF U */

    i__1 = *n;
    for (k = 1; k <= i__1; ++k) {

/*  INITIALIZE LINKED LIST AND FREE STORAGE FOR THIS ROW */
/*  THE R(K)-TH ROW OF A BECOMES THE K-TH ROW OF U. */

	p[*n + 1] = *n + 1;
	vk = r__[k];

/*  SET UP ADJACENCY LIST FOR VK, ORDERED IN */
/*  CURRENT COLUMN ORDER OF U.  THE LOOP INDEX */
/*  GOES DOWNWARD TO EXPLOIT ANY COLUMNS */
/*  FROM A IN CORRECT RELATIVE ORDER */

	jmin = ia[vk];
	jmax = ia[vk + 1] - 1;
	if (jmin > jmax) {
	    goto L1002;
	}
	j = jmax;
L20:
	jaj = ja[j];
	vj = ic[jaj];

/*  STORE A(K,J) IN WORK VECTOR */

	x[vj] = a[j];
/*  THIS CODE INSERTS VJ INTO ADJACENCY LIST OF VK */
	ppk = *n + 1;
L30:
	pk = ppk;
	ppk = p[pk];
	if ((i__2 = ppk - vj) < 0) {
	    goto L30;
	} else if (i__2 == 0) {
	    goto L1003;
	} else {
	    goto L40;
	}
L40:
	p[vj] = ppk;
	p[pk] = vj;
	--j;
	if (j >= jmin) {
	    goto L20;
	}

/*  THE FOLLOWING CODE COMPUTES THE K-TH ROW OF U */

	vi = *n + 1;
	yk = b[vk];
L50:
	vi = p[vi];
	if (vi >= k) {
	    goto L110;
	}

/*  VI LT VK -- PROCESS THE L(K,I) ELEMENT AND MERGE THE */
/*  ADJACENCY OF VI WITH THE ORDERED ADJACENCY OF VK */

	lki = -x[vi];
	x[vi] = zero;

/*  ADJUST RIGHT HAND SIDE TO REFLECT ELIMINATION */

	yk += lki * y[vi];
	ppk = vi;
	jmin = iu[vi];
	jmax = iu[vi + 1] - 1;
	if (jmin > jmax) {
	    goto L50;
	}
	i__2 = jmax;
	for (j = jmin; j <= i__2; ++j) {
	    juj = ju[j];
	    vj = ic[juj];

/*  IF VJ IS ALREADY IN THE ADJACENCY OF VK, */
/*  SKIP THE INSERTION */

	    if (x[vj] != zero) {
		goto L90;
	    }

/*  INSERT VJ IN ADJACENCY LIST OF VK. */
/*  RESET PPK TO VI IF WE HAVE PASSED THE CORRECT */
/*  INSERTION SPOT.  (THIS HAPPENS WHEN THE ADJACENCY OF */
/*  VI IS NOT IN CURRENT COLUMN ORDER DUE TO PIVOTING.) */

	    if ((i__3 = vj - ppk) < 0) {
		goto L60;
	    } else if (i__3 == 0) {
		goto L90;
	    } else {
		goto L70;
	    }
L60:
	    ppk = vi;
L70:
	    pk = ppk;
	    ppk = p[pk];
	    if ((i__3 = ppk - vj) < 0) {
		goto L70;
	    } else if (i__3 == 0) {
		goto L90;
	    } else {
		goto L80;
	    }
L80:
	    p[vj] = ppk;
	    p[pk] = vj;
	    ppk = vj;

/*  COMPUTE L(K,J) = L(K,J) - L(K,I)*U(I,J) FOR L(K,I) NONZERO */
/*  COMPUTE U*(K,J) = U*(K,J) - L(K,I)*U(I,J) FOR U(K,J) NONZERO */
/*  (U*(K,J) = U(K,J)*D(K,K)) */

L90:
	    x[vj] += lki * u[j];
/* L100: */
	}
	goto L50;

/*  PIVOT--INTERCHANGE LARGEST ENTRY OF K-TH ROW OF U WITH */
/*  THE DIAGONAL ENTRY. */

/*  FIND LARGEST ENTRY, COUNTING OFF-DIAGONAL NONZEROES */

L110:
	if (vi > *n) {
	    goto L1004;
	}
	xpvmax = (d__1 = x[vi], fabs(d__1));
	maxc = vi;
	nzcnt = 0;
	pv = vi;
L120:
	v = pv;
	pv = p[pv];
	if (pv > *n) {
	    goto L130;
	}
	++nzcnt;
	xpv = (d__1 = x[pv], fabs(d__1));
	if (xpv <= xpvmax) {
	    goto L120;
	}
	xpvmax = xpv;
	maxc = pv;
	maxcl = v;
	goto L120;
L130:
	if (xpvmax == zero) {
	    goto L1004;
	}

/*  IF VI = K, THEN THERE IS AN ENTRY FOR DIAGONAL */
/*  WHICH MUST BE DELETED.  OTHERWISE, DELETE THE */
/*  ENTRY WHICH WILL BECOME THE DIAGONAL ENTRY */

	if (vi == k) {
	    goto L140;
	}
	if (vi == maxc) {
	    goto L140;
	}
	p[maxcl] = p[maxc];
	goto L150;
L140:
	vi = p[vi];

/*  COMPUTE D(K) = 1/L(K,K) AND PERFORM INTERCHANGE. */

L150:
	dk = one / x[maxc];
	x[maxc] = x[k];
	i__ = c__[k];
	c__[k] = c__[maxc];
	c__[maxc] = i__;
	ck = c__[k];
	ic[ck] = k;
	ic[i__] = maxc;
	x[k] = zero;

/*  UPDATE RIGHT HAND SIDE. */

	y[k] = yk * dk;

/*  COMPUTE VALUE FOR IU(K+1) AND CHECK FOR STORAGE OVERFLOW */

	iu[k + 1] = iu[k] + nzcnt;
	if (iu[k + 1] > *max__ + 1) {
	    goto L1005;
	}

/*  MOVE COLUMN INDICES FROM LINKED LIST TO JU. */
/*  COLUMNS ARE STORED IN CURRENT ORDER WITH ORIGINAL */
/*  COLUMN NUMBER (C(J)) STORED FOR CURRENT COLUMN J */

	if (vi > *n) {
	    goto L170;
	}
	j = vi;
L160:
	++juptr;
	ju[juptr] = c__[j];
	u[juptr] = x[j] * dk;
	x[j] = zero;
	j = p[j];
	if (j <= *n) {
	    goto L160;
	}
L170:
	;
    }

/*  BACKSOLVE U X = Y, AND REORDER X TO CORRESPOND WITH A */

    k = *n;
    i__1 = *n;
    for (i__ = 1; i__ <= i__1; ++i__) {
	yk = y[k];
	jmin = iu[k];
	jmax = iu[k + 1] - 1;
	if (jmin > jmax) {
	    goto L190;
	}
	i__2 = jmax;
	for (j = jmin; j <= i__2; ++j) {
	    juj = ju[j];
	    juj = ic[juj];
	    yk -= u[j] * y[juj];
/* L180: */
	}
L190:
	y[k] = yk;
	ck = c__[k];
	x[ck] = yk;
	--k;
/* L200: */
    }

/*  RETURN WITH IERR = NUMBER OF OFF-DIAGONAL NONZEROES IN U */

    *ierr = iu[*n + 1] - iu[1];
    return 0;

/*  ERROR RETURNS */

/*  N = 0 */

L1001:
    *ierr = 0;
    return 0;

/*  ROW K OF A IS NULL */

L1002:
    *ierr = -k;
    return 0;

/*  ROW K OF A HAS A DUPLICATE ENTRY */

L1003:
    *ierr = -(*n + k);
    return 0;

/*  ZERO PIVOT IN ROW K */

L1004:
    *ierr = -((*n << 1) + k);
    return 0;

/*  STORAGE FOR U EXCEEDED ON ROW K */

L1005:
    *ierr = -(*n * 3 + k);
    return 0;
} /* nspiv1_ */

extern "C" int preord_(integer *n, integer *ia, integer *r__, integer *
	c__, integer *ic)
{
    /* System generated locals */
    integer i__1;

    /* Local variables */
    static integer i__, j, k, kdeg;


/*  PREORD ORDERS THE ROWS OF A BY INCREASING NUMBER OF NONZEROES. */
/*  THE ROW PERMUTATION IS RETURNED IN R.  C IS SET TO THE IDENTITY. */


    /* Parameter adjustments */
    --ic;
    --c__;
    --r__;
    --ia;

    /* Function Body */
    i__1 = *n;
    for (i__ = 1; i__ <= i__1; ++i__) {
	r__[i__] = i__;
	c__[i__] = i__;
	ic[i__] = i__;
/* L1: */
    }
    i__1 = *n;
    for (i__ = 1; i__ <= i__1; ++i__) {
/* L5: */
	c__[i__] = 0;
    }
    i__1 = *n;
    for (k = 1; k <= i__1; ++k) {
	kdeg = ia[k + 1] - ia[k];
	if (kdeg == 0) {
	    ++kdeg;
	}
	ic[k] = c__[kdeg];
	c__[kdeg] = k;
/* L10: */
    }
    i__ = 0;
    i__1 = *n;
    for (j = 1; j <= i__1; ++j) {
	if (c__[j] == 0) {
	    goto L30;
	}
	k = c__[j];
L20:
	++i__;
	r__[i__] = k;
	k = ic[k];
	if (k > 0) {
	    goto L20;
	}
L30:
	;
    }
    i__1 = *n;
    for (i__ = 1; i__ <= i__1; ++i__) {
	c__[i__] = i__;
	ic[i__] = i__;
/* L40: */
    }
    return 0;
} /* preord_ */

extern "C" DLLEXPORT void spivsolve(size_t N,double* M,double* b,int symm)
{
	integer n=(integer)N;
#ifdef __SYSNT__
	_ASSERT(0);
#endif
	std::vector<integer> IA,JA;
	std::vector<double> A;
	size_t i,j,t=1;
	double a;
	IA.push_back(t);
	for(i=0;i<N;++i)
	{
		for(j=0;j<N;++j)
		{
			if(symm)
			{
				if(i<j)
				{
					if((a=M[j*(j+1)/2+i]))
					{
						JA.push_back(j+1);
						A.push_back(a);
						t++;
					}
				}
				else
				{
					if((a=M[i*(i+1)/2+j]))
					{
						JA.push_back(j+1);
						A.push_back(a);
						t++;
					}
				}
			}
			else
			{
				if((a=M[i*n+j]))
				{
					JA.push_back(j+1);
					A.push_back(a);
					t++;
				}
			}
		}
		IA.push_back(t);
	}
	std::valarray<integer> R(n),C(n),IC(n);
	preord_(&n,&(IA.front()),&R[0],&C[0],&IC[0]);
	integer max=n*(n-1)/2,ierr;
	std::valarray<double>X(n),RTEMP(n+max);
	std::valarray<integer>ITEMP(2*(n+1)+max);
	nspiv_(&n,&(IA.front()),&(JA.front()),&(A.front()),b,&max,&R[0],&C[0],
		&IC[0],&X[0],&ITEMP[0],&RTEMP[0],&ierr);
	memmove(b,&X[0],n*sizeof(double));
}
#endif