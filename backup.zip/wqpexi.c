#include "ldefns.h"
void wqpexi(char *msg)
{
    lm_wmsg("\nQP EXIT-%s",msg);
}
