/*
	set a vector to zero
*/
#include "ldefns.h"


void dzerovec(dimen n, vector x)
{
	memset(x,0,n*sizeof(*x));
//	dzero(n,x,1);
}
void szerovec(dimen n, float* x)//single precision
{
	memset(x,0,n*sizeof(*x));
//	dzero(n,x,1);
}
