#!/bin/env python
#Colin 13-1-2005
#Semi-definite optimisation interior point algorithm
from safe import OptSemiGen,vec2symm,DOT
pen1=lambda x,y:x*(x+1)/2+y
def doublecov(n,a):
    n2=n+n
    la=len(a)
    aa=[0]*(n2*(n2+1)/2)
    ij=0
    for i in range(n2):
        for j in range(i+1):
            if i < n:
                aa[ij]=a[ij]
            else:
                ii=i-n
                if j >= n:
                    jj=j-n
                    aa[ij]=a[ii*(ii+1)/2+jj]
            ij+=1
    return aa
n=4
cov=[0.082413214985258054, 0.0085237134681903914, 0.089070270882033536, 0.0052971882656530911, -0.010020600571815669, 0.079791663443914862, 0.016249612103159561, -0.012009661280024869, -0.0056633461502720861, 0.092481531373906162]
cov=doublecov(n,cov)
cov+=[0]*(4*n*(4*n+1)/2-len(cov))
#cov+=[.1,.2,.3,.4,.1,.2,.3,.4]
cov+=[0]*(n+n+n+n+1)
oldn=n+n
n=n+n+n+n+1
nn=n*(n+1)/2
if len(cov) != nn:raise 'cov error'
m=15
A1=[0]*nn
#A1[nn-n:nn-n+oldn]=[1]*oldn
vec2symm(oldn+oldn,[1]*oldn+[0]*oldn,A1)
A2=[0]*nn
#A2[nn-n:nn-n+oldn/2]=[1]*(oldn/2)
#A2[-1]=-2
vec2symm(oldn+oldn,[-1]*(oldn/2)+[0]*(3*oldn/2),A2)
A2[-1]=1
A3=[0]*nn
A3[-1]=1
A4=[0]*nn
A4[pen1(4,0)]=1
A5=[0]*nn
A5[pen1(5,1)]=1
A6=[0]*nn
A6[pen1(6,2)]=1
A7=[0]*nn
A7[pen1(7,3)]=1

A8=[0]*nn
A8[pen1(oldn,oldn)]=1
A8[nn-n]=-1
A9=[0]*nn
A9[pen1(oldn+1,oldn+1)]=1
A9[nn-n+1]=-1
A10=[0]*nn
A10[pen1(oldn+2,oldn+2)]=1
A10[nn-n+2]=-1
A11=[0]*nn
A11[pen1(oldn+3,oldn+3)]=1
A11[nn-n+3]=-1
A12=[0]*nn
A12[pen1(oldn+4,oldn+4)]=1
A12[nn-n+4]=1
A13=[0]*nn
A13[pen1(oldn+5,oldn+5)]=1
A13[nn-n+5]=1
A14=[0]*nn
A14[pen1(oldn+6,oldn+6)]=1
A14[nn-n+6]=1
A15=[0]*nn
A15[pen1(oldn+7,oldn+7)]=1
A15[nn-n+7]=1
b=[0,0,1,0,0,0,0,0,0,0,0,0,0,0,0]
X=[0]*nn
A=A1+A2+A3+A4+A5+A6+A7+A8+A9+A10+A11+A12+A13+A14+A15
print OptSemiGen(n,m,X,cov,A,b,1000)

ij=0
for i in range(n):
    out='%2d '%i
    for j in range(i+1):
        out+='%8.1e '%X[ij]
        ij+=1
    print out
        
N=oldn
start=nn-n
W=X[start:start+oldn]
Xtest=[0]*(len(X))
print 'vec part',X[start:start+n-1]
vec2symm(n-1,X[start:start+n-1],Xtest)
Xtest[-1]=1
ij=0
for i in range(n):
    out='%2d '%i
    for j in range(i+1):
        out+='%8.1e '%Xtest[ij]
        ij+=1
    print out

n=N/2
print W[0:n]
print W[n:]
