/*
	dswapvec	interchange two real vectors

	argument	meaning
	n		dimen length of vectors
	a		real vector
	b		real vector

	R. G. Becker March 1992
*/
#include "ldefns.h"

void dswapvec(register dimen n, vector a, vector b)
{
	while(n--){
		register real temp = *a;
		*a++ = *b;
		*b++ = temp;
		}
}
