#! /bin/env python
from sys import path
path.append('./')   #Need to change this path to make the program work within Curve

from Opt import *

if jython:
    import CostFunc
else:
    class CostFunc:
        def modq(self,n,w,grad):
            """Transaction Cost second derivatives"""
        def modc(self,n,w,grad):
            """Transaction Cost first derivatives"""
        def util(self,n,w):
            """Transaction Cost function"""
        def f1d(self,x):
            """We want to find x so that this is zero"""

class SSS(CostFunc):
    def __init__(self,opt,buy,sell,make):
        for i in ['opt','buy','sell','make']:
            setattr(self,i,eval(i))
    def modq(self,n,w,grad):
        """Transaction Cost second derivatives"""
    def modc(self,n,w,grad):
        """Transaction Cost first derivatives"""
        for i in range(n):
            if w[i] < self.opt.initial[i]:grad[i]=-self.sell[i]
            else:grad[i]=self.buy[i]
    def util(self,n,w):
        """Transaction Cost function"""
        s=0
        for i in range(n):
            if w[i] < self.opt.initial[i]:s-=(w[i]-self.opt.initial[i])*self.sell[i]
            else:s+=(w[i]-self.opt.initial[i])*self.buy[i]
        return s
    def f1d(self,x):
        """This is zero when util(self,n,x) equals self.make"""
        opt.kappa=x
        opt.opt()
        cost=self.util(n,opt.w)
        print 'kappa %e cost %e'%(x,cost)
        return cost-self.make
print version()

#_____________________________________________________________________
n=10
buy=map(lambda t:2e-3,range(n))
sell=map(lambda t:2e-3,range(n))
opt=Opt()
opt.n=n
opt.m=1
opt.A=[1]*n
opt.alpha=map(lambda t:float(t-n/2)/n,range(n))
opt.bench=map(lambda t:1.0/n,range(n))
opt.initial=initial=map(lambda t:(opt.bench[t]),range(n))
opt.L=[0]*n+[1]
opt.U=[1]*n+[1]
opt.nfac=nfac=2
opt.FC=[1e-3,1e-5,2e-3]
opt.FL=[1]*n+[1,-1]*(n/2)
opt.SV=map(lambda t:(t+1)*1e-4,range(n))
opt.revise=1
opt.gamma=.1
kappa=.5
opt.kappa=.5
opt.log=0
#_____________________________________________________________________

makecost=3e-3
optcostI=SSS(opt,buy,sell,makecost)

if jython:
    opt.costfunc=optcostI
    opt.costgrad=optcostI
    opt.costhess=None
    print 'Optimal kappa is %-.8e'%Solve1D(optcostI,.2,.9,1e-8)   #find the value of kappa that gives a cost of 3e-3
else:
    opt.costfunc=optcostI.util
    opt.costgrad=optcostI.modc
    opt.costhess=None
    print 'Optimal kappa is %-.8e'%Solve1D(optcostI.f1d,.2,.9,1e-8)

print 'The cost is\t\t%-.8e'%optcostI.util(n,opt.w)
print 'The optimal weights\t',opt.w
opt.risks()
print 'Risk is\t\t\t%-.8e'%opt.risk
opt.props()
print 'Check; risk using MCAR\t%-.8e'%(dot(opt.w,opt.MCAR)-dot(opt.bench,opt.MCAR))


