/*
	assertion failure
*/
#include "ldefns.h"
void lm_assert_fail(const char *expr, const char *f, int l)
{
	lm_werr("ASSERT(%s)\n NOT TRUE\n\tFILE %s:%d" , expr, f, l );
	Crash("Assertion Failure");
}
