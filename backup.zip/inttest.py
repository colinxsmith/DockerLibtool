#!/bin/env python
import safe
def Symmult(n,n1,n2,n3,S,x,Sx):
#    print 'x ',x
    """Multiply a symmetric matrix S by a vector x to get Sx.
    S is a list of length n*(n+1)/2 containing the lower triangle of a symmetric
    matrix stored in the order [00,10,11,20,21,22,.......]
    x and Sx are lists of length n
    """
    if len(x)<n:raise 'x is not long enough'
    if len(Sx)<n:raise 'Sx is not long enough'
    if len(S)<n*(n+1)/2:raise 'S is not long enough'
    ij=0
    for i in range(n):
        Sx[i]=0
        for j in range(i+1):
            Sx[i]+=S[ij]*x[j]
            if i!=j:Sx[j]+=S[ij]*x[i]
            ij+=1
#    print 'Sx ',Sx

strength=3e0
def costhess(n,x,h):
    ij=0
    for i in range(n):
        for j in range(i+1):
            if i==j:
                h[ij]=6*x[i]*strength
            else:
                h[ij]=0
            ij+=1
#    print 'x ',x
#    print 'h ',h
#    hx=[0]*n
#    Symmult(n,1,1,1,h,x,hx)
#    print 'hx ',hx
def costgrad(n,x,g):
    for i in range(n):
        g[i]=3*x[i]*x[i]*strength
#    print 'x ',x
#    print 'g ',g
def cost(n,x):
    s=0
    for i in range(n):
        s+=x[i]*x[i]*x[i]*strength
    return s

o=safe.Optimise()
o.n=4
o.H=[1,0.1,2,0,0.6,3,0,0,0,4]
o.hmul=Symmult
o.SetLog()
o.Util=cost
o.ModDeriv=costgrad
o.ModHessian=costhess
o.round_result=0
o.CONJ=1
NN=4
MM=2
AA=[1,-1]*NN
LL=[-1]*NN+[.8,-1]
UU=[1]*NN+[.95,-.9]

CC=[(i+1) for i in range(NN)]
XX=[0]*NN
if o.OptInterior(NN,MM,XX,AA,LL,UU,CC):
    print 'Interior Point method failed'
#o.PrintLog()
print XX,sum(XX)
