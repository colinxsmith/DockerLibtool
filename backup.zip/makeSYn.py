#!/bin/env python
"""
Create and store the product of the scaling matrix and global/local factor exposures
YS
"""
from sys import path
path.append('e:/users/colin/safeqp')
from Optn import *

front = 'e:/users/colin/BIM/apr25/bimtest'
Yfile=front+'/'+'BIMe_203_GLFac_Exposures.20041101'
Gfile=front+'/'+'BIMe_203_GLCovar.20041101'
Sfile=front+'/'+'BIMe_203_GLScaling.20041101'
YSfile=front+'/'+'YSn.20041101'      #Output file
FGfile=front+'/'+'FGn.20041101'      #Output file

gfnames={}      #Names of factors in Global Covariance Matrix
getnames(open(Gfile),gfnames)

allfnames={}    #Names of all factors in the 3 extra files for local/global breakdown
getnames(open(Gfile),allfnames)
getnames(open(Yfile),allfnames)
getnames(open(Sfile),allfnames)

localnames=[i for i in allfnames.keys() if i.find('GL_')==-1]
globalnames=[i for i in allfnames.keys() if i in gfnames]

nl=len(localnames)  #Number of local factors
ng=len(globalnames) #Number of global factors
print 'Number of local factors ',nl
print 'Number of global factors ',ng

localorder={}
globalorder={}

setorder(localorder,localnames)
setorder(globalorder,globalnames)

G=getsym(ng,open(Gfile),globalorder)
S=getnonsym(nl,nl,open(Sfile),localorder,localorder)
Y=getnonsym(nl,ng,open(Yfile),localorder,globalorder)

if jython:
    YS=Allocate2D(nl,ng)
else:
    YS=[0]*(nl*ng)
    
genmult(nl,ng,Y,S,YS)

ysout=open(YSfile,'w')
for i in range(nl):
    for j in range(ng):
        if jython:
            if YS[i][j]!=0:ysout.write('%s|%s|%-20.8e\n'%(localnames[i],globalnames[j],YS[i][j]))
        else:
            if YS[i+j*nl]!=0:ysout.write('%s|%s|%-20.8e\n'%(localnames[i],globalnames[j],YS[i+j*nl]))

FCg=[0]*(nl*(nl+1)/2)
if jython:FCg=jython_set(FCg)
getFSF(nl,ng,G,YS,FCg)

fgout=open(FGfile,'w')

ij=0
for i in range(nl):
    for j in range(i+1):
        fgout.write('%s|%s|%-20.8e\n'%(localnames[i],localnames[j],FCg[ij]));ij+=1
