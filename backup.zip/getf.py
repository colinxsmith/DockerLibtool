from re import sub
def printl(list=None,top=5):
    if list == None:
        return
    out=''
    j=0
    for i in list:
        out += str(i)+' '
        if j == top:
            j=-1
            print (out)
            out=''
        j+=1
    if j < top:
        print (out)

def checkmissing(i):
    if i.strip() == '':
        return('0')
    else:
        return(i)
class datin:
    def getmodel(self,name='e:/users/colin/bitapl/model.txt'):
        file = open(name)
        nfac = 0
        self.FC = []
        self.FACNAMES = []
        procFac=0
        for line in file.readlines():
            line=line.strip()
            data = line.split()
            for i in range(len(data)):
                data[i]=data[i].strip()
            line=line.lower()
            if line.find('factor') != -1:
                del data[0]
                factors = data
                procFac = 1
            elif line.find('universe') != -1:
                procFac=0
                self.FACNAMES=data
                for i in self.FACNAMES:
                    exec( 'self.%s = []' % i)
            elif procFac:
                del data[0]
                self.FC+=data
            else:
                exec ('self.%s.append(\'%s\')' % (self.FACNAMES[0],data[0]))
                for i in range(1,len(data)):
                    exec('self.%s.append(%s)' % (self.FACNAMES[i],data[i]))
        for i in range(len(self.FC)):
            self.FC[i]=float(self.FC[i])

    def getBITA5(self,name='e:/users/colin/optplay/optimisationTrace.csv'):
        """Need to do Composite assets properly, this can't be done until I see them in
        a CURVE log output file"""
        file = open(name)
        procScal=0
        procVec=0
        procCon=0
        procCov=0
        nn=0
        for line in file.readlines():
            line=sub('[\s\[\]]','',line) # change Compx [name] to Compxname
            line=sub(',*$','',line) #get rid of ,,,,,,,,,, at the end of a line
            data=line.split(',')
            data=[checkmissing(i) for i in data]
            line=line.lower()
            if len(data)<1:continue
            for i in range(len(data)):
                data[i]=data[i].strip()
                if line.find('false') != -1:data[i]=data[i].replace('false','"false"')
                elif line.find('true') != -1:data[i]=data[i].replace('true','"true"')
            if line.find('num')!=-1:
                procScal=1
                procVec=0
                procCon=0
                procCov=0
                self.SCALARS=data
                for i in data:setattr(self,i,0)
            elif line.find('assetnames')!=-1:
                procVec=1
                procScal=0
                procCon=0
                procCov=0
                self.VECTORS=data
                for i in data:setattr(self,i,[0]*(self.numAssets))
            elif line.find('lower')!=-1:
                procVec=0
                procScal=0
                procCon=1
                procCov=0
                    
                CBOUNDS=data
                for i in data:
                    if len(i):setattr(self,i,{})
            elif data[0].lower().find('factor')!=-1:
                procVec=0
                procScal=0
                procCon=0
                procCov=1
                    
                self.FACNAMES=data
                self.FC=[]
            elif data[0].lower().find('asset1')!=-1:
                procVec=0
                procScal=0
                procCon=0
                procCov=2
                    
                self.STOCKNAMES=data
                self.Q=[]
            elif procCov==1:
                if len(data) > 0:self.FC+=data
            elif procCov==2:
                if len(data) > 0:self.Q+=data
            elif procScal:
                for i in range(len(data)):setattr(self,self.SCALARS[i],eval(data[i]))
            elif procCon:
                for i in range(1,len(data)):getattr(self,CBOUNDS[i])[str(data[0])]=eval(data[i])
            elif procVec:
                for i in range(len(data)):
                    try:getattr(self,self.VECTORS[i])[nn]=eval(data[i])
                    except:getattr(self,self.VECTORS[i])[nn]=(str(data[i]))
                nn+=1
        if procCov==1:                            
            self.FC=list(map(lambda t:float(t),self.FC))
        elif procCov==2:                            
            self.Q=list(map(lambda t:float(t),self.Q))
    
if __name__ == '__main__':
    a=datin()
    a.getBITA5()

    printl(a.SCALARS)
    printl(a.VECTORS)
    printl(a.FACNAMES)
    
 
