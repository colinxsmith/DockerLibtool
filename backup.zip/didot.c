/*
	didot( n, x, iix, y, iy )
	computes an inner product between the vectors x and y
		x[(i+1)*iix-1]*y[i*iy] i=0,...,n-1

	ie y is linearly incremented and x is quadratically incremented
	I use it only in connection with compactly stored triangular matrices.
*/
#include "ldefns.h"
real didot(
	dimen n,
	vector x,
	stride iix,
	vector y,
	stride iy	/*increment for y*/
	)
{
	register real	sum = 0;

	if(n){
		if(iix){
				if (iix > 0) {
					while (n--) {
						sum += (*x)*(*y);
						y += iy;
						x += iix++;
					}
				}
				else {
					iix = -iix;
					while (n--) {
						sum += (*x)*(*y);
						y += iy;
						x += iix--;
					}
				}
			}
		else	sum = *x * dsum(n,y,iy);
		}
	return sum;
}

