/*
	dsymplanerotate performs the symmetric plane rotation
	( x  y ) = ( x  y )*( c   s )   s != 0
                    	    ( s  -c )

	If s is supplied as zero then x and y are unaltered
*/
#include "ldefns.h"

void dsymplanerotate(dimen n, vector x, increment incx, vector y, increment incy, real c, real s)
{
integer i__1, i__2;

real temp1;
integer i, ix, iy;
--y;
--x;

	if(n > 0 && s != 0.){
		if (c == 0 && s == 1) {
			if (incx == incy && incx > 0) {
		    		i__1 = (n - 1) * incx + 1;
		    		i__2 = incx;
		    		for (ix = 1; (i__2 < 0 ? ix >= i__1 : ix <= i__1); ix += i__2) {
					temp1 = x[ix];
					x[ix] = y[ix];
					y[ix] = temp1;
		    			}
				}
			else	{
		    		if (incy >= 0){
					iy = 1;
		    			}
				else	{
					iy = 1 - (n - 1) * incy;
		    			}
		    		if (incx > 0){
					i__2 = (n - 1) * incx + 1;
					i__1 = incx;
					for (ix = 1; (i__1 < 0 ? ix >= i__2 : ix <= i__2); ix += i__1){
			    			temp1 = x[ix];
			    			x[ix] = y[iy];
			    			y[iy] = temp1;
			    			iy += incy;
						}
		    			}
				else	{
					ix = 1 - (n - 1) * incx;
					i__1 = n;
					for (i = 1; i <= i__1; ++i){
			    			temp1 = x[ix];
			    			x[ix] = y[iy];
			    			y[iy] = temp1;
			    			ix += incx;
			    			iy += incy;
						}
		    			}
				}
	    		}
		else if (c == 0 && s == -1){
			if (incx == incy && incx > 0) {
		    		i__1 = (n - 1) * incx + 1;
		    		i__2 = incx;
		    		for (ix = 1; (i__2 < 0 ? ix >= i__1 : ix <= i__1); ix += i__2) {
					temp1 = -x[ix];
					x[ix] = -y[ix];
					y[ix] = temp1;
		    			}
				}
			else	{
		    		if (incy >= 0) {
					iy = 1;
		    			}
				else	{
					iy = 1 - (n - 1) * incy;
		    			}
		    		if (incx > 0) {
					i__2 = (n - 1) * incx + 1;
					i__1 = incx;
					for (ix = 1; (i__1 < 0 ? ix >= i__2 : ix <= i__2); ix += i__1) {
			    			temp1 = -x[ix];
			    			x[ix] = -y[iy];
			    			y[iy] = temp1;
			    			iy += incy;
						}
		    			}
				else	{
					ix = 1 - (n - 1) * incx;
					i__1 = n;
					for (i = 1; i <= i__1; ++i) {
			    			temp1 = -x[ix];
			    			x[ix] = -y[iy];
			    			y[iy] = temp1;
			    			ix += incx;
			    			iy += incy;
						}
		    			}
				}
	    		}
		else	{
			if (incx == incy && incx > 0) {
		    		i__1 = (n - 1) * incx + 1;
		    		i__2 = incx;
		    		for (ix = 1; (i__2 < 0 ? ix >= i__1 : ix <= i__1); ix += i__2) {
					temp1 = x[ix];
					x[ix] = c * temp1 + s * y[ix];
					y[ix] = s * temp1 - c * y[ix];
		    			}
				}
			else	{
		    		if (incy >= 0) {
					iy = 1;
		    			}
				else	{
					iy = 1 - (n - 1) * incy;
		    			}
		    		if (incx > 0) {
					i__2 = (n - 1) * incx + 1;
					i__1 = incx;
					for (ix = 1; (i__1 < 0 ? ix >= i__2 : ix <= i__2); ix += i__1) {
			    			temp1 = x[ix];
			    			x[ix] = c * temp1 + s * y[iy];
			    			y[iy] = s * temp1 - c * y[iy];
			    			iy += incy;
						}
		    			}
				else	{
					ix = 1 - (n - 1) * incx;
					i__1 = n;
					for (i = 1; i <= i__1; ++i) {
			    			temp1 = x[ix];
			    			x[ix] = c * temp1 + s * y[iy];
			    			y[iy] = s * temp1 - c * y[iy];
			    			ix += incx;
			    			iy += incy;
						}
		    			}
				}
	    		}
		}
}
