#include "ldefns.h"
#include "constant.h"
void	dsmxainv( dimen n, ldl_matrix F, short_vec P, vector v )
{
	dimen	i;
	vector	f;
	real	lambda[2], V[4], a, b;

	dsmxaupt(n, F, P, SMXFAC_INVERSE, v );
	for(f=F,i=0;i<n;f+=i+1)
	{
		if(P[i]>0)
		{
			/*1x1 block*/
			if(fabs(f[0] * (1.0 - lm_rooteps)) <= lm_rooteps)
			{
				v[i] = 0.0;
			}
			else
				v[i] /= f[0];
			i++;
		}
		else
		{
			/*2x2 block;*/
			a = *f;
			f += i+1;
			b = *f++;
			dsmx22ev( a, b, *f, lambda, V );

			if(fabs(lambda[0] * (1.0 - lm_rooteps)) <= lm_rooteps)
			{
				a = 0.0;
			}
			else
				a = (V[0]*v[i]+V[1]*v[i+1]) / lambda[0];

			if(fabs(lambda[1] * (1.0 - lm_rooteps)) <= lm_rooteps)
			{
				b = 0.0;
			}
			else
				b = (V[2]*v[i]+V[3]*v[i+1]) / lambda[1];

			v[i] = V[0]*a+V[2]*b;
			v[i+1] = V[1]*a+V[3]*b;
			i += 2;
		}
	}
	dsmxaupt(n, F, P, SMXFAC_INVERSE_TRANSPOSE, v );
}
void	dsmxainvsqrt( dimen n, ldl_matrix F, short_vec P,int mode, vector v )
{
	dimen	i;
	vector	f;
	real	lambda[2], V[4], a, b;

	if(mode&SMXFAC_LEFT_ROOT)dsmxaupt(n, F, P, SMXFAC_INVERSE, v );
	for(f=F,i=0;i<n;f+=i+1)
	{
		if(P[i]>0)
		{
			/*1x1 block*/
			if(fabs(f[0] * (1.0 - lm_rooteps)) <= lm_rooteps)
			{
				v[i] = 0.0;
			}
			else
				v[i] /= sqrt(f[0]);
			i++;
		}
		else
		{
			/*2x2 block*/
			a = *f;
			f += i+1;
			b = *f++;
			dsmx22ev( a, b, *f, lambda, V );

			if(fabs(lambda[0] * (1.0 - lm_rooteps)) <= lm_rooteps)
			{
				a = 0.0;
			}
			else
				a = (V[0]*v[i]+V[1]*v[i+1]) / sqrt(lambda[0]);

			if(fabs(lambda[1] * (1.0 - lm_rooteps)) <= lm_rooteps)
			{
				b = 0.0;
			}
			else
				b = (V[2]*v[i]+V[3]*v[i+1]) / sqrt(lambda[1]);

			v[i] = V[0]*a+V[2]*b;
			v[i+1] = V[1]*a+V[3]*b;
			i += 2;
		}
	}
	if(!mode&SMXFAC_LEFT_ROOT)dsmxaupt(n, F, P, SMXFAC_INVERSE_TRANSPOSE, v );
}
