#include "ldefns.h"
static	const char *cur_fmt =(char*)"%15.6lg";
const char *lm_set_gdvwri_fmt( const char *new_fmt )
{
	const char *old_fmt=cur_fmt;
	if( new_fmt ) cur_fmt = new_fmt;
	else cur_fmt =(char*)"%15.6lg";
	return old_fmt;
}

void lm_gdvwri(dimen n, real *x, increment inc)
{
	dimen	i;
	for(i=0;i<n;i++){
		lm_item_write(5,cur_fmt,*x);
		x += inc;
		}
	__lm_item_write_count=0;
	lm_putc('\n');
}
