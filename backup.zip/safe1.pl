#!/usr/bin/perl -w
#Colin 25-7-2003

#This shows how to pass a function as an argument to a procedure written in 
#another language, which then can call back to the function. It means that 
#costs can be passed to the optimiser via functions which are written in PERL.

#Finally I show how to solve a non-linear equation in one variable which lets us do
#a cost constraint. This shows just how powerful this interface is. 
#The non-linear function which is called to solve the equation itself 
#does a risk-constrained optimisation!

use SAFEQP;

local $\="\n";
local $,="\t";
$A = new SAFEQP();

$n=10;
$A->{n}=$n;
$A->{m}=1;
$A->{nfac}=2;
@buy=();
@sell=();
@alpha=();
@bench=();
@initial=();
@L=();
@U=();
@SV=();
@FC=(1e-3,1e-5,2e-3);
@FL=(1,1,1,1,1,1,1,1,1,1,1,-1,1,-1,1,-1,1,-1,1,-1);
@AA=(1,1,1,1,1,1,1,1,1,1);
@stocks=();
for(0 .. $n-1)
{
	$buy[$_]=2e-3;
	$sell[$_]=2e-3;
	$alpha[$_]=(1.0*$_-$n/2)/$n;
	$initial[$_]=$bench[$_]=1.0/$n;
	$L[$_]=0;
	$U[$_]=1;
	$SV[$_]=(1.0+$_)*1e-4;
	$stocks="stock".$_;
}
$L[$n]=1;
$U[$n]=1;
$A->{stocks}=\@stocks;
$A->{alpha}=\@alpha;
$A->{benchmark}=\@bench;
$A->{initial}=\@initial;
$A->{L}=\@L;
$A->{U}=\@U;
$A->{SV}=\@SV;
$A->{FL}=\@FL;
$A->{FC}=\@FC;
$A->{A}=\@AA;
sub costfunc
{
	my $n=shift;
	my $w=shift;

    $s=0;
    for(0 .. $#$w)
	{
        if($$w[$_] < $initial[$_])
		{
			$s -= ($$w[$_]-$initial[$_])*$sell[$_];
		}
		else
		{
			$s += ($$w[$_]-$initial[$_])*$buy[$_];
		}
	}
    return $s;
}

sub costgrad
{
	my $n=shift;
	my $w=shift;
	my $grad=shift;

    for(0 .. $#$w)
	{
        if($$w[$_] < $initial[$_])
		{
			$$grad[$_]=-$sell[$_];
		}
        else
		{
			$$grad[$_]=$buy[$_];
		}
	}
}


$A->{revise}=1;
$A->{gamma}=.1;
$A->{piece_cost}=\&costfunc;
$A->{piece_grad}=\&costgrad;


sub opt
{
	$A->{kappa}=shift;
	$A->run;
	$cost=costfunc($A->{n},$A->{w});
	print $A->{kappa},"cost",$cost;
	return $cost - 3e-3;
}

$A->{maxRisk}=.04;
$A->{minRisk}=0;
print opt(.9);
print opt(.2);

$k=safepl::Solve1D(\&opt,.2,.9,1e-8);

print "Optimal kappa",$k,"cost",costfunc($n,$A->{w});

