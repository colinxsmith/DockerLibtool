#include <string.h>
#include "ldefns.h"
void lm_mdvwri(const char *name, dimen n, real *x)
{
	lm_mgdvwri(name,n, x, 1);
}
