#include "ldefns.h"

/*
	purpose
	=======
	drtmxsolve solves systems of reverse triangular equations

	description
	===========
	drtmxsolve solves the equations

		T*x = b ,   or   ( T' )*x = b ,

	where T is an n by n upper or lower reverse triangular matrix
	an upper reverse triangular matrix has the form illustrated by

	T = ( x  x  x  x  x )
	    ( x  x  x  x  0 )
	    ( x  x  x  0  0 )
	    ( x  x  0  0  0 )
	    ( x  0  0  0  0 )

	 and a lower reverse triangular matrix has the form illustrated by

	 T = ( 0  0  0  0  x )
	     ( 0  0  0  x  x )
	     ( 0  0  x  x  x )
	     ( 0  x  x  x  x )
	     ( x  x  x  x  x )

	 the type of triangular system solved is controlled by the
	 parameter job as described in the parameter section below

	 parameters
	 ==========
	 job   - integer
	 	on entry, job must contain one of the values -2, -1, 0, 1, 2
	 	to specify the type of reverse triangular system to be solved
	 	as follows
	 	job =  0 	T is assumed to be reverse diagonal and the
	 			equations T*x = b are solved
	 	job =  1	T is assumed to be upper reverse triangular and the
	 			equations T*x = b are solved
	 	job = -1	T is assumed to be upper reverse triangular and the
	 			equations ( T' )*x = b are solved
	 	job =  2	T is assumed to be lower reverse triangular and the
	 			equations T*x = b are solved
	 	job = -2	T is assumed to be lower reverse triangular and the
	 			equations ( T' )*x = b are solved
	 n     - integer
	 	on entry, n specifies the order of the matrix T. n must be at
	 	least unity
	 T     - real array of dimension ( nrt, nct ). nct must be at least n
	 	before entry T must contain the triangular elements. only
	 	those elements contained in the reverse triangular part of T
	 	are referenced by this routine
	 	unchanged on exit

	 nrt   - integer
	 	on entry, nrt specifies the first dimension of T as declared
	 	in the calling program. nrt must be at least n
	 b     - real array of dimension ( n )
	 	before entry, b must contain the right hand side of the
	 	equations to be solved
	 	on successful exit, b contains the solution vector x
	 idiag - integer
	 	before entry, idiag must be assigned a value. for users
	 	unfamiliar with this parameter the recommended value is zero
	 	on successful exit idiag will be zero. a positive value
	 	of idiag denotes an error as follows
	 	idiag = 1     one of the input parameters n, or nra, or job
	 			has been incorrectly specified
	 	idiag > 1	the element T( j, n - j + 1 ), where
	 			j = idiag - 1, is either zero or is too small
	 			to avoid overflow in computing an element of x.
	 			note that this element is a reverse diagonal element of T

	 further comments
	 ================
	 if T is part of a matrix a partitioned as

	 	A =	( A1  A2 )
	     		( A3  T  )

	 where A1 is an m by k matrix ( m>=0, k>=0), then this routine
	 may be called with the parameter T as a( m + 1, k + 1 ) and nrt as
	 the first dimension of A as declared in the calling (sub) program.
*/
void drtmxsolve(int job, dimen n, real *t, dimen nrt, real *b, integer *idiag)
{
    integer t_dim1, t_offset, i__1;

    int fail;
    real temp;
    integer j, k;
    integer jlast;

    --b;
    t_dim1 = nrt;
    t_offset = t_dim1 + 1;
    t -= t_offset;

    if (n >= 1 && nrt >= n && abs(job) <= 2) {
	goto L20;
    }
    *idiag = (int) lm_check_fail((short)(*idiag), CS(1), "drtmxsolve");
    return;
L20:
    if (job != 0) {
	goto L60;
    }
    k = n;
    i__1 = n;
    for (j = 1; j <= i__1; ++j) {
	b[j] = dprotdiv(&b[j], &t[j + k * t_dim1], &fail);
	if (fail) {
	    goto L280;
	}
	--k;
/* L40: */
    }
    goto L140;
L60:
    if (job != 1) {
	goto L100;
    }
    j = n;
    i__1 = n;
    for (k = 1; k <= i__1; ++k) {
	b[j] = dprotdiv(&b[j], &t[j + k * t_dim1], &fail);
	if (fail) {
	    goto L280;
	}
	if (j > 1) {
	    BITA_daxpy(j-1, -b[j], &t[k * t_dim1 + 1], 1, &b[1], 1);
	}
	--j;
/* L80: */
    }
    goto L140;
L100:
    if (job != 2) {
	goto L140;
    }
    k = n;
    i__1 = n;
    for (j = 1; j <= i__1; ++j) {
	b[j] = dprotdiv(&b[j], &t[j + k * t_dim1], &fail);
	if (fail) {
	    goto L280;
	}
	if (j <  (integer)n) {
	    BITA_daxpy(n-j, -b[j], &t[j + 1 + k * t_dim1], 1, &b[j + 1], 1);
	}
	--k;
/* L120: */
    }
L140:
    if (n == 1) {
	goto L180;
    }
    jlast = n / 2;
    k = n;
    i__1 = jlast;
    for (j = 1; j <= i__1; ++j) {
	temp = b[j];
	b[j] = b[k];
	b[k] = temp;
	--k;
/* L160: */
    }
L180:
    if (job != -1) {
	goto L220;
    }
    k = n;
    i__1 = n;
    for (j = 1; j <= i__1; ++j) {
	if (j > 1) b[j] -= ddotvec((dimen)(j-1), &t[k * t_dim1 + 1], &b[1]);
	b[j] = dprotdiv(&b[j], &t[j + k * t_dim1], &fail);
	if (fail) goto L280;
	--k;
/* L200: */
    }
    goto L260;
L220:
    if (job != -2) goto L260;
    j = n;
    i__1 = n;
    for (k = 1; k <= i__1; ++k) {
	if (j <  (integer)n) b[j] -= ddotvec((dimen)(n-j), &t[j + 1 + k * t_dim1], &b[j + 1]);
	b[j] = dprotdiv(&b[j], &t[j + k * t_dim1], &fail);
	if (fail) {
	    goto L280;
	}
	--j;
/* L240: */
    }
L260:
    *idiag = 0;
    return;
L280:
    *idiag = (int) lm_check_fail((short)(*idiag), (short)(j+1), "drtmxsolve");
}
