#include <string.h>
#include "ldefns.h"
int	__lm_namewnl = 1;
void lm_name_write(const char *name, ushort maxnum, ushort item_length)
{
	char	*last;
	ushort	len;

	if(name!=NULL && *name){
		lm_printf(name);
		if(__lm_namewnl) lm_putc('\n');
		else	{ /*check if we can write some on this line*/
			if((last=strrchr(name,'\n'))!=NULL) name = last+1;
			len=strlen(name);

			/*start positions are at columns 1 + k*item_length*/
			if(len>(1+maxnum*item_length)){
				lm_putc('\n');
				len = 0;
				}
			else if(len) while((++len%item_length)) lm_putc(' ');
			__lm_item_write_count = len / item_length;
			}
		}
}
