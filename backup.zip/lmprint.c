#ifdef WIN32
#include <stdio.h>
#include "ldefns.h"
static	FILE	*lm_stdout = NULL;
static	FILE	*lm_stderr = NULL;

#else
#ifdef __linux__
#include <stdio.h>
#include "ldefns.h"
static	FILE	*lm_stdout = NULL;
static	FILE	*lm_stderr = NULL;
#else
#include <stdio.h>
#include "ldefns.h"
static	FILE	*lm_stdout=0;/*stdout; */
static	FILE	*lm_stderr=0;/*stderr; */
#endif
#endif


void lm_fflushall(void)
{
	if(lm_stdout)
		fflush(lm_stdout);
	if(lm_stderr)
		fflush(lm_stderr);
}

int lm_putc(char c)
{
	if(lm_stdout)
		return fputc(c,lm_stdout);
	else
		return -1;
}

void lm_set_files(byte n, void *f)
{
#if	defined(sun) && defined(__svr4__)
#	if defined(fileno)
#		undef fileno
		extern int fileno( FILE * );
#	endif
#endif
	FILE **p=NULL;
	char *name;
	if(!f)
	{
		switch(n)
		{
		case(0):
			lm_stdout = NULL;
			break;
		case(1):
			lm_stderr = NULL;
			break;
		}
	}
	switch(n)
	{
		case 0:	p = &lm_stdout;
			name =(char*)"stdout";
			break;
		case 1: p = &lm_stderr;
			name =(char*)"stderr";
			break;
		default:Crash("lm_set_files: first argument (%u) is invalid",n);
	}
	lm_fflushall();
	*p = f;
}

int _lm_printf(const char *fmt, ARGADDR v)
{
	if(lm_stdout)
		return vfprintf(lm_stdout,fmt,v);
	else
		return -1;
}

int lm_printf(const char *fmt, ...)
{
	VA_START(fmt);
	if(lm_stdout)
		return vfprintf(lm_stdout,fmt,IVA_LIST(fmt));
	else
		return -1;
}
int lm_wmsg(const char *fmt, ...)
{
	int i;
	VA_START(fmt);
	if(lm_stdout)
		i = vfprintf(lm_stdout,fmt,IVA_LIST(fmt));
	else
		i = -1;
	if(i>=0){
		int j=lm_putc('\n');
		if(j<0) i = j;
		else i++;
		}
	return i;
}

int lm_printr(const char *fmt, ...)
{
	VA_START(fmt);
	if(lm_stderr)
		return vfprintf(lm_stderr,fmt,IVA_LIST(fmt));
	else
		return -1;
}

int _lm_werr(const char *fmt, ARGADDR v)
{
	int i;
	if(lm_stderr)
		i=vfprintf(lm_stderr,fmt,v);
	else
		i = -1;
	if(i>=0){
		int j=fputc('\n',lm_stderr);
		if(j<0) i = j;
		else i++;
		}
	return i;
}
int lm_werr(const char *fmt, ...)
{
	VA_START(fmt);
	return _lm_werr(fmt,IVA_LIST(fmt));
}
