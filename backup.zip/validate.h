#ifndef VALDT_H
#define VALDT_H

#ifdef VERSION	//Do this because perl Makemaker defines VERSION
#undef VERSION
#endif
typedef union
{
	unsigned char	b[16];
	struct	
	{
		unsigned int	pad;
		unsigned int	start;
		unsigned int	stop;
		unsigned int	hid;
	}t;
}validator_t;
typedef union
{
	unsigned char	b[12];
	struct	
	{
		unsigned int	t1;
		unsigned int	t2;
		unsigned int	hid;
	}t;
}pas_valid;

typedef union
{
	unsigned char n[4];
	unsigned int key;
}compkeyn;


class Validate
{
public:
#ifdef PAS
	int Password(const char* filename,unsigned char* passkey,bool make=false);
	const char* PASsecret;
	const char* filename;
#endif
	Validate();
	~Validate();
	int checklicence(int info=0);
	char* STOP;
	int number_of_days_left;
	char EXPIREDATE[30];
	char NOW[30];
	char VERSION[30];
	char CURVECOMPS[30];
	const char*	progname;
private:
	std::string licfile;
	void tobinary(char* curve,long curveextra);
	const char* vv;
	const char*	version_string_raw;
	size_t rawlen;
	char*	version_string;
	char*	validator_m;
	void make_valid(validator_t *vp,size_t start,size_t stop,size_t hid);
	int	check_valid( validator_t *vp);
	void	krypton(unsigned char *b);
	int bitaopt;
	void convert(unsigned char* s,unsigned int *h,unsigned int *t0,unsigned int *t1);
	void	modify_licence(validator_t& v,compkeyn& ckey,const char*licfile=(char*)"c:/extrahosts");
};
#define No_of_Curve_Components 9
#endif
